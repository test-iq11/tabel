import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  test('desktop SQLite creates the school schema and preserves data after reopening', () async {
    sqfliteFfiInit();
    final directory = await Directory.systemTemp.createTemp('jadwali-desktop-db-');
    final service = DatabaseService.withStorage(
      factory: databaseFactoryFfi, directory: directory.path,
    );
    addTearDown(() async {
      await service.close();
      await directory.delete(recursive: true);
    });
    var db = await service.database;
    expect((await db.rawQuery('PRAGMA foreign_keys')).single.values.single, 1);
    expect((await db.query('school_settings')).single['school_name'], 'مدرستي');
    expect(await db.query('grades'), hasLength(6));
    await db.update('school_settings', {'school_name': 'مدرسة الكمبيوتر'});
    final teacherId = await db.insert('teachers', {'name': 'معلم الحاسوب'});
    await expectLater(
      db.insert('teacher_subjects', {'teacher_id': teacherId, 'subject_id': 999999}),
      throwsA(isA<DatabaseException>()),
    );
    await service.close();
    db = await service.database;
    expect((await db.query('school_settings')).single['school_name'], 'مدرسة الكمبيوتر');
    expect((await db.query('teachers', where: 'id = ?', whereArgs: [teacherId])).single['name'], 'معلم الحاسوب');
    expect((await service.exportAll())['format'], 'iraqi_school_timetable_backup');
  });
}
