import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import '../core/theme.dart';
import '../features/conflicts/conflicts_page.dart';
import '../services/conflict_detection_service.dart';
import '../features/dashboard/dashboard_page.dart';
import '../features/data_management/data_management_page.dart';
import '../features/timetable/timetable_page.dart';
import '../features/tools/tools_page.dart';

class TimetableApp extends StatelessWidget {
  const TimetableApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'جدولي المدرسي',
    debugShowCheckedModeBanner: false,
    locale: const Locale('ar'),
    supportedLocales: const [Locale('ar'), Locale('en')],
    localizationsDelegates: const [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    theme: buildAppTheme(),
    home: const AppShell(),
  );
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  int _refreshToken = 0;
  Map<String, int?>? _focusTarget;
  int _focusToken = 0;

  void _openIssue(ConflictIssue issue) {
    setState(() {
      _focusToken++;
      _focusTarget = <String, int?>{
        'sectionId': issue.sectionId,
        'dayId': issue.dayId,
        'slotId': issue.slotId,
        'subjectId': issue.subjectId,
        'token': _focusToken,
      };
      _index = 2;
    });
  }

  void _goTo(int index) => setState(() => _index = index);
  void _refreshApp() => setState(() => _refreshToken++);

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(key: ValueKey('dashboard-$_refreshToken'), onNavigate: _goTo),
      // احتفظ بحالة تبويبات إدارة البيانات عند تحديث الإحصائيات؛ لا نغيّر مفتاح هذه الصفحة.
      DataManagementPage(key: const ValueKey('data-management'), onChanged: _refreshApp),
      TimetablePage(key: ValueKey('table-$_refreshToken'), onChanged: _refreshApp, focusTarget: _focusTarget),
      ConflictsPage(key: ValueKey('conflicts-$_refreshToken'), onNavigateToIssue: _openIssue),
      ToolsPage(key: ValueKey('tools-$_refreshToken'), onChanged: _refreshApp),
    ];
    return LayoutBuilder(builder: (context, constraints) {
      final wide = constraints.maxWidth >= 1000;
      const destinations = [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'الرئيسية'),
        NavigationDestination(icon: Icon(Icons.tune_outlined), selectedIcon: Icon(Icons.tune), label: 'البيانات'),
        NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'الجدول'),
        NavigationDestination(icon: Icon(Icons.rule_outlined), selectedIcon: Icon(Icons.rule), label: 'التعارضات'),
        NavigationDestination(icon: Icon(Icons.folder_copy_outlined), selectedIcon: Icon(Icons.folder_copy), label: 'التقارير'),
      ];
      final content = IndexedStack(index: _index, children: pages);
      return Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          body: SafeArea(child: wide ? Row(children: [
            NavigationRail(
              selectedIndex: _index,
              onDestinationSelected: _goTo,
              labelType: NavigationRailLabelType.all,
              minWidth: 100,
              destinations: destinations.map((destination) => NavigationRailDestination(
                icon: destination.icon,
                selectedIcon: destination.selectedIcon,
                label: Text(destination.label),
              )).toList(),
            ),
            const VerticalDivider(width: 1),
            Expanded(child: content),
          ]) : content),
          bottomNavigationBar: wide ? null : NavigationBar(
            height: 72,
            elevation: 2,
            selectedIndex: _index,
            onDestinationSelected: _goTo,
            destinations: destinations,
          ),
        ),
      );
    });
  }
}
