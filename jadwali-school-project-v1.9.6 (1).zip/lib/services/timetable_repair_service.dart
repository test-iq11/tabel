/// Repairs an existing full timetable with bounded two-period Kempe exchanges.
/// A component contains lessons connected by a shared teacher or section on
/// the same day. Exchanging its two periods preserves teacher/section clashes;
/// the caller validates every other school rule before a state is explored.
class TimetableRepairService {
  const TimetableRepairService();

  List<Map<String, Object?>>? repair({
    required List<Map<String, Object?>> initialPlacements,
    required List<Map<String, Object?>> blockedSlots,
    required List<Map<String, Object?>> slots,
    required bool Function(List<Map<String, Object?>>) isOtherwiseValid,
    int maxNodes = 500,
  }) {
    if (maxNodes <= 0 || initialPlacements.isEmpty) return null;
    final blocked = <String>{
      for (final row in blockedSlots)
        '${_int(row['subject_id'])}:${_int(row['slot_id'])}',
    };
    final periodIds = slots
        .where((s) => s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1)
        .map((s) => _int(s['id']))
        .toSet()
        .toList();
    final initial = initialPlacements.map((row) => Map<String, Object?>.from(row)).toList();
    if (!isOtherwiseValid(initial)) return null;
    bool isBlocked(Map<String, Object?> row) =>
        blocked.contains('${_int(row['subject_id'])}:${_int(row['slot_id'])}');
    int cost(List<Map<String, Object?>> entries) => entries.where(isBlocked).length;
    String fingerprint(List<Map<String, Object?>> entries) =>
        entries.map((row) => _int(row['slot_id'])).join(',');
    final initialCost = cost(initial);
    if (initialCost == 0) return initial;
    final frontier = <_RepairState>[_RepairState(initial, initialCost, 0)];
    final visited = <String>{fingerprint(initial)};
    final stateLimit = (maxNodes * 64).clamp(256, 32000);
    var explored = 0;
    // Each search node stores only changed maps. Bound the frontier too, so a
    // hard case cannot retain an unbounded number of full school schedules.
    final frontierLimit = maxNodes < 256 ? maxNodes : 256;
    while (frontier.isNotEmpty && explored < maxNodes) {
      frontier.sort((a, b) {
        final quality = a.blocked.compareTo(b.blocked);
        return quality != 0 ? quality : a.depth.compareTo(b.depth);
      });
      final state = frontier.removeAt(0);
      explored++;
      final entries = state.entries;
      for (var selected = 0; selected < entries.length; selected++) {
        final lesson = entries[selected];
        if (!isBlocked(lesson)) continue;
        final day = _int(lesson['day_id']);
        final originalSlot = _int(lesson['slot_id']);
        for (final targetSlot in periodIds) {
          if (targetSlot == originalSlot ||
              blocked.contains('${_int(lesson['subject_id'])}:$targetSlot')) continue;
          final component = <int>{selected};
          final pending = <int>[selected];
          for (var head = 0; head < pending.length; head++) {
            final current = entries[pending[head]];
            for (var i = 0; i < entries.length; i++) {
              if (component.contains(i)) continue;
              final other = entries[i];
              final otherSlot = _int(other['slot_id']);
              if (_int(other['day_id']) != day ||
                  (otherSlot != originalSlot && otherSlot != targetSlot)) continue;
              final teacher = _int(current['teacher_id']);
              final sharesTeacher = teacher > 0 && teacher == _int(other['teacher_id']);
              if (sharesTeacher || _int(current['section_id']) == _int(other['section_id'])) {
                component.add(i);
                pending.add(i);
              }
            }
          }
          final candidate = List<Map<String, Object?>>.from(entries);
          for (final index in component) {
            candidate[index] = <String, Object?>{
              ...entries[index],
              'slot_id': _int(entries[index]['slot_id']) == originalSlot ? targetSlot : originalSlot,
            };
          }
          final key = fingerprint(candidate);
          if (visited.contains(key)) continue;
          // Mobile memory must remain bounded even when one expanded node
          // offers many exchanges and most candidates fail validation.
          if (visited.length >= stateLimit) return null;
          visited.add(key);
          if (!isOtherwiseValid(candidate)) continue;
          final violations = cost(candidate);
          if (violations == 0) {
            return candidate.map((row) => Map<String, Object?>.from(row)).toList();
          }
          frontier.add(_RepairState(candidate, violations, state.depth + 1));
        }
      }
      if (frontier.length > frontierLimit) {
        frontier.sort((a, b) {
          final quality = a.blocked.compareTo(b.blocked);
          return quality != 0 ? quality : a.depth.compareTo(b.depth);
        });
        frontier.removeRange(frontierLimit, frontier.length);
      }
    }
    return null;
  }
}

class _RepairState {
  const _RepairState(this.entries, this.blocked, this.depth);
  final List<Map<String, Object?>> entries;
  final int blocked;
  final int depth;
}

int _int(Object? value, {int fallback = 0}) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
