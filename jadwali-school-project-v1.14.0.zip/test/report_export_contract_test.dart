import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('the report page exposes exactly PDF, Word and Excel output formats', () {
    final ui = File('lib/features/reports/reports_page.dart').readAsStringSync();
    expect(ui, contains("('pdf', 'PDF',"));
    expect(ui, contains("('docx', 'Word',"));
    expect(ui, contains("('xlsx', 'Excel',"));
    expect(ui, contains("'report-export-"));
    expect(ui, isNot(contains("'csv':")));
    expect(ui, contains(r"'report-kind-$type'"));
    expect(ui, contains('buildReferenceTimetablePdf'));
    expect(ui, contains('ReferenceOfficeService'));
    expect(ui, contains('FileSaveService().saveBytes'));
  });

  test('real thirteen screens and school identity are retained', () {
    final shell = File('lib/app/app.dart').readAsStringSync();
    final manifest = File('android/app/src/main/AndroidManifest.xml')
        .readAsStringSync();
    expect(shell, contains('List.filled(13, 0)'));
    for (final screen in const [
      'المعلمون', 'الحصص المطلوبة', 'المواد والقيود',
      'إتاحة المعلمين', 'التعارضات', 'التوزيع والحلول',
      'الغياب والبدلاء', 'النسخ والاعتماد', 'التقارير',
      'النسخ الاحتياطية', 'إعدادات المدرسة',
    ]) {
      expect(shell, contains(screen));
    }
    expect(manifest, contains('android:label="جدولي المدرسي"'));
  });
}
