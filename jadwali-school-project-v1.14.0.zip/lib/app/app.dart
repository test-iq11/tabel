import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import '../core/interface_settings.dart';

import '../core/theme.dart';
import '../core/design_widgets.dart';
import '../core/editor_navigation_guard.dart';
import '../features/conflicts/conflicts_page.dart';
import '../services/conflict_detection_service.dart';
import '../features/dashboard/dashboard_page.dart';
import '../features/data_management/data_management_page.dart';
import '../features/data_management/availability_page.dart';
import '../features/timetable/timetable_page.dart';
import '../features/timetable/teacher_absence_page.dart';
import '../features/reports/reports_page.dart';
import '../features/tools/tools_page.dart';

class TimetableApp extends StatefulWidget {
  const TimetableApp({super.key});
  @override
  State<TimetableApp> createState() => _TimetableAppState();
}

class _TimetableAppState extends State<TimetableApp> {
  @override
  void initState() {
    super.initState();
    InterfaceSettings.instance.load();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: InterfaceSettings.instance,
    builder: (context, _) => MaterialApp(
      title: 'الجدول المدرسي',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: buildAppTheme(dark: InterfaceSettings.instance.dark),
      home: AppShell(),
    ),
  );
}

class AppShell extends StatefulWidget {
  const AppShell({
    this.style = 'calm',
    this.textScale = 1,
    this.onAppearance,
    super.key,
  });
  final String style;
  final double textScale;
  final void Function(String, double)? onAppearance;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0, _focusToken = 0;
  final _editorGuard = EditorNavigationGuard();
  final _visited = <int>{0};
  final _epochs = List.filled(15, 0);
  Map<String, int?>? _focusTarget;
  static const _destinations = <({String label, IconData icon})>[
    (label: 'الرئيسية', icon: Icons.dashboard_outlined),
    (label: 'الجدول', icon: Icons.calendar_month_outlined),
    (label: 'المعلمون', icon: Icons.people_outline),
    (label: 'الحصص المطلوبة', icon: Icons.fact_check_outlined),
    (label: 'المواد والقيود', icon: Icons.menu_book_outlined),
    (label: 'إتاحة المعلمين', icon: Icons.event_available_outlined),
    (label: 'التعارضات', icon: Icons.rule_outlined),
    (label: 'التوزيع والحلول', icon: Icons.auto_awesome_outlined),
    (label: 'الغياب والبدلاء', icon: Icons.person_off_outlined),
    (label: 'النسخ والاعتماد', icon: Icons.history_outlined),
    (label: 'التقارير', icon: Icons.print_outlined),
    (label: 'النسخ الاحتياطية', icon: Icons.backup_outlined),
    (label: 'إعدادات المدرسة', icon: Icons.settings_outlined),
    (label: 'المدرسة', icon: Icons.school_outlined),
    (label: 'المزيد', icon: Icons.grid_view_outlined),
  ];
  Future<void> _goTo(int index) async {
    if (index == _index || index == 9) return;
    InterfaceSettings.instance.stopReading();
    if (_index == 3 &&
        !await (_editorGuard.beforeLeave?.call() ?? Future.value(true)))
      return;
    if (!mounted) return;
    setState(() {
      _epochs[index]++;
      _visited.add(index);
      _index = index;
    });
  }

  void _refreshApp() => setState(() {
    for (var i = 0; i < _epochs.length; i++) {
      if (i != _index) _epochs[i]++;
    }
  });
  void _openIssue(ConflictIssue issue) {
    _focusTarget = {
      'sectionId': issue.sectionId,
      'dayId': issue.dayId,
      'slotId': issue.slotId,
      'subjectId': issue.subjectId,
      'token': ++_focusToken,
    };
    _goTo(1);
  }

  void _openTable({int? sectionId, int? teacherId}) {
    _focusTarget = {
      'sectionId': sectionId,
      'teacherId': teacherId,
      'token': ++_focusToken,
    };
    _goTo(1);
  }

  Widget _page(int index) {
    if (!_visited.contains(index)) return const SizedBox.shrink();
    final key = ValueKey('screen-$index-${_epochs[index]}');
    return switch (index) {
      0 => DashboardPage(
        key: key,
        onNavigate: _goTo,
        onOpenSection: (id) => _openTable(sectionId: id),
      ),
      1 => TimetablePage(
        key: key,
        onChanged: _refreshApp,
        focusTarget: _focusTarget,
      ),
      2 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.teachers,
        onOpenTeacher: (id) => _openTable(teacherId: id),
      ),
      3 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.requirements,
        navigationGuard: _editorGuard,
      ),
      4 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.subjects,
      ),
      5 => AvailabilityPage(
        key: key,
        onChanged: _refreshApp,
        onEditTeachers: () => _goTo(2),
      ),
      6 => ConflictsPage(key: key, onNavigateToIssue: _openIssue),
      7 => TimetablePage(key: key, onChanged: _refreshApp, searchPage: true),
      8 => TeacherAbsencePage(key: key, onChanged: _refreshApp),
      10 => ReportsPage(key: key),
      11 => ToolsPage(
        key: key,
        onChanged: _refreshApp,
        section: ToolsSection.backups,
      ),
      13 => _hub(true),
      14 => _hub(false),
      _ => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.settings,
      ),
    };
  }

  void _help() {
    final text = switch (_index) {
      1 => 'اختر الصف واليوم من الشريط الثابت. اضغط الحصة لعرض أدواتها، واضغط مطولاً لقفلها أو فك قفلها. النقل من مقبض السحب. القفل يحمي حصة محددة؛ منع الفترة يخص المادة في كل الصفوف.',
      3 => 'اختر الصف وعدّل الأعداد. يظهر شريط الحفظ والتراجع عند أول تعديل. لن تفقد المسودة عند محاولة المغادرة دون حفظ.',
      4 => 'حدد الفترات الممنوعة على بطاقة المادة. يبقى موضع الصفحة ثابتاً بعد الحفظ. اضغط تعديل المادة لبقية التفاصيل.',
      0 => 'اسم المدرسة في بطاقتها الرئيسية. خصّص أربع بطاقات من زر تخصيص الرئيسية. يمكنك تغيير اسم المدرسة من إعدادات المدرسة.',
      _ => 'الأدوات مجمعة حسب المهمة. بيانات المدرسة للمعلمين والمواد، وأدوات الجدول للتوزيع والغياب، والتقارير والحفظ للتصدير والنسخ الاحتياطية.',
    };
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('دليل الشاشة', style: Theme.of(ctx).textTheme.titleLarge),
              const SizedBox(height: 14),
              Text(text),
              const SizedBox(height: 18),
              FilledButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  _goTo(
                    _index == 0
                        ? 12
                        : _index == 4
                        ? 4
                        : _index == 3
                        ? 3
                        : 1,
                  );
                },
                child: Text(
                  _index == 0 ? 'فتح إعدادات المدرسة' : 'الذهاب إلى الإجراء',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _hub(bool school) {
    final indices = school
        ? [2, 3, 4, 12]
        : [0, 1, 13, 2, 3, 4, 5, 12, 7, 6, 8, 10, 11];
    final descriptions = <int, String>{
      0: 'ملخص المدرسة والوصول السريع',
      1: 'حصص الصفوف والمعلمين',
      13: 'بيانات المدرسة وتنظيمها',
      2: 'النصاب، الاختصاص والإتاحة',
      3: 'أعداد المواد لكل صف',
      4: 'شروط المواد والفترات',
      12: 'الصفوف وأوقات الدوام',
      7: 'مراجعة ثم بحث ثم نتيجة',
      6: 'مراجعة الشروط الحالية',
      8: 'تنظيم حصص المعلم الغائب',
      10: 'معاينة وطباعة وتصدير',
      9: 'الأرشيف ومقارنة الجداول',
      11: 'حفظ البيانات واستعادتها',
      5: 'أوقات التدريس المتاحة',
    };
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(
          school ? 'تفاصيل صغيرة، مدرسة منظمة' : 'كل أدوات المدرسة',
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 6),
        Text(
          school
              ? 'كل بيانات المدرسة في أربع بطاقات واضحة.'
              : 'جميع الأقسام والأدوات في مكان واحد.',
          style: const TextStyle(color: designMuted, fontSize: 12),
        ),
        const SizedBox(height: 22),
        for (final group
            in (school
                ? [('بيانات المدرسة', indices)]
                : [
                    ('التنقل الرئيسي', [0, 1, 13]),
                    ('بيانات المدرسة', [2, 3, 4, 5, 12]),
                    ('أدوات الجدول', [7, 6, 8]),
                    ('التقارير والحفظ', [10, 11]),
                  ])) ...[
          if (!school)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Text(
                group.$1,
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                ),
              ),
            ),
          ActionGrid(
            children: [
              for (var n = 0; n < group.$2.length; n++)
                ActionTile(
                  key: ValueKey('more-destination-${group.$2[n]}'),
                  title: _destinations[group.$2[n]].label,
                  subtitle: descriptions[group.$2[n]]!,
                  icon: _destinations[group.$2[n]].icon,
                  tone: n % 4,
                  onTap: () => _goTo(group.$2[n]),
                ),
            ],
          ),
        ],
        const SizedBox(height: 18),
        if (school)
          const Text(
            'ابدأ بالمعلمين والحصص، ثم أضف الشروط التي تحتاجها.',
            style: TextStyle(color: designMuted, fontSize: 12),
          ),
      ],
    );
  }

  int get _tab => _index == 0
      ? 0
      : _index == 1
      ? 1
      : [2, 3, 4, 5, 12, 13].contains(_index)
      ? 2
      : 3;
  @override
  Widget build(BuildContext context) => PopScope(
    canPop: _index == 0 && !InterfaceSettings.instance.reading,
    onPopInvokedWithResult: (didPop, result) {
      if (InterfaceSettings.instance.reading) {
        InterfaceSettings.instance.stopReading();
        return;
      }
      if (!didPop)
        _goTo(
          [1, 13, 14].contains(_index)
              ? 0
              : _tab == 2
              ? 13
              : 14,
        );
    },
    child: Directionality(
      textDirection: TextDirection.rtl,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final wide = constraints.maxWidth > 900;
          final ui = InterfaceSettings.instance;
          final content = IndexedStack(
            index: _index,
            children: List.generate(
              15,
              (i) => TickerMode(enabled: _index == i, child: _page(i)),
            ),
          );
          return Scaffold(
            body: SafeArea(
              child: Column(
                children: [
                  if (!ui.reading)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 18,
                        vertical: 14,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surface,
                        border: Border(
                          bottom: BorderSide(
                            color: Theme.of(context).dividerColor,
                          ),
                        ),
                      ),
                      child: Row(
                        children: [
                          if (![0, 1, 13, 14].contains(_index))
                            IconButton(
                              tooltip: 'العودة',
                              onPressed: () => _goTo(_tab == 2 ? 13 : 14),
                              icon: const Icon(Icons.chevron_right),
                            ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              _index == 0 ? '' : _destinations[_index].label,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          IconButton(
                            tooltip: ui.dark ? 'الوضع الفاتح' : 'الوضع الداكن',
                            onPressed: () {
                              ui.dark = !ui.dark;
                              ui.save();
                            },
                            icon: Icon(
                              ui.dark
                                  ? Icons.light_mode_outlined
                                  : Icons.dark_mode_outlined,
                            ),
                          ),
                          IconButton(
                            tooltip: 'دليل الشاشة',
                            onPressed: _help,
                            icon: const Icon(Icons.help_outline),
                          ),
                        ],
                      ),
                    ),
                  Expanded(
                    child: wide && !ui.reading
                        ? Row(
                            children: [
                              SizedBox(
                                width: ui.collapsed ? 76 : 210,
                                child: ListView(
                                  padding: const EdgeInsets.all(10),
                                  children: [
                                    IconButton(
                                      tooltip: ui.collapsed
                                          ? 'توسيع التنقل'
                                          : 'طي التنقل',
                                      onPressed: () {
                                        ui.collapsed = !ui.collapsed;
                                        ui.save();
                                      },
                                      icon: const Icon(Icons.menu),
                                    ),
                                    for (final i in [0, 1, 13, 14])
                                      Padding(
                                        padding: const EdgeInsets.only(
                                          bottom: 4,
                                        ),
                                        child: ListTile(
                                          key: ValueKey('rail-destination-$i'),
                                          selected: i == _index,
                                          selectedTileColor: Theme.of(context)
                                              .colorScheme
                                              .primaryContainer,
                                          leading: Icon(_destinations[i].icon),
                                          title: ui.collapsed
                                              ? null
                                              : Text(_destinations[i].label),
                                          onTap: () => _goTo(i),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              const VerticalDivider(width: 1),
                              Expanded(child: content),
                            ],
                          )
                        : ScreenEntrance(page: _index, child: content),
                  ),
                ],
              ),
            ),
            bottomNavigationBar: wide || ui.reading
                ? null
                : SafeArea(
                    top: false,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surface,
                        border: Border(
                          top: BorderSide(color: Color(0xFFE6EBEE)),
                        ),
                      ),
                      padding: const EdgeInsets.all(8),
                      child: Row(
                        children: [
                          for (var i = 0; i < 4; i++)
                            Expanded(
                              child: Semantics(
                                selected: _tab == i,
                                child: InkWell(
                                  key: ValueKey('main-tab-$i'),
                                  onTap: () => _goTo([0, 1, 13, 14][i]),
                                  borderRadius: BorderRadius.circular(15),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 8,
                                    ),
                                    decoration: BoxDecoration(
                                      color: _tab == i
                                          ? Theme.of(context)
                                                .colorScheme
                                                .primary
                                                .withValues(alpha: .09)
                                          : Colors.transparent,
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(
                                          [
                                            Icons.home_outlined,
                                            Icons.calendar_month_outlined,
                                            Icons.school_outlined,
                                            Icons.grid_view_outlined,
                                          ][i],
                                          size: 19,
                                          color: _tab == i
                                              ? Theme.of(context)
                                                    .colorScheme
                                                    .primary
                                              : const Color(0xFF768390),
                                        ),
                                        const SizedBox(height: 5),
                                        Text(
                                          [
                                            'الرئيسية',
                                            'الجدول',
                                            'المدرسة',
                                            'المزيد',
                                          ][i],
                                          style: const TextStyle(fontSize: 10),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
          );
        },
      ),
    ),
  );
}
