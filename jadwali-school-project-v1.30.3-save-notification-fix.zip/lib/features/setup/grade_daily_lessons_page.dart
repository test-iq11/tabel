import 'package:flutter/material.dart';

import '../../data/database_service.dart';
import '../../services/school_timetable_policy.dart';

/// The normal daily limit is saved in the existing grades/sections columns.
/// The engine already grants sixth grade one extra Sunday period when the
/// seventh time slot is available and weekly demand actually needs it.
/// We intentionally do not create a second, UI-only scheduling rule.
class GradeDailyLessonsPage extends StatefulWidget {
  const GradeDailyLessonsPage({
    required this.onChanged,
    required this.onSchoolTimes,
    this.database,
    this.saveDailyLimit,
    super.key,
  });

  final VoidCallback onChanged;
  final VoidCallback onSchoolTimes;
  /// Optional isolated database used by widget regression tests.
  final DatabaseService? database;
  /// Optional UI-test seam; real application uses DatabaseService.
  final Future<void> Function(int gradeId, int normalLimit)? saveDailyLimit;

  @override
  State<GradeDailyLessonsPage> createState() => _GradeDailyLessonsPageState();
}

class _GradeDailyLessonsPageState extends State<GradeDailyLessonsPage> {
  late Future<List<List<Map<String, Object?>>>> _data;
  bool _saving = false;
  DatabaseService get _db => widget.database ?? DatabaseService.instance;

  @override
  void initState() {
    super.initState();
    _data = _load();
  }

  Future<List<List<Map<String, Object?>>>> _load() async => [
    await _db.gradesDetailed(),
    await _db.rows('school_days', orderBy: 'position'),
    await _db.rows('time_slots', orderBy: 'position'),
  ];

  int _integer(Object? value, {int fallback = 6}) {
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }

  bool _sixth(Map<String, Object?> grade) => SchoolTimetablePolicy.isSixthGrade({
    'grade_name': grade['name'],
    'grade_position': grade['position'],
  });

  int _normal(Map<String, Object?> grade) =>
      _integer(grade['max_daily_lessons']).clamp(1, 6).toInt();

  Future<void> _persistLimit(int gradeId, int normal) async {
    final writer = widget.saveDailyLimit;
    if (writer != null) {
      await writer(gradeId, normal);
    } else {
      await _db.updateGradeDailyLimit(gradeId, normal);
    }
  }

  Future<void> _edit(Map<String, Object?> grade) async {
    var value = _normal(grade);
    final saved = await showDialog<int>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, update) => AlertDialog(
          title: Text('حصص ${grade['name']}'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('عدد الحصص المعتاد لكل يوم دوام'),
            const SizedBox(height: 12),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton(
                tooltip: 'تقليل حصة',
                onPressed: value > 1 ? () => update(() => value--) : null,
                icon: const Icon(Icons.remove_circle_outline),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 22),
                child: Text('$value', style: Theme.of(context).textTheme.headlineMedium),
              ),
              IconButton(
                tooltip: 'زيادة حصة',
                onPressed: value < 6 ? () => update(() => value++) : null,
                icon: const Icon(Icons.add_circle_outline),
              ),
            ]),
            const SizedBox(height: 12),
            Text(
              _sixth(grade)
                  ? 'عند اختيار 6 يبقى يوم الأحد مؤهلاً للحصة السابعة إذا كانت مطلوبة وتوجد فترة سابعة مفعّلة.'
                  : 'يسري التعديل على جميع أيام هذا الصف وجميع شعبه.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 8),
            const Text('قد يلزم إصلاح الجدول بعد تقليل الحد اليومي؛ لن تُنقل الحصص تلقائياً.'),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext),
                child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, value),
                child: const Text('حفظ')),
          ],
        ),
      ),
    );
    if (saved == null || saved == _normal(grade) || !mounted) return;
    setState(() => _saving = true);
    try {
      await _persistLimit(grade['id'] as int, saved);
      // The write is committed now. Notify the owning screen even if this
      // page was closed while SQLite (or a replacement writer) was awaiting.
      // In particular, do not silently drop the change notification behind
      // the UI's `mounted` guard.
      widget.onChanged();
      if (!mounted) return;
      setState(() => _data = _load());
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('تم حفظ الحد اليومي للصف وجميع شعبه. افحص التعارضات بعد التعديل.'),
      ));
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('تعذر حفظ عدد الحصص: $error'),
      ));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _reset() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('استعادة العدد الافتراضي'),
        content: const Text('إعادة الحصص المعتادة إلى 6 لكل الصفوف والشعب. يبقى السادس مؤهلاً للحصة السابعة يوم الأحد عند الحاجة. لن يُعاد توزيع جدولك تلقائياً.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('استعادة')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _saving = true);
    try {
      final db = await _db.database;
      await db.transaction((txn) async {
        await txn.update('grades', {'max_daily_lessons': 6});
        await txn.update('sections', {'max_daily_lessons': 6});
        await txn.insert('audit_log', {
          'action': 'استعادة الحدود اليومية الافتراضية',
          'entity': 'grades', 'entity_id': 0,
          'details': '6 حصص يومياً؛ استثناء السابع يوم الأحد للسادس عند الحاجة',
          'created_at': DateTime.now().toIso8601String(),
        });
      });
      if (!mounted) return;
      setState(() => _data = _load());
      widget.onChanged();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('تمت استعادة الأعداد الافتراضية وحفظها.'),
      ));
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('تعذرت استعادة الإعدادات: $error'),
      ));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<List<Map<String, Object?>>>>(
    future: _data,
    builder: (context, snapshot) {
      if (snapshot.hasError) return Center(child: Text('تعذر قراءة الصفوف: ${snapshot.error}'));
      if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
      final grades = snapshot.data![0];
      final days = snapshot.data![1]
          .where((day) => _integer(day['is_active'], fallback: 1) == 1).toList();
      final lessonCount = snapshot.data![2]
          .where((slot) => slot['kind'] == 'lesson' &&
              _integer(slot['is_available'], fallback: 1) == 1).length;
      final scheme = Theme.of(context).colorScheme;
      const tones = <Color>[
        Color(0xff5f66d6), Color(0xff12968b), Color(0xffd38655),
        Color(0xff9272c9), Color(0xff367fba), Color(0xffb56c92),
      ];
      return ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Icon(Icons.view_week_rounded, color: scheme.primary),
          const SizedBox(width: 10),
          Expanded(child: Text('الحصص المخصصة لكل صف',
            style: Theme.of(context).textTheme.titleLarge)),
        ]),
        const SizedBox(height: 8),
        Text('الافتراضي: 6 حصص في أيام الدوام للصفوف جميعها، والسادس يوم الأحد حتى 7 حصص عند الحاجة.',
          style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 12),
        if (lessonCount < 7) Card(
          color: scheme.tertiaryContainer.withValues(alpha: .40),
          child: Padding(padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('يوجد $lessonCount فترة دراسية مفعّلة فقط. العدد المطلوب لا يتحول إلى حصص فعلية قبل تعريف 6 أو 7 فترات.',
                style: TextStyle(color: scheme.onSurface)),
              TextButton.icon(onPressed: widget.onSchoolTimes,
                icon: const Icon(Icons.schedule),
                label: const Text('فتح إعدادات المدرسة والأوقات')),
            ]))),
        for (var i = 0; i < grades.length; i++)
          Padding(padding: const EdgeInsets.only(bottom: 12), child: Card(
            child: InkWell(
              key: ValueKey('tap-grade-daily-${grades[i]['id']}'),
              borderRadius: BorderRadius.circular(18),
              onTap: _saving ? null : () => _edit(grades[i]),
              child: Padding(padding: const EdgeInsets.all(15), child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: tones[i % tones.length].withValues(alpha: .12),
                      borderRadius: BorderRadius.circular(12)),
                    child: Icon(Icons.school_outlined, color: tones[i % tones.length])),
                  const SizedBox(width: 10),
                  Expanded(child: Text('${grades[i]['name']}',
                    style: Theme.of(context).textTheme.titleMedium)),
                  IconButton(
                    key: ValueKey('edit-grade-daily-${grades[i]['id']}'),
                    tooltip: 'تعديل عدد الحصص',
                    icon: Icon(Icons.edit_outlined, color: tones[i % tones.length]),
                    onPressed: _saving ? null : () => _edit(grades[i]),
                  ),
                ]),
                const SizedBox(height: 10),
                Wrap(spacing: 7, runSpacing: 7, children: [
                  for (final day in days)
                    Builder(builder: (context) {
                      final sundayExtra = _sixth(grades[i]) &&
                          SchoolTimetablePolicy.isSunday(day) &&
                          _normal(grades[i]) == 6;
                      final limit = _normal(grades[i]) + (sundayExtra ? 1 : 0);
                      return Chip(
                        avatar: Icon(sundayExtra ? Icons.star_rounded : Icons.event_available,
                          color: sundayExtra ? tones[i % tones.length] : scheme.primary,
                          size: 17),
                        label: Text('${day['name']} · $limit'),
                        backgroundColor: sundayExtra
                            ? tones[i % tones.length].withValues(alpha: .13)
                            : scheme.surfaceContainerHighest.withValues(alpha: .48),
                      );
                    }),
                ]),
                const SizedBox(height: 8),
                Text('الإجمالي الأقصى: ${days.length * _normal(grades[i]) +
                    (_sixth(grades[i]) && _normal(grades[i]) == 6 &&
                     days.any(SchoolTimetablePolicy.isSunday) ? 1 : 0)} حصة أسبوعياً لكل شعبة عند توفر الفترات والقيود المناسبة.',
                  style: Theme.of(context).textTheme.bodySmall),
              ]))),
          )),
        const SizedBox(height: 3),
        OutlinedButton.icon(
          key: const ValueKey('restore-default-grade-periods'),
          onPressed: _saving ? null : _reset,
          icon: const Icon(Icons.restore_outlined),
          label: const Text('استعادة العدد الافتراضي لجميع الصفوف'),
        ),
        const SizedBox(height: 10),
        Text('هذه حدود يومية قصوى وليست حصصاً مضافة تلقائياً إلى المواد؛ حدد حصص المواد أسبوعياً من بطاقة «الحصص المطلوبة». الحصة السابعة للسادس تُستخدم فقط إذا تطلبها النصاب الأسبوعي وكانت الفترة السابعة مفعّلة.',
          style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 70),
      ]);
    },
  );
}
