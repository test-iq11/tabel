import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:iraqi_school_timetable/features/setup/grade_daily_lessons_page.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  // Sqflite FFI, directory creation, and real file I/O must not be awaited
  // directly inside testWidgets' fake-async zone: that can hang until the
  // ten-minute test timeout even when the app itself has no issue.
  late Directory folder;
  late DatabaseService db;
  late List<Map<String, Object?>> grades;
  setUpAll(() async {
    sqfliteFfiInit();
    folder = await Directory.systemTemp.createTemp('jadwali-grade-card-');
    db = DatabaseService.withStorage(
      factory: databaseFactoryFfi,
      directory: folder.path,
    );
    grades = await db.gradesDetailed();
  });
  tearDownAll(() async {
    await db.close();
    await folder.delete(recursive: true);
  });

  testWidgets('tapping a grade card sends the edited limit through Save',
      (tester) async {
    final firstId = grades.first['id'] as int;
    var changes = 0;
    int? writtenGrade;
    int? writtenLimit;
    await tester.pumpWidget(MaterialApp(
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          body: GradeDailyLessonsPage(
            database: db,
            // UI interaction is tested with a deterministic writer. The real
            // SQLite transaction is verified in the separate test below.
            saveDailyLimit: (gradeId, limit) async {
              writtenGrade = gradeId;
              writtenLimit = limit;
            },
            onChanged: () => changes++,
            onSchoolTimes: () {},
          ),
        ),
      ),
    ));
    final card = find.byKey(ValueKey('tap-grade-daily-$firstId'));
    for (var i = 0; i < 40 && card.evaluate().isEmpty; i++) {
      await tester.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 30)));
      await tester.pump(const Duration(milliseconds: 100));
    }
    expect(card, findsOneWidget);
    await tester.tap(card);
    await tester.pumpAndSettle();
    expect(find.text('حصص ${grades.first['name']}'), findsOneWidget);
    expect(find.text('6'), findsOneWidget);
    await tester.tap(find.byTooltip('تقليل حصة'));
    await tester.pumpAndSettle();
    expect(find.text('5'), findsOneWidget,
        reason: 'The decrement control must really change the dialog value.');
    await tester.tap(find.text('حفظ'));
    await tester.pumpAndSettle();
    // Closing a dialog and completing the asynchronous save callback are
    // separate events. `pumpAndSettle` only waits for scheduled UI frames;
    // it is not a guarantee that the writer's Future has resumed. Advance
    // the widget clock until the success notification is observable.
    for (var attempt = 0; attempt < 30 && changes == 0; attempt++) {
      await tester.pump(const Duration(milliseconds: 50));
    }
    expect(writtenGrade, firstId,
        reason: 'The edited grade must be passed to the writer.');
    expect(writtenLimit, 5,
        reason: 'The confirmed value must be passed to the writer.');
    expect(changes, 1,
        reason: 'A successful save must notify exactly once, after commit.');
    expect(tester.takeException(), isNull);
    // A widget test must not perform an actual SQLite transaction in the fake
    // async zone. The next plain test performs a real persisted database read.
  });

  test('real SQLite updates the grade and all its sections atomically',
      () async {
    final firstId = grades.first['id'] as int;
    final database = await db.database;
    final sectionId = await database.insert('sections', {
      'grade_id': firstId,
      'name': 'شعبة اختبار الحد اليومي',
      'max_daily_lessons': 6,
    });
    try {
      await db.updateGradeDailyLimit(firstId, 5);
      final persisted = await db.gradesDetailed();
      expect(persisted.first['max_daily_lessons'], 5);
      final sections = await database.query('sections',
          columns: ['max_daily_lessons'], where: 'id=?', whereArgs: [sectionId]);
      expect(sections.single['max_daily_lessons'], 5);
      final audit = await database.query('audit_log',
          where: 'action=? AND entity_id=?',
          whereArgs: ['تعديل الحد اليومي للصف', firstId],
          orderBy: 'id DESC', limit: 1);
      expect(audit, isNotEmpty);
      await expectLater(db.updateGradeDailyLimit(firstId, 7),
          throwsA(isA<RangeError>()));
      expect((await db.gradesDetailed()).first['max_daily_lessons'], 5);
    } finally {
      await db.updateGradeDailyLimit(firstId, 6);
      await database.delete('sections', where: 'id=?', whereArgs: [sectionId]);
    }
  });
}
