import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/theme.dart';
import '../features/conflicts/conflicts_page.dart';
import '../services/conflict_detection_service.dart';
import '../features/dashboard/dashboard_page.dart';
import '../features/data_management/data_management_page.dart';
import '../features/data_management/availability_page.dart';
import '../features/timetable/timetable_page.dart';
import '../features/timetable/teacher_absence_page.dart';
import '../features/reports/reports_page.dart';
import '../features/tools/tools_page.dart';

class TimetableApp extends StatefulWidget {
  const TimetableApp({super.key});
  @override
  State<TimetableApp> createState() => _TimetableAppState();
}

class _TimetableAppState extends State<TimetableApp> {
  String _style = 'calm';
  double _textScale = 1;
  @override
  void initState() {
    super.initState();
    _loadAppearance();
  }

  Future<void> _loadAppearance() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _style = prefs.getString('interface_style') ?? 'calm';
      _textScale = (prefs.getDouble('interface_scale') ?? 1).clamp(.9, 1.3);
    });
  }

  Future<void> _setAppearance(String style, double scale) async {
    setState(() {
      _style = style;
      _textScale = scale;
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('interface_style', style);
    await prefs.setDouble('interface_scale', scale);
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'جدولي المدرسي',
    debugShowCheckedModeBanner: false,
    locale: const Locale('ar'),
    supportedLocales: const [Locale('ar'), Locale('en')],
    localizationsDelegates: const [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    theme: buildAppTheme(style: _style),
    builder: (context, child) => MediaQuery(
      data: MediaQuery.of(context).copyWith(
        textScaler: TextScaler.linear(
          MediaQuery.textScalerOf(context).scale(1) * _textScale,
        ),
      ),
      child: child!,
    ),
    home: AppShell(
      style: _style,
      textScale: _textScale,
      onAppearance: _setAppearance,
    ),
  );
}

class AppShell extends StatefulWidget {
  const AppShell({
    this.style = 'calm',
    this.textScale = 1,
    this.onAppearance,
    super.key,
  });
  final String style;
  final double textScale;
  final void Function(String, double)? onAppearance;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0, _focusToken = 0;
  final _visited = <int>{0};
  final _epochs = List.filled(13, 0);
  Map<String, int?>? _focusTarget;
  static const _destinations = <({String label, IconData icon})>[
    (label: 'الرئيسية', icon: Icons.dashboard_outlined),
    (label: 'الجدول', icon: Icons.calendar_month_outlined),
    (label: 'المعلمون', icon: Icons.people_outline),
    (label: 'الحصص المطلوبة', icon: Icons.fact_check_outlined),
    (label: 'المواد والقيود', icon: Icons.menu_book_outlined),
    (label: 'إتاحة المعلمين', icon: Icons.event_available_outlined),
    (label: 'التعارضات', icon: Icons.rule_outlined),
    (label: 'التوزيع والحلول', icon: Icons.auto_awesome_outlined),
    (label: 'الغياب والبدلاء', icon: Icons.person_off_outlined),
    (label: 'النسخ والاعتماد', icon: Icons.history_outlined),
    (label: 'التقارير', icon: Icons.print_outlined),
    (label: 'النسخ الاحتياطية', icon: Icons.backup_outlined),
    (label: 'إعدادات المدرسة', icon: Icons.settings_outlined),
  ];
  void _goTo(int index) {
    if (index == _index) return;
    setState(() {
      _epochs[index]++;
      _visited.add(index);
      _index = index;
    });
  }

  void _refreshApp() => setState(() {
    for (var i = 0; i < _epochs.length; i++) {
      if (i != _index) _epochs[i]++;
    }
  });
  void _openIssue(ConflictIssue issue) {
    _focusTarget = {
      'sectionId': issue.sectionId,
      'dayId': issue.dayId,
      'slotId': issue.slotId,
      'subjectId': issue.subjectId,
      'token': ++_focusToken,
    };
    _goTo(1);
  }

  Widget _page(int index) {
    if (!_visited.contains(index)) return const SizedBox.shrink();
    final key = ValueKey('screen-$index-${_epochs[index]}');
    return switch (index) {
      0 => DashboardPage(key: key, onNavigate: _goTo),
      1 => TimetablePage(
        key: key,
        onChanged: _refreshApp,
        focusTarget: _focusTarget,
      ),
      2 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.teachers,
      ),
      3 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.requirements,
      ),
      4 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.subjects,
      ),
      5 => AvailabilityPage(
        key: key,
        onChanged: _refreshApp,
        onEditTeachers: () => _goTo(2),
      ),
      6 => ConflictsPage(key: key, onNavigateToIssue: _openIssue),
      7 => TimetablePage(key: key, onChanged: _refreshApp, searchPage: true),
      8 => TeacherAbsencePage(key: key, onChanged: _refreshApp),
      9 => ToolsPage(
        key: key,
        onChanged: _refreshApp,
        section: ToolsSection.versions,
      ),
      10 => ReportsPage(key: key),
      11 => ToolsPage(
        key: key,
        onChanged: _refreshApp,
        section: ToolsSection.backups,
      ),
      _ => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.settings,
      ),
    };
  }

  Future<void> _more() async {
    // Wait for the route to finish closing before replacing the active page.
    // This also avoids navigation being triggered during the modal's animation.
    final selectedDestination = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: .85,
          builder: (_, controller) => ListView(
            controller: controller,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            children: [
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  'كل أقسام جدولي',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                ),
              ),
              for (var i = 0; i < _destinations.length; i++)
                ListTile(
                  key: ValueKey('more-destination-$i'),
                  selected: _index == i,
                  leading: Icon(_destinations[i].icon),
                  title: Text(_destinations[i].label),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.of(sheetContext).pop(i),
                ),
              const Divider(height: 24),
              const Text(
                'مظهر الواجهة',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Wrap(
                spacing: 8,
                children: [
                  for (final style in {
                    'dark': 'ليلي',
                    'calm': 'هادئ',
                    'blue': 'أزرق',
                    'paper': 'ورقي',
                  }.entries)
                    ChoiceChip(
                      label: Text(style.value),
                      selected: widget.style == style.key,
                      onSelected: (_) {
                        Navigator.pop(sheetContext);
                        widget.onAppearance?.call(style.key, widget.textScale);
                      },
                    ),
                ],
              ),
              const SizedBox(height: 12),
              const Text('حجم النص'),
              Wrap(
                spacing: 8,
                children: [
                  for (final scale in [1.0, 1.15, 1.3])
                    ChoiceChip(
                      label: Text('${(scale * 100).round()}٪'),
                      selected: widget.textScale == scale,
                      onSelected: (_) {
                        Navigator.pop(sheetContext);
                        widget.onAppearance?.call(widget.style, scale);
                      },
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    if (mounted && selectedDestination != null) {
      _goTo(selectedDestination);
    }
  }

  Widget _sidebar(BuildContext context) {
    final theme = Theme.of(context), scheme = theme.colorScheme;
    return Container(
      width: 236,
      decoration: BoxDecoration(
        color: scheme.surface,
        border: Border(left: BorderSide(color: theme.dividerColor)),
      ),
      padding: const EdgeInsets.fromLTRB(12, 25, 12, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 18),
            child: Row(
              children: [
                Container(
                  height: 44, width: 44,
                  decoration: BoxDecoration(
                    color: scheme.primary.withValues(alpha: .10),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: Icon(Icons.calendar_month_rounded, color: scheme.primary, size: 27),
                ),
                const SizedBox(width: 10),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('جدولي', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: scheme.primary)),
                    Text('إدارة الجدول المدرسي', style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant)),
                  ],
                )),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 11),
            child: Text('مساحة العمل', style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant)),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _destinations.length,
              itemBuilder: (context, i) {
                final active = _index == i;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Material(
                    color: active ? scheme.primary.withValues(alpha: .10) : Colors.transparent,
                    borderRadius: BorderRadius.circular(9),
                    child: InkWell(
                      key: ValueKey('nav-$i'),
                      borderRadius: BorderRadius.circular(9),
                      onTap: () => _goTo(i),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                        child: Row(children: [
                          Icon(_destinations[i].icon, size: 19, color: active ? scheme.primary : scheme.onSurfaceVariant),
                          const SizedBox(width: 12),
                          Expanded(child: Text(_destinations[i].label,
                            style: TextStyle(fontSize: 12, fontWeight: active ? FontWeight.w800 : FontWeight.w500,
                              color: active ? scheme.primary : scheme.onSurfaceVariant))),
                          if (active) Icon(Icons.circle, size: 6, color: scheme.primary),
                        ]),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Divider(color: theme.dividerColor),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('جدولي المدرسي', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
              const SizedBox(height: 3),
              Text('إدارة محلية للجدول والقيود والتقارير',
                  style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant)),
              const SizedBox(height: 9),
              OutlinedButton.icon(onPressed: _more,
                icon: const Icon(Icons.tune_rounded, size: 17),
                label: const Text('مظهر الواجهة')),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _topbar(BuildContext context, bool wide) {
    final theme = Theme.of(context), scheme = theme.colorScheme;
    return Container(
      height: wide ? 76 : 62,
      padding: EdgeInsets.symmetric(horizontal: wide ? 26 : 12),
      decoration: BoxDecoration(
        color: scheme.surface,
        border: Border(bottom: BorderSide(color: theme.dividerColor)),
      ),
      child: Row(children: [
        if (!wide) ...[
          Icon(Icons.calendar_month_outlined, color: scheme.primary),
          const SizedBox(width: 10),
        ],
        Expanded(child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('نظام إدارة المدرسة / جدولي', style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant)),
            Text(_destinations[_index].label, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: scheme.onSurface)),
          ],
        )),
        if (wide) ...[
          for (final style in const ['calm', 'blue', 'paper'])
            Padding(padding: const EdgeInsets.only(left: 3), child: TextButton(
              onPressed: () => widget.onAppearance?.call(style, widget.textScale),
              style: TextButton.styleFrom(
                backgroundColor: widget.style == style ? scheme.primary.withValues(alpha: .12) : null,
                minimumSize: const Size(47, 34),
                padding: const EdgeInsets.symmetric(horizontal: 8),
              ),
              child: Text(style == 'calm' ? 'هادئ' : style == 'blue' ? 'أزرق' : 'ورقي', style: const TextStyle(fontSize: 11)),
            )),
        ],
        IconButton(
          tooltip: widget.style == 'dark' ? 'الوضع النهاري' : 'الوضع الليلي',
          onPressed: () => widget.onAppearance?.call(widget.style == 'dark' ? 'calm' : 'dark', widget.textScale),
          icon: Icon(widget.style == 'dark' ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
        ),
        TextButton.icon(onPressed: _more,
          icon: const Icon(Icons.apps_outlined, size: 17),
          label: const Text('كل الشاشات', style: TextStyle(fontSize: 11))),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: LayoutBuilder(builder: (context, constraints) {
      final wide = constraints.maxWidth >= 1000;
      final content = IndexedStack(index: _index, children: List.generate(13, _page));
      return Scaffold(
        body: SafeArea(
          child: Row(children: [
            if (wide) _sidebar(context),
            Expanded(child: Column(children: [
              _topbar(context, wide),
              Expanded(child: content),
            ])),
          ]),
        ),
        bottomNavigationBar: wide ? null : NavigationBar(
          // The Material 3 destination layout needs room for both its icon
          // and Arabic label. A height of 69 causes a RenderFlex overflow
          // on 390px-wide phones (observed in app_navigation_test.dart).
          // Reserve extra vertical space as the user increases text size.
          height: 88.0 + (widget.textScale - 1.0).clamp(0.0, 0.3).toDouble() * 40.0,
          selectedIndex: _index <= 3 ? _index : 4,
          onDestinationSelected: (i) => i == 4 ? _more() : _goTo(i),
          destinations: [
            for (var i = 0; i < 4; i++)
              NavigationDestination(icon: Icon(_destinations[i].icon),
                label: i == 3 ? 'المتطلبات' : _destinations[i].label),
            const NavigationDestination(icon: Icon(Icons.grid_view_outlined), label: 'المزيد'),
          ],
        ),
      );
    }),
  );
}
