جدولي المدرسي — الإصدار v1.13.3
==============================

إصلاح فشل اختبار التنقل على الهواتف:
* عالجنا ارتفاع NavigationBar غير الكافي في lib/app/app.dart.
* جرى ضبط الارتفاع إلى 88 نقطة منطقية افتراضياً، مع زيادة تدريجية عند تكبير حجم النص.
* سبب التعديل: RenderFlex overflowed by 7.0 pixels on the bottom أثناء اختبار app_navigation_test.dart بحجم شاشة 390×844.
* بقي اختبار التنقل كاملاً ويواصل التحقق من الشاشات الثلاث عشرة، دون تجاهل أخطاء Flutter.
* لم تتغير خدمات الجدول والقيود والتقارير ولا البيانات.

التحقق:
* تأكيد تعديل المصدر وفحص بنية ZIP وملف Workflow.
* لا يتوفر Flutter SDK في بيئة إعداد الحزمة؛ لذلك يجب تشغيل Flutter Analyze وFlutter Test على GitHub Actions للتحقق النهائي.

طريقة البناء من ZIP:
1- ارفع jadwali-school-project-v1.13.3.zip إلى جذر مستودع GitHub.
2- ضع build-jadwali-v1.13.3.yml في .github/workflows/build-apk.yml.
3- افتح GitHub Actions وشغّل Workflow.
4- عند نجاح الفحوص والبناء ستجد APK في Artifacts.

ملحوظة: لا تحتاج إلى فك ضغط ملف مشروع Flutter على GitHub.
