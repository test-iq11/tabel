import 'package:flutter/material.dart';

import 'interface_settings.dart';

/// Native Flutter recreation of the approved HTML dashboard banner.
/// The repair button opens the live conflict screen, not a simulated result.
class HtmlDashboardHero extends StatelessWidget {
  const HtmlDashboardHero({
    super.key,
    required this.onRepair,
    required this.onTimetable,
    required this.onCustomize,
  });
  final VoidCallback onRepair;
  final VoidCallback onTimetable;
  final VoidCallback onCustomize;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final ui = InterfaceSettings.instance;
    final accent = colors.primary;
    final narrow = MediaQuery.sizeOf(context).width < 650;
    return Container(
      key: const ValueKey('html-dashboard-hero'),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(32),
        gradient: LinearGradient(
          begin: AlignmentDirectional.topStart,
          end: AlignmentDirectional.bottomEnd,
          colors: [Color.lerp(accent, const Color(0xff293a9a), .38)!,
            accent, ui.design.b],
        ),
        boxShadow: [BoxShadow(color: accent.withValues(alpha: .15),
          blurRadius: 30, offset: const Offset(0, 12))],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(32),
        child: Stack(children: [
          Positioned(left: -95, top: -120, child: Container(width: 360,
            height: 360, decoration: BoxDecoration(shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withValues(alpha: .17))))),
          Positioned(right: -75, bottom: -200, child: Container(width: 310,
            height: 310, decoration: BoxDecoration(shape: BoxShape.circle,
              color: Colors.white.withValues(alpha: .045)))),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: narrow ? 23 : 34,
              vertical: narrow ? 28 : 37),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(padding: const EdgeInsets.symmetric(
                  horizontal: 15, vertical: 9),
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: .13),
                    borderRadius: BorderRadius.circular(90),
                    border: Border.all(color: Colors.white.withValues(alpha: .2))),
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.auto_awesome, color: Colors.white, size: 19),
                    SizedBox(width: 7),
                    Text('تجربة جديدة للإصلاح الذكي',
                      style: TextStyle(color: Colors.white, fontSize: 12,
                        fontWeight: FontWeight.w800)),
                  ])),
                const SizedBox(height: 25),
                Text('جدول أجمل، وقرارات أذكى،\nوتغييرات أقل.',
                  style: TextStyle(color: Colors.white,
                    fontWeight: FontWeight.w900, height: 1.45,
                    fontSize: narrow ? 26 : 34)),
                const SizedBox(height: 14),
                Text('حل التعارضات مع إبراز المواضع المتأثرة،\nومعاينة كل خطوة قبل اعتمادها.',
                  style: TextStyle(color: Colors.white.withValues(alpha: .85),
                    fontSize: narrow ? 12 : 15, height: 1.8)),
                const SizedBox(height: 23),
                Wrap(spacing: 9, runSpacing: 10, children: [
                  FilledButton.icon(onPressed: onRepair,
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: accent,
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                    icon: const Icon(Icons.auto_fix_high_outlined, size: 21),
                    label: const Text('استكشف الإصلاح الذكي',
                      style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13))),
                  OutlinedButton.icon(
                    key: const ValueKey('customize-school-card'),
                    onPressed: onCustomize,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side: BorderSide(color: Colors.white.withValues(alpha: .55)),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12)),
                    icon: const Icon(Icons.tune_outlined, size: 16),
                    label: const Text('تخصيص', style: TextStyle(fontSize: 12))),
                ]),
                const SizedBox(height: 10),
                TextButton.icon(onPressed: onTimetable,
                  style: TextButton.styleFrom(foregroundColor: Colors.white),
                  icon: const Icon(Icons.calendar_month_outlined, size: 16),
                  label: const Text('فتح الجدول الدراسي')),
              ]),
          ),
        ]),
      ),
    );
  }
}
