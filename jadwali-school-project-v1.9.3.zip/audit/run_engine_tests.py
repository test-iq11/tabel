#!/usr/bin/env python3
"""Run the pure scheduling service tests using Dart when Flutter is unavailable.

Only the test runner import is adapted in a temporary directory. Production
sources are copied unchanged. This does not replace Flutter analysis/UI tests.
Usage: python3 audit/run_engine_tests.py --dart /path/to/dart
"""
import argparse
from pathlib import Path
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dart', default='dart')
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
services = [
    'auto_scheduler_service', 'teacher_capacity_flow', 'teacher_assignment_policy',
    'school_timetable_policy', 'required_repeat_policy',
    'conflict_detection_service', 'preflight_inspection_service',
    'teacher_workload_service',
]
tests = [
    'auto_scheduler_service', 'teacher_capacity_flow', 'teacher_assignment_policy',
    'school_timetable_policy', 'conflict_detection_service',
    'preflight_inspection_service', 'teacher_workload_service',
    'scheduler_safety_regression',
]
with tempfile.TemporaryDirectory(prefix='jadwali-engine-') as directory:
    target = Path(directory)
    (target / 'lib/services').mkdir(parents=True)
    (target / 'lib/core').mkdir(parents=True)
    (target / 'test').mkdir()
    for service in services:
        shutil.copy2(root / f'lib/services/{service}.dart', target / f'lib/services/{service}.dart')
    shutil.copy2(root / 'lib/core/timetable_ordering.dart', target / 'lib/core/timetable_ordering.dart')
    for test in tests:
        content = (root / f'test/{test}_test.dart').read_text()
        (target / f'test/{test}_test.dart').write_text(content.replace(
            'package:flutter_test/flutter_test.dart', 'package:test/test.dart'))
    (target / 'pubspec.yaml').write_text(
        'name: iraqi_school_timetable\n'
        'environment:\n  sdk: ">=3.13.0 <4.0.0"\n'
        'dev_dependencies:\n  test: ^1.33.0\n')
    for command in [['pub', 'get'], ['test', '--reporter', 'expanded']]:
        subprocess.run([args.dart, '--suppress-analytics', *command], cwd=target, check=True)
