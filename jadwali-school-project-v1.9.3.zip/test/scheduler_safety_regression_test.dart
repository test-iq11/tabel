import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:iraqi_school_timetable/services/conflict_detection_service.dart';

void main() {
  test('يشخّص عجز السعة المشتركة ويحفظ أكبر عدد ممكن دون تعارض', () {
    final result = const AutoSchedulerService(nodeLimit: 5000).generate(
      sections: [
        for (var id = 1; id <= 3; id++)
          {'id': id, 'grade_id': 1, 'max_daily_lessons': 2},
      ],
      requirements: [
        for (var id = 1; id <= 3; id++)
          {'section_id': id, 'subject_id': 1, 'weekly_lessons': 2, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 1, 'weekly_load': 2, 'max_daily_lessons': 2},
        {'id': 2, 'weekly_load': 2, 'max_daily_lessons': 2},
        {'id': 3, 'weekly_load': 20, 'max_daily_lessons': 2},
      ],
      qualifications: [
        {'teacher_id': 1, 'subject_id': 1},
        {'teacher_id': 1, 'subject_id': 1},
        {'teacher_id': 2, 'subject_id': 1},
        {'teacher_id': 3, 'subject_id': 2},
      ],
      days: [
        for (var id = 1; id <= 3; id++) {'id': id, 'position': id, 'is_active': 1},
      ],
      slots: [
        for (var id = 1; id <= 2; id++)
          {'id': id, 'position': id, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(result.placements, hasLength(4));
    expect(result.complete, isFalse);
    expect(result.unscheduled.join(' '), contains('سعة المعلمين المؤهلين المشتركة'));
  });

  test('فاحص التعارضات يعتمد صف الشعبة الحالي للحصص غير المحفوظة', () {
    final issues = const ConflictDetectionService().scan(
      entries: [
        {'section_id': 1, 'subject_id': 1, 'teacher_id': 1, 'day_id': 1, 'slot_id': 1, 'grade_id': 2},
      ],
      sections: [{'id': 1, 'grade_id': 1}],
      qualifications: [{'teacher_id': 1, 'subject_id': 1}],
      teacherSubjectGrades: [{'teacher_id': 1, 'subject_id': 1, 'grade_id': 1}],
    );
    expect(issues.where((i) => i.type == 'تعذر تحديد صف الشعبة' || i.type == 'الصف غير مسموح للمعلم'), isEmpty);
  });

  test('80 مدرسة عشوائية: لا تزامن ولا مخالفة إتاحة أو نصاب', () {
    final random = Random(193);
    for (var sample = 0; sample < 80; sample++) {
      final days = <Map<String, Object?>>[
        for (var d = 1; d <= 3; d++)
          {'id': d, 'position': d, 'name': 'يوم $d', 'is_active': 1},
      ];
      final slots = <Map<String, Object?>>[
        for (var s = 1; s <= 3; s++)
          {'id': s, 'position': s, 'kind': 'lesson', 'is_available': 1},
      ];
      final sections = <Map<String, Object?>>[
        for (var s = 1; s <= 3; s++)
          {'id': s, 'grade_id': 1, 'max_daily_lessons': 3},
      ];
      final teachers = <Map<String, Object?>>[
        for (var t = 1; t <= 3; t++)
          {
            'id': t,
            'weekly_load': 2 + random.nextInt(6),
            'max_daily_lessons': 1 + random.nextInt(3),
            'max_consecutive_lessons': 1 + random.nextInt(3),
          },
      ];
      final qualifications = <Map<String, Object?>>[
        for (var t = 1; t <= 3; t++)
          for (var subject = 1; subject <= 2; subject++)
            if (random.nextBool()) {'teacher_id': t, 'subject_id': subject},
      ];
      final requirements = <Map<String, Object?>>[
        for (var section = 1; section <= 3; section++)
          for (var subject = 1; subject <= 2; subject++)
            {
              'section_id': section,
              'subject_id': subject,
              'weekly_lessons': 1 + random.nextInt(3),
              'allow_same_day': 0,
              'max_daily_lessons': 1,
            },
      ];
      final availability = <Map<String, Object?>>[
        for (var t = 1; t <= 3; t++)
          for (var d = 1; d <= 3; d++)
            for (var s = 1; s <= 3; s++)
              if (random.nextInt(5) == 0)
                {'teacher_id': t, 'day_id': d, 'slot_id': s, 'is_available': 0},
      ];
      final blocked = <Map<String, Object?>>[
        if (random.nextBool()) {'subject_id': 1, 'slot_id': 3},
      ];
      final result = const AutoSchedulerService(nodeLimit: 300).generate(
        sections: sections,
        requirements: requirements,
        teachers: teachers,
        qualifications: qualifications,
        days: days,
        slots: slots,
        teacherAvailability: availability,
        subjectBlockedSlots: blocked,
      );
      final teacherCells = <String>{};
      final sectionCells = <String>{};
      for (final entry in result.placements) {
        expect(
          teacherCells.add(
            '${entry['teacher_id']}:${entry['day_id']}:${entry['slot_id']}',
          ),
          isTrue,
        );
        expect(
          sectionCells.add(
            '${entry['section_id']}:${entry['day_id']}:${entry['slot_id']}',
          ),
          isTrue,
        );
      }
      final issues = const ConflictDetectionService().scan(
        entries: result.placements,
        requirements: requirements,
        sections: sections,
        slots: slots,
        days: days,
        teachers: teachers,
        qualifications: qualifications,
        teacherAvailability: availability,
        subjectBlockedSlots: blocked,
      );
      // Missing lessons are expected on deliberately infeasible instances.
      final violations = issues
          .where(
            (issue) => ![
              'نقص الحصص',
              'تكرار توقيت المادة في أيام متتالية',
            ].contains(issue.type),
          )
          .toList();
      expect(
        violations,
        isEmpty,
        reason:
            'sample $sample: ${violations.map((i) => '${i.type}: ${i.message}').join('; ')}',
      );
    }
  });
}
