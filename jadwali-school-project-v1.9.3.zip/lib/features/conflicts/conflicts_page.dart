import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';

import '../../core/ui_helpers.dart';
import '../../data/database_service.dart';
import '../../services/auto_scheduler_service.dart';
import '../../services/conflict_detection_service.dart';


List<Map<String, Object?>> _repairMapList(Object? value) =>
    (value as List).map((row) => Map<String, Object?>.from(row as Map)).toList();

/// Generates a timetable in a background isolate using the same hardened scheduler
/// used by the timetable editor. This action creates a new version; it never edits
/// or deletes the current saved version.
Map<String, Object?> _generateConflictRepairInBackground(Map<String, Object?> input) {
  final result = const AutoSchedulerService(nodeLimit: 180000).generate(
    sections: _repairMapList(input['sections']),
    requirements: _repairMapList(input['requirements']),
    teachers: _repairMapList(input['teachers']),
    qualifications: _repairMapList(input['qualifications']),
    teacherGrades: _repairMapList(input['teacherGrades']),
    teacherSubjectGrades: _repairMapList(input['teacherSubjectGrades']),
    subjectBlockedSlots: _repairMapList(input['subjectBlockedSlots']),
    days: _repairMapList(input['days']),
    slots: _repairMapList(input['slots']),
    teacherAvailability: _repairMapList(input['availability']),
  );
  return <String, Object?>{
    'placements': result.placements,
    'unscheduled': result.unscheduled,
    'requestedCount': result.requestedCount,
    'exploredNodes': result.exploredNodes,
    'searchLimitReached': result.searchLimitReached,
    'dailySpreadIssues': result.dailySpreadIssues,
  };
}

class ConflictsPage extends StatefulWidget {
  const ConflictsPage({required this.onNavigateToIssue, super.key});
  final ValueChanged<ConflictIssue> onNavigateToIssue;
  @override
  State<ConflictsPage> createState() => _ConflictsPageState();
}

class _ConflictsPageState extends State<ConflictsPage> {
  Future<Map<String, Object?>>? _future;
  String _filter = 'الكل';
  String _typeFilter = 'الكل';
  String _query = '';
  bool _showOnlyActionable = false;
  bool _scanned = false;
  bool _isRepairingSchedule = false;
  @override
  void initState() { super.initState(); _reload(); }
  void _reload() => _future = _load();

  Future<Map<String, Object?>> _load() async {
    final db = DatabaseService.instance;
    final versionId = await db.activeVersionId(await db.activeYearId());
    final data = <String, Object?>{
      'yearId': await db.activeYearId(),
      'year': await db.activeYear() ?? <String, Object?>{},
      'sections': await db.sectionsDetailed(),
      'availability': await db.rows('teacher_availability'),
      'versionId': versionId,
      'version': versionId == null ? <String, Object?>{} : (await db.rows('timetable_versions')).firstWhere((v) => v['id'] == versionId, orElse: () => <String, Object?>{}),
      'entries': await db.entriesDetailed(versionId: versionId),
      'requirements': await db.requirementsDetailed(),
      'slots': await db.rows('time_slots'),
      'teachers': await db.rows('teachers'),
      'qualifications': await db.rows('teacher_subjects'),
      'teacherGrades': await db.rows('teacher_grades'),
      'teacherSubjectGrades': await db.rows('teacher_subject_grades'),
      'subjectBlockedSlots': await db.rows('subject_blocked_slots'),
      'days': await db.rows('school_days'),
    };
    return data;
  }

  List<ConflictIssue> _scan(Map<String, Object?> data) => const ConflictDetectionService().scan(
    entries: (data['entries'] as List).cast<Map<String, Object?>>(),
    requirements: (data['requirements'] as List).cast<Map<String, Object?>>(),
    sections: (data['sections'] as List).cast<Map<String, Object?>>(),
    slots: (data['slots'] as List).cast<Map<String, Object?>>(),
    teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
    qualifications: (data['qualifications'] as List).cast<Map<String, Object?>>(),
    days: (data['days'] as List).cast<Map<String, Object?>>(),
    teacherGrades: (data['teacherGrades'] as List).cast<Map<String, Object?>>(),
    teacherSubjectGrades: (data['teacherSubjectGrades'] as List).cast<Map<String, Object?>>(),
    subjectBlockedSlots: (data['subjectBlockedSlots'] as List).cast<Map<String, Object?>>(),
    teacherAvailability: (data['availability'] as List).cast<Map<String, Object?>>(),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('فحص التعارضات')),
    body: FutureBuilder<Map<String, Object?>>(future: _future, builder: (context, snapshot) {
      if (snapshot.hasError) return emptyState(icon: Icons.error_outline, title: 'تعذر فحص الجدول', message: '${snapshot.error}');
      if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
      if (!snapshot.hasData) return emptyState(icon: Icons.info_outline, title: 'لا توجد بيانات', message: 'لم تُرجع قاعدة البيانات بيانات للفحص. حدّث الصفحة وحاول مرة أخرى.');
      final data = snapshot.data!;
      final entries = (data['entries'] as List).cast<Map<String, Object?>>();
      final issues = _scan(data);
      final blockers = issues.where((i) => i.severity == 'خطأ مانع').length;
      final warnings = issues.where((i) => i.severity == 'تحذير').length;
      final notes = issues.where((i) => i.severity == 'ملاحظة').length;
      final filtered = issues.where((i) {
        if (_filter != 'الكل' && i.severity != _filter) return false;
        if (_typeFilter != 'الكل' && i.type != _typeFilter) return false;
        if (_showOnlyActionable && i.sectionId == null) return false;
        final term = _query.trim().toLowerCase();
        if (term.isNotEmpty && !'${i.type} ${i.message} ${i.suggestion ?? ''} ${i.teacherId ?? ''} ${i.sectionId ?? ''}'
            .toLowerCase().contains(term)) return false;
        return true;
      }).toList()..sort((a, b) {
        int rank(String severity) => severity == 'خطأ مانع' ? 0 : severity == 'تحذير' ? 1 : 2;
        return rank(a.severity).compareTo(rank(b.severity));
      });
      final version = (data['version'] as Map).cast<String, Object?>();
      final problemTypes = <String, int>{};
      for (final issue in issues) {
        problemTypes[issue.type] = (problemTypes[issue.type] ?? 0) + 1;
      }
      final sortedProblemTypes = problemTypes.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));
      final problemSections = issues.where((i) => i.sectionId != null)
          .map((i) => i.sectionId).toSet().length;
      final affectedTeachers = issues.where((i) => i.teacherId != null)
          .map((i) => i.teacherId).toSet().length;
      final isHealthy = blockers == 0;
      final statusColor = isHealthy ? const Color(0xFF16836A) : const Color(0xFFB9384A);

      return ListView(padding: const EdgeInsets.all(16), children: [
        pageHeading('فحص صحة الجدول', 'تُعاد قراءة بيانات النسخة النشطة من SQLite عند فتح هذه الصفحة.', trailing: IconButton(onPressed: () => setState(() { _reload(); _scanned = true; }), icon: const Icon(Icons.refresh, color: Color(0xFF2878C8)))),
        // One diagnostic overview: issue severity, impacted locations and a
        // safe repair action are visible before the full detailed list.
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: isHealthy
              ? const [Color(0xFFE3F6EE), Color(0xFFF0FAF7)]
              : const [Color(0xFFFFECEE), Color(0xFFFFF7F2)]),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: statusColor.withValues(alpha: .24)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(isHealthy ? Icons.verified_outlined : Icons.shield_outlined,
                color: statusColor, size: 28),
              const SizedBox(width: 10),
              Expanded(child: Text(isHealthy
                ? 'لا توجد تعارضات مانعة في الجدول الحالي'
                : 'يحتاج الجدول إلى معالجة $blockers مشكلة مانعة',
                style: TextStyle(color: statusColor, fontSize: 17,
                  fontWeight: FontWeight.w900))),
            ]),
            const SizedBox(height: 10),
            Text('الشعب المتأثرة: $problemSections  •  المعلمون المتأثرون: $affectedTeachers  •  النتائج: ${issues.length}',
              style: const TextStyle(color: Color(0xFF40566B), fontSize: 12)),
            const SizedBox(height: 12),
            ClipRRect(borderRadius: BorderRadius.circular(20), child:
              LinearProgressIndicator(value: issues.isEmpty ? 1 :
                (issues.length - blockers) / issues.length,
                minHeight: 8, backgroundColor: const Color(0xFFDCE5ED),
                valueColor: AlwaysStoppedAnimation<Color>(statusColor))),
            const SizedBox(height: 10),
            Text(isHealthy
              ? 'يمكنك مراجعة التحذيرات أو إعادة الفحص بعد تعديل قيود الفترات.'
              : 'اضغط على المشكلة لمعرفة السبب والحل. لا يُسمح باعتماد أي توزيع يحتوي تداخلاً زمنياً.',
              style: const TextStyle(fontSize: 12.5)),
          ]),
        ),
        const SizedBox(height: 12),
        Card(color: const Color(0xFFEAF3FC), child: Padding(padding: const EdgeInsets.all(12), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.info_outline, color: Color(0xFF2878C8)), const SizedBox(width: 9),
          const Expanded(child: Text('توضيح: يُفحص نقص الحصص فقط للمواد التي سُجل لها عدد مطلوب في «البيانات > الحصص المطلوبة» لشعبة محددة. إذا كانت مادة مثل الأخلاقية لا تُدرّس في الصف الثالث، فلا تضف لها متطلباً في شعب الصف الثالث. وإذا ظهر تنبيه لهذا الصف، فهذا يعني أن هناك متطلباً مسجلاً له؛ احذفه أو اجعل العدد 0.', style: TextStyle(fontSize: 12.5))),
        ]))),
        Card(child: Padding(padding: const EdgeInsets.all(15), child: Row(children: [
          const Icon(Icons.fact_check_outlined, size: 30, color: Color(0xFF2878C8)), const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${version['name'] ?? 'لا توجد نسخة'}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)), Text('الحالة: ${version['status'] ?? '—'} • حصص محفوظة: ${entries.length}', style: const TextStyle(color: Colors.black54, fontSize: 12))])),
          FilledButton.icon(onPressed: () => setState(() { _reload(); _scanned = true; }), icon: const Icon(Icons.manage_search), label: const Text('فحص الآن')),
        ]))),
        if (blockers > 0)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('إصلاح التعارضات وإعادة التوزيع الآمن', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 6),
                const Text('يفحص التطبيق القيود الزمنية وصلاحيات المعلمين والفترات الممنوعة، ثم يبحث عن توزيع جديد دون تعارض، ويحفظ نسخة مستقلة دون حذف الجدول الحالي. إذا كانت القيود مستحيلة، يعرض الحصص المتبقية وأسبابها بدلاً من اختراع تعارض.'),
                const SizedBox(height: 10),
                SizedBox(width: double.infinity, child: FilledButton.icon(
                  onPressed: _isRepairingSchedule ? null : () => _createCorrectedVersion(data),
                  icon: _isRepairingSchedule ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_fix_high),
                  label: Text(_isRepairingSchedule ? 'جارٍ إنشاء توزيع متحقق منه…' : 'اقتراح توزيع جديد بلا تعارض'),
                )),
              ]),
            ),
          ),
        const SizedBox(height: 12),
        GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: MediaQuery.sizeOf(context).width > 600 ? 3 : 1, mainAxisSpacing: 9, crossAxisSpacing: 9, childAspectRatio: MediaQuery.sizeOf(context).width > 600 ? 1.9 : 3.2, children: [
          _IssueSummary(title: 'أخطاء مانعة', value: blockers, color: Colors.red.shade700, icon: Icons.error_outline),
          _IssueSummary(title: 'تحذيرات', value: warnings, color: Colors.deepOrange.shade700, icon: Icons.warning_amber_outlined),
          _IssueSummary(title: 'ملاحظات', value: notes, color: const Color(0xFF2878C8), icon: Icons.info_outline),
        ]),
        const SizedBox(height: 12),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('النتيجة النهائية', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)), const SizedBox(height: 8),
          Text(blockers > 0 ? 'لا يمكن اعتماد الجدول حالياً؛ يجب معالجة الأخطاء المانعة أولاً.' : warnings > 0 ? 'لا توجد أخطاء مانعة مكتشفة، لكن توجد تحذيرات ينبغي مراجعتها قبل الاعتماد.' : 'لم تُكتشف أخطاء مانعة أو تحذيرات ضمن الفحوص المفعلة.'),
          if (_scanned) const Padding(padding: EdgeInsets.only(top: 6), child: Text('أُعيد تشغيل الفحص بناءً على البيانات الحالية.', style: TextStyle(fontSize: 12, color: Colors.black54))),
        ]))),
        const SizedBox(height: 12),
        Card(color: const Color(0xFFF0F5FE), child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            TextField(
              onChanged: (value) => setState(() => _query = value),
              decoration: const InputDecoration(
                labelText: 'بحث ذكي في الأسباب والمعلمين والشعب',
                hintText: 'مثال: نصاب، لغة عربية، رقم المعلم…',
                prefixIcon: Icon(Icons.search_rounded),
              ),
            ),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              title: const Text('المشكلات التي يمكن الانتقال إلى موقعها', style: TextStyle(fontSize: 12)),
              value: _showOnlyActionable,
              onChanged: (value) => setState(() => _showOnlyActionable = value ?? false),
            ),
            Text('يعرض ${filtered.length} من أصل ${issues.length} نتيجة، مرتبة بحسب الخطورة والنوع.',
              style: const TextStyle(color: Color(0xFF43556F), fontSize: 12)),
          ]),
        )),
        if (sortedProblemTypes.isNotEmpty) ...[
          const SizedBox(height: 12),
          const Text('تصنيف ذكي بحسب سبب المشكلة',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Wrap(spacing: 7, runSpacing: 6, children: [
            ChoiceChip(label: Text('الجميع (${issues.length})'),
              selected: _typeFilter == 'الكل',
              onSelected: (_) => setState(() => _typeFilter = 'الكل')),
            ...sortedProblemTypes.take(7).map((item) => ChoiceChip(
              label: Text('${item.key} (${item.value})'),
              selected: _typeFilter == item.key,
              onSelected: (_) => setState(() => _typeFilter = item.key))),
          ]),
        ],
        const SizedBox(height: 12),
        Row(children: [const Expanded(child: Text('تفاصيل النتائج', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))), SizedBox(width: 160, child: DropdownButtonFormField<String>(initialValue: _filter, isExpanded: true, decoration: const InputDecoration(labelText: 'تصفية'), items: const [DropdownMenuItem(value: 'الكل', child: Text('كل النتائج')), DropdownMenuItem(value: 'خطأ مانع', child: Text('أخطاء مانعة')), DropdownMenuItem(value: 'تحذير', child: Text('تحذيرات')), DropdownMenuItem(value: 'ملاحظة', child: Text('ملاحظات'))], onChanged: (v) => setState(() => _filter = v ?? 'الكل')))]),
        const SizedBox(height: 8),
        if (filtered.isEmpty) emptyState(icon: Icons.check_circle_outline, title: 'لا توجد نتائج ضمن هذا التصنيف', message: 'قد يكون الجدول خالياً أو اجتاز الفحوص الحالية. تحقق من تسجيل متطلبات المواد إذا كان ذلك مطلوباً.'),
        ...filtered.map((issue) => Padding(padding: const EdgeInsets.only(bottom: 9), child: Card(
          color: _colorFor(issue.severity).withValues(alpha: .035),
          child: ExpansionTile(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          leading: CircleAvatar(backgroundColor: _colorFor(issue.severity).withValues(alpha: .12),
            child: Icon(_iconFor(issue.severity), color: _colorFor(issue.severity))),
          title: Text(issue.type, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(issue.message, maxLines: 3, overflow: TextOverflow.ellipsis),
          childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
          children: [
            Align(alignment: Alignment.centerRight, child: Chip(label: Text(issue.severity), backgroundColor: _colorFor(issue.severity).withValues(alpha: .12))),
            if (issue.suggestion != null) Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFE8F4F3),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Row(children: [Icon(Icons.lightbulb_outline, size: 18,
                    color: Color(0xFF08766B)), SizedBox(width: 6),
                  Text('التشخيص والإجراء المقترح',
                    style: TextStyle(color: Color(0xFF08766B), fontWeight: FontWeight.w800))]),
                const SizedBox(height: 6),
                Text(issue.suggestion!, style: const TextStyle(height: 1.5)),
              ]),
            ),
            if (issue.sectionId != null) ...[
              const SizedBox(height: 8),
              Align(alignment: Alignment.centerRight, child: FilledButton.tonalIcon(
                onPressed: () => widget.onNavigateToIssue(issue),
                icon: const Icon(Icons.my_location),
                label: Text(issue.dayId != null && issue.slotId != null ? 'الانتقال إلى موضع المشكلة في الجدول' : 'فتح جدول الشعبة المرتبطة بالمشكلة'),
              )),
            ],
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 6, children: [
              if (issue.sectionId != null) _InfoPill(label: 'معرّف الشعبة', value: '${issue.sectionId}'),
              if (issue.teacherId != null) _InfoPill(label: 'معرّف المعلم', value: '${issue.teacherId}'),
              if (issue.dayId != null) _InfoPill(label: 'اليوم', value: '${issue.dayId}'),
              if (issue.slotId != null) _InfoPill(label: 'الفترة', value: '${issue.slotId}'),
            ]),
          ],
        )))),
      ]);
    }),
  );

  Future<void> _createCorrectedVersion(Map<String, Object?> data) async {
    if (_isRepairingSchedule) return;
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('إنشاء نسخة مصححة'),
        content: const Text(
          'سيعيد التطبيق توزيع الحصص لجميع شعب المدرسة باستخدام صلاحية (المعلم + المادة + الصف). '
          'ستُحفظ النتيجة كنسخة جديدة وتصبح النشطة، بينما تبقى المسودة الحالية وسائر بيانات المدرسة دون حذف. '
          'قد تكون النتيجة جزئية إذا كانت بعض الحصص لا تملك معلماً متاحاً ومسموحاً له.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ابدأ الإصلاح')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    setState(() => _isRepairingSchedule = true);
    try {
      final yearId = data['yearId'] as int?;
      if (yearId == null) throw StateError('لا يوجد عام دراسي نشط.');
      List<Map<String, Object?>> list(String key) =>
          (data[key] as List).cast<Map<String, Object?>>();
      final sections = list('sections');
      final requirements = list('requirements');
      if (sections.isEmpty || requirements.isEmpty) {
        throw StateError('لا توجد شعب أو حصص مطلوبة كافية لإنشاء جدول جديد.');
      }

      final generated = await compute(_generateConflictRepairInBackground, <String, Object?>{
        'sections': sections,
        'requirements': requirements,
        'teachers': list('teachers'),
        'qualifications': list('qualifications'),
        'teacherGrades': list('teacherGrades'),
        'teacherSubjectGrades': list('teacherSubjectGrades'),
        'subjectBlockedSlots': list('subjectBlockedSlots'),
        'days': list('days'),
        'slots': list('slots'),
        'availability': list('availability'),
      }, debugLabel: 'jadwali_conflict_repair');

      final placements = _repairMapList(generated['placements']);
      final requestedCount = generated['requestedCount'] as int;
      final unscheduled = (generated['unscheduled'] as List).cast<String>();
      final exploredNodes = generated['exploredNodes'] as int;
      final searchLimitReached = generated['searchLimitReached'] as bool;
      final dailySpreadIssues = (generated['dailySpreadIssues'] as List? ?? const []).cast<String>();
      if (placements.isEmpty) {
        throw StateError(
          'لم ينتج التوزيع أي حصة مسندة. لم تتغير النسخة الحالية. راجع تأهيل المعلمين، وصفوف المواد، والفترات والنصاب، ثم حاول مرة أخرى.',
        );
      }

      final scanIssues = const ConflictDetectionService().scan(
        entries: placements,
        requirements: requirements,
        sections: sections,
        slots: list('slots'),
        teachers: list('teachers'),
        qualifications: list('qualifications'),
        days: list('days'),
        teacherGrades: list('teacherGrades'),
        teacherSubjectGrades: list('teacherSubjectGrades'),
        subjectBlockedSlots: list('subjectBlockedSlots'),
        teacherAvailability: list('availability'),
        enforceQualifications: true,
      );
      final dailySpreadBlockers = scanIssues.where((issue) =>
          issue.severity == 'خطأ مانع' && issue.type == 'توزيع المادة على كل أيام الأسبوع').toList();
      
      final allDailySpreadMessages = <String>{
        ...dailySpreadIssues,
        ...dailySpreadBlockers.map((issue) => issue.message),
      }.toList(growable: false);
      final complete = placements.length == requestedCount && unscheduled.isEmpty &&
          allDailySpreadMessages.isEmpty;
      final blockers = scanIssues.where((issue) =>
          issue.severity == 'خطأ مانع' &&
          !(!complete && (issue.type == 'نقص الحصص' ||
              issue.type == 'توزيع المادة على كل أيام الأسبوع'))).toList();
      if (blockers.isNotEmpty) {
        final details = blockers.take(8).map((issue) => '• ${issue.type}: ${issue.message}').join('\n');
        throw StateError('أوقف الإصلاح لأن فحص التوزيع الجديد اكتشف أخطاء مانعة؛ لم تتغير النسخة الحالية:\n$details');
      }

      if (!mounted) return;
      final save = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          title: Text(complete ? 'التوزيع الجديد اجتاز فحص الإسناد' : 'التوزيع الجديد آمن لكنه غير مكتمل'),
          content: SizedBox(
            width: 460,
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('المطلوب: $requestedCount حصة'),
                Text('الموزع: ${placements.length} حصة'),
                Text('المتبقي: ${requestedCount - placements.length} حصة'),
                Text('عُقد البحث: $exploredNodes${searchLimitReached ? ' (وصل إلى حد البحث)' : ''}'),
                if (allDailySpreadMessages.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  const Text('تغطية الأيام تحتاج إلى استكمال', style: TextStyle(fontWeight: FontWeight.w800, color: Colors.deepOrange)),
                  ...allDailySpreadMessages.take(6).map((message) => Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text('• $message', style: const TextStyle(fontSize: 12)),
                  )),
                ],
                const SizedBox(height: 10),
                Text(complete
                  ? 'لم يجد فحص الإسناد مخالفات مانعة في التوزيع الجديد. ستُحفظ نسخة جديدة نشطة، وستبقى النسخة القديمة محفوظة.'
                  : 'لم تُسند جميع الحصص أو لم تستوفَ تغطية جميع الأيام بسبب القيود المسجلة. إذا حفظت، ستصبح النتيجة مسودة جديدة غير نشطة بعد التحقق من صلاحية الإسنادات. ستبقى النسخة القديمة محفوظة، ويمكنك مراجعة الحصص والتغطية المتبقية.'),
                if (unscheduled.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  const Text('أسباب الحصص المتبقية:', style: TextStyle(fontWeight: FontWeight.w800, color: Colors.deepOrange)),
                  ...unscheduled.take(6).map((reason) => Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Text('• $reason', style: const TextStyle(fontSize: 12)),
                  )),
                  if (unscheduled.length > 6) Text('... و${unscheduled.length - 6} أسباب أخرى'),
                ],
              ]),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء دون تغيير الجدول')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(complete ? 'حفظ النسخة المصححة' : 'حفظ كمسودة جديدة')),
          ],
        ),
      );
      if (save != true || !mounted) return;

      final year = (data['year'] as Map).cast<String, Object?>();
      final yearName = year['name']?.toString() ?? 'العام الدراسي';
      final versionId = await DatabaseService.instance.saveAsNewVersion(
        yearId: yearId,
        name: 'نسخة مصححة لصلاحيات المعلمين ${DateTime.now().toString().substring(0, 16)}',
        entries: placements,
        activate: complete,
        notes: complete
          ? 'توزيع جديد للعام $yearName بعد فحص قواعد المعلم والمادة والصف. عُقد البحث: $exploredNodes.'
          : 'توزيع جزئي جديد للعام $yearName؛ اجتاز فحص إسناد المعلم للمادة والصف. وُزعت ${placements.length} من $requestedCount حصة. المتبقي: ${requestedCount - placements.length}. تغطية الأيام الناقصة: ${allDailySpreadMessages.length}. مسودة غير نشطة؛ بقي الجدول السابق نشطاً. عُقد البحث: $exploredNodes.',
      );
      if (!mounted) return;
      setState(() {
        _future = _load();
        _scanned = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(complete
          ? 'تم إنشاء النسخة المصححة رقم $versionId وتفعيلها. النسخة السابقة محفوظة.'
          : requestedCount > placements.length
              ? 'تم إنشاء المسودة الجديدة رقم $versionId. بقيت ${requestedCount - placements.length} حصة غير موزعة؛ النسخة السابقة محفوظة.'
              : 'تم إنشاء المسودة الجديدة رقم $versionId. اكتمل عدد الحصص لكن تغطية الأيام تحتاج إلى مراجعة؛ النسخة السابقة محفوظة.'),
        duration: const Duration(seconds: 6),
      ));
    } catch (error) {
      if (mounted) {
        await showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('لم يكتمل إصلاح الجدول'),
            content: SelectableText('$error'),
            actions: [FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق'))],
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isRepairingSchedule = false);
    }
  }

  IconData _iconFor(String severity) => switch (severity) { 'خطأ مانع' => Icons.error_outline, 'تحذير' => Icons.warning_amber_outlined, _ => Icons.info_outline };
  Color _colorFor(String severity) => switch (severity) { 'خطأ مانع' => Colors.red.shade700, 'تحذير' => Colors.deepOrange.shade700, _ => const Color(0xFF2878C8) };
}

class _IssueSummary extends StatelessWidget {
  const _IssueSummary({required this.title, required this.value, required this.color, required this.icon});
  final String title; final int value; final Color color; final IconData icon;
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Row(children: [Icon(icon, color: color, size: 28), const SizedBox(width: 12), Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700))), Text('$value', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: color))])));
}

class _InfoPill extends StatelessWidget {
  const _InfoPill({required this.label, required this.value});
  final String label; final String value;
  @override
  Widget build(BuildContext context) => Chip(label: Text('$label: $value'), visualDensity: VisualDensity.compact);
}
