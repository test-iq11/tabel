import 'school_timetable_policy.dart';

/// Allows one necessary second occurrence when demand exceeds school days.
/// The extra lesson may use ANY two distinct permitted periods. A subject
/// blocked from period 5 or 6 must not become unschedulable solely because
/// an older implementation hard-coded period 6 for this exception.
class RequiredRepeatPolicy {
  const RequiredRepeatPolicy._();

  static bool allowsLatePeriodRepeat({
    required Map<String, Object?> requirement,
    required Map<String, Object?> section,
    required List<Map<String, Object?>> activeDays,
    required int sectionWeeklyDemand,
    required List<Map<String, Object?>> lessonSlots,
    required List<Map<String, Object?>> subjectBlockedSlots,
  }) {
    final weekly = _int(requirement['weekly_lessons']);
    if (activeDays.isEmpty || weekly <= activeDays.length ||
        _int(requirement['allow_same_day']) == 1) {
      return false;
    }

    final sectionLimitValue = _int(section['max_daily_lessons'], fallback: 6);
    final sectionDailyLimit = sectionLimitValue > 0
        ? sectionLimitValue
        : lessonSlots.length;
    if (sectionDailyLimit < 2) return false;

    final subjectId = _int(requirement['subject_id']);
    final blocked = <int>{
      for (final row in subjectBlockedSlots)
        if (_int(row['subject_id']) == subjectId) _int(row['slot_id']),
    };

    final seventhPeriodAllowed = SchoolTimetablePolicy.isSixthGrade(section) &&
        SchoolTimetablePolicy.normalDailyLimit(
          section: section,
          lessonSlotCount: lessonSlots.length,
        ) >= 6 &&
        lessonSlots.length >= 7 &&
        activeDays.any(SchoolTimetablePolicy.isSunday) &&
        sectionWeeklyDemand > activeDays.length * 6;
    final allowedSlotCount = lessonSlots.asMap().entries.where((entry) {
      final rank = entry.key;
      final withinNormalDay = rank < sectionDailyLimit && rank < 6;
      final exceptionalSeventh = rank == 6 && seventhPeriodAllowed;
      return (withinNormalDay || exceptionalSeventh) &&
          !blocked.contains(_int(entry.value['id']));
    }).length;
    return allowedSlotCount >= 2;
  }

  static int _int(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
