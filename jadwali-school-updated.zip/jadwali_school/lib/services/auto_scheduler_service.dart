/// محرك جدولة أسبوعية آلي يستخدم CSP مع اختيار المتطلب الأقل خيارات (MRV)
/// والتراجع المنظم. يوزّع المعلمين المؤهلين على الشعب وقتياً؛ لا يحتاج المستخدم
/// إلى إسناد المعلم إلى صف بعينه ما دام تأهيله للمادة مسجلاً.
class SchedulerResult {
  const SchedulerResult({
    required this.placements,
    required this.unscheduled,
    required this.requestedCount,
    required this.exploredNodes,
    required this.searchLimitReached,
  });

  final List<Map<String, Object?>> placements;
  final List<String> unscheduled;
  final int requestedCount;
  final int exploredNodes;
  final bool searchLimitReached;
  bool get complete => placements.length == requestedCount && unscheduled.isEmpty;
}

class _RequirementGroup {
  _RequirementGroup({
    required this.section,
    required this.requirement,
    required this.teachers,
    required this.total,
  }) : remaining = total;

  final Map<String, Object?> section;
  final Map<String, Object?> requirement;
  final List<Map<String, Object?>> teachers;
  final int total;
  int remaining;
  int lastGridRank = -1;

  int get sectionId => _integer(section['id'] ?? requirement['section_id']);
  int get subjectId => _integer(requirement['subject_id']);
  bool get allowSameDay => _integer(requirement['allow_same_day']) == 1;
  int get maxSubjectDaily => _integer(requirement['max_daily_lessons'], fallback: 2);
}

class _Candidate {
  const _Candidate({
    required this.group,
    required this.teacher,
    required this.day,
    required this.slot,
    required this.gridRank,
    required this.score,
  });

  final _RequirementGroup group;
  final Map<String, Object?> teacher;
  final Map<String, Object?> day;
  final Map<String, Object?> slot;
  final int gridRank;
  final int score;

  int get teacherId => _integer(teacher['id']);
  int get dayId => _integer(day['id']);
  int get slotId => _integer(slot['id']);
  int get teacherIdSort => teacherId;
}

class AutoSchedulerService {
  const AutoSchedulerService({this.nodeLimit = 30000});
  final int nodeLimit;

  SchedulerResult generate({
    required List<Map<String, Object?>> sections,
    required List<Map<String, Object?>> requirements,
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> qualifications,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    List<Map<String, Object?>> teacherAvailability = const [],
  }) {
    final enabledDays = days
        .where((d) => _integer(d['is_active'], fallback: 1) == 1)
        .toList()
      ..sort((a, b) => _integer(a['position']).compareTo(_integer(b['position'])));
    final lessonSlots = slots
        .where((s) => s['kind'] == 'lesson' && _integer(s['is_available'], fallback: 1) == 1)
        .toList()
      ..sort((a, b) => _integer(a['position']).compareTo(_integer(b['position'])));

    final requestedCount = requirements.fold<int>(
      0,
      (sum, r) => sum + _integer(r['weekly_lessons']).clamp(0, 1000).toInt(),
    );
    final sectionById = {for (final s in sections) _integer(s['id']): s};
    final teacherById = {for (final t in teachers) _integer(t['id']): t};
    final qualifiedIds = <int, List<int>>{};
    for (final qualification in qualifications) {
      final subjectId = _integer(qualification['subject_id']);
      final teacherId = _integer(qualification['teacher_id']);
      if (teacherById.containsKey(teacherId)) {
        (qualifiedIds[subjectId] ??= <int>[]).add(teacherId);
      }
    }
    final unavailable = <String>{
      for (final item in teacherAvailability)
        if (_integer(item['is_available'], fallback: 1) == 0)
          '${_integer(item['teacher_id'])}:${_integer(item['day_id'])}:${_integer(item['slot_id'])}',
    };
    final dayRank = {for (var i = 0; i < enabledDays.length; i++) _integer(enabledDays[i]['id']): i};
    final slotRank = {for (var i = 0; i < lessonSlots.length; i++) _integer(lessonSlots[i]['id']): i};

    final groups = <_RequirementGroup>[];
    for (final requirement in requirements) {
      final count = _integer(requirement['weekly_lessons']).clamp(0, 1000).toInt();
      if (count <= 0) continue;
      final sectionId = _integer(requirement['section_id']);
      final section = sectionById[sectionId];
      if (section == null) continue;
      final candidates = (qualifiedIds[_integer(requirement['subject_id'])] ?? const <int>[])
          .map((id) => teacherById[id])
          .whereType<Map<String, Object?>>()
          .toList();
      groups.add(_RequirementGroup(
        section: section,
        requirement: requirement,
        teachers: candidates,
        total: count,
      ));
    }

    final schedulableGroups = groups.where((g) => g.teachers.isNotEmpty && enabledDays.isNotEmpty && lessonSlots.isNotEmpty).toList();
    final schedulableCount = schedulableGroups.fold<int>(0, (sum, g) => sum + g.total);

    final sectionCells = <String>{};
    final teacherCells = <String>{};
    final teacherWeekly = <int, int>{};
    final teacherDaily = <String, int>{};
    final sectionDaily = <String, int>{};
    final subjectDaily = <String, int>{};
    final teacherDaySlotRanks = <String, List<int>>{};
    final placed = <Map<String, Object?>>[];
    var best = <Map<String, Object?>>[];
    var nodes = 0;
    var limitReached = false;
    var foundBestFeasible = false;

    String teacherDayKey(int teacherId, int dayId) => '$teacherId:$dayId';
    String sectionDayKey(int sectionId, int dayId) => '$sectionId:$dayId';
    String subjectDayKey(int sectionId, int subjectId, int dayId) => '$sectionId:$subjectId:$dayId';

    bool teacherConsecutiveAllowed(int teacherId, int dayId, int newSlotRank, int maxConsecutive) {
      if (maxConsecutive <= 0) return true;
      final values = [...(teacherDaySlotRanks[teacherDayKey(teacherId, dayId)] ?? const <int>[]), newSlotRank]..sort();
      var run = 1;
      var longest = 1;
      for (var i = 1; i < values.length; i++) {
        run = values[i] == values[i - 1] + 1 ? run + 1 : 1;
        if (run > longest) longest = run;
      }
      return longest <= maxConsecutive;
    }

    List<_Candidate> candidatesFor(_RequirementGroup group) {
      if (group.teachers.isEmpty || enabledDays.isEmpty || lessonSlots.isEmpty) return <_Candidate>[];
      final output = <_Candidate>[];
      for (final teacher in group.teachers) {
        final teacherId = _integer(teacher['id']);
        final weeklyLimit = _integer(teacher['weekly_load'], fallback: 24);
        if (weeklyLimit > 0 && (teacherWeekly[teacherId] ?? 0) >= weeklyLimit) continue;
        for (final day in enabledDays) {
          final dayId = _integer(day['id']);
          final dRank = dayRank[dayId] ?? 0;
          final tDayKey = teacherDayKey(teacherId, dayId);
          final sDayKey = sectionDayKey(group.sectionId, dayId);
          final subjectDayKeyValue = subjectDayKey(group.sectionId, group.subjectId, dayId);
          final currentTeacherDay = teacherDaily[tDayKey] ?? 0;
          final teacherDayLimit = _integer(teacher['max_daily_lessons'], fallback: 6);
          if (teacherDayLimit > 0 && currentTeacherDay >= teacherDayLimit) continue;
          final currentSectionDay = sectionDaily[sDayKey] ?? 0;
          final sectionLimit = _integer(group.section['max_daily_lessons'], fallback: 7);
          if (sectionLimit > 0 && currentSectionDay >= sectionLimit) continue;
          final currentSubjectDay = subjectDaily[subjectDayKeyValue] ?? 0;
          final subjectLimit = group.allowSameDay ? group.maxSubjectDaily : 1;
          if (currentSubjectDay >= (subjectLimit <= 0 ? 1 : subjectLimit)) continue;

          for (var sRank = 0; sRank < lessonSlots.length; sRank++) {
            final slot = lessonSlots[sRank];
            final slotId = _integer(slot['id']);
            final gridRank = dRank * lessonSlots.length + sRank;
            // الحصص المتكررة للمادة نفسها تُرتّب زمنياً لمنع بحث مكرر في تبديل نسخ متطابقة.
            if (gridRank <= group.lastGridRank) continue;
            if (sectionCells.contains('${group.sectionId}:$dayId:$slotId')) continue;
            if (teacherCells.contains('$teacherId:$dayId:$slotId')) continue;
            if (unavailable.contains('$teacherId:$dayId:$slotId')) continue;
            if (!teacherConsecutiveAllowed(teacherId, dayId, sRank, _integer(teacher['max_consecutive_lessons'], fallback: 0))) continue;

            // تفضيلات مرنة: موازنة نصاب المعلم، وتوزيع حصصه على اليوم، وتقليل الفجوات.
            var score = (teacherWeekly[teacherId] ?? 0) * 100;
            score += currentTeacherDay * 30;
            score += currentSectionDay * 15;
            score += currentSubjectDay * 1000;
            final positions = teacherDaySlotRanks[tDayKey] ?? const <int>[];
            if (positions.isNotEmpty) {
              final adjacent = positions.any((p) => (p - sRank).abs() == 1);
              score += adjacent ? -20 : 8;
            }
            score += gridRank;
            output.add(_Candidate(group: group, teacher: teacher, day: day, slot: slot, gridRank: gridRank, score: score));
          }
        }
      }
      output.sort((a, b) {
        final score = a.score.compareTo(b.score);
        if (score != 0) return score;
        final rank = a.gridRank.compareTo(b.gridRank);
        if (rank != 0) return rank;
        return a.teacherIdSort.compareTo(b.teacherIdSort);
      });
      return output;
    }

    void apply(_Candidate c) {
      final g = c.group;
      final t = c.teacherId;
      final d = c.dayId;
      final s = c.slotId;
      final sRank = slotRank[s] ?? 0;
      sectionCells.add('${g.sectionId}:$d:$s');
      teacherCells.add('$t:$d:$s');
      teacherWeekly[t] = (teacherWeekly[t] ?? 0) + 1;
      teacherDaily[teacherDayKey(t, d)] = (teacherDaily[teacherDayKey(t, d)] ?? 0) + 1;
      sectionDaily[sectionDayKey(g.sectionId, d)] = (sectionDaily[sectionDayKey(g.sectionId, d)] ?? 0) + 1;
      subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] = (subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] ?? 0) + 1;
      (teacherDaySlotRanks[teacherDayKey(t, d)] ??= <int>[]).add(sRank);
      g.remaining--;
      g.lastGridRank = c.gridRank;
      placed.add({
        'section_id': g.sectionId,
        'subject_id': g.subjectId,
        'teacher_id': t,
        'day_id': d,
        'slot_id': s,
        'room_id': null,
      });
    }

    void undo(_Candidate c, int oldLastGridRank) {
      final g = c.group;
      final t = c.teacherId;
      final d = c.dayId;
      final s = c.slotId;
      final sRank = slotRank[s] ?? 0;
      sectionCells.remove('${g.sectionId}:$d:$s');
      teacherCells.remove('$t:$d:$s');
      teacherWeekly[t] = (teacherWeekly[t] ?? 1) - 1;
      teacherDaily[teacherDayKey(t, d)] = (teacherDaily[teacherDayKey(t, d)] ?? 1) - 1;
      sectionDaily[sectionDayKey(g.sectionId, d)] = (sectionDaily[sectionDayKey(g.sectionId, d)] ?? 1) - 1;
      subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] = (subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] ?? 1) - 1;
      teacherDaySlotRanks[teacherDayKey(t, d)]?.remove(sRank);
      g.remaining++;
      g.lastGridRank = oldLastGridRank;
      placed.removeLast();
    }

    void search() {
      if (foundBestFeasible || limitReached) return;
      nodes++;
      if (placed.length > best.length) {
        best = placed.map((e) => Map<String, Object?>.from(e)).toList();
      }
      if (placed.length == schedulableCount && schedulableGroups.every((g) => g.remaining == 0)) {
        foundBestFeasible = true;
        return;
      }
      if (nodes >= nodeLimit) {
        limitReached = true;
        return;
      }

      _RequirementGroup? selected;
      List<_Candidate> selectedCandidates = <_Candidate>[];
      var smallestOptions = 1 << 30;
      for (final group in schedulableGroups) {
        if (group.remaining <= 0) continue;
        final options = candidatesFor(group);
        if (options.isEmpty) return; // قيد مسدود في هذه الحالة؛ ارجع للفرع السابق.
        if (options.length < smallestOptions) {
          selected = group;
          selectedCandidates = options;
          smallestOptions = options.length;
          if (smallestOptions == 1) break;
        }
      }
      if (selected == null) return;
      for (final candidate in selectedCandidates) {
        final oldLast = selected.lastGridRank;
        apply(candidate);
        search();
        undo(candidate, oldLast);
        if (foundBestFeasible || limitReached) return;
      }
    }

    search();
    final placedCounts = <String, int>{};
    for (final placement in best) {
      final key = '${placement['section_id']}:${placement['subject_id']}';
      placedCounts[key] = (placedCounts[key] ?? 0) + 1;
    }
    final unscheduled = <String>[];
    for (final requirement in requirements) {
      final sectionId = _integer(requirement['section_id']);
      final subjectId = _integer(requirement['subject_id']);
      final required = _integer(requirement['weekly_lessons']).clamp(0, 1000).toInt();
      final completed = placedCounts['$sectionId:$subjectId'] ?? 0;
      final section = sectionById[sectionId];
      for (var n = completed; n < required; n++) {
        final label = '${section?['grade_name'] ?? ''} ${section?['section_name'] ?? section?['name'] ?? 'الشعبة $sectionId'} / ${requirement['subject_name'] ?? 'المادة $subjectId'}'.trim();
        final possibleTeachers = qualifiedIds[subjectId] ?? const <int>[];
        final reason = section == null
            ? 'الشعبة غير موجودة.'
            : possibleTeachers.isEmpty
                ? 'لا يوجد معلم مؤهل لهذه المادة. أضف المادة إلى اختصاصات أحد المعلمين.'
                : enabledDays.isEmpty || lessonSlots.isEmpty
                    ? 'لا توجد أيام دوام أو فترات تدريس متاحة.'
                    : 'لم يُعثر على مكان ومعلم يحققان القيود؛ قد يكون النصاب أو عدد الفترات غير كافٍ أو بلغ البحث حده.';
        unscheduled.add('$label: الحصة ${n + 1} غير موزعة — $reason');
      }
    }
    return SchedulerResult(
      placements: best,
      unscheduled: unscheduled,
      requestedCount: requestedCount,
      exploredNodes: nodes,
      searchLimitReached: limitReached,
    );
  }
}

int _integer(Object? value, {int fallback = 0}) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse('$value') ?? fallback;
}
