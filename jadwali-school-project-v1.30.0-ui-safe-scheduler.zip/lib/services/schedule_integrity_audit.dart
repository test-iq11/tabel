/// Fast, independent structural audit of a proposed complete timetable.
///
/// This does not replace ConflictDetectionService (which knows subject,
/// teacher availability, daily and seventh-period policies). It is a second
/// defensive gate, intentionally independent of the search strategies.
/// It never changes the timetable and never claims that a partial search is
/// proof of infeasibility.
class ScheduleIntegrityAudit {
  const ScheduleIntegrityAudit();

  List<String> inspect(
    Map<String, Object?> input,
    List<Map<String, Object?>> placements,
  ) {
    List<Map<String, Object?>> rows(String name) =>
        (input[name] as List? ?? const [])
            .map((value) => Map<String, Object?>.from(value as Map))
            .toList();
    int n(Object? value) => value is num
        ? value.toInt()
        : int.tryParse('$value') ?? 0;
    final problems = <String>[];
    final activeDays = {
      for (final day in rows('days'))
        if (n(day['is_active'] ?? 1) == 1) n(day['id']),
    };
    final validSlots = {
      for (final slot in rows('slots'))
        if (slot['kind'] == 'lesson' && n(slot['is_available'] ?? 1) == 1)
          n(slot['id']),
    };
    final validSections = {for (final section in rows('sections')) n(section['id'])};
    final validTeachers = {for (final teacher in rows('teachers')) n(teacher['id'])};
    String lessonKey(Map<String, Object?> r) =>
        '${n(r['section_id'])}:${n(r['subject_id'])}';
    String placementKey(Map<String, Object?> r) => [
      'section_id', 'subject_id', 'teacher_id', 'day_id', 'slot_id', 'room_id',
    ].map((key) => '${r[key] ?? ''}').join(':');

    final required = <String, int>{};
    for (final r in rows('requirements')) {
      final key = lessonKey(r);
      required[key] = (required[key] ?? 0) + n(r['weekly_lessons']);
    }
    final placed = <String, int>{};
    final sectionCells = <String>{};
    final teacherCells = <String>{};
    final roomCells = <String>{};
    for (final p in placements) {
      final s = n(p['section_id']), t = n(p['teacher_id']);
      final d = n(p['day_id']), period = n(p['slot_id']);
      final room = n(p['room_id']);
      final lesson = lessonKey(p);
      placed[lesson] = (placed[lesson] ?? 0) + 1;
      if (!validSections.contains(s) || !validTeachers.contains(t) ||
          !activeDays.contains(d) || !validSlots.contains(period)) {
        problems.add('حصة تشير إلى معلم أو شعبة أو فترة غير صالحة.');
      }
      if (!sectionCells.add('$s:$d:$period')) {
        problems.add('تعارض شعبة في الوقت نفسه.');
      }
      if (!teacherCells.add('$t:$d:$period')) {
        problems.add('تعارض معلم في الوقت نفسه.');
      }
      if (room > 0 && !roomCells.add('$room:$d:$period')) {
        problems.add('تعارض قاعة في الوقت نفسه.');
      }
      if (!required.containsKey(lesson)) {
        problems.add('حصة لم تُسجّل ضمن الحصص المطلوبة.');
      }
    }
    for (final r in required.entries) {
      if ((placed[r.key] ?? 0) != r.value) {
        problems.add('عدد حصص إحدى المواد لا يطابق النصاب المطلوب.');
      }
    }
    final keys = placements.map(placementKey).toSet();
    for (final locked in rows('lockedPlacements')) {
      if (!keys.contains(placementKey(locked))) {
        problems.add('حصة مقفلة غائبة أو تغير موضعها.');
      }
    }
    return problems.toSet().toList(growable: false);
  }

  bool accepts(Map<String, Object?> input, List<Map<String, Object?>> entries) =>
      inspect(input, entries).isEmpty;
}
