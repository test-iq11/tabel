import 'package:flutter/material.dart';

/// The five coordinated palettes from the HTML design preview.
class JadwaliPalettes {
  const JadwaliPalettes._();
  static const palettes = <String, (String, Color, Color)> {
    'indigo': ('نيلي', Color(0xff525fe8), Color(0xff9299f9)),
    'teal': ('فيروزي', Color(0xff058f93), Color(0xff58c7be)),
    'purple': ('بنفسجي', Color(0xff8754be), Color(0xffc093e8)),
    'blue': ('أزرق', Color(0xff277bc9), Color(0xff83c1ed)),
    'coral': ('مرجاني', Color(0xffd66d79), Color(0xfff3a48b)),
  };
}
