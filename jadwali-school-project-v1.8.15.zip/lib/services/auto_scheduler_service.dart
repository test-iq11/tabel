import 'teacher_assignment_policy.dart';
import 'required_repeat_policy.dart';
import 'school_timetable_policy.dart';

/// محرك جدولة أسبوعية آلي يستخدم CSP مع اختيار المتطلب الأقل خيارات (MRV)
/// والتراجع المنظم. يراعي تأهيل المعلم للمادة وصلاحية المادة في صف الشعبة.
class SchedulerResult {
  const SchedulerResult({
    required this.placements,
    required this.unscheduled,
    required this.requestedCount,
    required this.exploredNodes,
    required this.searchLimitReached,
    this.dailySpreadIssues = const [],
  });

  final List<Map<String, Object?>> placements;
  final List<String> unscheduled;
  /// Coverage violations remain separate from unplaced lesson counts. A result
  /// can place every requested lesson and still be incomplete if a subject
  /// required on every active day is missing from one or more days.
  final List<String> dailySpreadIssues;
  final int requestedCount;
  final int exploredNodes;
  final bool searchLimitReached;
  bool get complete => placements.length == requestedCount &&
      unscheduled.isEmpty && dailySpreadIssues.isEmpty;
}

class _RequirementGroup {
  _RequirementGroup({
    required this.section,
    required this.requirement,
    required this.teachers,
    required this.total,
    required this.requiredLatePeriodRepeat,
  }) : remaining = total;

  final Map<String, Object?> section;
  final Map<String, Object?> requirement;
  final List<Map<String, Object?>> teachers;
  final int total;
  /// True only for a necessary exception: weekly demand exceeds active days,
  /// the saved same-day-repeat switch is off, and a valid late-period slot exists.
  final bool requiredLatePeriodRepeat;
  int remaining;
  int lastGridRank = -1;

  int get sectionId => _integer(section['id'] ?? requirement['section_id']);
  int get subjectId => _integer(requirement['subject_id']);
  bool get allowSameDay => _integer(requirement['allow_same_day']) == 1;
  int get maxSubjectDaily => _integer(requirement['max_daily_lessons'], fallback: 2);
}

class _Candidate {
  const _Candidate({
    required this.group,
    required this.teacher,
    required this.day,
    required this.slot,
    required this.gridRank,
    required this.score,
  });

  final _RequirementGroup group;
  final Map<String, Object?> teacher;
  final Map<String, Object?> day;
  final Map<String, Object?> slot;
  final int gridRank;
  final int score;

  int get teacherId => _integer(teacher['id']);
  int get dayId => _integer(day['id']);
  int get slotId => _integer(slot['id']);
  int get teacherIdSort => teacherId;
}

class AutoSchedulerService {
  const AutoSchedulerService({this.nodeLimit = 120000});
  final int nodeLimit;

  SchedulerResult generate({
    required List<Map<String, Object?>> sections,
    required List<Map<String, Object?>> requirements,
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> qualifications,
    List<Map<String, Object?>> teacherGrades = const [],
    List<Map<String, Object?>> teacherSubjectGrades = const [],
    List<Map<String, Object?>> subjectBlockedSlots = const [],
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    List<Map<String, Object?>> teacherAvailability = const [],
  }) {
    // The UI calls this engine with a large legacy node limit. Cap it here so
    // unusually flexible school data cannot trigger a long exhaustive search.
    // Smaller limits supplied by tests/callers are respected unchanged.
    final effectiveNodeLimit = nodeLimit.clamp(1, 30000).toInt();
    final improvementNodeBudget = (effectiveNodeLimit ~/ 15).clamp(200, 1800).toInt();
    final enabledDays = days
        .where((d) => _integer(d['is_active'], fallback: 1) == 1)
        .toList()
      ..sort((a, b) => _integer(a['position']).compareTo(_integer(b['position'])));
    final lessonSlots = slots
        .where((s) => s['kind'] == 'lesson' && _integer(s['is_available'], fallback: 1) == 1)
        .toList()
      ..sort((a, b) => _integer(a['position']).compareTo(_integer(b['position'])));

    final requestedCount = requirements.fold<int>(
      0,
      (sum, r) => sum + _integer(r['weekly_lessons']).clamp(0, 1000).toInt(),
    );
    final sectionById = {for (final s in sections) _integer(s['id']): s};
    final teacherById = {for (final t in teachers) _integer(t['id']): t};
    final qualifiedIds = <int, List<int>>{};
    for (final qualification in qualifications) {
      final subjectId = _integer(qualification['subject_id']);
      final teacherId = _integer(qualification['teacher_id']);
      if (teacherById.containsKey(teacherId)) {
        (qualifiedIds[subjectId] ??= <int>[]).add(teacherId);
      }
    }
    final assignmentPolicy = TeacherAssignmentPolicy(
      qualifications: qualifications,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
    );
    bool teacherCanTeachSubjectGrade(int teacherId, int subjectId, Map<String, Object?>? section) =>
        section != null && assignmentPolicy.isGradeAllowed(
          teacherId, subjectId, _integer(section['grade_id']),
        );
    final eligibleTeacherCache = <String, List<int>>{};
    List<int> eligibleTeacherIdsFor(int subjectId, Map<String, Object?>? section) {
      if (section == null) return const <int>[];
      final cacheKey = '${_integer(section['id'])}:$subjectId';
      return eligibleTeacherCache.putIfAbsent(cacheKey, () =>
          (qualifiedIds[subjectId] ?? const <int>[])
              .where((id) => teacherCanTeachSubjectGrade(id, subjectId, section))
              .toList(growable: false));
    }
    final blockedSubjectSlotPairs = <String>{
      for (final item in subjectBlockedSlots)
        '${_integer(item['subject_id'])}:${_integer(item['slot_id'])}',
    };
    int weeklyDemandForSection(int sectionId) => requirements
        .where((row) => _integer(row['section_id']) == sectionId)
        .fold<int>(0, (sum, row) =>
            sum + _integer(row['weekly_lessons']).clamp(0, 1000).toInt());

    bool hasNecessaryLatePeriodRepeat(Map<String, Object?> requirement) {
      final section = sectionById[_integer(requirement['section_id'])];
      if (section == null) return false;
      return RequiredRepeatPolicy.allowsLatePeriodRepeat(
        requirement: requirement,
        section: section,
        activeDays: enabledDays,
        sectionWeeklyDemand: weeklyDemandForSection(_integer(requirement['section_id'])),
        lessonSlots: lessonSlots,
        subjectBlockedSlots: subjectBlockedSlots,
      );
    }

    // Preserve every requested lesson. If the subject is required more often
    // than there are active weekdays, allow the necessary extra occurrence
    // only when it can be put in period 6 (or an already-authorized period 7).
    final maxSchedulableCache = <String, int>{};
    int maxSchedulableForRequirement(Map<String, Object?> requirement) {
      final cacheKey = '${_integer(requirement['section_id'])}:${_integer(requirement['subject_id'])}';
      final cached = maxSchedulableCache[cacheKey];
      if (cached != null) return cached;
      if (enabledDays.isEmpty || lessonSlots.isEmpty) {
        maxSchedulableCache[cacheKey] = 0;
        return 0;
      }
      final subjectId = _integer(requirement['subject_id']);
      final allowSameDay = _integer(requirement['allow_same_day']) == 1;
      final configuredMax = _integer(requirement['max_daily_lessons'], fallback: 2);
      final necessaryRepeat = hasNecessaryLatePeriodRepeat(requirement);
      final subjectDailyLimit = allowSameDay
          ? (configuredMax > 0 ? configuredMax : 1)
          : (necessaryRepeat ? 2 : 1);
      final subjectAvailableSlots = lessonSlots.where((slot) =>
          !blockedSubjectSlotPairs.contains('$subjectId:${_integer(slot['id'])}')).length;
      final effectiveDailyLimit = subjectDailyLimit < subjectAvailableSlots
          ? subjectDailyLimit
          : subjectAvailableSlots;
      final result = enabledDays.length * effectiveDailyLimit;
      maxSchedulableCache[cacheKey] = result;
      return result;
    }
    final unavailable = <String>{
      for (final item in teacherAvailability)
        if (_integer(item['is_available'], fallback: 1) == 0)
          '${_integer(item['teacher_id'])}:${_integer(item['day_id'])}:${_integer(item['slot_id'])}',
    };
    // حد أدنى مضمون لنصاب المعلم: المتطلبات التي لا يوجد لها سوى معلم مؤهل واحد.
    final mandatoryDemandByTeacher = <int, int>{};
    for (final requirement in requirements) {
      final requested = _integer(requirement['weekly_lessons']).clamp(0, 1000).toInt();
      if (requested <= 0) continue;
      final count = requested < maxSchedulableForRequirement(requirement)
          ? requested
          : maxSchedulableForRequirement(requirement);
      if (count <= 0) continue;
      final section = sectionById[_integer(requirement['section_id'])];
      final eligible = eligibleTeacherIdsFor(_integer(requirement['subject_id']), section);
      if (eligible.length == 1) {
        mandatoryDemandByTeacher[eligible.single] = (mandatoryDemandByTeacher[eligible.single] ?? 0) + count;
      }
    }
    final mandatoryTeacherCapacityIssue = <int, String>{};
    for (final teacherEntry in mandatoryDemandByTeacher.entries) {
      final teacher = teacherById[teacherEntry.key];
      final weeklyLimit = teacher == null ? 0 : _integer(teacher['weekly_load'], fallback: 24);
      if (teacher != null && weeklyLimit > 0 && teacherEntry.value > weeklyLimit) {
        mandatoryTeacherCapacityIssue[teacherEntry.key] = 'المعلم ${teacher['name']} هو الوحيد المؤهل لمتطلبات مجموعها ${teacherEntry.value} حصة أسبوعياً، بينما النصاب المسجل له $weeklyLimit فقط. أضف معلماً مؤهلاً بديلاً لبعض الشعب أو صحّح النصاب إذا كان مسجلاً خطأً.';
      }
    }
    final dayRank = {for (var i = 0; i < enabledDays.length; i++) _integer(enabledDays[i]['id']): i};
    final slotRank = {for (var i = 0; i < lessonSlots.length; i++) _integer(lessonSlots[i]['id']): i};
    // Rotate the preferred period for each subject through the school week.
    // Using a stable subject order (instead of raw database IDs) keeps the
    // result consistent even if IDs are not consecutive.
    final orderedSubjectIds = requirements
        .map((row) => _integer(row['subject_id']))
        .toSet()
        .toList()
      ..sort();
    final subjectRotationOffset = <int, int>{
      for (var i = 0; i < orderedSubjectIds.length; i++) orderedSubjectIds[i]: i,
    };
    final subjectNameById = <int, String>{
      for (final row in requirements)
        _integer(row['subject_id']):
            (row['subject_name'] ?? row['name'] ?? 'مادة ${_integer(row['subject_id'])}').toString(),
    };

    // تقدير سعة كل شعبة قبل البحث. يمنع استنزاف البحث عندما تكون الحصص المطلوبة
    // أكثر من الخانات المتاحة أصلاً، ويتيح توزيع بقية المواد بدلاً من التوقف بلا تفسير.
    final sectionCapacity = <int, int>{};
    final sectionDemand = <int, int>{};
    final sectionDailyLimitById = <int, int>{};
    final sectionAllowsSeventhById = <int, bool>{};
    final sectionCapacityMessage = <int, String>{};
    final requirementRowsBySection = <int, List<Map<String, Object?>>>{};
    for (final requirement in requirements) {
      final sectionId = _integer(requirement['section_id']);
      (requirementRowsBySection[sectionId] ??= <Map<String, Object?>>[]).add(requirement);
      sectionDemand[sectionId] = (sectionDemand[sectionId] ?? 0) +
          _integer(requirement['weekly_lessons']).clamp(0, 1000).toInt();
    }
    final slotsPerDay = lessonSlots.length;
    for (final section in sections) {
      final sectionId = _integer(section['id']);
      final configuredDailyLimit = _integer(section['max_daily_lessons'], fallback: 6);
      final configuredCapacity = configuredDailyLimit > 0
          ? (configuredDailyLimit < slotsPerDay ? configuredDailyLimit : slotsPerDay)
          : slotsPerDay;
      // Keep the normal daily limit at six. The seventh period contributes at
      // most one extra cell for sixth grade on Sunday, and only if required.
      final standardDailyLimit = configuredCapacity < 6 ? configuredCapacity : 6;
      final demand = sectionDemand[sectionId] ?? 0;
      final needsSeventh = SchoolTimetablePolicy.isSixthGrade(section) &&
          enabledDays.any(SchoolTimetablePolicy.isSunday) &&
          slotsPerDay >= 7 && standardDailyLimit >= 6 &&
          demand > enabledDays.length * 6;
      final effectiveDailyLimit = standardDailyLimit;
      sectionAllowsSeventhById[sectionId] = needsSeventh;
      sectionDailyLimitById[sectionId] = effectiveDailyLimit;
      final capacity = enabledDays.length * effectiveDailyLimit + (needsSeventh ? 1 : 0);
      sectionCapacity[sectionId] = capacity;
      if (demand > capacity) {
        final stage = (section['stage_name'] ?? '').toString().trim();
        final grade = (section['grade_name'] ?? 'صف غير محدد').toString().trim();
        final sectionName = (section['section_name'] ?? section['name'] ?? 'غير محددة').toString().trim();
        final location = [if (stage.isNotEmpty) 'المرحلة $stage', 'الصف $grade', 'الشعبة $sectionName'].join('، ');
        final capacityExplanation = needsSeventh
            ? '${enabledDays.length} أيام × $effectiveDailyLimit حصص، مع حصة سابعة إضافية يوم الأحد للصف السادس فقط'
            : '${enabledDays.length} أيام × $effectiveDailyLimit حصص يومياً';
        sectionCapacityMessage[sectionId] = '$location: مجموع المطلوب $demand حصة أسبوعياً، لكن المتاح $capacity خانة فقط '
            '($capacityExplanation). زد عدد الفترات المتاحة أو خفّض المتطلبات حتى يصبح المجموع ضمن السعة.';
      }
    }

    // إذا تجاوزت متطلبات الشعبة سعتها، نخصّص الخانات أولاً للمواد ذات المعلمين
    // الأقل عدداً. تبقى الحصص التي لم تحصل على خانة ضمن تقرير غير الموزع.
    final targetCountByRequirement = <String, int>{};
    for (final sectionEntry in requirementRowsBySection.entries) {
      final sectionId = sectionEntry.key;
      final rows = sectionEntry.value;
      final capacity = sectionCapacity[sectionId] ?? 0;
      final demand = sectionDemand[sectionId] ?? 0;
      if (demand <= capacity) {
        for (final row in rows) {
          final key = '$sectionId:${_integer(row['subject_id'])}';
          final requested = _integer(row['weekly_lessons']).clamp(0, 1000).toInt();
          final ruleMaximum = maxSchedulableForRequirement(row);
          targetCountByRequirement[key] = requested < ruleMaximum ? requested : ruleMaximum;
        }
        continue;
      }
      for (final row in rows) {
        final key = '$sectionId:${_integer(row['subject_id'])}';
        targetCountByRequirement[key] = 0;
      }
      final section = sectionById[sectionId];
      final eligibleRows = rows.where((row) =>
          _integer(row['weekly_lessons']) > 0 &&
          maxSchedulableForRequirement(row) > 0 &&
          eligibleTeacherIdsFor(_integer(row['subject_id']), section).isNotEmpty).toList();
      int effectiveRequest(Map<String, Object?> row) {
        final weekly = _integer(row['weekly_lessons']).clamp(0, 1000).toInt();
        final maximum = maxSchedulableForRequirement(row);
        return weekly < maximum ? weekly : maximum;
      }
      eligibleRows.sort((a, b) {
        // Coverage is the first priority when capacity is insufficient: a
        // 5+ lesson subject should receive enough slots to reach every active
        // day before flexible low-frequency lessons consume the same capacity.
        final aCoverage = _integer(a['weekly_lessons']) >= 5 ? 0 : 1;
        final bCoverage = _integer(b['weekly_lessons']) >= 5 ? 0 : 1;
        final coverageOrder = aCoverage.compareTo(bCoverage);
        if (coverageOrder != 0) return coverageOrder;
        // Among equally important requests, protect the requirements having
        // the fewest qualified teachers first.
        final aTeacherCount = eligibleTeacherIdsFor(_integer(a['subject_id']), section).length;
        final bTeacherCount = eligibleTeacherIdsFor(_integer(b['subject_id']), section).length;
        final scarcity = aTeacherCount.compareTo(bTeacherCount);
        if (scarcity != 0) return scarcity;
        final demandOrder = _integer(b['weekly_lessons']).compareTo(_integer(a['weekly_lessons']));
        if (demandOrder != 0) return demandOrder;
        return _integer(a['subject_id']).compareTo(_integer(b['subject_id']));
      });
      var budget = capacity;
      // Pass one reserves a coverage floor for each 5+ lesson subject. If the
      // section capacity cannot cover all such floors, scarcity order decides
      // which requirements are preserved first; any shortfall stays explicit.
      for (final row in eligibleRows.where((r) => _integer(r['weekly_lessons']) >= 5)) {
        final key = '$sectionId:${_integer(row['subject_id'])}';
        final desired = effectiveRequest(row) < enabledDays.length
            ? effectiveRequest(row)
            : enabledDays.length;
        final reserved = desired < budget ? desired : budget;
        targetCountByRequirement[key] = reserved;
        budget -= reserved;
      }
      // Pass two distributes remaining capacity, continuing high-priority
      // coverage subjects before shorter weekly requirements.
      for (final row in eligibleRows) {
        final key = '$sectionId:${_integer(row['subject_id'])}';
        final current = targetCountByRequirement[key] ?? 0;
        final additionalDemand = effectiveRequest(row) - current;
        if (additionalDemand <= 0 || budget <= 0) continue;
        final additional = additionalDemand < budget ? additionalDemand : budget;
        targetCountByRequirement[key] = current + additional;
        budget -= additional;
      }
    }

    final groups = <_RequirementGroup>[];
    for (final requirement in requirements) {
      final requested = _integer(requirement['weekly_lessons']).clamp(0, 1000).toInt();
      if (requested <= 0) continue;
      final sectionId = _integer(requirement['section_id']);
      final section = sectionById[sectionId];
      if (section == null) continue;
      final target = targetCountByRequirement['$sectionId:${_integer(requirement['subject_id'])}'] ?? requested;
      if (target <= 0) continue;
      final candidates = eligibleTeacherIdsFor(_integer(requirement['subject_id']), section)
          .map((id) => teacherById[id])
          .whereType<Map<String, Object?>>()
          .toList();
      if (candidates.isEmpty) continue;
      groups.add(_RequirementGroup(
        section: section,
        requirement: requirement,
        teachers: candidates,
        total: target,
        requiredLatePeriodRepeat: target > enabledDays.length &&
            _integer(requirement['allow_same_day']) != 1 &&
            hasNecessaryLatePeriodRepeat(requirement),
      ));
    }

    // Keep requirements schedulable even when their count cannot cover every
    // active day. In that case the solver preserves the usable lessons, reports
    // the impossible coverage explicitly, and the UI saves only an inactive draft.
    final schedulableGroups = groups.where((g) =>
      enabledDays.isNotEmpty && lessonSlots.isNotEmpty
    ).toList();
    final schedulableCount = schedulableGroups.fold<int>(0, (sum, g) => sum + g.total);

    final sectionCells = <String>{};
    // Counts are required because the emergency sixth-period fallback may
    // intentionally place one teacher on two sections in the same time cell.
    final teacherCells = <String, int>{};
    var allowEmergencySixthPeriodConflicts = false;
    final teacherWeekly = <int, int>{};
    final teacherDaily = <String, int>{};
    final sectionDaily = <String, int>{};
    final subjectDaily = <String, int>{};
    // Fairness counters: avoid assigning a subject to the same period on
    // adjacent school days, and spread each subject across periods over a week.
    final subjectPositionUsage = <String, int>{};
    final subjectPositionByDay = <String, int>{};
    final teacherDaySlotRanks = <String, List<int>>{};
    final placed = <Map<String, Object?>>[];
    var best = <Map<String, Object?>>[];
    var bestPartialScore = 1 << 62;
    var nodes = 0;
    var limitReached = false;
    int? firstCompleteNode;
    var runningScore = 0;
    var bestCompleteScore = 1 << 62;
    var bestComplete = <Map<String, Object?>>[];

    String teacherDayKey(int teacherId, int dayId) => '$teacherId:$dayId';
    String sectionDayKey(int sectionId, int dayId) => '$sectionId:$dayId';
    String subjectDayKey(int sectionId, int subjectId, int dayId) => '$sectionId:$subjectId:$dayId';

    bool teacherConsecutiveAllowed(int teacherId, int dayId, int newSlotRank, int maxConsecutive) {
      if (maxConsecutive <= 0) return true;
      final values = [...(teacherDaySlotRanks[teacherDayKey(teacherId, dayId)] ?? const <int>[]), newSlotRank]..sort();
      var run = 1;
      var longest = 1;
      for (var i = 1; i < values.length; i++) {
        run = values[i] == values[i - 1] + 1 ? run + 1 : 1;
        if (run > longest) longest = run;
      }
      return longest <= maxConsecutive;
    }

    List<_Candidate> candidatesFor(_RequirementGroup group) {
      if (group.teachers.isEmpty || enabledDays.isEmpty || lessonSlots.isEmpty) return <_Candidate>[];
      final output = <_Candidate>[];
      for (final teacher in group.teachers) {
        final teacherId = _integer(teacher['id']);
        // group.teachers is cached and prefiltered through both subject
        // qualification and the teacher-subject-grade assignment policy.
        final weeklyLimit = _integer(teacher['weekly_load'], fallback: 24);
        if (weeklyLimit > 0 && (teacherWeekly[teacherId] ?? 0) >= weeklyLimit) continue;
        for (final day in enabledDays) {
          final dayId = _integer(day['id']);
          final dRank = dayRank[dayId] ?? 0;
          final tDayKey = teacherDayKey(teacherId, dayId);
          final sDayKey = sectionDayKey(group.sectionId, dayId);
          final subjectDayKeyValue = subjectDayKey(group.sectionId, group.subjectId, dayId);
          final currentTeacherDay = teacherDaily[tDayKey] ?? 0;
          final teacherDayLimit = _integer(teacher['max_daily_lessons'], fallback: 6);
          if (teacherDayLimit > 0 && currentTeacherDay >= teacherDayLimit) continue;
          final currentSectionDay = sectionDaily[sDayKey] ?? 0;
          final sectionLimit = sectionDailyLimitById[group.sectionId] ?? (slotsPerDay < 6 ? slotsPerDay : 6);
          final dayAllowsSeventh = (sectionAllowsSeventhById[group.sectionId] ?? false) &&
              SchoolTimetablePolicy.isSunday(day);
          final dailySectionLimit = dayAllowsSeventh ? 7 : sectionLimit;
          if (dailySectionLimit > 0 && currentSectionDay >= dailySectionLimit) continue;
          final currentSubjectDay = subjectDaily[subjectDayKeyValue] ?? 0;
          final requiresEveryDay = _integer(group.requirement['weekly_lessons']) >= 5;
          final missingSubjectDays = requiresEveryDay
              ? enabledDays.where((candidateDay) =>
                  (subjectDaily[subjectDayKey(group.sectionId, group.subjectId, _integer(candidateDay['id']))] ?? 0) == 0).length
              : 0;
          // Do not repeat a subject on an already-covered day until each other
          // active day has one lesson, unless the remaining count makes that
          // impossible (in that case the branch itself is rejected).
          if (requiresEveryDay && currentSubjectDay > 0 &&
              group.remaining <= missingSubjectDays) {
            continue;
          }
          final subjectLimit = group.allowSameDay
              ? group.maxSubjectDaily
              : (group.requiredLatePeriodRepeat ? 2 : 1);
          if (currentSubjectDay >= (subjectLimit <= 0 ? 1 : subjectLimit)) continue;

          for (var sRank = 0; sRank < lessonSlots.length; sRank++) {
            // A necessary second lesson goes in period 6/7. Reserve early
            // periods for the normal daily occurrence; never silently place an
            // implicit duplicate in periods 1-5.
            if (group.requiredLatePeriodRepeat) {
              if (currentSubjectDay == 0 && sRank >= 5) continue;
              if (currentSubjectDay > 0 && sRank < 5) continue;
            }
            // Never use period seven merely because it exists in settings.
            // Only the sixth grade on Sunday may use it, when section demand
            // exceeds six per active day and the six normal periods are allowed.
            if (sRank >= 6 && !(dayAllowsSeventh && sRank == 6)) continue;
            if (sRank >= dailySectionLimit) continue;
            final slot = lessonSlots[sRank];
            final slotId = _integer(slot['id']);
            final gridRank = dRank * lessonSlots.length + sRank;
            // الحصص المتكررة للمادة نفسها تُرتّب زمنياً لمنع بحث مكرر في تبديل نسخ متطابقة.
            // The exceptional seventh period is on Sunday, so its grid rank
            // can be earlier than already-placed lessons later in the week.
            // Permit this single intentional back-step for a required repeat.
            final seventhOnSundayForRepeatedSubject = sRank == 6 && dayAllowsSeventh &&
                currentSubjectDay > 0 && group.requiredLatePeriodRepeat;
            // For 5+ weekly lessons, coverage of every weekday outranks the
            // chronological de-duplication shortcut. Otherwise a high-scoring
            // late weekday could be chosen first and permanently exclude an
            // earlier still-missing day from this requirement.
            final requiresDailyCoverage = _integer(group.requirement['weekly_lessons']) >= 5;
            if (gridRank <= group.lastGridRank &&
                !seventhOnSundayForRepeatedSubject && !requiresDailyCoverage) continue;
            if (sectionCells.contains('${group.sectionId}:$dayId:$slotId')) continue;
            if (blockedSubjectSlotPairs.contains('${group.subjectId}:$slotId')) continue;
            final teacherCellKey = '$teacherId:$dayId:$slotId';
            final hasTeacherCollision = (teacherCells[teacherCellKey] ?? 0) > 0;
            // First pass remains fully conflict-free. Only if that search fails
            // do we allow an unavoidable teacher overlap in period six.
            if (hasTeacherCollision &&
                !(allowEmergencySixthPeriodConflicts && sRank == 5)) continue;
            if (unavailable.contains('$teacherId:$dayId:$slotId')) continue;
            if (!teacherConsecutiveAllowed(teacherId, dayId, sRank, _integer(teacher['max_consecutive_lessons'], fallback: 0))) continue;

            // Soft fairness objective. The desired period rotates by one slot
            // each school day and each subject gets a stable starting offset.
            // This is a preference only: if constraints make it impossible, the
            // scheduler may reuse a period rather than leave a lesson unplaced.
            final sectionSubjectPrefix = '${group.sectionId}:${group.subjectId}';
            final periodCount = (sectionDailyLimitById[group.sectionId] ?? 6)
                .clamp(1, lessonSlots.length < 6 ? lessonSlots.length : 6)
                .toInt();
            final rotationOffset = subjectRotationOffset[group.subjectId] ?? 0;
            final preferredRank = (rotationOffset + dRank) % periodCount;
            final forwardDistance = (sRank - preferredRank + periodCount) % periodCount;
            final rotationDistance = forwardDistance < periodCount - forwardDistance
                ? forwardDistance
                : periodCount - forwardDistance;
            final slotUseKey = '$sectionSubjectPrefix:$sRank';
            final repeatedPeriodCount = subjectPositionUsage[slotUseKey] ?? 0;
            final previousDayUse = dRank > 0
                ? (subjectPositionByDay['$sectionSubjectPrefix:${dRank - 1}:$sRank'] ?? 0)
                : 0;
            final nextDayUse = dRank + 1 < enabledDays.length
                ? (subjectPositionByDay['$sectionSubjectPrefix:${dRank + 1}:$sRank'] ?? 0)
                : 0;

            // Balance normalized teacher load rather than raw counts: 4/6
            // hours is heavier than 4/24, so the optimizer should prefer the
            // teacher with more remaining capacity when both are eligible.
            final currentTeacherWeekly = teacherWeekly[teacherId] ?? 0;
            final normalizedWeeklyLimit = weeklyLimit > 0
                ? weeklyLimit
                : (enabledDays.length * lessonSlots.length).clamp(1, 10000).toInt();
            final normalizedTeacherDayLimit = teacherDayLimit > 0
                ? teacherDayLimit
                : (lessonSlots.length > 0 ? lessonSlots.length : 1);
            var score = (currentTeacherWeekly * 2400) ~/ normalizedWeeklyLimit;
            score += (currentTeacherDay * 360) ~/ normalizedTeacherDayLimit;
            // Spread each section's load across days. This replaces the old
            // chronological gridRank cost, which unintentionally biased the
            // optimizer toward earlier weekdays instead of balanced days.
            score += currentSectionDay * 80;
            score += currentSubjectDay * 1000;
            if (requiresEveryDay && missingSubjectDays > 0) {
              // Establish one occurrence on each missing day before spending
              // flexible lessons on a day already covered by this subject.
              score += currentSubjectDay > 0 ? 250000 : -2500;
            }
            score += rotationDistance * 24;
            // Reusing the same period throughout the week is undesirable even
            // when days are not adjacent; consecutive-day repetition is much
            // worse and receives its own dominant penalty.
            score += repeatedPeriodCount * 1200;
            // Adjacent-day repetition is the user's most visible fairness issue
            // (for example, Arabic first period on Sunday and Monday). Treat it
            // as a dominant soft objective, without ever overriding hard rules.
            score += (previousDayUse + nextDayUse) * 100000;
            if (hasTeacherCollision) {
              // In the emergency pass, prefer overlaps attached to physical
              // education / arts over other subjects. The large penalty means
              // any lower-conflict complete arrangement wins when available.
              final candidateIsPreferred = _isPreferredEmergencySubject(
                subjectNameById[group.subjectId] ?? group.requirement['subject_name']?.toString() ?? '',
              );
              final existingIsPreferred = placed.any((placement) =>
                _integer(placement['teacher_id']) == teacherId &&
                _integer(placement['day_id']) == dayId &&
                _integer(placement['slot_id']) == slotId &&
                _isPreferredEmergencySubject(
                  subjectNameById[_integer(placement['subject_id'])] ?? '',
                ));
              score += (candidateIsPreferred || existingIsPreferred)
                  ? 1000000000
                  : 2000000000;
            }
            final positions = teacherDaySlotRanks[tDayKey] ?? const <int>[];
            if (positions.isNotEmpty) {
              final adjacent = positions.any((p) => (p - sRank).abs() == 1);
              score += adjacent ? -20 : 8;
            }
            output.add(_Candidate(group: group, teacher: teacher, day: day, slot: slot, gridRank: gridRank, score: score));
          }
        }
      }
      output.sort((a, b) {
        final score = a.score.compareTo(b.score);
        if (score != 0) return score;
        final rank = a.gridRank.compareTo(b.gridRank);
        if (rank != 0) return rank;
        return a.teacherIdSort.compareTo(b.teacherIdSort);
      });
      return output;
    }

    void apply(_Candidate c) {
      final g = c.group;
      final t = c.teacherId;
      final d = c.dayId;
      final s = c.slotId;
      final sRank = slotRank[s] ?? 0;
      sectionCells.add('${g.sectionId}:$d:$s');
      final teacherCellKey = '$t:$d:$s';
      teacherCells[teacherCellKey] = (teacherCells[teacherCellKey] ?? 0) + 1;
      teacherWeekly[t] = (teacherWeekly[t] ?? 0) + 1;
      teacherDaily[teacherDayKey(t, d)] = (teacherDaily[teacherDayKey(t, d)] ?? 0) + 1;
      sectionDaily[sectionDayKey(g.sectionId, d)] = (sectionDaily[sectionDayKey(g.sectionId, d)] ?? 0) + 1;
      subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] = (subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] ?? 0) + 1;
      final subjectPrefix = '${g.sectionId}:${g.subjectId}';
      final positionKey = '$subjectPrefix:$sRank';
      final dayPositionKey = '$subjectPrefix:${dayRank[d] ?? 0}:$sRank';
      subjectPositionUsage[positionKey] = (subjectPositionUsage[positionKey] ?? 0) + 1;
      subjectPositionByDay[dayPositionKey] = (subjectPositionByDay[dayPositionKey] ?? 0) + 1;
      (teacherDaySlotRanks[teacherDayKey(t, d)] ??= <int>[]).add(sRank);
      g.remaining--;
      g.lastGridRank = c.gridRank;
      runningScore += c.score;
      placed.add({
        'section_id': g.sectionId,
        'subject_id': g.subjectId,
        'teacher_id': t,
        'day_id': d,
        'slot_id': s,
        'room_id': null,
      });
    }

    void undo(_Candidate c, int oldLastGridRank) {
      final g = c.group;
      final t = c.teacherId;
      final d = c.dayId;
      final s = c.slotId;
      final sRank = slotRank[s] ?? 0;
      sectionCells.remove('${g.sectionId}:$d:$s');
      final teacherCellKey = '$t:$d:$s';
      final remainingTeacherCellCount = (teacherCells[teacherCellKey] ?? 1) - 1;
      if (remainingTeacherCellCount <= 0) {
        teacherCells.remove(teacherCellKey);
      } else {
        teacherCells[teacherCellKey] = remainingTeacherCellCount;
      }
      teacherWeekly[t] = (teacherWeekly[t] ?? 1) - 1;
      teacherDaily[teacherDayKey(t, d)] = (teacherDaily[teacherDayKey(t, d)] ?? 1) - 1;
      sectionDaily[sectionDayKey(g.sectionId, d)] = (sectionDaily[sectionDayKey(g.sectionId, d)] ?? 1) - 1;
      subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] = (subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] ?? 1) - 1;
      final subjectPrefix = '${g.sectionId}:${g.subjectId}';
      final positionKey = '$subjectPrefix:$sRank';
      final dayPositionKey = '$subjectPrefix:${dayRank[d] ?? 0}:$sRank';
      final remainingPositionUse = (subjectPositionUsage[positionKey] ?? 1) - 1;
      if (remainingPositionUse <= 0) {
        subjectPositionUsage.remove(positionKey);
      } else {
        subjectPositionUsage[positionKey] = remainingPositionUse;
      }
      final remainingDayUse = (subjectPositionByDay[dayPositionKey] ?? 1) - 1;
      if (remainingDayUse <= 0) {
        subjectPositionByDay.remove(dayPositionKey);
      } else {
        subjectPositionByDay[dayPositionKey] = remainingDayUse;
      }
      teacherDaySlotRanks[teacherDayKey(t, d)]?.remove(sRank);
      g.remaining++;
      g.lastGridRank = oldLastGridRank;
      // Candidate scores are accumulated during apply; remove this placement's
      // contribution before exploring a sibling branch.
      // The matching score is stored on the last placement's candidate stack.
      runningScore -= _integer(c.score);
      placed.removeLast();
    }

    void search() {
      if (limitReached) return;
      nodes++;
      // If a fully feasible timetable is impossible, keep the best partial
      // arrangement by both lesson count and fairness score. This avoids
      // returning an arbitrary, unnecessarily repetitive partial result.
      if (placed.length > best.length ||
          (placed.length == best.length && runningScore < bestPartialScore)) {
        best = placed.map((e) => Map<String, Object?>.from(e)).toList();
        bestPartialScore = runningScore;
      }
      if (placed.length == schedulableCount && schedulableGroups.every((g) => g.remaining == 0)) {
        // Keep the first complete solution immediately, then use a bounded
        // optimization window to improve fairness. Exhaustively enumerating
        // equivalent complete schedules was the main source of long waits.
        firstCompleteNode ??= nodes;
        if (runningScore < bestCompleteScore) {
          bestCompleteScore = runningScore;
          bestComplete = placed.map((e) => Map<String, Object?>.from(e)).toList();
        }
        return;
      }
      if (firstCompleteNode != null && nodes - firstCompleteNode! >= improvementNodeBudget) {
        limitReached = true;
        return;
      }
      // Do not prune by the current score: coverage candidates can carry a
      // negative reward of -2500, in addition to the small adjacent-teacher
      // reward. A lower bound based only on -20 incorrectly cuts off better
      // schedules. The hard node budget and bounded post-solution window keep
      // this search finite without compromising the objective function.
      if (nodes >= effectiveNodeLimit) {
        limitReached = true;
        return;
      }

      _RequirementGroup? selected;
      List<_Candidate> selectedCandidates = <_Candidate>[];
      // First select within the highest active priority tier. This avoids
      // generating large candidate lists for lower-priority lessons at every
      // search node, and makes the solver faster on large schools.
      for (var tier = 0; tier < 3 && selected == null; tier++) {
        var smallestRatio = double.infinity;
        for (final group in schedulableGroups) {
          if (group.remaining <= 0) continue;
          final requiresDailyCoverage = _integer(group.requirement['weekly_lessons']) >= 5;
          final coveredDays = requiresDailyCoverage
              ? enabledDays.where((day) =>
                  (subjectDaily[subjectDayKey(group.sectionId, group.subjectId, _integer(day['id']))] ?? 0) > 0).length
              : 0;
          // Tier 0: cover missing days for 5+ lessons; tier 1: finish these
          // requirements; tier 2: place all other lessons. MRV breaks ties.
          final priority = !requiresDailyCoverage
              ? 2
              : coveredDays < enabledDays.length
                  ? 0
                  : 1;
          if (priority != tier) continue;
          final options = candidatesFor(group);
          // An impossible request must not stop the entire partial schedule.
          // Other groups may still have valid placements; report this request
          // as unscheduled/coverage-deficient after the search instead.
          if (options.isEmpty) continue;
          final ratio = options.length / group.remaining;
          final emergencyCollisionScore = options.first.score;
          final selectedCollisionScore = selectedCandidates.isEmpty
              ? (1 << 62)
              : selectedCandidates.first.score;
          final shouldSelect = ratio < smallestRatio ||
              (allowEmergencySixthPeriodConflicts && ratio == smallestRatio &&
                  (emergencyCollisionScore >= 1000000000 || selectedCollisionScore >= 1000000000) &&
                  emergencyCollisionScore < selectedCollisionScore);
          if (shouldSelect) {
            selected = group;
            selectedCandidates = options;
            smallestRatio = ratio;
          }
          if (options.length == 1 && !allowEmergencySixthPeriodConflicts) {
            // In the strict pass, a single legal continuation is forced, so
            // avoid scanning all other groups. The fallback must compare
            // emergency collision penalties across equally constrained groups
            // so sport / arts can be preferred over ordinary subjects.
            break;
          }
        }
      }
      if (selected == null) return;
      for (final candidate in selectedCandidates) {
        final oldLast = selected.lastGridRank;
        apply(candidate);
        search();
        undo(candidate, oldLast);
        if (limitReached) return;
      }
    }

    search();
    if (bestComplete.isNotEmpty) best = bestComplete;

    // Never trade a conflict-free complete timetable for a conflicting one.
    // Run the relaxed search only when the strict pass could not fill all of
    // the scheduler's capacity-adjusted targets.
    final strictFullyAssigned = schedulableCount > 0 && bestComplete.length == schedulableCount;
    if (!strictFullyAssigned && schedulableCount > 0) {
      final strictBest = best.map((row) => Map<String, Object?>.from(row)).toList();
      final strictBestScore = bestComplete.isNotEmpty ? bestCompleteScore : bestPartialScore;
      final strictNodes = nodes;
      final strictLimitReached = limitReached;

      allowEmergencySixthPeriodConflicts = true;
      for (final group in schedulableGroups) {
        group.remaining = group.total;
        group.lastGridRank = -1;
      }
      sectionCells.clear();
      teacherCells.clear();
      teacherWeekly.clear();
      teacherDaily.clear();
      sectionDaily.clear();
      subjectDaily.clear();
      subjectPositionUsage.clear();
      subjectPositionByDay.clear();
      teacherDaySlotRanks.clear();
      placed.clear();
      best = <Map<String, Object?>>[];
      bestPartialScore = 1 << 62;
      nodes = 0;
      limitReached = false;
      firstCompleteNode = null;
      runningScore = 0;
      bestCompleteScore = 1 << 62;
      bestComplete = <Map<String, Object?>>[];

      search();
      if (bestComplete.isNotEmpty) {
        best = bestComplete;
      } else if (strictBest.length > best.length ||
          (strictBest.length == best.length && strictBestScore <= bestPartialScore)) {
        // If the fallback also cannot complete, keep the best non-conflicting
        // partial result when it is at least as useful as the relaxed result.
        best = strictBest;
      }
      nodes += strictNodes;
      limitReached = limitReached || strictLimitReached;
    }

    // تحقق نهائي قبل إعادة النتيجة (والحفظ في قاعدة البيانات): أي موضع لا يطابق
    // تأهيل المعلم للمادة وصلاحية المادة في صف الشعبة يُستبعد احتياطياً.
    // هذا دفاع مستقل عن مرشحي البحث، حتى لا تُحفظ حصة مخالفة عند حدوث انحدار لاحق.
    best = best.where((placement) {
      final teacherId = _integer(placement['teacher_id']);
      final subjectId = _integer(placement['subject_id']);
      final section = sectionById[_integer(placement['section_id'])];
      return section != null &&
          assignmentPolicy.isSubjectQualified(teacherId, subjectId) &&
          teacherCanTeachSubjectGrade(teacherId, subjectId, section);
    }).toList();

    // Re-evaluate day coverage AFTER safety filtering. This is a separate
    // completion condition: all lesson counts can be placed while the weekly
    // distribution still misses an active day. Never label that result complete.
    final invalidDailySpreadKeys = <String>{};
    final dailySpreadIssues = <String>[];
    for (final requirement in requirements) {
      if (_integer(requirement['weekly_lessons']) < 5) continue;
      final sectionId = _integer(requirement['section_id']);
      final subjectId = _integer(requirement['subject_id']);
      final key = '$sectionId:$subjectId';
      final hasEveryDay = enabledDays.every((day) => best.any((placement) =>
        _integer(placement['section_id']) == sectionId &&
        _integer(placement['subject_id']) == subjectId &&
        _integer(placement['day_id']) == _integer(day['id'])));
      if (!hasEveryDay && invalidDailySpreadKeys.add(key)) {
        final section = sectionById[sectionId];
        final stage = (section?['stage_name'] ?? requirement['stage_name'] ?? '').toString().trim();
        final grade = (section?['grade_name'] ?? requirement['grade_name'] ?? '').toString().trim();
        final sectionName = (section?['section_name'] ?? requirement['section_name'] ?? 'الشعبة $sectionId').toString().trim();
        final location = [if (stage.isNotEmpty) 'المرحلة $stage', if (grade.isNotEmpty) 'الصف $grade', 'الشعبة $sectionName'].join('، ');
        final subjectName = (requirement['subject_name'] ?? 'المادة $subjectId').toString();
        dailySpreadIssues.add('$location، مادة $subjectName: يجب أن تظهر حصة واحدة على الأقل في كل يوم دوام، لكن بعض الأيام لا تحتوي على حصة منها.');
      }
    }

    final placedCounts = <String, int>{};
    for (final placement in best) {
      final key = '${placement['section_id']}:${placement['subject_id']}';
      placedCounts[key] = (placedCounts[key] ?? 0) + 1;
    }
    final unscheduled = <String>[];
    for (final requirement in requirements) {
      final sectionId = _integer(requirement['section_id']);
      final subjectId = _integer(requirement['subject_id']);
      final required = _integer(requirement['weekly_lessons']).clamp(0, 1000).toInt();
      if (required <= 0) continue;
      final completed = placedCounts['$sectionId:$subjectId'] ?? 0;
      if (completed >= required) continue;
      final section = sectionById[sectionId];
      final stage = (section?['stage_name'] ?? requirement['stage_name'] ?? '').toString().trim();
      final grade = (section?['grade_name'] ?? requirement['grade_name'] ?? '').toString().trim();
      final sectionName = (section?['section_name'] ?? requirement['section_name'] ?? 'الشعبة $sectionId').toString().trim();
      final location = [if (stage.isNotEmpty) 'المرحلة $stage', if (grade.isNotEmpty) 'الصف $grade', 'الشعبة $sectionName'].join('، ');
      final subjectName = (requirement['subject_name'] ?? 'المادة $subjectId').toString();
      final possibleTeachers = qualifiedIds[subjectId] ?? const <int>[];
      final sectionTeachers = eligibleTeacherIdsFor(subjectId, section);
      final blockedForSubject = lessonSlots.where((slot) =>
          blockedSubjectSlotPairs.contains('$subjectId:${_integer(slot['id'])}')).length;
      final capacityMessage = sectionCapacityMessage[sectionId];
      final teacherCapacityMessage = sectionTeachers.length == 1
          ? mandatoryTeacherCapacityIssue[sectionTeachers.single]
          : null;
      final reason = section == null
          ? 'الشعبة غير موجودة؛ راجع ربط المتطلب بالصف والشعبة.'
          : invalidDailySpreadKeys.contains('$sectionId:$subjectId')
              ? 'لأن المادة مطلوبة 5 حصص أسبوعياً أو أكثر، يشترط الجدول الكامل وضع حصة واحدة منها على الأقل في كل يوم دوام. احتُفظ بالحصص التي أمكن إسنادها دون تعارض في المسودة؛ أكمل الأيام الناقصة أو عدّل قيود المعلم والفترات الممنوعة ثم أعد التوزيع.'
          : possibleTeachers.isEmpty
              ? 'لا يوجد معلم مسجل ضمن اختصاص مادة $subjectName. افتح «البيانات > المعلمون»، وعدّل معلماً وحدد المادة ضمن مواده المؤهل لتدريسها.'
              : sectionTeachers.isEmpty
                  ? 'يوجد معلمون لمادة $subjectName، لكن لا يوجد معلم مسموح له بتدريسها في ${location} ضمن إعدادات الصفوف الحالية. افتح «البيانات > المعلمون» وحدد هذا الصف ضمن صفوف المعلم، أو اختر «جميع الصفوف».'
                  : blockedForSubject >= lessonSlots.length && lessonSlots.isNotEmpty
                      ? 'المادة $subjectName ممنوعة من جميع فترات التدريس المتاحة. افتح «البيانات > المواد» وعدّل الفترات الممنوعة لهذه المادة.'
              : enabledDays.isEmpty
                  ? 'لا توجد أيام دوام مفعّلة؛ فعّل أيام المدرسة من إعدادات الدوام.'
                  : lessonSlots.isEmpty
                      ? 'لا توجد فترات متاحة من نوع «حصة دراسية»؛ أضف الفترات أو فعّلها في إعدادات الدوام.'
                      : required > maxSchedulableForRequirement(requirement)
                          ? 'إعداد هذه المادة يسمح بحد أقصى ${maxSchedulableForRequirement(requirement)} حصة أسبوعياً ضمن عدد أيام الدوام والفترات المسموحة، بينما المتطلب المسجل $required. لتمكين الحصة المتبقية عند تجاوز المطلوب عدد أيام الدوام، فعّل الفترة السادسة للشعبة (أو السابعة إذا كانت مسموحة)، واجعل الفترة غير ممنوعة للمادة ومتاحة لمعلمها؛ لم تتغير بياناتك تلقائياً.'
                      : [if (capacityMessage != null) capacityMessage,
                         if (teacherCapacityMessage != null) teacherCapacityMessage,
                         if (blockedForSubject > 0 && blockedForSubject < lessonSlots.length) 'هذه المادة ممنوعة في $blockedForSubject من أصل ${lessonSlots.length} فترات؛ تم استبعادها من تلك الفترات تلقائياً.',
                         if (capacityMessage == null && teacherCapacityMessage == null)
                           (limitReached
                             ? 'توقف البحث بعد فحص $nodes حالة دون العثور على حل كامل ضمن القيود. جرّب زيادة الفترات أو تخفيف القيود اليومية/النصاب.'
                             : 'لم تتوفر خانة ومعلم يحققان القيود الحالية. راجع النصاب الأسبوعي واليومي، أوقات عدم إتاحة المعلم، وحد الحصص المتتالية.')].join(' ');
      unscheduled.add('$location، مادة $subjectName: المطلوب $required حصة أسبوعياً، الموزع $completed، المتبقي ${required - completed}. $reason');
    }
    return SchedulerResult(
      placements: best,
      unscheduled: unscheduled,
      requestedCount: requestedCount,
      exploredNodes: nodes,
      searchLimitReached: limitReached,
      dailySpreadIssues: dailySpreadIssues,
    );
  }
}

bool _isPreferredEmergencySubject(String value) {
  var name = value.trim().toLowerCase();
  name = name.replaceAll(RegExp(r'[\u064B-\u065F\u0670\u0640]'), '');
  name = name.replaceAll(RegExp(r'[أإآٱ]'), 'ا').replaceAll('ى', 'ي').replaceAll('ة', 'ه');
  return name.contains('رياضه') || name.contains('رياضيه') ||
      name.contains('البدنيه') || name.contains('تربيه بدنيه') ||
      name.contains('فنيه') || name.contains('فنون') ||
      name.contains('physical education') || name == 'pe' ||
      name.contains('sports') || name.contains('sport') ||
      name.contains('art');
}

int _integer(Object? value, {int fallback = 0}) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse('$value') ?? fallback;
}
