#!/usr/bin/env python3
"""Dependency-free pre-flight checks; these do not replace flutter test/analyze."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]


class EnhancedUIStaticTests(unittest.TestCase):
    def test_exact_palette_count_and_html_names(self):
        src = (ROOT/'lib/core/jadwali_palettes.dart').read_text()
        html = (ROOT/'design-reference/approved-enhanced-ui-18-palettes.html').read_text()
        entries = re.findall(r"^    '(\w+)': \('([^']+)', Color\(0x[0-9a-f]+\), Color\(0x[0-9a-f]+\)\),$", src, re.M)
        self.assertEqual(len(entries), 18)
        self.assertEqual(len(set(name for name, _ in entries)), 18)
        for key, title in entries:
            self.assertIn(f'data-color="{key}"', html)
            self.assertIn(title, html)

    def test_notifications_are_data_backed_and_mounted(self):
        src = (ROOT/'lib/features/notifications/jadwali_notification_center.dart').read_text()
        shell = (ROOT/'lib/app/app.dart').read_text()
        self.assertIn('ConflictDetectionService().scan(', src)
        self.assertIn("db.summary()", src)
        self.assertIn('JadwaliNotificationPanel(', shell)
        self.assertIn('top-notifications', shell)
        self.assertNotIn('جدول نموذجي 180', src)

    def test_dark_palette_uses_scheme_not_white_for_search(self):
        theme = (ROOT/'lib/core/theme.dart').read_text()
        teachers = (ROOT/'lib/features/data_management/data_management_page.dart').read_text()
        self.assertIn('surfaceContainerLow: raised', theme)
        self.assertIn('fillColor: Theme.of(context).colorScheme.surfaceContainerLow', teachers)

    def test_analyzer_regression_app_shell(self):
        app = (ROOT/'lib/app/app.dart').read_text()
        self.assertNotIn("import '../data/database_service.dart';", app)
        self.assertNotRegex(app, r"const\s+Text\(\s*'التكرار في اليوم:")
        self.assertIn('Theme.of(context).colorScheme.onSurfaceVariant', app)

    def test_mobile_settings_and_teacher_color_code_paths(self):
        shell = (ROOT/'lib/app/app.dart').read_text()
        settings = (ROOT/'lib/features/settings/app_settings_page.dart').read_text()
        report = (ROOT/'lib/features/reports/reports_page.dart').read_text()
        pdf = (ROOT/'lib/services/pdf_report_service.dart').read_text()
        office = (ROOT/'lib/services/reference_office_service.dart').read_text()
        self.assertNotIn('drawer:', shell)
        self.assertIn('top-settings', shell)
        self.assertIn("(1, 'الجدول', Icons.calendar_month_outlined)", settings)
        self.assertIn('settings-destination-', settings)
        self.assertIn('colorTeacherSubjects:', report)
        self.assertIn('colorTeacherSubjects = false', pdf)
        self.assertIn('cellColors: subjectColors', office)
        self.assertIn('rowColors: reportColors', report)
        self.assertTrue((ROOT/'test/workload_report_colors_1307_test.dart').exists())

    def test_workflows_version_and_project_files(self):
        pubspec = (ROOT/'pubspec.yaml').read_text()
        self.assertIn('version: 1.31.1+92', pubspec)
        for name in ('build-apk.yml', 'build-windows.yml'):
            workflow = (ROOT/'.github/workflows'/name).read_text()
            self.assertIn('\njobs:', workflow)
            self.assertIn('1.31.1', workflow.splitlines()[0])
        apk = (ROOT/'.github/workflows/build-apk.yml').read_text()
        self.assertIn(r"version:\s*1\.31\.1", apk)
        self.assertIn('1[.]31[.]1', apk)
        self.assertIn('test/section_time_domain_flow_1308_test.dart', apk)
        self.assertTrue((ROOT/'lib/services/section_time_domain_flow.dart').exists())
        self.assertTrue((ROOT/'lib/main.dart').exists())
        self.assertTrue((ROOT/'android/app/build.gradle').exists())
        self.assertTrue((ROOT/'test/grade_daily_interaction_130_test.dart').exists())
        self.assertTrue((ROOT/'test/notification_center_1305_test.dart').exists())

if __name__ == '__main__':
    unittest.main()
