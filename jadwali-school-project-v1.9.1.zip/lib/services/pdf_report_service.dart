import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf_text_shaper/pdf_text_shaper.dart';
import 'package:printing/printing.dart';

import 'timetable_report_layout.dart';
import '../core/timetable_palette.dart';

/// يصدّر شبكة الجدول الأسبوعي لجميع الشعب إلى PDF أفقي قابل للطباعة.
class PdfReportService {
  Future<ShapedFont> _arabicFont() async {
    final data = await rootBundle.load('assets/fonts/Arabic-Regular.ttf');
    return ShapedFont.fromBytes(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      name: 'Noto Naskh Arabic',
    );
  }

  pw.Widget _text(
    String value, {
    required ShapedFont font,
    double size = 10,
    PdfColor color = PdfColors.black,
    ShapedTextAlign align = ShapedTextAlign.center,
  }) {
    // The bundled font has a limited glyph map. Normalize punctuation first,
    // then remove any code point unsupported by that exact font so text entered
    // by users cannot make PDF generation fail at runtime.
    final normalized = value
        .replaceAll(RegExp(r'[\u002D\u2010-\u2015\u2212]'), ' إلى ')
        .replaceAll('/', ' أو ')
        .replaceAll('|', '،')
        .replaceAll('•', '،')
        .replaceAll('·', '،')
        .replaceAll(RegExp(r'[()\[\]{}]'), ' ')
        .replaceAll('_', ' ')
        .replaceAll('%', ' بالمئة ')
        .replaceAll('+', ' زائد ');
    final safeValue = String.fromCharCodes(normalized.runes.where((rune) =>
        rune == 10 || rune == 9 || _fontHasGlyph(rune)));
    return ShapedText(
      safeValue,
      style: ShapedTextStyle(
        font: font,
        fontSize: size,
        color: color,
        direction: ShapedTextDirection.rightToLeft,
        align: align,
        preserveUnicodeText: true,
      ),
    );
  }

  Future<Uint8List> buildTimetablePdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<Map<String, Object?>> entries,
    List<Map<String, Object?>> sections = const [],
    List<Map<String, Object?>> days = const [],
    List<Map<String, Object?>> slots = const [],
    PdfPageFormat? pageFormat,
    String title = 'الجدول الأسبوعي الشامل',
    bool schoolWideLayout = true,
  }) async {
    final font = await _arabicFont();
    try {
      final pdf = pw.Document();
      final format = pageFormat ?? PdfPageFormat.a3.landscape;
      final layout = TimetableReportLayout(
        entries: entries,
        sections: sections,
        days: days,
        slots: slots,
      );
      const periodWidth = 92.0;

      /// Common card styling with the in-app weekly editor. Accent/tint are
      /// derived from the subject id, not from the current cell position.
      pw.Widget cell(String text, {bool header = false, bool period = false,
          int? subjectId}) {
        final accent = subjectId == null
            ? const PdfColor.fromInt(0xFF183B66)
            : PdfColor.fromInt(TimetablePalette.accent(subjectId));
        final background = header
            ? const PdfColor.fromInt(0xFF183B66)
            : period
                ? const PdfColor.fromInt(0xFFDCE9F8)
                : subjectId == null
                    ? const PdfColor.fromInt(0xFFFAFBFD)
                    : PdfColor.fromInt(TimetablePalette.tint(subjectId));
        return pw.Container(
          alignment: pw.Alignment.center,
          padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 4),
          decoration: pw.BoxDecoration(
            color: background,
            borderRadius: pw.BorderRadius.circular(7),
            border: pw.Border.all(
              color: subjectId == null
                  ? const PdfColor.fromInt(0xFFD9E5F2)
                  : accent, width: subjectId == null ? .45 : .8),
          ),
          child: _text(text, font: font,
            size: header ? 7.2 : (period ? 6.6 : 7.2),
            color: header ? PdfColors.white : (subjectId == null
                ? const PdfColor.fromInt(0xFF18324D) : accent)),
        );
      }

      pw.Widget sectionDayCards(Map<String, Object?> section, Map<String, Object?> day) {
        final sectionId = _safeInt(section['id']);
        final dayId = _safeInt(day['id']);
        final cards = <pw.Widget>[];
        for (final slot in layout.slots) {
          final entry = layout.entryAt(sectionId, dayId, _safeInt(slot['id']));
          if (entry == null) continue;
          final subject = '${entry['subject_name'] ?? 'مادة'}';
          final teacher = '${entry['teacher_name'] ?? 'غير مسند'}';
          final period = '${slot['name'] ?? 'حصة'}';
          cards.add(cell('$period: $subject، $teacher', subjectId: _safeInt(entry['subject_id'])));
          cards.add(pw.SizedBox(height: 2));
        }
        if (cards.isEmpty) return cell('—');
        return pw.Padding(
          padding: const pw.EdgeInsets.all(2),
          child: pw.Column(mainAxisSize: pw.MainAxisSize.min,
            crossAxisAlignment: pw.CrossAxisAlignment.stretch, children: cards),
        );
      }

      final reportBlocks = <pw.Widget>[];
      if (schoolWideLayout) {
        // The comprehensive print view is a school matrix: days are rows and
        // grades/sections are columns. Keep at most six classes per table so
        // the cells remain legible on A3 landscape when a grade has divisions.
        const maxSectionColumnsPerTable = 6;
        if (layout.sections.isEmpty) {
          reportBlocks.add(_text('لا توجد شعب أو فترات تدريس متاحة. راجع إعدادات المدرسة.', font: font, size: 9));
        } else {
          for (var start = 0; start < layout.sections.length; start += maxSectionColumnsPerTable) {
            final end = (start + maxSectionColumnsPerTable < layout.sections.length)
                ? start + maxSectionColumnsPerTable
                : layout.sections.length;
            final sectionChunk = layout.sections.sublist(start, end);
            final tableRows = <pw.TableRow>[
              pw.TableRow(children: [
                ...sectionChunk.reversed.map((section) => cell(layout.sectionColumnTitle(section), header: true)),
                cell('اليوم', header: true),
              ]),
              ...layout.days.map((day) => pw.TableRow(children: [
                ...sectionChunk.reversed.map((section) => sectionDayCards(section, day)),
                cell('${day['name'] ?? ''}', period: true),
              ])),
            ];
            reportBlocks.add(pw.Table(
              columnWidths: <int, pw.TableColumnWidth>{
                for (var i = 0; i < sectionChunk.length; i++) i: const pw.FlexColumnWidth(1),
                sectionChunk.length: const pw.FixedColumnWidth(48),
              },
              border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.45),
              defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
              children: tableRows,
            ));
            if (end < layout.sections.length) {
              reportBlocks.add(pw.SizedBox(height: 10));
              reportBlocks.add(_text('تابع الصفوف/الشعب في الصفحة التالية', font: font, size: 7));
              reportBlocks.add(pw.SizedBox(height: 4));
            }
          }
        }
      } else {
        // Individual-section printouts keep the familiar period-by-day grid.
        for (final section in layout.sections) {
          reportBlocks.add(pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 4),
            decoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFFDCE9F8)),
            child: _text(layout.sectionTitle(section), font: font, size: 9.2, color: const PdfColor.fromInt(0xFF183B66)),
          ));
          reportBlocks.add(pw.SizedBox(height: 2));
          final tableRows = <pw.TableRow>[
            pw.TableRow(children: [
              ...layout.slots.reversed.map((slot) => cell(layout.periodLabel(slot), header: true)),
              cell('اليوم', header: true),
            ]),
            ...layout.days.map((day) => pw.TableRow(children: [
              ...layout.slots.reversed.map((slot) {
                final entry = layout.entryAt(_safeInt(section['id']), _safeInt(day['id']), _safeInt(slot['id']));
                return cell(layout.lessonCell(section, day, slot),
                    subjectId: entry == null ? null : _safeInt(entry['subject_id']));
              }),
              cell('${day['name'] ?? ''}', period: true),
            ])),
          ];
          reportBlocks.add(pw.Table(
            columnWidths: <int, pw.TableColumnWidth>{
              for (var i = 0; i < layout.slots.length; i++) i: const pw.FlexColumnWidth(1),
              layout.slots.length: const pw.FixedColumnWidth(periodWidth),
            },
            border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.45),
            defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
            children: tableRows,
          ));
          reportBlocks.add(pw.SizedBox(height: 8));
        }
      }
      if (reportBlocks.isEmpty) {
        reportBlocks.add(_text('لا توجد شعب أو فترات تدريس متاحة. راجع إعدادات المدرسة.', font: font, size: 9));
      }

      pdf.addPage(pw.MultiPage(
        pageFormat: format,
        margin: const pw.EdgeInsets.all(14),
        header: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            _text(schoolName, font: font, size: 13.5, color: const PdfColor.fromInt(0xFF183B66)),
            _text(title, font: font, size: 9.5, color: const PdfColor.fromInt(0xFF23354B)),
            _text('العام الدراسي: $academicYear، النسخة: $versionName، الحالة: $status', font: font, size: 7.2),
            pw.SizedBox(height: 5),
          ],
        ),
        footer: (context) => pw.Align(
          alignment: pw.Alignment.centerRight,
          child: _text('تاريخ التقرير: ${_dateStamp(DateTime.now())} • صفحة ${context.pageNumber} من ${context.pagesCount}', font: font, size: 6),
        ),
        build: (context) => reportBlocks,
      ));
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  /// A teacher-specific weekly view: each cell shows subject and section,
  /// while the period/time remains exactly once in the first column.
  Future<Uint8List> buildTeacherTimetablePdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required Map<String, Object?> teacher,
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    required int targetLoad,
    PdfPageFormat? pageFormat,
  }) async {
    final font = await _arabicFont();
    try {
      final pdf = pw.Document();
      final teacherId = _safeInt(teacher['id']);
      final teacherEntries = entries.where((entry) => _safeInt(entry['teacher_id'], fallback: -1) == teacherId).toList();
      final layout = TimetableReportLayout(
        entries: teacherEntries,
        sections: const [],
        days: days,
        slots: slots,
      );
      final dailyCounts = <int, int>{};
      for (final entry in teacherEntries) {
        final dayId = _safeInt(entry['day_id']);
        dailyCounts[dayId] = (dailyCounts[dayId] ?? 0) + 1;
      }
      final bodyRows = <pw.TableRow>[
        pw.TableRow(children: [
          ...layout.slots.reversed.map((slot) => _reportCell(layout.periodLabel(slot), font: font, header: true)),
          _reportCell('اليوم', font: font, header: true),
        ]),
        ...layout.days.map((day) => pw.TableRow(children: [
          ...layout.slots.reversed.map((slot) {
            final matchingEntries = teacherEntries.where((row) =>
              _safeInt(row['day_id']) == _safeInt(day['id']) &&
              _safeInt(row['slot_id']) == _safeInt(slot['id'])).toList();
            if (matchingEntries.isEmpty) return _reportCell('', font: font);
            final entry = matchingEntries.first;
            final subject = '${entry['subject_name'] ?? 'مادة'}';
            final grade = '${entry['grade_name'] ?? entry['section_grade_name'] ?? ''}'.replaceFirst(RegExp(r'^الصف\s+'), '');
            final section = '${entry['section_name'] ?? ''}';
            return _reportCell('$subject\n$grade - $section', font: font, subjectId: _safeInt(entry['subject_id']));
          }),
          _reportCell('${day['name'] ?? ''}', font: font, period: true),
        ])),
      ];
      final actualLoad = teacherEntries.length;
      final dayNames = <String>[];
      for (final day in layout.days) {
        if (dailyCounts.containsKey(_safeInt(day['id']))) {
          dayNames.add('${day['name']} (${dailyCounts[_safeInt(day['id'])]})');
        }
      }
      pdf.addPage(pw.MultiPage(
        pageFormat: pageFormat ?? PdfPageFormat.a3.landscape,
        margin: const pw.EdgeInsets.all(16),
        header: (context) => pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.stretch, children: [
          _text(schoolName, font: font, size: 14, color: const PdfColor.fromInt(0xFF183B66)),
          _text('الجدول الأسبوعي للمعلم: ${teacher['name'] ?? 'المعلم'}', font: font, size: 11),
          _text('العام الدراسي: $academicYear، النسخة: $versionName، الحالة: $status', font: font, size: 7.5),
          _text('النصاب المحدد: $targetLoad حصة، الموزع: $actualLoad، ${actualLoad > targetLoad ? 'التجاوز: ${actualLoad - targetLoad}' : 'المتبقي: ${targetLoad - actualLoad}'}', font: font, size: 8),
          if (dayNames.isNotEmpty) _text('الحصص حسب اليوم: ${dayNames.join('، ')}', font: font, size: 7.5),
          pw.SizedBox(height: 6),
        ]),
        footer: (context) => pw.Align(
          alignment: pw.Alignment.centerRight,
          child: _text('تاريخ التقرير: ${_dateStamp(DateTime.now())} • صفحة ${context.pageNumber} من ${context.pagesCount}', font: font, size: 6),
        ),
        build: (context) => [
          pw.Table(
            columnWidths: <int, pw.TableColumnWidth>{
              for (var i = 0; i < layout.slots.length; i++) i: const pw.FlexColumnWidth(1),
              layout.slots.length: const pw.FixedColumnWidth(100),
            },
            border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
            defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
            children: bodyRows,
          ),
          if (teacherEntries.isEmpty) pw.Padding(padding: const pw.EdgeInsets.all(12), child: _text('لا توجد حصص مسندة لهذا المعلم في النسخة المحددة.', font: font, size: 9)),
        ],
      ));
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  pw.Widget _reportCell(String value, {required ShapedFont font, bool header = false, bool period = false, int? subjectId}) {
    final background = header
        ? const PdfColor.fromInt(0xFF183B66)
        : period
            ? const PdfColor.fromInt(0xFFDCE9F8)
            : subjectId == null
                ? const PdfColor.fromInt(0xFFFAFBFD)
                : PdfColor.fromInt(TimetablePalette.tint(subjectId));
    return pw.Container(
      alignment: pw.Alignment.center,
      padding: const pw.EdgeInsets.symmetric(horizontal: 3, vertical: 4),
      decoration: pw.BoxDecoration(
        color: background,
        borderRadius: pw.BorderRadius.circular(6),
        border: pw.Border.all(color: subjectId == null
            ? const PdfColor.fromInt(0xFFD9E5F2)
            : PdfColor.fromInt(TimetablePalette.accent(subjectId)), width: .65),
      ),
      child: _text(value, font: font, size: header ? 7.4 : (period ? 6.8 : 7),
          color: header ? PdfColors.white : (subjectId == null
              ? const PdfColor.fromInt(0xFF18324D)
              : PdfColor.fromInt(TimetablePalette.accent(subjectId)))),
    );
  }

  int _safeInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }

  String _dateStamp(DateTime date) => '${date.year}.${date.month.toString().padLeft(2, '0')}.${date.day.toString().padLeft(2, '0')}';

  // Character ranges were derived from assets/fonts/Arabic-Regular.ttf's cmap.
  bool _fontHasGlyph(int rune) {
    const ranges = <List<int>>[
      [0, 0], [13, 13], [32, 33], [44, 44], [46, 46], [48, 58], [160, 160],
      [171, 171], [187, 187], [1536, 1540], [1542, 1563], [1566, 1791], [1872, 1919],
      [2208, 2208], [2210, 2220], [2276, 2302], [8203, 8209], [8271, 8271],
      [9676, 9676], [11841, 11841], [64336, 64449], [64467, 64831],
      [64848, 64911], [64914, 64967], [65008, 65021], [65136, 65140],
      [65142, 65276], [65279, 65279],
    ];
    for (final range in ranges) {
      if (rune >= range[0] && rune <= range[1]) return true;
    }
    return false;
  }

  Future<String?> savePdf(Uint8List bytes, {String fileName = 'الجدول-المدرسي.pdf'}) async {
    return FilePicker.platform.saveFile(
      dialogTitle: 'حفظ تقرير PDF',
      fileName: fileName,
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      bytes: bytes,
    );
  }

  Future<void> preview(Uint8List bytes) async {
    await Printing.layoutPdf(onLayout: (_) async => bytes);
  }

}
