جدولي 1.30.6 — إصلاح فشل flutter analyze في 1.30.5

ما تغير:
1) lib/app/app.dart: حذف import غير مستخدم لـ database_service.dart.
2) lib/app/app.dart: إزالة const من Text يستخدم Theme.of(context) في نمط الألوان.
3) pubspec.yaml: 1.30.6+88.
4) ملفات GitHub Actions: فحص إصدار 1.30.6 وتفضيل ZIP الخاص به.
5) فحوص Python المصدرية: تحديث الإصدار وإضافة تحقق من الخطأين السابقين.

لم يتم تغيير خوارزميات التوزيع أو قاعدة البيانات أو قوالب التقارير أو اختبارات Flutter.

ارفع jadwali-school-project-v1.30.6-analyze-fix.zip إلى جذر مستودع GitHub دون استخراج،
واستبدل .github/workflows/build-apk.yml بملف البناء المرفق.

تشغيل flutter analyze واختبارات Flutter وبناء APK يتطلب بيئة Flutter؛ نجاحها غير مؤكد قبل GitHub Actions.
