import 'conflict_detection_service.dart';
import 'schedule_comparison_service.dart';
import 'schedule_integrity_audit.dart';

/// Improves a complete, independently validated board. Every accepted exchange
/// preserves all hard rules and locks. Bounded search is not an optimality proof.
class ScheduleImprovementService {
  const ScheduleImprovementService();

  static String identity(Map<String, Object?> e) => [
    'section_id',
    'subject_id',
    'teacher_id',
    'day_id',
    'slot_id',
    'room_id',
  ].map((k) => '${e[k] ?? ''}').join(':');

  static bool valid(
    Map<String, Object?> input,
    List<Map<String, Object?>> entries,
  ) {
    final requested = rows(input['requirements'])
        .fold<int>(0, (s, r) => s + number(r['weekly_lessons']));
    if (entries.length != requested) return false;
    // Independent structural audit protects demand, pins and collisions even
    // when a search strategy reports a full board.
    if (!const ScheduleIntegrityAudit().accepts(input, entries)) return false;
    final keys = entries.map(identity).toSet();
    if (!rows(input['lockedPlacements'])
        .every((e) => keys.contains(identity(e))))
      return false;
    return const ConflictDetectionService()
        .scan(
          entries: entries,
          requirements: rows(input['requirements']),
          sections: rows(input['sections']),
          teachers: rows(input['teachers']),
          qualifications: rows(input['qualifications']),
          teacherGrades: rows(input['teacherGrades']),
          teacherSubjectGrades: rows(input['teacherSubjectGrades']),
          days: rows(input['days']),
          slots: rows(input['slots']),
          subjectBlockedSlots: rows(input['subjectBlockedSlots']),
          teacherAvailability: rows(
            input['teacherAvailability'] ?? input['availability'],
          ),
        )
        .every((issue) => issue.type == 'تكرار توقيت المادة في أيام متتالية');
  }

  /// Missing demand/coverage is permitted only for a draft. All placement
  /// constraints still apply; this predicate never labels a board complete.
  static bool validPartial(
    Map<String, Object?> input,
    List<Map<String, Object?>> entries,
  ) {
    final demand = <String, int>{};
    for (final req in rows(input['requirements'])) {
      final key = '${req['section_id']}:${req['subject_id']}';
      demand[key] = (demand[key] ?? 0) + number(req['weekly_lessons']);
    }
    final sections = rows(input['sections'])
        .map((r) => number(r['id']))
        .toSet();
    final teachers = rows(input['teachers'])
        .map((r) => number(r['id']))
        .toSet();
    final placed = <String, int>{};
    for (final row in entries) {
      final key = '${row['section_id']}:${row['subject_id']}';
      placed[key] = (placed[key] ?? 0) + 1;
      if (!sections.contains(number(row['section_id'])) ||
          !teachers.contains(number(row['teacher_id'])) ||
          placed[key]! > (demand[key] ?? 0))
        return false;
    }
    return const ConflictDetectionService()
        .scan(
          entries: entries,
          requirements: rows(input['requirements']),
          sections: rows(input['sections']),
          teachers: rows(input['teachers']),
          qualifications: rows(input['qualifications']),
          teacherGrades: rows(input['teacherGrades']),
          teacherSubjectGrades: rows(input['teacherSubjectGrades']),
          days: rows(input['days']),
          slots: rows(input['slots']),
          subjectBlockedSlots: rows(input['subjectBlockedSlots']),
          teacherAvailability: rows(
            input['teacherAvailability'] ?? input['availability'],
          ),
        )
        .every(
          (issue) => const {
            'نقص الحصص',
            'توزيع المادة على كل أيام الأسبوع',
            'تكرار توقيت المادة في أيام متتالية',
            'الحصص المطلوبة تتجاوز سعة الشعبة',
          }.contains(issue.type),
        );
  }

  static List<Map<String, Object?>> retainValidSeed(
    Map<String, Object?> input,
  ) {
    final original = rows(input['initialPlacements']);
    if (valid(input, original) && validPartial(input, original))
      return original.map((r) => Map<String, Object?>.from(r)).toList();
    final kept = rows(input['lockedPlacements']);
    if (!validPartial(input, kept)) return [];
    final known = kept.map(identity).toSet();
    for (final row in rows(input['initialPlacements'])) {
      if (known.contains(identity(row))) continue;
      if (validPartial(input, [...kept, row])) {
        kept.add(Map<String, Object?>.from(row));
        known.add(identity(row));
      }
    }
    return kept;
  }

  static int score(
    ScheduleQuality q,
    String profile,
    Map<String, Object?> weights,
  ) {
    int weight(String key) => number(weights[key], fallback: 2).clamp(1, 3);
    final gaps =
        (q.worstTeacherDayGaps * q.worstTeacherDayGaps * 100 +
            q.teacherGaps * 10) *
        weight('gaps');
    final balance =
        (q.worstSectionDaySpread * q.worstSectionDaySpread * 50 +
            q.subjectBalancePenalty) *
        weight('balance');
    final spacing = q.repeatSpacingPenalty * weight('spacing');
    return switch (profile) {
      'teacher_gaps' => gaps * 100 + balance + spacing + q.changedLessons,
      'balanced_subjects' =>
        balance * 30 + spacing * 30 + gaps + q.changedLessons,
      _ => q.changedLessons * 1000000 + gaps + balance + spacing,
    };
  }

  List<Map<String, Object?>> improve({
    required Map<String, Object?> input,
    required List<Map<String, Object?>> seed,
    required String profile,
    int maxCandidates = 3000,
    Duration timeLimit = const Duration(seconds: 8),
    void Function(List<Map<String, Object?>>, ScheduleQuality)? onImproved,
  }) {
    if (!valid(input, seed))
      throw ArgumentError('التحسين يتطلب جدولاً كاملاً صالحاً.');
    var best = seed.map((e) => Map<String, Object?>.from(e)).toList();
    final clock = Stopwatch()..start();
    final locks = rows(input['lockedPlacements']).map(identity).toSet();
    final weights = Map<String, Object?>.from(
      input['softPriorities'] as Map? ?? {},
    );
    ScheduleQuality quality(List<Map<String, Object?>> board) =>
        ScheduleComparisonService.evaluate(
          entries: board,
          before: rows(input['initialPlacements']),
          slots: rows(input['slots']),
          days: rows(input['days']),
          requirements: rows(input['requirements']),
        );
    var bestScore = score(quality(best), profile, weights);
    final cells = [
      for (final d in rows(
        input['days'],
      ).where((e) => number(e['is_active'], fallback: 1) == 1))
        for (final s in rows(input['slots']).where(
          (e) =>
              e['kind'] == 'lesson' &&
              number(e['is_available'], fallback: 1) == 1,
        ))
          (number(d['id']), number(s['id'])),
    ];
    var checks = 0;
    for (var pass = 0; pass < 4; pass++) {
      var improved = false;
      for (var selected = 0; selected < best.length; selected++) {
        for (final target in cells) {
          if (checks++ >= maxCandidates || clock.elapsed >= timeLimit)
            return best;
          final origin = (
            number(best[selected]['day_id']),
            number(best[selected]['slot_id']),
          );
          if (origin == target || locks.contains(identity(best[selected])))
            continue;
          final component = <int>{selected};
          final pending = [selected];
          for (var head = 0; head < pending.length; head++) {
            final current = best[pending[head]];
            for (var i = 0; i < best.length; i++) {
              if (component.contains(i)) continue;
              final other = best[i];
              final cell = (number(other['day_id']), number(other['slot_id']));
              if (cell != origin && cell != target) continue;
              final teacher = number(current['teacher_id']);
              if (current['section_id'] == other['section_id'] ||
                  (teacher > 0 && teacher == number(other['teacher_id']))) {
                component.add(i);
                pending.add(i);
              }
            }
          }
          if (component.any((i) => locks.contains(identity(best[i])))) continue;
          final candidate = [...best];
          for (final i in component) {
            final to =
                (number(best[i]['day_id']), number(best[i]['slot_id'])) ==
                    origin
                ? target
                : origin;
            candidate[i] = {...best[i], 'day_id': to.$1, 'slot_id': to.$2};
          }
          final q = quality(candidate);
          final value = score(q, profile, weights);
          if (value >= bestScore || !valid(input, candidate)) continue;
          best = candidate;
          bestScore = value;
          improved = true;
          onImproved?.call(
            best.map((e) => Map<String, Object?>.from(e)).toList(),
            q,
          );
        }
      }
      if (!improved) break;
    }
    return best;
  }
}

List<Map<String, Object?>> rows(Object? value) => (value as List? ?? [])
    .map((e) => Map<String, Object?>.from(e as Map))
    .toList();
int number(Object? value, {int fallback = 0}) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
