import '../core/timetable_ordering.dart';
import 'teacher_availability_policy.dart';
import 'school_timetable_policy.dart';
import 'teacher_assignment_policy.dart';
import 'teacher_capacity_flow.dart';

/// Necessary simultaneous staffing condition, not a complete feasibility test.
/// Only sections with demand equal to ALL usable cells force occupancy here.
class MandatoryPeriodCapacity {
  const MandatoryPeriodCapacity();
  List<Map<String, Object?>> inspect(Map<String, Object?> input) {
    List<Map<String, Object?>> rows(String k) => (input[k] as List? ?? [])
        .map((r) => Map<String, Object?>.from(r as Map))
        .toList();
    final days = rows('days').where((r) => _n(r['is_active'], 1) == 1).toList()
      ..sort(TimetableOrdering.compare);
    final slots =
        rows('slots')
            .where(
              (r) => r['kind'] == 'lesson' && _n(r['is_available'], 1) == 1,
            )
            .toList()
          ..sort(TimetableOrdering.compare);
    final requirements = rows('requirements');
    final sections = rows('sections');
    final teachers = rows('teachers');
    final policy = TeacherAssignmentPolicy(
      qualifications: rows('qualifications'),
      teacherGrades: rows('teacherGrades'),
      teacherSubjectGrades: rows('teacherSubjectGrades'),
    );
    final blocked = {
      for (final r in rows('subjectBlockedSlots'))
        '${r['subject_id']}:${r['slot_id']}',
    };
    final availability = TeacherAvailabilityPolicy(input.containsKey('teacherAvailability') ? rows('teacherAvailability') : rows('availability'));
    final cells = <String, List<Map<String, Object?>>>{};
    for (final section in sections) {
      final demand = requirements
          .where((r) => _n(r['section_id']) == _n(section['id']))
          .fold<int>(0, (a, r) => a + _n(r['weekly_lessons']));
      final available = <String>[];
      for (final day in days) {
        final limit = SchoolTimetablePolicy.dailyLimit(
          section: section, day: day, activeDays: days,
          lessonSlots: slots, weeklyDemand: demand,
        );
        for (var s = 0; s < limit; s++) {
          available.add('${day['id']}:${slots[s]['id']}');
        }
      }
      if (demand <= 0 || demand != available.length) continue;
      for (final cell in available) {
        (cells[cell] ??= []).add(section);
      }
    }
    final problems = <Map<String, Object?>>[];
    for (final day in days)
      for (final slot in slots) {
        final required = cells['${day['id']}:${slot['id']}'] ?? [];
        if (required.isEmpty) continue;
        final options = <List<int>>[];
        for (final section in required) {
          final eligible = <int>{};
          for (final req in requirements.where(
            (r) =>
                _n(r['weekly_lessons']) > 0 &&
                _n(r['section_id']) == _n(section['id']),
          )) {
            final subject = _n(req['subject_id']);
            if (blocked.contains('$subject:${slot['id']}')) continue;
            for (final teacher in teachers) {
              final t = _n(teacher['id']);
              if (!availability.isAvailable(teacherId: t, dayId: _n(day['id']), slotId: _n(slot['id']), gradeId: _n(section['grade_id']), subjectId: subject))
                continue;
              if (policy.isSubjectQualified(t, subject) &&
                  policy.isGradeAllowed(t, subject, _n(section['grade_id'])))
                eligible.add(t);
            }
          }
          options.add(eligible.toList());
        }
        final capacity = TeacherCapacityFlow.maximum(
          demand: List.filled(required.length, 1),
          eligibleTeachers: options,
          capacity: {for (final t in teachers) _n(t['id']): 1},
        );
        if (capacity < required.length)
          problems.add({
            'dayId': day['id'],
            'slotId': slot['id'],
            'dayName': day['name'] ?? day['id'],
            'slotName': slot['name'] ?? slot['id'],
            'required': required.length,
            'capacity': capacity,
            'sectionIds': required.map((s) => _n(s['id'])).toList(),
            'teacherIds': options.expand((ts) => ts).toSet().toList(),
          });
      }
    return problems;
  }
}

int _n(Object? value, [int fallback = 0]) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
