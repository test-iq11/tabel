import 'teacher_availability_policy.dart';
import '../core/timetable_ordering.dart';
import 'teacher_assignment_policy.dart';
import 'teacher_capacity_flow.dart';
import 'conflict_detection_service.dart';
import 'timetable_repair_service.dart';
import 'ejection_chain_repair.dart';
import 'mandatory_period_capacity.dart';
import 'schedule_improvement_service.dart';
import 'teacher_timetable_capacity.dart';
import 'whole_week_local_search.dart';
import 'required_repeat_policy.dart';
import 'same_day_spacing_preference.dart';
import 'school_timetable_policy.dart';

/// محرك جدولة أسبوعية آلي يستخدم CSP مع اختيار المتطلب الأقل خيارات (MRV)
/// والتراجع المنظم. يراعي تأهيل المعلم للمادة وصلاحية المادة في صف الشعبة.
class SchedulerResult {
  const SchedulerResult({
    required this.placements,
    required this.unscheduled,
    required this.requestedCount,
    required this.exploredNodes,
    required this.searchLimitReached,
    this.dailySpreadIssues = const [],
    this.provenInfeasible = false,
  });

  final List<Map<String, Object?>> placements;
  final List<String> unscheduled;

  /// Coverage violations remain separate from unplaced lesson counts. A result
  /// can place every requested lesson and still be incomplete if a subject
  /// required on every active day is missing from one or more days.
  final List<String> dailySpreadIssues;
  final int requestedCount;
  final int exploredNodes;
  final bool searchLimitReached;
  final bool provenInfeasible;
  bool get complete =>
      placements.length == requestedCount &&
      unscheduled.isEmpty &&
      dailySpreadIssues.isEmpty;
}

class _RequirementGroup {
  _RequirementGroup({
    required this.section,
    required this.requirement,
    required this.teachers,
    required this.total,
    required this.requiredLatePeriodRepeat,
  }) : remaining = total;

  final Map<String, Object?> section;
  final Map<String, Object?> requirement;
  final List<Map<String, Object?>> teachers;
  final int total;

  /// True only for a necessary exception: weekly demand exceeds active days,
  /// the saved same-day-repeat switch is off, and a valid late-period slot exists.
  final bool requiredLatePeriodRepeat;
  int remaining;
  int lastGridRank = -1;

  int get sectionId => _integer(section['id'] ?? requirement['section_id']);
  int get subjectId => _integer(requirement['subject_id']);
  bool get allowSameDay => _integer(requirement['allow_same_day']) == 1;
  int get maxSubjectDaily =>
      _integer(requirement['max_daily_lessons'], fallback: 2);
}

class _Candidate {
  const _Candidate({
    required this.group,
    required this.teacher,
    required this.day,
    required this.slot,
    required this.gridRank,
    required this.score,
  });

  final _RequirementGroup group;
  final Map<String, Object?> teacher;
  final Map<String, Object?> day;
  final Map<String, Object?> slot;
  final int gridRank;
  final int score;

  int get teacherId => _integer(teacher['id']);
  int get dayId => _integer(day['id']);
  int get slotId => _integer(slot['id']);
  int get teacherIdSort => teacherId;
}

class AutoSchedulerService {
  const AutoSchedulerService({this.nodeLimit = 120000});
  final int nodeLimit;

  SchedulerResult generate({
    required List<Map<String, Object?>> sections,
    required List<Map<String, Object?>> requirements,
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> qualifications,
    List<Map<String, Object?>> teacherGrades = const [],
    List<Map<String, Object?>> teacherSubjectGrades = const [],
    List<Map<String, Object?>> subjectBlockedSlots = const [],
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    List<Map<String, Object?>> teacherAvailability = const [],
    List<Map<String, Object?>> initialPlacements = const [],
    List<Map<String, Object?>> lockedPlacements = const [],
    List<Map<String, Object?>> subjectPreferences = const [],
    String preference = 'minimal_changes',
    void Function(Map<String, Object?> progress)? onProgress,
    Duration? timeLimit,
    bool feasibilityOnly = false,
  }) {
    final clock = Stopwatch()..start();
    final profile =
        const [
          'minimal_changes',
          'teacher_gaps',
          'balanced_subjects',
        ].contains(preference)
        ? preference
        : 'minimal_changes';
    var lastProgressMs = -250;
    var timedOut = false;
    bool expired() {
      if (timeLimit != null && clock.elapsed >= timeLimit) timedOut = true;
      return timedOut;
    }

    void progress(
      List<Map<String, Object?>> placements,
      int requested,
      int explored,
      String phase, {
      bool force = false,
      bool complete = false,
    }) {
      if (onProgress == null ||
          (!force && clock.elapsedMilliseconds - lastProgressMs < 250))
        return;
      lastProgressMs = clock.elapsedMilliseconds;
      onProgress({
        'placements': placements
            .map((e) => Map<String, Object?>.from(e))
            .toList(),
        'bestCount': placements.length,
        'requestedCount': requested,
        'exploredNodes': explored,
        'elapsedMs': clock.elapsedMilliseconds,
        'phase': phase,
        'preference': profile,
        'complete': complete,
      });
    }

    String placementKey(Map<String, Object?> row) =>
        [
          'section_id',
          'subject_id',
          'teacher_id',
          'day_id',
          'slot_id',
        ].map((key) => _integer(row[key])).join(':') +
        ':${row['room_id'] ?? ''}';
    final locks = lockedPlacements
        .map(
          (row) => <String, Object?>{
            for (final key in [
              'section_id',
              'subject_id',
              'teacher_id',
              'day_id',
              'slot_id',
              'room_id',
            ])
              key: row[key],
          },
        )
        .toList();
    final lockKeys = locks.map(placementKey).toSet();
    bool containsLocks(List<Map<String, Object?>> entries) {
      final keys = entries.map(placementKey).toSet();
      return lockKeys.every(keys.contains);
    }

    final oldPlacementKeys = initialPlacements.map(placementKey).toSet();
    final morningPriorities = {
      for (final row in subjectPreferences)
        _integer(row['id'] ?? row['subject_id']): _integer(
          row['morning_priority'],
          fallback: 1,
        ).clamp(1, 3).toInt(),
    };
    final lockCounts = <String, int>{};
    for (final row in locks) {
      final key =
          '${_integer(row['section_id'])}:${_integer(row['subject_id'])}';
      lockCounts[key] = (lockCounts[key] ?? 0) + 1;
    }

    // Divide the caller's effort across deterministic restarts. Do not hide
    // a fixed 35,000-node ceiling that defeats requests for deeper repair.
    final restartCount = nodeLimit >= 60000 ? 5 : (nodeLimit >= 15000 ? 2 : 1);
    final effectiveNodeLimit =
        (nodeLimit.clamp(1, 2000000).toInt() ~/ restartCount)
            .clamp(1, 2000000)
            .toInt();
    final improvementNodeBudget = (effectiveNodeLimit ~/ 15)
        .clamp(200, 1800)
        .toInt();
    final enabledDays =
        days.where((d) => _integer(d['is_active'], fallback: 1) == 1).toList()
          ..sort((a, b) => TimetableOrdering.compare(a, b));
    final lessonSlots =
        slots
            .where(
              (s) =>
                  s['kind'] == 'lesson' &&
                  _integer(s['is_available'], fallback: 1) == 1,
            )
            .toList()
          ..sort((a, b) => TimetableOrdering.compare(a, b));

    final requestedCount = requirements.fold<int>(
      0,
      (sum, r) => sum + _integer(r['weekly_lessons']).clamp(0, 1000).toInt(),
    );
    progress(const [], requestedCount, 0, 'starting', force: true);
    if (locks.isNotEmpty) {
      final requirementKeys = {
        for (final r in requirements)
          '${_integer(r['section_id'])}:${_integer(r['subject_id'])}',
      };
      final sectionIds = sections.map((r) => _integer(r['id'])).toSet();
      final teacherIds = teachers.map((r) => _integer(r['id'])).toSet();
      final activeDayIds = enabledDays.map((r) => _integer(r['id'])).toSet();
      final availableSlotIds = lessonSlots
          .map((r) => _integer(r['id']))
          .toSet();
      final lockIssues = <String>[];
      if (lockKeys.length != locks.length)
        lockIssues.add('توجد حصة مثبتة مكررة أكثر من مرة.');
      for (final row in locks) {
        if (!sectionIds.contains(_integer(row['section_id'])) ||
            !teacherIds.contains(_integer(row['teacher_id'])) ||
            !activeDayIds.contains(_integer(row['day_id'])) ||
            !availableSlotIds.contains(_integer(row['slot_id'])) ||
            !requirementKeys.contains(
              '${_integer(row['section_id'])}:${_integer(row['subject_id'])}',
            )) {
          lockIssues.add(
            'توجد حصة مثبتة مرتبطة بمعلم أو شعبة أو متطلب غير موجود.',
          );
        }
      }
      final partialIssues = const ConflictDetectionService()
          .scan(
            entries: locks,
            requirements: requirements,
            sections: sections,
            slots: slots,
            teachers: teachers,
            qualifications: qualifications,
            days: days,
            teacherGrades: teacherGrades,
            teacherSubjectGrades: teacherSubjectGrades,
            subjectBlockedSlots: subjectBlockedSlots,
            teacherAvailability: teacherAvailability,
          )
          .where(
            (issue) => !const {
              'نقص الحصص',
              'توزيع المادة على كل أيام الأسبوع',
              'تكرار توقيت المادة في أيام متتالية',
              'الحصص المطلوبة تتجاوز سعة الشعبة',
            }.contains(issue.type),
          );
      lockIssues.addAll(
        partialIssues.map((issue) => '${issue.type}: ${issue.message}'),
      );
      if (lockIssues.isNotEmpty) {
        progress(const [], requestedCount, 0, 'invalid_locks', force: true);
        progress(const [], requestedCount, 0, 'done', force: true);
        return SchedulerResult(
          placements: const [],
          unscheduled: [
            'تعذر احترام الحصص المثبتة. أزل القفل عن الحصص المتعارضة أو صحح القيود ثم أعد البحث.',
            ...lockIssues.toSet(),
          ],
          requestedCount: requestedCount,
          exploredNodes: 0,
          searchLimitReached: false,
        );
      }
    }
    final schoolInput = <String, Object?>{
      'sections': sections,
      'requirements': requirements,
      'teachers': teachers,
      'qualifications': qualifications,
      'teacherGrades': teacherGrades,
      'teacherSubjectGrades': teacherSubjectGrades,
      'subjectBlockedSlots': subjectBlockedSlots,
      'teacherAvailability': teacherAvailability,
      'days': days,
      'slots': slots,
      'initialPlacements': initialPlacements,
      'lockedPlacements': locks,
    };
    late final retainedSeed = ScheduleImprovementService.retainValidSeed(
      schoolInput,
    );
    final shortages = const MandatoryPeriodCapacity().inspect(schoolInput);
    if (shortages.isNotEmpty &&
        initialPlacements.length == requestedCount &&
        requestedCount > 0) {
      final reasons = shortages
          .map(
            (r) =>
                '${r['dayName']}، ${r['slotName']}: تحتاج ${r['required']} شعب إلى حصص متزامنة، لكن المعلمين المؤهلين والمتاحين يسمحون بإسناد ${r['capacity']} فقط. راجع قيود هذه الفترة.',
          )
          .toList();
      progress(retainedSeed, requestedCount, 0, 'done', force: true);
      return SchedulerResult(
        placements: retainedSeed,
        unscheduled: reasons,
        requestedCount: requestedCount,
        exploredNodes: 0,
        searchLimitReached: false,
        provenInfeasible: true,
      );
    }
    // Optimizing a different preference must not discard a valid complete
    // timetable when the new search runs out of time. Keep it as a safe bound.
    List<Map<String, Object?>>? completeIncumbent;
    if (profile != 'minimal_changes' &&
        initialPlacements.length == requestedCount &&
        requestedCount > 0) {
      final seed = initialPlacements
          .map(
            (row) => <String, Object?>{
              for (final key in [
                'section_id',
                'subject_id',
                'teacher_id',
                'day_id',
                'slot_id',
                'room_id',
              ])
                key: row[key],
            },
          )
          .toList();
      if (containsLocks(seed) &&
          const ConflictDetectionService()
              .scan(
                entries: seed,
                requirements: requirements,
                sections: sections,
                slots: slots,
                teachers: teachers,
                qualifications: qualifications,
                days: days,
                teacherGrades: teacherGrades,
                teacherSubjectGrades: teacherSubjectGrades,
                subjectBlockedSlots: subjectBlockedSlots,
                teacherAvailability: teacherAvailability,
              )
              .every(
                (issue) => issue.type == 'تكرار توقيت المادة في أيام متتالية',
              )) {
        completeIncumbent = seed;
        progress(
          seed,
          requestedCount,
          1,
          'optimizing',
          force: true,
          complete: true,
        );
      }
    }
    // Reuse only the active timetable. Repairing connected lessons can move
    // many teachers and sections together while preserving every lesson count.
    // Never trust database row IDs or old joined labels as placement identity.
    var repairChecks = completeIncumbent == null ? 0 : 1;
    if (profile == 'minimal_changes' &&
        initialPlacements.length == requestedCount &&
        requestedCount > 0 &&
        !expired()) {
      final seed = initialPlacements
          .map(
            (row) => <String, Object?>{
              for (final key in [
                'section_id',
                'subject_id',
                'teacher_id',
                'day_id',
                'slot_id',
                'room_id',
              ])
                key: row[key],
            },
          )
          .toList();
      bool validExceptNewBlocks(List<Map<String, Object?>> entries) {
        repairChecks++;
        if (expired() || !containsLocks(entries)) return false;
        // Repair candidates may still contain newly blocked lessons. Only
        // validated fixed rows are safe as a cancellable partial snapshot.
        progress(locks, requestedCount, repairChecks, 'repairing');
        return const ConflictDetectionService()
            .scan(
              entries: entries,
              requirements: requirements,
              sections: sections,
              slots: slots,
              teachers: teachers,
              qualifications: qualifications,
              days: days,
              teacherGrades: teacherGrades,
              teacherSubjectGrades: teacherSubjectGrades,
              subjectBlockedSlots: subjectBlockedSlots,
              teacherAvailability: teacherAvailability,
            )
            .every(
              (issue) =>
                  issue.type == 'المادة في فترة ممنوعة' ||
                  issue.type == 'المعلم غير متاح في الفترة' ||
                  issue.type == 'تكرار توقيت المادة في أيام متتالية',
            );
      }

      var repaired = const TimetableRepairService().repair(
        initialPlacements: seed,
        blockedSlots: subjectBlockedSlots,
        slots: slots,
        sections: sections,
        teacherAvailability: teacherAvailability,
        isOtherwiseValid: validExceptNewBlocks,
        maxNodes: (nodeLimit ~/ 10).clamp(1, 300).toInt(),
        lockedPlacements: locks,
        shouldStop: expired,
      );
      // Conflict-directed multi-period chains follow cheap same-day exchanges,
      // before whole-week tabu and CSP fallback searches. Reserve time for fallbacks.
      final chainStart = clock.elapsedMilliseconds;
      final chainBudgetMs = timeLimit == null
          ? 1500
          : ((timeLimit.inMilliseconds - chainStart) ~/ 5).clamp(0, 2000);
      bool chainStop() =>
          expired() || clock.elapsedMilliseconds - chainStart >= chainBudgetMs;
      bool chainValid(
        List<Map<String, Object?>> rows, {
        required bool complete,
      }) {
        if (chainStop()) return false;
        final issues = const ConflictDetectionService().scan(
          entries: rows,
          requirements: requirements,
          sections: sections,
          slots: slots,
          teachers: teachers,
          qualifications: qualifications,
          days: days,
          teacherGrades: teacherGrades,
          teacherSubjectGrades: teacherSubjectGrades,
          subjectBlockedSlots: subjectBlockedSlots,
          teacherAvailability: teacherAvailability,
        );
        return (!complete || containsLocks(rows)) &&
            issues.every(
              (issue) =>
                  issue.type == 'تكرار توقيت المادة في أيام متتالية' ||
                  (!complete &&
                      const {
                        'نقص الحصص',
                        'توزيع المادة على كل أيام الأسبوع',
                      }.contains(issue.type)),
            );
      }

      if (repaired == null && chainBudgetMs > 0 && validExceptNewBlocks(seed)) {
        repaired = const EjectionChainRepair().repair(
          initial: seed,
          days: days,
          slots: slots,
          locks: locks,
          partialValid: (rows) => chainValid(rows, complete: false),
          completeValid: (rows) => chainValid(rows, complete: true),
          maxNodes: (nodeLimit ~/ 10).clamp(3, 3000),
          shouldStop: chainStop,
          onNode: (_) {
            repairChecks++;
            progress(locks, requestedCount, repairChecks, 'repairing');
          },
        );
      }
      // Widen only after the local same-day repair budget is exhausted.
      if (repaired == null && !expired()) {
        repaired = const TimetableRepairService().repair(
          initialPlacements: seed,
          blockedSlots: subjectBlockedSlots,
          slots: slots,
          days: days,
          sections: sections,
          teacherAvailability: teacherAvailability,
          isOtherwiseValid: validExceptNewBlocks,
          maxNodes: (nodeLimit ~/ 20).clamp(1, 150).toInt(),
          lockedPlacements: locks,
          shouldStop: expired,
        );
      }
      if (repaired != null) {
        progress(
          repaired,
          requestedCount,
          repairChecks,
          'done',
          force: true,
          complete: true,
        );
        return SchedulerResult(
          placements: repaired,
          unscheduled: const [],
          requestedCount: requestedCount,
          exploredNodes: repairChecks,
          searchLimitReached: false,
        );
      }
    }
    progress(retainedSeed, requestedCount, 0, 'repairing', force: true);
    final sectionById = {for (final s in sections) _integer(s['id']): s};
    final teacherById = {for (final t in teachers) _integer(t['id']): t};
    final qualifiedIds = <int, Set<int>>{};
    for (final qualification in qualifications) {
      final subjectId = _integer(qualification['subject_id']);
      final teacherId = _integer(qualification['teacher_id']);
      if (teacherById.containsKey(teacherId)) {
        (qualifiedIds[subjectId] ??= <int>{}).add(teacherId);
      }
    }
    final assignmentPolicy = TeacherAssignmentPolicy(
      qualifications: qualifications,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
    );
    bool teacherCanTeachSubjectGrade(
      int teacherId,
      int subjectId,
      Map<String, Object?>? section,
    ) =>
        section != null &&
        assignmentPolicy.isGradeAllowed(
          teacherId,
          subjectId,
          _integer(section['grade_id']),
        );
    final eligibleTeacherCache = <String, List<int>>{};
    List<int> eligibleTeacherIdsFor(
      int subjectId,
      Map<String, Object?>? section,
    ) {
      if (section == null) return const <int>[];
      final cacheKey = '${_integer(section['id'])}:$subjectId';
      return eligibleTeacherCache.putIfAbsent(
        cacheKey,
        () => (qualifiedIds[subjectId] ?? const <int>{})
            .where((id) => teacherCanTeachSubjectGrade(id, subjectId, section))
            .toList(growable: false),
      );
    }

    final blockedSubjectSlotPairs = <String>{
      for (final item in subjectBlockedSlots)
        '${_integer(item['subject_id'])}:${_integer(item['slot_id'])}',
    };
    int weeklyDemandForSection(int sectionId) => requirements
        .where((row) => _integer(row['section_id']) == sectionId)
        .fold<int>(
          0,
          (sum, row) =>
              sum + _integer(row['weekly_lessons']).clamp(0, 1000).toInt(),
        );

    bool hasNecessaryLatePeriodRepeat(Map<String, Object?> requirement) {
      final section = sectionById[_integer(requirement['section_id'])];
      if (section == null) return false;
      return RequiredRepeatPolicy.allowsLatePeriodRepeat(
        requirement: requirement,
        section: section,
        activeDays: enabledDays,
        sectionWeeklyDemand: weeklyDemandForSection(
          _integer(requirement['section_id']),
        ),
        lessonSlots: lessonSlots,
        subjectBlockedSlots: subjectBlockedSlots,
      );
    }

    // Preserve every requested lesson. If the subject is required more often
    // than there are active weekdays, allow the necessary extra occurrence
    // only when it can be put in period 6 (or an already-authorized period 7).
    final maxSchedulableCache = <String, int>{};
    int maxSchedulableForRequirement(Map<String, Object?> requirement) {
      final cacheKey =
          '${_integer(requirement['section_id'])}:${_integer(requirement['subject_id'])}';
      final cached = maxSchedulableCache[cacheKey];
      if (cached != null) return cached;
      if (enabledDays.isEmpty || lessonSlots.isEmpty) {
        maxSchedulableCache[cacheKey] = 0;
        return 0;
      }
      final subjectId = _integer(requirement['subject_id']);
      final allowSameDay = _integer(requirement['allow_same_day']) == 1;
      final configuredMax = _integer(
        requirement['max_daily_lessons'],
        fallback: 2,
      );
      final necessaryRepeat = hasNecessaryLatePeriodRepeat(requirement);
      final subjectDailyLimit = allowSameDay
          ? (configuredMax > 0 ? configuredMax : 1)
          : (necessaryRepeat ? 2 : 1);
      final subjectAvailableSlots = lessonSlots
          .where(
            (slot) => !blockedSubjectSlotPairs.contains(
              '$subjectId:${_integer(slot['id'])}',
            ),
          )
          .length;
      final effectiveDailyLimit = subjectDailyLimit < subjectAvailableSlots
          ? subjectDailyLimit
          : subjectAvailableSlots;
      final result = enabledDays.length * effectiveDailyLimit;
      maxSchedulableCache[cacheKey] = result;
      return result;
    }

    final availabilityPolicy = TeacherAvailabilityPolicy(teacherAvailability);
    // حد أدنى مضمون لنصاب المعلم: المتطلبات التي لا يوجد لها سوى معلم مؤهل واحد.
    final mandatoryDemandByTeacher = <int, int>{};
    for (final requirement in requirements) {
      final requested = _integer(requirement['weekly_lessons'])
          .clamp(0, 1000)
          .toInt();
      if (requested <= 0) continue;
      final count = requested < maxSchedulableForRequirement(requirement)
          ? requested
          : maxSchedulableForRequirement(requirement);
      if (count <= 0) continue;
      final section = sectionById[_integer(requirement['section_id'])];
      final eligible = eligibleTeacherIdsFor(
        _integer(requirement['subject_id']),
        section,
      );
      if (eligible.length == 1) {
        mandatoryDemandByTeacher[eligible.single] =
            (mandatoryDemandByTeacher[eligible.single] ?? 0) + count;
      }
    }
    final mandatoryTeacherCapacityIssue = <int, String>{};
    for (final teacherEntry in mandatoryDemandByTeacher.entries) {
      final teacher = teacherById[teacherEntry.key];
      final weeklyLimit = teacher == null
          ? 0
          : _integer(teacher['weekly_load'], fallback: 24);
      if (teacher != null &&
          weeklyLimit > 0 &&
          teacherEntry.value > weeklyLimit) {
        mandatoryTeacherCapacityIssue[teacherEntry.key] =
            'المعلم ${teacher['name']} هو الوحيد المؤهل لمتطلبات مجموعها ${teacherEntry.value} حصة أسبوعياً، بينما النصاب المسجل له $weeklyLimit فقط. أضف معلماً مؤهلاً بديلاً لبعض الشعب أو صحّح النصاب إذا كان مسجلاً خطأً.';
      }
    }
    final dayRank = {
      for (var i = 0; i < enabledDays.length; i++)
        _integer(enabledDays[i]['id']): i,
    };
    final slotRank = {
      for (var i = 0; i < lessonSlots.length; i++)
        _integer(lessonSlots[i]['id']): i,
    };
    // Rotate the preferred period for each subject through the school week.
    // Using a stable subject order (instead of raw database IDs) keeps the
    // result consistent even if IDs are not consecutive.
    final orderedSubjectIds =
        requirements.map((row) => _integer(row['subject_id'])).toSet().toList()
          ..sort();
    final subjectRotationOffset = <int, int>{
      for (var i = 0; i < orderedSubjectIds.length; i++)
        orderedSubjectIds[i]: i,
    };

    // تقدير سعة كل شعبة قبل البحث. يمنع استنزاف البحث عندما تكون الحصص المطلوبة
    // أكثر من الخانات المتاحة أصلاً، ويتيح توزيع بقية المواد بدلاً من التوقف بلا تفسير.
    final sectionCapacity = <int, int>{};
    final sectionDemand = <int, int>{};
    final sectionDailyLimitById = <int, int>{};
    final sectionLimitsByDay = <int, Map<int, int>>{};
    final sectionCapacityMessage = <int, String>{};
    final requirementRowsBySection = <int, List<Map<String, Object?>>>{};
    for (final requirement in requirements) {
      final sectionId = _integer(requirement['section_id']);
      (requirementRowsBySection[sectionId] ??= <Map<String, Object?>>[]).add(
        requirement,
      );
      sectionDemand[sectionId] =
          (sectionDemand[sectionId] ?? 0) +
          _integer(requirement['weekly_lessons']).clamp(0, 1000).toInt();
    }
    final slotsPerDay = lessonSlots.length;
    for (final section in sections) {
      final sectionId = _integer(section['id']);
      final configuredDailyLimit = _integer(
        section['max_daily_lessons'],
        fallback: 6,
      );
      final configuredCapacity = configuredDailyLimit > 0
          ? (configuredDailyLimit < slotsPerDay
                ? configuredDailyLimit
                : slotsPerDay)
          : slotsPerDay;
      // Keep the normal daily limit at six. The seventh period contributes at
      // most one extra cell for sixth grade on Sunday, and only if required.
      final standardDailyLimit = configuredCapacity < 6
          ? configuredCapacity
          : 6;
      final demand = sectionDemand[sectionId] ?? 0;
      final dayLimits = <int, int>{
        for (final day in enabledDays)
          _integer(day['id']): SchoolTimetablePolicy.dailyLimit(
            section: section, day: day, activeDays: enabledDays,
            lessonSlots: lessonSlots, weeklyDemand: demand,
          ),
      };
      final effectiveDailyLimit = standardDailyLimit;
      sectionDailyLimitById[sectionId] = effectiveDailyLimit;
      sectionLimitsByDay[sectionId] = dayLimits;
      final capacity = dayLimits.values.fold<int>(0, (a, b) => a + b);
      sectionCapacity[sectionId] = capacity;
      if (demand > capacity) {
        final stage = (section['stage_name'] ?? '').toString().trim();
        final grade = (section['grade_name'] ?? 'صف غير محدد')
            .toString()
            .trim();
        final sectionName =
            (section['section_name'] ?? section['name'] ?? 'غير محددة')
                .toString()
                .trim();
        final location = [
          if (stage.isNotEmpty) 'المرحلة $stage',
          'الصف $grade',
          'الشعبة $sectionName',
        ].join('، ');
        final capacityExplanation = enabledDays.map((day) =>
            '${day['name']}: ${dayLimits[_integer(day['id'])] ?? 0}')
            .join('، ');
        sectionCapacityMessage[sectionId] =
            '$location: مجموع المطلوب $demand حصة أسبوعياً، لكن المتاح $capacity خانة فقط '
            '($capacityExplanation). زد عدد الفترات المتاحة أو خفّض المتطلبات حتى يصبح المجموع ضمن السعة.';
      }
    }

    // إذا تجاوزت متطلبات الشعبة سعتها، نخصّص الخانات أولاً للمواد ذات المعلمين
    // الأقل عدداً. تبقى الحصص التي لم تحصل على خانة ضمن تقرير غير الموزع.
    final targetCountByRequirement = <String, int>{};
    for (final sectionEntry in requirementRowsBySection.entries) {
      final sectionId = sectionEntry.key;
      final rows = sectionEntry.value;
      final capacity = sectionCapacity[sectionId] ?? 0;
      final demand = sectionDemand[sectionId] ?? 0;
      if (demand <= capacity) {
        for (final row in rows) {
          final key = '$sectionId:${_integer(row['subject_id'])}';
          final requested = _integer(row['weekly_lessons'])
              .clamp(0, 1000)
              .toInt();
          final ruleMaximum = maxSchedulableForRequirement(row);
          targetCountByRequirement[key] = requested < ruleMaximum
              ? requested
              : ruleMaximum;
        }
        continue;
      }
      for (final row in rows) {
        final key = '$sectionId:${_integer(row['subject_id'])}';
        targetCountByRequirement[key] = 0;
      }
      final section = sectionById[sectionId];
      final eligibleRows = rows
          .where(
            (row) =>
                _integer(row['weekly_lessons']) > 0 &&
                maxSchedulableForRequirement(row) > 0 &&
                eligibleTeacherIdsFor(
                  _integer(row['subject_id']),
                  section,
                ).isNotEmpty,
          )
          .toList();
      int effectiveRequest(Map<String, Object?> row) {
        final weekly = _integer(row['weekly_lessons']).clamp(0, 1000).toInt();
        final maximum = maxSchedulableForRequirement(row);
        return weekly < maximum ? weekly : maximum;
      }

      eligibleRows.sort((a, b) {
        // Coverage is the first priority when capacity is insufficient: a
        // 5+ lesson subject should receive enough slots to reach every active
        // day before flexible low-frequency lessons consume the same capacity.
        final aCoverage = _integer(a['weekly_lessons']) >= 5 ? 0 : 1;
        final bCoverage = _integer(b['weekly_lessons']) >= 5 ? 0 : 1;
        final coverageOrder = aCoverage.compareTo(bCoverage);
        if (coverageOrder != 0) return coverageOrder;
        // Among equally important requests, protect the requirements having
        // the fewest qualified teachers first.
        final aTeacherCount = eligibleTeacherIdsFor(
          _integer(a['subject_id']),
          section,
        ).length;
        final bTeacherCount = eligibleTeacherIdsFor(
          _integer(b['subject_id']),
          section,
        ).length;
        final scarcity = aTeacherCount.compareTo(bTeacherCount);
        if (scarcity != 0) return scarcity;
        final demandOrder = _integer(b['weekly_lessons'])
            .compareTo(_integer(a['weekly_lessons']));
        if (demandOrder != 0) return demandOrder;
        return _integer(a['subject_id']).compareTo(_integer(b['subject_id']));
      });
      var budget = capacity;
      // Pass one reserves a coverage floor for each 5+ lesson subject. If the
      // section capacity cannot cover all such floors, scarcity order decides
      // which requirements are preserved first; any shortfall stays explicit.
      for (final row in eligibleRows.where(
        (r) => _integer(r['weekly_lessons']) >= 5,
      )) {
        final key = '$sectionId:${_integer(row['subject_id'])}';
        final desired = effectiveRequest(row) < enabledDays.length
            ? effectiveRequest(row)
            : enabledDays.length;
        final reserved = desired < budget ? desired : budget;
        targetCountByRequirement[key] = reserved;
        budget -= reserved;
      }
      // Pass two distributes remaining capacity, continuing high-priority
      // coverage subjects before shorter weekly requirements.
      for (final row in eligibleRows) {
        final key = '$sectionId:${_integer(row['subject_id'])}';
        final current = targetCountByRequirement[key] ?? 0;
        final additionalDemand = effectiveRequest(row) - current;
        if (additionalDemand <= 0 || budget <= 0) continue;
        final additional = additionalDemand < budget
            ? additionalDemand
            : budget;
        targetCountByRequirement[key] = current + additional;
        budget -= additional;
      }
    }

    // When section demand exceeds capacity, reserve valid fixed lessons
    // before allocating partial coverage to the other requirements.
    if (locks.isNotEmpty) {
      for (final entry in lockCounts.entries) {
        if ((targetCountByRequirement[entry.key] ?? 0) < entry.value) {
          targetCountByRequirement[entry.key] = entry.value;
        }
      }
      for (final section in sections) {
        final sectionId = _integer(section['id']);
        final keys = targetCountByRequirement.keys
            .where((key) => key.startsWith('$sectionId:'))
            .toList();
        var excess =
            keys.fold<int>(
              0,
              (sum, key) => sum + targetCountByRequirement[key]!,
            ) -
            (sectionCapacity[sectionId] ?? 0);
        for (final key in keys.reversed) {
          if (excess <= 0) break;
          final removable =
              targetCountByRequirement[key]! - (lockCounts[key] ?? 0);
          final remove = removable < excess ? removable : excess;
          targetCountByRequirement[key] =
              targetCountByRequirement[key]! - remove;
          excess -= remove;
        }
      }
    }

    final groups = <_RequirementGroup>[];
    for (final requirement in requirements) {
      final requested = _integer(requirement['weekly_lessons'])
          .clamp(0, 1000)
          .toInt();
      if (requested <= 0) continue;
      final sectionId = _integer(requirement['section_id']);
      final section = sectionById[sectionId];
      if (section == null) continue;
      final target =
          targetCountByRequirement['$sectionId:${_integer(requirement['subject_id'])}'] ??
          requested;
      if (target <= 0) continue;
      final candidates = eligibleTeacherIdsFor(
        _integer(requirement['subject_id']),
        section,
      ).map((id) => teacherById[id]).whereType<Map<String, Object?>>().toList();
      if (candidates.isEmpty) continue;
      groups.add(
        _RequirementGroup(
          section: section,
          requirement: requirement,
          teachers: candidates,
          total: target,
          requiredLatePeriodRepeat:
              target > enabledDays.length &&
              _integer(requirement['allow_same_day']) != 1 &&
              hasNecessaryLatePeriodRepeat(requirement),
        ),
      );
    }

    // Keep requirements schedulable even when their count cannot cover every
    // active day. In that case the solver preserves the usable lessons, reports
    // the impossible coverage explicitly, and the UI saves only an inactive draft.
    final schedulableGroups = groups
        .where((g) => enabledDays.isNotEmpty && lessonSlots.isNotEmpty)
        .toList();
    final schedulableCount = schedulableGroups.fold<int>(
      0,
      (sum, g) => sum + g.total,
    );

    // Relax only cell collisions and subject rules. Weekly/daily teacher
    // limits and unavailable cells still give a rigorous capacity upper bound.
    final teacherCapacity = const TeacherTimetableCapacity().calculate(
      teachers: teachers,
      sections: sections,
      requirements: requirements,
      qualifications: qualifications,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
      days: enabledDays,
      slots: lessonSlots,
      subjectBlockedSlots: subjectBlockedSlots,
      teacherAvailability: teacherAvailability,
    );
    final assignmentUpperBound = TeacherCapacityFlow.maximum(
      demand: schedulableGroups.map((g) => g.total).toList(),
      eligibleTeachers: schedulableGroups
          .map((g) => g.teachers.map((t) => _integer(t['id'])).toList())
          .toList(),
      capacity: teacherCapacity,
    );
    final sharedCapacityIssue = assignmentUpperBound < schedulableCount
        ? 'سعة المعلمين المؤهلين المشتركة تسمح بحد أقصى $assignmentUpperBound '
              'من أصل $schedulableCount حصة قابلة للتوزيع، حتى قبل فحص تزامن الشعب. '
              'راجع الأنصبة وأوقات الإتاحة أو أضف معلماً مؤهلاً للمواد المقيدة.'
        : null;

    // A complete-board search can repair an obstacle by exchanging lessons on
    // ANY weekday and changing eligible teachers. It does not depend on a valid
    // old timetable and does not throw away 175 good lessons to restart at zero.
    if (requestedCount >= 40 &&
        schedulableCount == requestedCount &&
        assignmentUpperBound == schedulableCount &&
        !expired()) {
      progress(locks, requestedCount, repairChecks, 'whole_week', force: true);
      final remainingMs = timeLimit == null
          ? null
          : timeLimit.inMilliseconds - clock.elapsedMilliseconds;
      final localDeadline = remainingMs == null
          ? null
          : clock.elapsedMilliseconds +
                (remainingMs ~/ 2).clamp(1, remainingMs > 0 ? remainingMs : 1);
      var localNodes = 0;
      final candidate = const WholeWeekLocalSearch().solve(
        sections: sections,
        requirements: requirements,
        teachers: teachers,
        qualifications: qualifications,
        teacherGrades: teacherGrades,
        teacherSubjectGrades: teacherSubjectGrades,
        days: enabledDays,
        slots: lessonSlots,
        subjectBlockedSlots: subjectBlockedSlots,
        teacherAvailability: teacherAvailability,
        lockedPlacements: locks,
        maxIterations: (nodeLimit ~/ 4).clamp(1, 40000),
        shouldStop: () =>
            expired() ||
            (localDeadline != null &&
                clock.elapsedMilliseconds >= localDeadline),
        onIteration: (iterations) {
          localNodes = iterations;
          progress(
            locks,
            requestedCount,
            repairChecks + iterations,
            'whole_week',
          );
        },
      );
      repairChecks += localNodes;
      if (candidate != null &&
          containsLocks(candidate) &&
          const ConflictDetectionService()
              .scan(
                entries: candidate,
                requirements: requirements,
                sections: sections,
                slots: slots,
                teachers: teachers,
                qualifications: qualifications,
                days: days,
                teacherGrades: teacherGrades,
                teacherSubjectGrades: teacherSubjectGrades,
                subjectBlockedSlots: subjectBlockedSlots,
                teacherAvailability: teacherAvailability,
              )
              .every(
                (issue) => issue.type == 'تكرار توقيت المادة في أيام متتالية',
              )) {
        if (profile == 'minimal_changes') {
          progress(
            candidate,
            requestedCount,
            repairChecks,
            'done',
            force: true,
            complete: true,
          );
          return SchedulerResult(
            placements: candidate,
            unscheduled: const [],
            requestedCount: requestedCount,
            exploredNodes: repairChecks,
            searchLimitReached: false,
          );
        }
        completeIncumbent ??= candidate;
      }
    }

    var passIndex = 0;
    int? passDeadlineMs;
    bool passExpired() =>
        expired() ||
        (passDeadlineMs != null && clock.elapsedMilliseconds >= passDeadlineMs);
    var allNodes = repairChecks;
    var anyLimitReached = false;
    var globalBest = <Map<String, Object?>>[];
    var globalBestScore = 1 << 62;
    var globalComplete = false;

    final sectionCells = <String>{};
    // Counts are used for reversible search; collisions are always forbidden.
    final teacherCells = <String, int>{};
    final teacherWeekly = <int, int>{};
    final teacherDaily = <String, int>{};
    final sectionDaily = <String, int>{};
    final subjectDaily = <String, int>{};
    // Fairness counters: avoid assigning a subject to the same period on
    // adjacent school days, and spread each subject across periods over a week.
    final subjectPositionUsage = <String, int>{};
    final subjectPositionByDay = <String, int>{};
    final teacherDaySlotRanks = <String, List<int>>{};
    final placed = <Map<String, Object?>>[];
    var best = <Map<String, Object?>>[];
    var bestPartialScore = 1 << 62;
    var nodes = 0;
    var limitReached = false;
    int? firstCompleteNode;
    var runningScore = 0;
    var bestCompleteScore = 1 << 62;
    var bestComplete = <Map<String, Object?>>[];

    String teacherDayKey(int teacherId, int dayId) => '$teacherId:$dayId';
    String sectionDayKey(int sectionId, int dayId) => '$sectionId:$dayId';
    String subjectDayKey(int sectionId, int subjectId, int dayId) =>
        '$sectionId:$subjectId:$dayId';

    bool teacherConsecutiveAllowed(
      int teacherId,
      int dayId,
      int newSlotRank,
      int maxConsecutive,
    ) {
      if (maxConsecutive <= 0) return true;
      final values = [
        ...(teacherDaySlotRanks[teacherDayKey(teacherId, dayId)] ??
            const <int>[]),
        newSlotRank,
      ]..sort();
      var run = 1;
      var longest = 1;
      for (var i = 1; i < values.length; i++) {
        run = values[i] == values[i - 1] + 1 ? run + 1 : 1;
        if (run > longest) longest = run;
      }
      return longest <= maxConsecutive;
    }

    List<_Candidate> candidatesFor(_RequirementGroup group) {
      if (expired()) return <_Candidate>[];
      if (group.teachers.isEmpty || enabledDays.isEmpty || lessonSlots.isEmpty)
        return <_Candidate>[];
      final output = <_Candidate>[];
      for (final teacher in group.teachers) {
        final teacherId = _integer(teacher['id']);
        // group.teachers is cached and prefiltered through both subject
        // qualification and the teacher-subject-grade assignment policy.
        final weeklyLimit = _integer(teacher['weekly_load'], fallback: 24);
        if (weeklyLimit > 0 && (teacherWeekly[teacherId] ?? 0) >= weeklyLimit)
          continue;
        final reserved = group.teachers.length > 1
            ? schedulableGroups
                  .where(
                    (g) =>
                        g != group &&
                        g.teachers.length == 1 &&
                        _integer(g.teachers.single['id']) == teacherId,
                  )
                  .fold<int>(0, (sum, g) => sum + g.remaining)
            : 0;
        final usesReservedCapacity =
            reserved > 0 &&
            (teacherCapacity[teacherId] ?? 0) -
                    (teacherWeekly[teacherId] ?? 0) <=
                reserved;

        for (final day in enabledDays) {
          final dayId = _integer(day['id']);
          final dRank = dayRank[dayId] ?? 0;
          final tDayKey = teacherDayKey(teacherId, dayId);
          final sDayKey = sectionDayKey(group.sectionId, dayId);
          final subjectDayKeyValue = subjectDayKey(
            group.sectionId,
            group.subjectId,
            dayId,
          );
          final currentTeacherDay = teacherDaily[tDayKey] ?? 0;
          final teacherDayLimit = _integer(
            teacher['max_daily_lessons'],
            fallback: 6,
          );
          if (teacherDayLimit > 0 && currentTeacherDay >= teacherDayLimit)
            continue;
          final currentSectionDay = sectionDaily[sDayKey] ?? 0;
          final dailySectionLimit =
              sectionLimitsByDay[group.sectionId]?[dayId] ??
              (sectionDailyLimitById[group.sectionId] ?? 6);
          final dayAllowsSeventh = dailySectionLimit >= 7;
          if (currentSectionDay >= dailySectionLimit) continue;
          final currentSubjectDay = subjectDaily[subjectDayKeyValue] ?? 0;
          final requiresEveryDay =
              _integer(group.requirement['weekly_lessons']) >= 5;
          final missingSubjectDays = requiresEveryDay
              ? enabledDays
                    .where(
                      (candidateDay) =>
                          (subjectDaily[subjectDayKey(
                                group.sectionId,
                                group.subjectId,
                                _integer(candidateDay['id']),
                              )] ??
                              0) ==
                          0,
                    )
                    .length
              : 0;
          // Do not repeat a subject on an already-covered day until each other
          // active day has one lesson, unless the remaining count makes that
          // impossible (in that case the branch itself is rejected).
          if (requiresEveryDay &&
              currentSubjectDay > 0 &&
              group.remaining <= missingSubjectDays) {
            continue;
          }
          final subjectLimit = group.allowSameDay
              ? group.maxSubjectDaily
              : (group.requiredLatePeriodRepeat ? 2 : 1);
          if (currentSubjectDay >= (subjectLimit <= 0 ? 1 : subjectLimit))
            continue;

          for (var sRank = 0; sRank < lessonSlots.length; sRank++) {
            // A necessary second lesson goes in period 6/7. Reserve early
            // periods for the normal daily occurrence; never silently place an
            // implicit duplicate in periods 1-5.
            if (group.requiredLatePeriodRepeat) {
              if (currentSubjectDay == 0 && sRank >= 5) continue;
              if (currentSubjectDay > 0) {
                final hasEarlyOccurrence = List.generate(5, (rank) => rank).any(
                  (rank) =>
                      (subjectPositionByDay['${group.sectionId}:${group.subjectId}:$dRank:$rank'] ??
                          0) >
                      0,
                );
                if (hasEarlyOccurrence && sRank < 5) continue;
                // A fixed late lesson may be loaded before its normal early
                // occurrence. Let the free early lesson complete that pair.
                if (!hasEarlyOccurrence && sRank >= 5) continue;
              }
            }
            // Never use period seven merely because it exists in settings.
            // Only the sixth grade on Sunday may use it, when section demand
            // exceeds six per active day and the six normal periods are allowed.
            if (sRank >= 7) continue;
            if (sRank >= dailySectionLimit) continue;
            final slot = lessonSlots[sRank];
            final slotId = _integer(slot['id']);
            final gridRank = dRank * lessonSlots.length + sRank;
            // الحصص المتكررة للمادة نفسها تُرتّب زمنياً لمنع بحث مكرر في تبديل نسخ متطابقة.
            // The exceptional seventh period is on Sunday, so its grid rank
            // can be earlier than already-placed lessons later in the week.
            // Permit this single intentional back-step for a required repeat.
            final seventhOnSundayForRepeatedSubject =
                sRank == 6 &&
                dayAllowsSeventh &&
                currentSubjectDay > 0 &&
                group.requiredLatePeriodRepeat;
            // For 5+ weekly lessons, coverage of every weekday outranks the
            // chronological de-duplication shortcut. Otherwise a high-scoring
            // late weekday could be chosen first and permanently exclude an
            // earlier still-missing day from this requirement.
            final requiresDailyCoverage =
                _integer(group.requirement['weekly_lessons']) >= 5;
            if (gridRank <= group.lastGridRank &&
                (lockCounts['${group.sectionId}:${group.subjectId}'] ?? 0) ==
                    0 &&
                !seventhOnSundayForRepeatedSubject &&
                !requiresDailyCoverage)
              continue;
            if (sectionCells.contains('${group.sectionId}:$dayId:$slotId'))
              continue;
            if (blockedSubjectSlotPairs.contains('${group.subjectId}:$slotId'))
              continue;
            final teacherCellKey = '$teacherId:$dayId:$slotId';
            final hasTeacherCollision = (teacherCells[teacherCellKey] ?? 0) > 0;
            // Never produce a timetable where a teacher has concurrent lessons.
            if (hasTeacherCollision) continue;
            if (!availabilityPolicy.isAvailable(
              teacherId: teacherId,
              dayId: dayId,
              slotId: slotId,
              gradeId: _integer(group.section['grade_id']),
              subjectId: group.subjectId,
            ))
              continue;
            if (!teacherConsecutiveAllowed(
              teacherId,
              dayId,
              sRank,
              _integer(teacher['max_consecutive_lessons'], fallback: 0),
            ))
              continue;

            // Soft fairness objective. The desired period rotates by one slot
            // each school day and each subject gets a stable starting offset.
            // This is a preference only: if constraints make it impossible, the
            // scheduler may reuse a period rather than leave a lesson unplaced.
            final sectionSubjectPrefix =
                '${group.sectionId}:${group.subjectId}';
            final periodCount = dailySectionLimit.clamp(1,
                lessonSlots.length < 6 ? lessonSlots.length : 6).toInt();
            final rotationOffset = subjectRotationOffset[group.subjectId] ?? 0;
            final preferredRank = (rotationOffset + dRank) % periodCount;
            final forwardDistance =
                (sRank - preferredRank + periodCount) % periodCount;
            final rotationDistance =
                forwardDistance < periodCount - forwardDistance
                ? forwardDistance
                : periodCount - forwardDistance;
            final slotUseKey = '$sectionSubjectPrefix:$sRank';
            final repeatedPeriodCount = subjectPositionUsage[slotUseKey] ?? 0;
            final previousDayUse = dRank > 0
                ? (subjectPositionByDay['$sectionSubjectPrefix:${dRank - 1}:$sRank'] ??
                      0)
                : 0;
            final nextDayUse = dRank + 1 < enabledDays.length
                ? (subjectPositionByDay['$sectionSubjectPrefix:${dRank + 1}:$sRank'] ??
                      0)
                : 0;

            // Balance normalized teacher load rather than raw counts: 4/6
            // hours is heavier than 4/24, so the optimizer should prefer the
            // teacher with more remaining capacity when both are eligible.
            final currentTeacherWeekly = teacherWeekly[teacherId] ?? 0;
            final normalizedWeeklyLimit = weeklyLimit > 0
                ? weeklyLimit
                : (enabledDays.length * lessonSlots.length)
                      .clamp(1, 10000)
                      .toInt();
            final normalizedTeacherDayLimit = teacherDayLimit > 0
                ? teacherDayLimit
                : (lessonSlots.length > 0 ? lessonSlots.length : 1);
            var score = (currentTeacherWeekly * 2400) ~/ normalizedWeeklyLimit;
            score += (currentTeacherDay * 360) ~/ normalizedTeacherDayLimit;
            if (usesReservedCapacity) score += 1000000;

            // Spread each section's load across days. This replaces the old
            // chronological gridRank cost, which unintentionally biased the
            // optimizer toward earlier weekdays instead of balanced days.
            score += currentSectionDay * 80;
            score += currentSubjectDay * 1000;
            // Prefer separating repeated lessons into an early period and
            // period 6/7, but retain every candidate allowed by hard rules.
            score += SameDaySpacingPreference.cost(
              candidateRank: sRank,
              likelyRepeat:
                  _integer(group.requirement['weekly_lessons']) >
                  enabledDays.length,
              existingRanks: [
                for (var rank = 0; rank < lessonSlots.length; rank++)
                  if ((subjectPositionByDay['${group.sectionId}:${group.subjectId}:$dRank:$rank'] ??
                          0) >
                      0)
                    rank,
              ],
            );
            if (requiresEveryDay && missingSubjectDays > 0) {
              // Establish one occurrence on each missing day before spending
              // flexible lessons on a day already covered by this subject.
              score += currentSubjectDay > 0 ? 250000 : -2500;
            }
            score += rotationDistance * 24;
            // Reusing the same period throughout the week is undesirable even
            // when days are not adjacent; consecutive-day repetition is much
            // worse and receives its own dominant penalty.
            score += repeatedPeriodCount * 1200;
            // Adjacent-day repetition is the user's most visible fairness issue
            // (for example, Arabic first period on Sunday and Monday). Treat it
            // as a dominant soft objective, without ever overriding hard rules.
            score += (previousDayUse + nextDayUse) * 100000;
            final positions = teacherDaySlotRanks[tDayKey] ?? const <int>[];
            if (positions.isNotEmpty) {
              final adjacent = positions.any((p) => (p - sRank).abs() == 1);
              score += adjacent ? -20 : 8;
            }
            if (profile == 'minimal_changes' &&
                oldPlacementKeys.isNotEmpty &&
                firstCompleteNode != null) {
              final oldKey = placementKey({
                'section_id': group.sectionId,
                'subject_id': group.subjectId,
                'teacher_id': teacherId,
                'day_id': dayId,
                'slot_id': slotId,
                'room_id': null,
              });
              if (oldPlacementKeys.contains(oldKey)) score -= 500000;
            } else if (profile == 'teacher_gaps') {
              int gaps(List<int> ranks) {
                if (ranks.length < 2) return 0;
                final ordered = ranks.toSet().toList()..sort();
                return ordered.last - ordered.first + 1 - ordered.length;
              }

              score += (gaps([...positions, sRank]) - gaps(positions)) * 300000;
            } else if (profile == 'balanced_subjects') {
              score +=
                  ((morningPriorities[group.subjectId] ?? 1) - 1) *
                  sRank *
                  20000;
              score += repeatedPeriodCount * 25000 + currentSectionDay * 1200;
              // Frequent subjects prefer early periods; compulsory late
              // repeats remain available because this is only a soft cost.
              if (_integer(group.requirement['weekly_lessons']) >= 5)
                score += sRank * 6000;
            }
            output.add(
              _Candidate(
                group: group,
                teacher: teacher,
                day: day,
                slot: slot,
                gridRank: gridRank,
                score: score,
              ),
            );
          }
        }
      }
      output.sort((a, b) {
        // Diversified deterministic restarts: favor a different legal day/slot
        // before ranking by the usual fairness score. Hard rules do not change.
        if (passIndex > 0) {
          final cycle = enabledDays.length * lessonSlots.length;
          if (cycle > 0) {
            final aOrder = (a.gridRank + passIndex * 7) % cycle;
            final bOrder = (b.gridRank + passIndex * 7) % cycle;
            final aBias = aOrder ~/ (passIndex.isOdd ? 3 : 5);
            final bBias = bOrder ~/ (passIndex.isOdd ? 3 : 5);
            final bias = aBias.compareTo(bBias);
            if (bias != 0) return bias;
          }
        }
        final score = a.score.compareTo(b.score);
        if (score != 0) return score;
        final rank = a.gridRank.compareTo(b.gridRank);
        if (rank != 0) return rank;
        return a.teacherIdSort.compareTo(b.teacherIdSort);
      });
      return output;
    }

    void apply(_Candidate c) {
      final g = c.group;
      final t = c.teacherId;
      final d = c.dayId;
      final s = c.slotId;
      final sRank = slotRank[s] ?? 0;
      sectionCells.add('${g.sectionId}:$d:$s');
      final teacherCellKey = '$t:$d:$s';
      teacherCells[teacherCellKey] = (teacherCells[teacherCellKey] ?? 0) + 1;
      teacherWeekly[t] = (teacherWeekly[t] ?? 0) + 1;
      teacherDaily[teacherDayKey(t, d)] =
          (teacherDaily[teacherDayKey(t, d)] ?? 0) + 1;
      sectionDaily[sectionDayKey(g.sectionId, d)] =
          (sectionDaily[sectionDayKey(g.sectionId, d)] ?? 0) + 1;
      subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] =
          (subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] ?? 0) + 1;
      final subjectPrefix = '${g.sectionId}:${g.subjectId}';
      final positionKey = '$subjectPrefix:$sRank';
      final dayPositionKey = '$subjectPrefix:${dayRank[d] ?? 0}:$sRank';
      subjectPositionUsage[positionKey] =
          (subjectPositionUsage[positionKey] ?? 0) + 1;
      subjectPositionByDay[dayPositionKey] =
          (subjectPositionByDay[dayPositionKey] ?? 0) + 1;
      (teacherDaySlotRanks[teacherDayKey(t, d)] ??= <int>[]).add(sRank);
      g.remaining--;
      g.lastGridRank = c.gridRank;
      runningScore += c.score;
      placed.add({
        'section_id': g.sectionId,
        'subject_id': g.subjectId,
        'teacher_id': t,
        'day_id': d,
        'slot_id': s,
        'room_id': null,
      });
    }

    void undo(_Candidate c, int oldLastGridRank) {
      final g = c.group;
      final t = c.teacherId;
      final d = c.dayId;
      final s = c.slotId;
      final sRank = slotRank[s] ?? 0;
      sectionCells.remove('${g.sectionId}:$d:$s');
      final teacherCellKey = '$t:$d:$s';
      final remainingTeacherCellCount = (teacherCells[teacherCellKey] ?? 1) - 1;
      if (remainingTeacherCellCount <= 0) {
        teacherCells.remove(teacherCellKey);
      } else {
        teacherCells[teacherCellKey] = remainingTeacherCellCount;
      }
      teacherWeekly[t] = (teacherWeekly[t] ?? 1) - 1;
      teacherDaily[teacherDayKey(t, d)] =
          (teacherDaily[teacherDayKey(t, d)] ?? 1) - 1;
      sectionDaily[sectionDayKey(g.sectionId, d)] =
          (sectionDaily[sectionDayKey(g.sectionId, d)] ?? 1) - 1;
      subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] =
          (subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] ?? 1) - 1;
      final subjectPrefix = '${g.sectionId}:${g.subjectId}';
      final positionKey = '$subjectPrefix:$sRank';
      final dayPositionKey = '$subjectPrefix:${dayRank[d] ?? 0}:$sRank';
      final remainingPositionUse = (subjectPositionUsage[positionKey] ?? 1) - 1;
      if (remainingPositionUse <= 0) {
        subjectPositionUsage.remove(positionKey);
      } else {
        subjectPositionUsage[positionKey] = remainingPositionUse;
      }
      final remainingDayUse = (subjectPositionByDay[dayPositionKey] ?? 1) - 1;
      if (remainingDayUse <= 0) {
        subjectPositionByDay.remove(dayPositionKey);
      } else {
        subjectPositionByDay[dayPositionKey] = remainingDayUse;
      }
      teacherDaySlotRanks[teacherDayKey(t, d)]?.remove(sRank);
      g.remaining++;
      g.lastGridRank = oldLastGridRank;
      // Candidate scores are accumulated during apply; remove this placement's
      // contribution before exploring a sibling branch.
      // Each decision has its exact recorded candidate cost.
      runningScore -= _integer(c.score);
      placed.removeLast();
    }

    // First solve feasibility across the whole week. A blocked request makes
    // this search immediately undo earlier decisions, on ANY day. The old
    // partial optimizer instead continued placing unrelated lessons below a
    // dead end, spending its budget without repairing the blocking decision.
    // Conflict-weighted MRV and a bounded transposition table. Store only
    // proven exhausted states (never a state truncated by node/time budget).
    // Last chronological cursors are included to preserve search semantics.
    final failedFeasibilityStates = <String>{};
    final conflictWeights = <_RequirementGroup, int>{};
    bool solveWholeWeek(int budget) {
      if (nodes >= budget || passExpired()) return false;
      nodes++;
      String? stateSignature;
      if (placed.length >= 3 &&
          schedulableGroups.where((g) => g.remaining > 0).length <= 12 &&
          failedFeasibilityStates.length < 6000) {
        final keys =
            placed
                .map(
                  (row) =>
                      '${row['section_id']}:${row['subject_id']}:${row['teacher_id']}:${row['day_id']}:${row['slot_id']}',
                )
                .toList()
              ..sort();
        final cursors = schedulableGroups
            .map((g) => '${g.remaining}:${g.lastGridRank}')
            .join(',');
        stateSignature = '$cursors|${keys.join(';')}';
        if (failedFeasibilityStates.contains(stateSignature)) return false;
      }
      bool exhausted({_RequirementGroup? culprit}) {
        if (culprit != null) {
          conflictWeights[culprit] = ((conflictWeights[culprit] ?? 0) + 1)
              .clamp(0, 30)
              .toInt();
        }
        if (stateSignature != null &&
            nodes < budget &&
            !passExpired() &&
            failedFeasibilityStates.length < 6000) {
          failedFeasibilityStates.add(stateSignature);
        }
        return false;
      }

      if (placed.length > best.length ||
          (placed.length == best.length && runningScore < bestPartialScore)) {
        best = placed.map((e) => Map<String, Object?>.from(e)).toList();
        bestPartialScore = runningScore;
        progress(best, requestedCount, allNodes + nodes, 'searching');
      }
      final pending = schedulableGroups.where((g) => g.remaining > 0).toList();
      if (pending.isEmpty) {
        bestComplete = placed.map((e) => Map<String, Object?>.from(e)).toList();
        bestCompleteScore = runningScore;
        firstCompleteNode = nodes;
        progress(
          bestComplete,
          requestedCount,
          allNodes + nodes,
          'searching',
          force: true,
        );
        return true;
      }
      final domains = <_RequirementGroup, List<_Candidate>>{};
      _RequirementGroup? selected;
      var tightest = double.infinity;
      for (final group in pending) {
        final options = candidatesFor(group);
        if (options.isEmpty) return exhausted(culprit: group);
        domains[group] = options;
        final cellCount = options.map((c) => c.gridRank).toSet().length;
        // Late repeats unlock new options after the first lesson of a day.
        // Their current domains must not be mistaken for a capacity bound.
        if (!group.requiredLatePeriodRepeat && cellCount < group.remaining)
          return exhausted(culprit: group);
        if (_integer(group.requirement['weekly_lessons']) >= 5) {
          for (final day in enabledDays) {
            final id = _integer(day['id']);
            if ((subjectDaily[subjectDayKey(
                          group.sectionId,
                          group.subjectId,
                          id,
                        )] ??
                        0) ==
                    0 &&
                !options.any((c) => c.dayId == id))
              return exhausted(culprit: group);
          }
        }
        // Dom/wdeg: prioritize tight requirements involved in past failures.
        final weight = (conflictWeights[group] ?? 0).clamp(0, 30);
        final ratio = (cellCount / group.remaining) / (1 + weight * 0.12);
        if (ratio < tightest ||
            (ratio == tightest &&
                options.length < (domains[selected]?.length ?? (1 << 30)))) {
          selected = group;
          tightest = ratio;
        }
      }
      // Detect shared bottlenecks, not just empty individual domains. Both
      // matchings are optimistic relaxations of the real timetable problem.
      if (nodes % 12 == 1 || pending.length <= 6) {
        // Count the slots a teacher can still use without creating a run of
        // consecutive lessons. Cell matching alone overestimates, for example,
        // five available periods in a row when the teacher's run limit is four.
        final remainingCapacity = <int, int>{};
        for (final teacher in teachers) {
          final id = _integer(teacher['id']);
          final relevant = pending
              .where((g) => g.teachers.any((t) => _integer(t['id']) == id))
              .toList();
          if (relevant.isEmpty) {
            remainingCapacity[id] = 0;
            continue;
          }
          final weeklyLeft =
              (teacherCapacity[id] ?? 0) - (teacherWeekly[id] ?? 0);
          if (relevant.any((g) => g.requiredLatePeriodRepeat)) {
            // A future early occurrence unlocks a late repeat. Its current
            // domain is not an upper bound on all future teacher cells.
            remainingCapacity[id] = weeklyLeft > 0 ? weeklyLeft : 0;
            continue;
          }
          final possible = <int>{
            for (final g in relevant)
              for (final c in domains[g]!)
                if (c.teacherId == id) c.gridRank,
          };
          final runLimit = _integer(teacher['max_consecutive_lessons']);
          final maxRun = runLimit > 0 && runLimit < lessonSlots.length
              ? runLimit
              : lessonSlots.length;
          var capacity = 0;
          for (var d = 0; d < enabledDays.length; d++) {
            final dayId = _integer(enabledDays[d]['id']);
            final occupied =
                teacherDaySlotRanks[teacherDayKey(id, dayId)] ?? const <int>[];
            var states = List<int>.filled(maxRun + 1, -1000000)..[0] = 0;
            for (var s = 0; s < lessonSlots.length; s++) {
              final fixed = occupied.contains(s);
              final next = List<int>.filled(maxRun + 1, -1000000);
              for (var run = 0; run <= maxRun; run++) {
                if (states[run] < 0) continue;
                if (!fixed && states[run] > next[0]) next[0] = states[run];
                if (run < maxRun &&
                    (fixed || possible.contains(d * lessonSlots.length + s))) {
                  final value = states[run] + (fixed ? 0 : 1);
                  if (value > next[run + 1]) next[run + 1] = value;
                }
              }
              states = next;
            }
            var additional = states.reduce((a, b) => a > b ? a : b);
            final dailyLimit = _integer(
              teacher['max_daily_lessons'],
              fallback: 6,
            );
            final dailyLeft = dailyLimit - occupied.length;
            if (dailyLimit > 0 && additional > dailyLeft)
              additional = dailyLeft;
            capacity += additional > 0 ? additional : 0;
          }
          remainingCapacity[id] = capacity < weeklyLeft ? capacity : weeklyLeft;
        }
        if (TeacherCapacityFlow.maximum(
              demand: pending.map((g) => g.remaining).toList(),
              eligibleTeachers: pending
                  .map((g) => g.teachers.map((t) => _integer(t['id'])).toList())
                  .toList(),
              capacity: remainingCapacity,
            ) <
            pending.fold<int>(0, (sum, g) => sum + g.remaining))
          return exhausted();
        for (final byTeacher in [false, true]) {
          final ids = <String, int>{};
          final demand = <int>[];
          final eligible = <List<int>>[];
          for (final group in pending) {
            if (group.requiredLatePeriodRepeat) continue;
            demand.add(group.remaining);
            eligible.add(
              domains[group]!
                  .map((c) {
                    final key = byTeacher
                        ? '${c.teacherId}:${c.dayId}:${c.slotId}'
                        : '${group.sectionId}:${c.dayId}:${c.slotId}';
                    return ids.putIfAbsent(key, () => ids.length);
                  })
                  .toSet()
                  .toList(),
            );
          }
          if (TeacherCapacityFlow.maximum(
                demand: demand,
                eligibleTeachers: eligible,
                capacity: {for (final id in ids.values) id: 1},
              ) <
              demand.fold<int>(0, (sum, n) => sum + n))
            return exhausted();
        }
      }
      final group = selected!;
      var choices = domains[group]!;
      // Daily occurrences of one requirement are indistinguishable. Fill its
      // missing weekdays in order, then place its extra occurrences anywhere.
      // This removes factorial permutations of the same board without fixing
      // any lesson to a particular period or preventing cross-day backtracking.
      if (_integer(group.requirement['weekly_lessons']) >= 5) {
        final missingDays = enabledDays
            .where(
              (day) =>
                  (subjectDaily[subjectDayKey(
                        group.sectionId,
                        group.subjectId,
                        _integer(day['id']),
                      )] ??
                      0) ==
                  0,
            )
            .toList();
        if (missingDays.isNotEmpty) {
          missingDays.sort((a, b) {
            final aCount = choices
                .where((c) => c.dayId == _integer(a['id']))
                .length;
            final bCount = choices
                .where((c) => c.dayId == _integer(b['id']))
                .length;
            if (aCount != bCount) return aCount.compareTo(bCount);
            final count = enabledDays.length;
            return ((dayRank[_integer(a['id'])]! + passIndex) % count)
                .compareTo((dayRank[_integer(b['id'])]! + passIndex) % count);
          });
          choices = choices
              .where((c) => c.dayId == _integer(missingDays.first['id']))
              .toList();
        }
      }
      // Prefer placements that consume fewer scarce options of other groups.
      final pressure = <String, double>{};
      for (final other in pending) {
        if (other == group) continue;
        final keys = <String>{};
        for (final c in domains[other]!) {
          keys.add('s:${other.sectionId}:${c.dayId}:${c.slotId}');
          keys.add('t:${c.teacherId}:${c.dayId}:${c.slotId}');
        }
        for (final key in keys) {
          pressure[key] = (pressure[key] ?? 0) + other.remaining / keys.length;
        }
      }
      double impact(_Candidate c) =>
          (pressure['s:${group.sectionId}:${c.dayId}:${c.slotId}'] ?? 0) +
          (pressure['t:${c.teacherId}:${c.dayId}:${c.slotId}'] ?? 0);
      final order = {for (var i = 0; i < choices.length; i++) choices[i]: i};
      choices.sort((a, b) {
        final comparison = impact(a).compareTo(impact(b));
        return comparison != 0 ? comparison : order[a]!.compareTo(order[b]!);
      });
      for (final candidate in choices) {
        final oldLast = group.lastGridRank;
        apply(candidate);
        final solved = solveWholeWeek(budget);
        undo(candidate, oldLast);
        if (solved) return true;
        if (nodes >= budget || passExpired()) return false;
      }
      return exhausted(culprit: group);
    }

    void search() {
      if (limitReached || passExpired()) return;
      nodes++;
      // If a fully feasible timetable is impossible, keep the best partial
      // arrangement by both lesson count and fairness score. This avoids
      // returning an arbitrary, unnecessarily repetitive partial result.
      if (placed.length > best.length ||
          (placed.length == best.length && runningScore < bestPartialScore)) {
        best = placed.map((e) => Map<String, Object?>.from(e)).toList();
        bestPartialScore = runningScore;
        progress(best, requestedCount, allNodes + nodes, 'searching');
      }
      if (placed.length == assignmentUpperBound) {
        // Keep the first complete solution immediately, then use a bounded
        // optimization window to improve fairness. Exhaustively enumerating
        // equivalent complete schedules was the main source of long waits.
        firstCompleteNode ??= nodes;
        if (runningScore < bestCompleteScore) {
          bestCompleteScore = runningScore;
          bestComplete = placed
              .map((e) => Map<String, Object?>.from(e))
              .toList();
        }
        return;
      }
      if (firstCompleteNode != null &&
          nodes - firstCompleteNode! >= improvementNodeBudget) {
        limitReached = true;
        return;
      }
      // Do not prune by the current score: coverage candidates can carry a
      // negative reward of -2500, in addition to the small adjacent-teacher
      // reward. A lower bound based only on -20 incorrectly cuts off better
      // schedules. The hard node budget and bounded post-solution window keep
      // this search finite without compromising the objective function.
      if (nodes >= effectiveNodeLimit) {
        limitReached = true;
        return;
      }

      _RequirementGroup? selected;
      List<_Candidate> selectedCandidates = <_Candidate>[];
      // First select within the highest active priority tier. This avoids
      // generating large candidate lists for lower-priority lessons at every
      // search node, and makes the solver faster on large schools.
      for (var tier = 0; tier < 3 && selected == null; tier++) {
        var smallestRatio = double.infinity;
        for (final group in schedulableGroups) {
          if (group.remaining <= 0) continue;
          final requiresDailyCoverage =
              _integer(group.requirement['weekly_lessons']) >= 5;
          final coveredDays = requiresDailyCoverage
              ? enabledDays
                    .where(
                      (day) =>
                          (subjectDaily[subjectDayKey(
                                group.sectionId,
                                group.subjectId,
                                _integer(day['id']),
                              )] ??
                              0) >
                          0,
                    )
                    .length
              : 0;
          // Tier 0: cover missing days for 5+ lessons; tier 1: finish these
          // requirements; tier 2: place all other lessons. MRV breaks ties.
          final priority = passIndex == 0
              ? (!requiresDailyCoverage
                    ? 2
                    : coveredDays < enabledDays.length
                    ? 0
                    : 1)
              : (passIndex == 1
                    ? (!requiresDailyCoverage
                          ? 1
                          : coveredDays < enabledDays.length
                          ? 0
                          : 2)
                    : (passIndex == 2
                          ? (!requiresDailyCoverage
                                ? 0
                                : coveredDays < enabledDays.length
                                ? 1
                                : 2)
                          : (!requiresDailyCoverage
                                ? 2
                                : coveredDays < enabledDays.length
                                ? 1
                                : 0)));
          if (priority != tier) continue;
          final options = candidatesFor(group);
          // An impossible request must not stop the entire partial schedule.
          // Other groups may still have valid placements; report this request
          // as unscheduled/coverage-deficient after the search instead.
          if (options.isEmpty) continue;
          final ratio = options.length / group.remaining;
          final shouldSelect =
              ratio < smallestRatio ||
              (ratio == smallestRatio &&
                  passIndex > 0 &&
                  (passIndex.isOdd
                      ? group.teachers.length <
                            (selected?.teachers.length ?? 999999)
                      : (group.sectionId + passIndex) % 7 <
                            ((selected?.sectionId ?? 99999) + passIndex) % 7));
          if (shouldSelect) {
            selected = group;
            selectedCandidates = options;
            smallestRatio = ratio;
          }
          if (options.length == 1 && passIndex == 0) {
            // Fast-path a forced choice in the first ordering.
            break;
          }
        }
      }
      if (selected == null) return;
      for (final candidate in selectedCandidates) {
        final oldLast = selected.lastGridRank;
        apply(candidate);
        search();
        undo(candidate, oldLast);
        if (limitReached) return;
      }
      // A partial optimum may require leaving this request for another group.
      // Previously every branch forced it, losing otherwise usable lessons.
      final deferred = selected.remaining;
      final otherRemaining = schedulableGroups
          .where((g) => g != selected)
          .fold<int>(0, (sum, g) => sum + g.remaining);
      if (bestComplete.isEmpty &&
          placed.length + otherRemaining > best.length) {
        selected.remaining = 0;
        search();
        selected.remaining = deferred;
      }
    }

    // A new pass must restore all mutable state (including each group's
    // chronological cursor), rather than inheriting one previous search path.
    for (passIndex = 0; passIndex < restartCount; passIndex++) {
      // Give every restart an opportunity on phones. A difficult first tree
      // must not consume the wall-clock budget reserved for all other orders.
      if (timeLimit != null) {
        final remainingMs =
            timeLimit.inMilliseconds - clock.elapsedMilliseconds;
        passDeadlineMs =
            clock.elapsedMilliseconds +
            (remainingMs ~/ (restartCount - passIndex)).clamp(
              1,
              remainingMs > 0 ? remainingMs : 1,
            );
      }
      sectionCells.clear();
      teacherCells.clear();
      teacherWeekly.clear();
      teacherDaily.clear();
      sectionDaily.clear();
      subjectDaily.clear();
      subjectPositionUsage.clear();
      subjectPositionByDay.clear();
      teacherDaySlotRanks.clear();
      placed.clear();
      best = <Map<String, Object?>>[];
      bestComplete = <Map<String, Object?>>[];
      bestPartialScore = 1 << 62;
      bestCompleteScore = 1 << 62;
      firstCompleteNode = null;
      runningScore = 0;
      nodes = 0;
      limitReached = false;
      for (final group in schedulableGroups) {
        group.remaining = group.total;
        group.lastGridRank = -1;
      }
      for (final row in locks) {
        final group = schedulableGroups.firstWhere(
          (g) =>
              g.sectionId == _integer(row['section_id']) &&
              g.subjectId == _integer(row['subject_id']),
        );
        final teacher = group.teachers.firstWhere(
          (t) => _integer(t['id']) == _integer(row['teacher_id']),
        );
        final day = enabledDays.firstWhere(
          (d) => _integer(d['id']) == _integer(row['day_id']),
        );
        final slot = lessonSlots.firstWhere(
          (s) => _integer(s['id']) == _integer(row['slot_id']),
        );
        apply(
          _Candidate(
            group: group,
            teacher: teacher,
            day: day,
            slot: slot,
            gridRank:
                dayRank[_integer(day['id'])]! * lessonSlots.length +
                slotRank[_integer(slot['id'])]!,
            score: 0,
          ),
        );
        placed.last['room_id'] = row['room_id'];
      }
      if (locks.isNotEmpty && best.length < placed.length) {
        best = placed.map((e) => Map<String, Object?>.from(e)).toList();
        bestPartialScore = runningScore;
        progress(
          best,
          requestedCount,
          allNodes,
          'searching',
          force: passIndex == 0,
        );
      }
      if (assignmentUpperBound == schedulableCount) {
        solveWholeWeek(
          (effectiveNodeLimit * 3 ~/ 4).clamp(1, effectiveNodeLimit),
        );
      }
      if (!(feasibilityOnly && bestComplete.isNotEmpty)) search();
      allNodes += nodes;
      anyLimitReached = anyLimitReached || limitReached;
      final passBest = bestComplete.isNotEmpty ? bestComplete : best;
      final passScore = bestComplete.isNotEmpty
          ? bestCompleteScore
          : bestPartialScore;
      final complete = passBest.length == schedulableCount;
      if ((complete && !globalComplete) ||
          (complete == globalComplete &&
              (passBest.length > globalBest.length ||
                  (passBest.length == globalBest.length &&
                      passScore < globalBestScore)))) {
        globalBest = passBest.map((e) => Map<String, Object?>.from(e)).toList();
        globalBestScore = passScore;
        globalComplete = complete;
      }
      // Once complete, a second deterministic ordering still improves period
      // rotation, but avoid spending all search passes on a solved timetable.
      if ((globalComplete && (feasibilityOnly || passIndex >= 1)) || expired())
        break;
    }
    best = globalBest;
    if (retainedSeed.length > best.length) best = retainedSeed;
    if (completeIncumbent != null && best.length < requestedCount) {
      best = completeIncumbent;
    }
    nodes = allNodes;
    limitReached = anyLimitReached;

    // Safety invariant: a teacher cannot teach two sections simultaneously.
    // Keep the best strict result rather than manufacture a full but unusable
    // timetable by overlapping teachers in the sixth period.
    // An incomplete result is explicitly reported as a draft by the caller.

    // تحقق نهائي قبل إعادة النتيجة (والحفظ في قاعدة البيانات): أي موضع لا يطابق
    // تأهيل المعلم للمادة وصلاحية المادة في صف الشعبة يُستبعد احتياطياً.
    // هذا دفاع مستقل عن مرشحي البحث، حتى لا تُحفظ حصة مخالفة عند حدوث انحدار لاحق.
    best = best.where((placement) {
      final teacherId = _integer(placement['teacher_id']);
      final subjectId = _integer(placement['subject_id']);
      final section = sectionById[_integer(placement['section_id'])];
      return section != null &&
          assignmentPolicy.isSubjectQualified(teacherId, subjectId) &&
          teacherCanTeachSubjectGrade(teacherId, subjectId, section);
    }).toList();

    // Re-evaluate day coverage AFTER safety filtering. This is a separate
    // completion condition: all lesson counts can be placed while the weekly
    // distribution still misses an active day. Never label that result complete.
    final invalidDailySpreadKeys = <String>{};
    final dailySpreadIssues = <String>[];
    for (final requirement in requirements) {
      if (_integer(requirement['weekly_lessons']) < 5) continue;
      final sectionId = _integer(requirement['section_id']);
      final subjectId = _integer(requirement['subject_id']);
      final key = '$sectionId:$subjectId';
      final hasEveryDay = enabledDays.every(
        (day) => best.any(
          (placement) =>
              _integer(placement['section_id']) == sectionId &&
              _integer(placement['subject_id']) == subjectId &&
              _integer(placement['day_id']) == _integer(day['id']),
        ),
      );
      if (!hasEveryDay && invalidDailySpreadKeys.add(key)) {
        final section = sectionById[sectionId];
        final stage =
            (section?['stage_name'] ?? requirement['stage_name'] ?? '')
                .toString()
                .trim();
        final grade =
            (section?['grade_name'] ?? requirement['grade_name'] ?? '')
                .toString()
                .trim();
        final sectionName =
            (section?['section_name'] ??
                    requirement['section_name'] ??
                    'الشعبة $sectionId')
                .toString()
                .trim();
        final location = [
          if (stage.isNotEmpty) 'المرحلة $stage',
          if (grade.isNotEmpty) 'الصف $grade',
          'الشعبة $sectionName',
        ].join('، ');
        final subjectName = (requirement['subject_name'] ?? 'المادة $subjectId')
            .toString();
        dailySpreadIssues.add(
          '$location، مادة $subjectName: يجب أن تظهر حصة واحدة على الأقل في كل يوم دوام، لكن بعض الأيام لا تحتوي على حصة منها.',
        );
      }
    }

    final placedCounts = <String, int>{};
    for (final placement in best) {
      final key = '${placement['section_id']}:${placement['subject_id']}';
      placedCounts[key] = (placedCounts[key] ?? 0) + 1;
    }
    final unscheduled = <String>[];
    for (final requirement in requirements) {
      final sectionId = _integer(requirement['section_id']);
      final subjectId = _integer(requirement['subject_id']);
      final required = _integer(requirement['weekly_lessons'])
          .clamp(0, 1000)
          .toInt();
      if (required <= 0) continue;
      final completed = placedCounts['$sectionId:$subjectId'] ?? 0;
      if (completed >= required) continue;
      final section = sectionById[sectionId];
      final stage = (section?['stage_name'] ?? requirement['stage_name'] ?? '')
          .toString()
          .trim();
      final grade = (section?['grade_name'] ?? requirement['grade_name'] ?? '')
          .toString()
          .trim();
      final sectionName =
          (section?['section_name'] ??
                  requirement['section_name'] ??
                  'الشعبة $sectionId')
              .toString()
              .trim();
      final location = [
        if (stage.isNotEmpty) 'المرحلة $stage',
        if (grade.isNotEmpty) 'الصف $grade',
        'الشعبة $sectionName',
      ].join('، ');
      final subjectName = (requirement['subject_name'] ?? 'المادة $subjectId')
          .toString();
      final possibleTeachers = qualifiedIds[subjectId] ?? const <int>{};
      final sectionTeachers = eligibleTeacherIdsFor(subjectId, section);
      final blockedForSubject = lessonSlots
          .where(
            (slot) => blockedSubjectSlotPairs.contains(
              '$subjectId:${_integer(slot['id'])}',
            ),
          )
          .length;
      final capacityMessage = sectionCapacityMessage[sectionId];
      final teacherCapacityMessage = sectionTeachers.length == 1
          ? mandatoryTeacherCapacityIssue[sectionTeachers.single]
          : null;
      final reason = section == null
          ? 'الشعبة غير موجودة؛ راجع ربط المتطلب بالصف والشعبة.'
          : invalidDailySpreadKeys.contains('$sectionId:$subjectId')
          ? 'لأن المادة مطلوبة 5 حصص أسبوعياً أو أكثر، يشترط الجدول الكامل وضع حصة واحدة منها على الأقل في كل يوم دوام. احتُفظ بالحصص التي أمكن إسنادها دون تعارض في المسودة؛ أكمل الأيام الناقصة أو عدّل قيود المعلم والفترات الممنوعة ثم أعد التوزيع.'
          : possibleTeachers.isEmpty
          ? 'لا يوجد معلم مسجل ضمن اختصاص مادة $subjectName. افتح «البيانات > المعلمون»، وعدّل معلماً وحدد المادة ضمن مواده المؤهل لتدريسها.'
          : sectionTeachers.isEmpty
          ? 'يوجد معلمون لمادة $subjectName، لكن لا يوجد معلم مسموح له بتدريسها في ${location} ضمن إعدادات الصفوف الحالية. افتح «البيانات > المعلمون» وحدد هذا الصف ضمن صفوف المعلم، أو اختر «جميع الصفوف».'
          : blockedForSubject >= lessonSlots.length && lessonSlots.isNotEmpty
          ? 'المادة $subjectName ممنوعة من جميع فترات التدريس المتاحة. افتح «البيانات > المواد» وعدّل الفترات الممنوعة لهذه المادة.'
          : enabledDays.isEmpty
          ? 'لا توجد أيام دوام مفعّلة؛ فعّل أيام المدرسة من إعدادات الدوام.'
          : lessonSlots.isEmpty
          ? 'لا توجد فترات متاحة من نوع «حصة دراسية»؛ أضف الفترات أو فعّلها في إعدادات الدوام.'
          : required > maxSchedulableForRequirement(requirement)
          ? 'إعداد هذه المادة يسمح بحد أقصى ${maxSchedulableForRequirement(requirement)} حصة أسبوعياً ضمن عدد أيام الدوام والفترات المسموحة، بينما المتطلب المسجل $required. لتمكين الحصة المتبقية عند تجاوز المطلوب عدد أيام الدوام، فعّل الفترة السادسة للشعبة (أو السابعة إذا كانت مسموحة)، واجعل الفترة غير ممنوعة للمادة ومتاحة لمعلمها؛ لم تتغير بياناتك تلقائياً.'
          : [
              if (sharedCapacityIssue != null) sharedCapacityIssue,
              if (capacityMessage != null) capacityMessage,
              if (teacherCapacityMessage != null) teacherCapacityMessage,
              if (blockedForSubject > 0 &&
                  blockedForSubject < lessonSlots.length)
                'هذه المادة ممنوعة في $blockedForSubject من أصل ${lessonSlots.length} فترات؛ تم استبعادها من تلك الفترات تلقائياً.',
              if (capacityMessage == null &&
                  teacherCapacityMessage == null &&
                  sharedCapacityIssue == null)
                (limitReached
                    ? 'توقف البحث بعد فحص $nodes حالة دون العثور على حل كامل ضمن القيود. جرّب زيادة الفترات أو تخفيف القيود اليومية/النصاب.'
                    : 'لم تتوفر خانة ومعلم يحققان القيود الحالية. راجع النصاب الأسبوعي واليومي، أوقات عدم إتاحة المعلم، وحد الحصص المتتالية.'),
            ].join(' ');
      unscheduled.add(
        '$location، مادة $subjectName: المطلوب $required حصة أسبوعياً، الموزع $completed، المتبقي ${required - completed}. $reason',
      );
    }
    progress(
      best,
      requestedCount,
      nodes,
      'done',
      force: true,
      complete:
          best.length == requestedCount &&
          unscheduled.isEmpty &&
          dailySpreadIssues.isEmpty,
    );
    return SchedulerResult(
      placements: best,
      unscheduled: unscheduled,
      requestedCount: requestedCount,
      exploredNodes: nodes,
      searchLimitReached:
          (limitReached && best.length < assignmentUpperBound) ||
          (timedOut && best.length < requestedCount),
      dailySpreadIssues: dailySpreadIssues,
    );
  }
}

int _integer(Object? value, {int fallback = 0}) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse('$value') ?? fallback;
}
