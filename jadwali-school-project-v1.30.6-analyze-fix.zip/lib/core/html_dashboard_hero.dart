import 'package:flutter/material.dart';

import 'interface_settings.dart';

/// Interactive Flutter counterpart of the approved HTML dashboard banner.
/// Actions open real features and remain reachable at 320 logical pixels.
class HtmlDashboardHero extends StatelessWidget {
  const HtmlDashboardHero({
    super.key,
    required this.onRepair,
    required this.onTimetable,
  });

  final VoidCallback onRepair;
  final VoidCallback onTimetable;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final ui = InterfaceSettings.instance;
    final accent = colors.primary;
    final width = MediaQuery.sizeOf(context).width;
    final narrow = width < 650;
    final compact = width < 420;

    Widget repairButton() => FilledButton(
      onPressed: onRepair,
      style: FilledButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: accent,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      child: Row(
        mainAxisSize: compact ? MainAxisSize.max : MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.auto_fix_high_outlined, size: 20),
          const SizedBox(width: 8),
          Flexible(child: Text('استكشف الإصلاح الذكي',
            maxLines: 2,
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13))),
        ],
      ),
    );

    Widget timetableButton() => TextButton(
      onPressed: onTimetable,
      style: TextButton.styleFrom(foregroundColor: Colors.white),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.calendar_month_outlined, size: 17),
          SizedBox(width: 7),
          Flexible(child: Text('فتح الجدول الدراسي',
            maxLines: 2, textAlign: TextAlign.center)),
        ],
      ),
    );

    return Container(
      key: const ValueKey('html-dashboard-hero'),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(32),
        gradient: LinearGradient(
          begin: AlignmentDirectional.topStart,
          end: AlignmentDirectional.bottomEnd,
          colors: [
            Color.lerp(accent, const Color(0xff293a9a), .38)!,
            accent,
            ui.design.b,
          ],
        ),
        boxShadow: [BoxShadow(
          color: accent.withValues(alpha: .15),
          blurRadius: 30,
          offset: const Offset(0, 12),
        )],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(32),
        child: Stack(children: [
          Positioned(left: -95, top: -120, child: Container(
            width: 360, height: 360,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withValues(alpha: .17)),
            ),
          )),
          Positioned(right: -75, bottom: -200, child: Container(
            width: 310, height: 310,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withValues(alpha: .045),
            ),
          )),
          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: narrow ? 18 : 34,
              vertical: narrow ? 24 : 37,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Flexible(child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: .13),
                      borderRadius: BorderRadius.circular(90),
                      border: Border.all(color: Colors.white.withValues(alpha: .2)),
                    ),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.auto_awesome, color: Colors.white, size: 17),
                      SizedBox(width: 7),
                      Flexible(child: Text('تجربة جديدة للإصلاح الذكي',
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        style: TextStyle(color: Colors.white, fontSize: 12,
                          fontWeight: FontWeight.w800))),
                    ]),
                  )),
                ]),
                SizedBox(height: compact ? 18 : 25),
                Text('جدول أجمل، وقرارات أذكى،\nوتغييرات أقل.',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    height: 1.4,
                    fontSize: compact ? 22 : narrow ? 26 : 34,
                  )),
                const SizedBox(height: 12),
                Text('حل التعارضات مع إبراز المواضع المتأثرة،\nومعاينة كل خطوة قبل اعتمادها.',
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: .85),
                    fontSize: compact ? 12 : 15,
                    height: 1.7,
                  )),
                SizedBox(height: compact ? 15 : 23),
                if (compact) ...[
                  // Keep the primary action within the available width.
                  SizedBox(width: double.infinity, child: repairButton()),
                  Align(alignment: AlignmentDirectional.centerStart,
                    child: timetableButton()),
                ] else ...[
                  Wrap(spacing: 9, runSpacing: 10, children: [
                    repairButton(),
                  ]),
                  const SizedBox(height: 10),
                  timetableButton(),
                ],
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
