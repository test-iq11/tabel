import 'package:flutter/material.dart';

/// The 18 colour families from the user-approved interactive HTML preview.
/// These colours apply to the app chrome only; timetable subjects and printed
/// reports keep their own independent colour system.
class JadwaliPalettes {
  const JadwaliPalettes._();

  static const palettes = <String, (String, Color, Color)>{
    'indigo': ('نيلي هادئ', Color(0xff525fe8), Color(0xff9298f8)),
    'teal': ('فيروزي ناعم', Color(0xff058f93), Color(0xff58c7bf)),
    'purple': ('بنفسجي مخملي', Color(0xff8754be), Color(0xffbd97e7)),
    'blue': ('أزرق سماوي', Color(0xff277bc9), Color(0xff81c1f1)),
    'coral': ('مرجاني دافئ', Color(0xffd66d79), Color(0xfff5a88c)),
    'emerald': ('زمردي طبيعي', Color(0xff138d72), Color(0xff60ceb0)),
    'ocean': ('أزرق المحيط', Color(0xff2868a3), Color(0xff54b7cf)),
    'lavender': ('لافندر راقٍ', Color(0xff7565b5), Color(0xffc3b2ed)),
    'rose': ('وردي غباري', Color(0xffb65d82), Color(0xffeca7c4)),
    'copper': ('نحاسي أنيق', Color(0xffaa704b), Color(0xffeab58d)),
    'mint': ('نعناعي هادئ', Color(0xff208f83), Color(0xff95dac7)),
    'amethyst': ('جمشت', Color(0xff7152a5), Color(0xffb1a0dc)),
    'slate': ('أزرق أردوازي', Color(0xff45658e), Color(0xff8da9ce)),
    'olive': ('زيتوني عصري', Color(0xff78833e), Color(0xffb9c77b)),
    'sky': ('سماوي مضيء', Color(0xff248ebd), Color(0xff8ed5ea)),
    'berry': ('توتي فخم', Color(0xff923f74), Color(0xffd98ab6)),
    'peach': ('مشمشي لطيف', Color(0xffbc735a), Color(0xfff6b69c)),
    'forest': ('أخضر الغابة', Color(0xff306f5d), Color(0xff7bb9a1)),
  };
}
