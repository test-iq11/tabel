import 'minimal_repair_dialog.dart';
import 'weekly_lesson_content.dart';
import '../../services/lesson_swap_service.dart';
import '../../core/timetable_ordering.dart';

import 'dart:convert';
import 'dart:async';

import '../../core/interface_settings.dart';

import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

import '../../core/ui_helpers.dart';
import '../../core/preview_widgets.dart';
import '../../core/jadwali_visuals.dart';
import '../../core/timetable_palette.dart';
import '../../data/database_service.dart';

import '../../services/auto_scheduler_service.dart';
import '../../services/conflict_detection_service.dart';
import '../../services/preflight_inspection_service.dart';
import '../../services/teacher_assignment_policy.dart';
import '../../services/teacher_availability_policy.dart';
import '../../services/school_timetable_policy.dart';
import '../../services/constraint_explanation_service.dart';
import '../../services/schedule_comparison_service.dart';
import 'constraint_explanation_dialog.dart';
import 'schedule_comparison_dialog.dart';
import 'schedule_search_dialog.dart';

List<Map<String, Object?>> _schedulerMapList(Object? value) => (value as List)
    .map((row) => Map<String, Object?>.from(row as Map))
    .toList();

int _asInt(Object? value, {int fallback = 0}) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse('$value') ?? fallback;
}

class TimetablePage extends StatefulWidget {
  const TimetablePage({
    required this.onChanged,
    this.focusTarget,
    this.searchPage = false,
    super.key,
  });
  final VoidCallback onChanged;
  final bool searchPage;
  final Map<String, int?>? focusTarget;
  @override
  State<TimetablePage> createState() => _TimetablePageState();
}

class _TimetablePageState extends State<TimetablePage> {
  Future<Map<String, Object?>>? _future;
  int? _sectionFilter;
  int? _dayFilter;
  int? _teacherFilter;
  String _viewMode = 'list';
  double _cellScale = 1;
  bool _isGenerating = false;
  bool _changingPin = false;
  bool _swapping = false;
  Map<String, Object?>? _swapFirst;

  Future<void> _tapLesson(
    Map<String, Object?> entry,
    Map<String, Object?> data,
  ) async {
    if (_swapping || _changingPin || _isGenerating) return;
    if (_swapFirst == null) {
      if (_asInt(entry['is_locked']) == 1) {
        showMessage(context, 'هذه الحصة مقفلة؛ اضغط مطولاً لفتح القفل.');
        return;
      }
      setState(() => _swapFirst = Map.from(entry));
      return;
    }
    if (_swapFirst!['id'] == entry['id']) {
      setState(() => _swapFirst = null);
      return;
    }
    final first = _swapFirst!;
    var committed = false;
    setState(() => _swapping = true);
    try {
      await DatabaseService.instance.swapLessons(
        yearId: _asInt(data['yearId']),
        first: first,
        second: Map.from(entry),
      );
      committed = true;
      final updated = await _loadData();
      if (!mounted) return;
      setState(() {
        _swapFirst = null;
        _future = SynchronousFuture(updated);
      });
      widget.onChanged();
      _flash(entry);
      _offerUndo(
        'تم تبديل ${first['subject_name']} و${entry['subject_name']} فقط.',
      );
    } catch (error) {
      if (!mounted) return;
      if (committed) {
        setState(_reload);
        _offerUndo(
          'تم حفظ التبديل؛ تعذر تحديث العرض مؤقتاً. حدّث الصفحة إذا لزم.',
        );
        return;
      }
      setState(() => _swapping = false);
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          icon: const Icon(Icons.swap_horiz, size: 32),
          title: const Text('هذا التبديل غير متاح'),
          content: Text(
            '${error is StateError ? error.message : error}\n\nلم يتم حفظ التبديل. يمكنك اختيار حصة أخرى.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('اختيار حصة أخرى'),
            ),
          ],
        ),
      );
    } finally {
      if (mounted) setState(() => _swapping = false);
    }
  }

  Widget _swapBanner() {
    final color = Theme.of(context).colorScheme;
    return Container(
      key: const ValueKey('touch-swap-banner'),
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.primaryContainer.withValues(alpha: .45),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.primary.withValues(alpha: .2)),
      ),
      child: Row(
        children: [
          if (_swapping)
            const SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(strokeWidth: 2),
            )
          else
            Icon(Icons.swap_horiz, color: color.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _swapping
                      ? 'جارٍ فحص التبديل وحفظه…'
                      : _swapFirst == null
                      ? 'المس الحصة الأولى ثم الثانية للتبديل'
                      : '${_swapFirst!['subject_name']} · ${_swapFirst!['day_name']} · ${_swapFirst!['slot_name']}',
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
                Text(
                  _swapFirst == null
                      ? 'ضغط مطوّل للقفل · زر المعلومات للتفاصيل'
                      : 'اختر الثانية في الصف نفسه؛ يمكنك الانتقال إلى يوم آخر.',
                  style: TextStyle(fontSize: 10, color: color.onSurfaceVariant),
                ),
              ],
            ),
          ),
          if (_swapFirst != null)
            TextButton(
              onPressed: _swapping
                  ? null
                  : () => setState(() => _swapFirst = null),
              child: const Text('إلغاء'),
            )
          else
            IconButton(
              tooltip: 'التراجع عن آخر تعديل',
              onPressed:
                  DatabaseService.instance.canUndoManualEdit && !_changingPin
                  ? _undoManualEdit
                  : null,
              icon: const Icon(Icons.undo),
            ),
        ],
      ),
    );
  }

  int? _pinningEntryId;
  String? _detailKey, _flashKey;
  Timer? _flashTimer;
  int? _highlightSectionId;
  int? _highlightDayId;
  int? _highlightSlotId;
  int? _lastFocusToken;

  @override
  void initState() {
    super.initState();
    _applyFocusTarget(widget.focusTarget);
    _reload();
  }

  @override
  void didUpdateWidget(covariant TimetablePage oldWidget) {
    super.didUpdateWidget(oldWidget);
    final token = widget.focusTarget?['token'];
    if (token != null && token != _lastFocusToken) {
      _applyFocusTarget(widget.focusTarget);
    }
  }

  void _applyFocusTarget(Map<String, int?>? target) {
    if (target == null) return;
    _lastFocusToken = target['token'];
    _teacherFilter = target['teacherId'];
    _viewMode = _teacherFilter != null ? 'teacher' : 'list';
    _highlightSectionId = target['sectionId'];
    _highlightDayId = target['dayId'];
    _highlightSlotId = target['slotId'];
    if (_highlightSectionId != null) _sectionFilter = _highlightSectionId;
    if (_highlightDayId != null) _dayFilter = _highlightDayId;
  }

  String _entryKey(Map<String, Object?> e) =>
      '${e['section_id']}:${e['day_id']}:${e['slot_id']}';
  void _flash(Map<String, Object?> e) {
    _flashTimer?.cancel();
    setState(() => _flashKey = _entryKey(e));
    _flashTimer = Timer(const Duration(milliseconds: 1200), () {
      if (mounted) setState(() => _flashKey = null);
    });
  }

  @override
  void dispose() {
    _flashTimer?.cancel();
    super.dispose();
  }

  Future<void> _openDetails(
    Map<String, Object?> entry,
    Map<String, Object?> data,
  ) async {
    if (MediaQuery.sizeOf(context).width > 1100 &&
        !InterfaceSettings.instance.reading) {
      setState(() => _detailKey = _entryKey(entry));
      return;
    }
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(22),
          child: _detailContent(entry, data, onClose: () => Navigator.pop(ctx)),
        ),
      ),
    );
  }

  Widget _detailContent(
    Map<String, Object?> e,
    Map<String, Object?> data, {
    VoidCallback? onClose,
  }) {
    List<Map<String, Object?>> rows(String key) =>
        (data[key] as List).cast<Map<String, Object?>>();
    final locked = _asInt(e['is_locked']) == 1;
    final section = rows('sections')
        .where((s) => _asInt(s['id']) == _asInt(e['section_id']))
        .firstOrNull;
    final availabilityPolicy = TeacherAvailabilityPolicy(rows('availability'));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text('تفاصيل الحصة', style: Theme.of(context).textTheme.titleLarge),
        SizedBox(height: 16),
        Text(
          '${e['subject_name']}',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
        ),
        SizedBox(height: 8),
        Text('${e['teacher_name'] ?? 'غير مسند'}'),
        Text('${e['day_name']} · ${e['slot_name']}'),
        Text('${e['start_time']} – ${e['end_time']}'),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withValues(alpha: .06),
            borderRadius: BorderRadius.circular(17),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'شروط هذه الحصة',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 8),
              Text(
                locked
                    ? 'هذه الحصة مقفلة؛ يحافظ البحث على مكانها.'
                    : 'هذه الحصة غير مقفلة؛ يمكن للبحث نقلها وفق الشروط.',
                style: const TextStyle(fontSize: 12),
              ),
              Text(
                e['teacher_id'] == null
                    ? 'هذه الحصة غير مسندة إلى معلم بعد.'
                    : !availabilityPolicy.isAvailable(
                        teacherId: _asInt(e['teacher_id']),
                        dayId: _asInt(e['day_id']),
                        slotId: _asInt(e['slot_id']),
                        gradeId: _asInt(
                          section?['grade_id'] ??
                              e['section_grade_id'] ??
                              e['grade_id'],
                        ),
                        subjectId: _asInt(e['subject_id']),
                      )
                    ? 'تنبيه: يوجد منع لإتاحة المعلم في هذه الفترة.'
                    : 'لا يوجد منع مسجّل لإتاحة المعلم في هذه الفترة.',
                style: const TextStyle(fontSize: 12),
              ),
              Text(
                rows('subjectBlockedSlots').any(
                      (b) =>
                          b['subject_id'] == e['subject_id'] &&
                          b['slot_id'] == e['slot_id'],
                    )
                    ? 'تنبيه: الفترة الحالية ممنوعة لهذه المادة.'
                    : 'الفترة الحالية ليست ممنوعة لهذه المادة.',
                style: const TextStyle(fontSize: 12),
              ),
              const SizedBox(height: 6),
              Text(
                'هذه مراجعة للشروط الحالية، وليست تفسيراً لسبب اختيار المحرك لهذا المكان.',
                style: TextStyle(
                  fontSize: 10,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 20),
        OutlinedButton.icon(
          key: ValueKey('repair-lesson-${e['id']}'),
          onPressed: locked || _swapping || _isGenerating
              ? null
              : () async {
                  onClose?.call();
                  final saved = await showMinimalRepairDialog(
                    context: context, data: data, entry: e,
                  );
                  if (!mounted || !saved) return;
                  setState(() { _swapFirst = null; _reload(); });
                  widget.onChanged();
                  showMessage(context, 'تم حفظ إصلاح الحصة في نسخة جديدة، وبقيت السابقة محفوظة.');
                },
          icon: const Icon(Icons.auto_fix_high),
          label: const Text('أصلح هذه الحصة · معاينة البدائل'),
        ),
        SizedBox(height: 8),
        FilledButton.icon(
          onPressed: _changingPin
              ? null
              : () {
                  onClose?.call();
                  _togglePin(e);
                },
          icon: Icon(locked ? Icons.lock_open : Icons.lock_outline),
          label: Text(locked ? 'فك قفل الحصة' : 'قفل الحصة'),
        ),
        SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: locked
              ? null
              : () async {
                  onClose?.call();
                  await _editCell(
                    rows('sections')
                        .firstWhere((s) => s['id'] == e['section_id']),
                    rows('days').firstWhere((d) => d['id'] == e['day_id']),
                    rows('slots').firstWhere((p) => p['id'] == e['slot_id']),
                    e,
                    rows('slots'),
                    rows('entries'),
                    rows('requirements'),
                    rows('subjects'),
                    rows('teachers'),
                    rows('qualifications'),
                    rows('teacherGrades'),
                    rows('teacherSubjectGrades'),
                    rows('days'),
                  );
                },
          icon: const Icon(Icons.edit_outlined),
          label: Text('تعديل الحصة'),
        ),
        SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: locked
              ? null
              : () {
                  onClose?.call();
                  _chooseMove(e, data);
                },
          icon: const Icon(Icons.swap_horiz),
          label: Text('نقل الحصة'),
        ),
        SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: e['teacher_id'] == null
              ? null
              : () {
                  onClose?.call();
                  setState(() {
                    _teacherFilter = _asInt(e['teacher_id']);
                    _viewMode = 'teacher';
                    _detailKey = null;
                  });
                },
          icon: const Icon(Icons.person_outline),
          label: Text('جدول المعلم'),
        ),
      ],
    );
  }

  Future<void> _chooseMove(
    Map<String, Object?> e,
    Map<String, Object?> data,
  ) async {
    List<Map<String, Object?>> rows(String key) =>
        (data[key] as List).cast<Map<String, Object?>>();
    var dayId = _asInt(e['day_id']), slotId = _asInt(e['slot_id']);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, update) => AlertDialog(
          title: Text('نقل الحصة'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<int>(
                initialValue: dayId,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'اليوم'),
                items: [
                  for (final d in rows('days'))
                    DropdownMenuItem(
                      value: _asInt(d['id']),
                      child: Text('${d['name']}'),
                    ),
                ],
                onChanged: (v) => update(() => dayId = v!),
              ),
              SizedBox(height: 12),
              DropdownButtonFormField<int>(
                initialValue: slotId,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'الحصة'),
                items: [
                  for (final p in rows('slots'))
                    DropdownMenuItem(
                      value: _asInt(p['id']),
                      child: Text('${p['name']}'),
                    ),
                ],
                onChanged: (v) => update(() => slotId = v!),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text('فحص ونقل'),
            ),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    await _moveEntryToCell(
      source: e,
      section: rows('sections').firstWhere((s) => s['id'] == e['section_id']),
      day: rows('days').firstWhere((d) => d['id'] == dayId),
      slot: rows('slots').firstWhere((p) => p['id'] == slotId),
      allDays: rows('days'),
      allSlots: rows('slots'),
    );
    if (mounted) setState(() => _dayFilter = dayId);
  }

  Widget _readingTools() {
    final ui = InterfaceSettings.instance;
    return Wrap(
      spacing: 6,
      children: [
        TextButton.icon(
          onPressed: () {
            ui.compact = !ui.compact;
            ui.save();
          },
          icon: const Icon(Icons.density_small, size: 18),
          label: Text(ui.compact ? 'عرض مريح' : 'عرض مختصر'),
        ),
        TextButton.icon(
          onPressed: ui.toggleReading,
          icon: Icon(
            ui.reading ? Icons.fullscreen_exit : Icons.fullscreen,
            size: 18,
          ),
          label: Text(ui.reading ? 'إنهاء القراءة' : 'ملء الشاشة'),
        ),
      ],
    );
  }

  Future<void> _togglePin(Map<String, Object?> entry) async {
    if (_changingPin || _isGenerating || _swapping) return;
    setState(() {
      _changingPin = true;
      _pinningEntryId = _asInt(entry['id']);
    });
    try {
      final db = DatabaseService.instance;
      final yearId = await db.activeYearId();
      if (yearId == null) throw StateError('لا يوجد عام نشط.');
      final locked = _asInt(entry['is_locked']) != 1;
      await db.setEntryLock(
        yearId: yearId,
        sectionId: _asInt(entry['section_id']),
        dayId: _asInt(entry['day_id']),
        slotId: _asInt(entry['slot_id']),
        locked: locked,
      );
      final updated = await _loadData();
      if (!mounted) return;
      setState(() {
        _future = SynchronousFuture(updated);
        _swapFirst = null;
      });
      widget.onChanged();
      _flash(entry);
      _offerUndo(locked ? 'تم قفل الحصة في مكانها.' : 'تم فك قفل الحصة.');
    } catch (e) {
      if (mounted)
        showMessage(context, 'تعذر تحديث قفل الحصة: $e', error: true);
    } finally {
      if (mounted)
        setState(() {
          _changingPin = false;
          _pinningEntryId = null;
        });
    }
  }

  Future<void> _undoManualEdit() async {
    if (_swapping || _changingPin || _isGenerating) return;
    setState(() => _swapping = true);
    try {
      await DatabaseService.instance.undoLastManualEdit();
      if (!mounted) return;
      final updated = await _loadData();
      if (!mounted) return;
      setState(() {
        _swapFirst = null;
        _future = SynchronousFuture(updated);
      });
      widget.onChanged();
      showMessage(context, 'تم التراجع عن آخر تعديل يدوي.');
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر التراجع: $e', error: true);
    } finally {
      if (mounted) setState(() => _swapping = false);
    }
  }

  void _offerUndo(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          duration: const Duration(seconds: 8),
          action: DatabaseService.instance.canUndoManualEdit
              ? SnackBarAction(label: 'تراجع', onPressed: _undoManualEdit)
              : null,
        ),
      );
  }

  void _reload() {
    _swapFirst = null;
    _future = _loadData();
  }

  Future<Map<String, Object?>> _loadData() async {
    final db = DatabaseService.instance;
    final yearId = await db.activeYearId();
    final versionId = await db.activeVersionId(yearId);
    return {
      'year': await db.activeYear() ?? <String, Object?>{},
      'versionId': versionId,
      'version': versionId == null
          ? <String, Object?>{}
          : (await db.rows('timetable_versions')).firstWhere(
              (v) => v['id'] == versionId,
              orElse: () => <String, Object?>{},
            ),
      'sections': await db.sectionsDetailed(),
      'subjects': await db.rows('subjects', orderBy: 'name'),
      'teachers': await db.rows('teachers', orderBy: 'name'),
      'qualifications': await db.rows('teacher_subjects'),
      'teacherGrades': await db.rows('teacher_grades'),
      'teacherSubjectGrades': await db.rows('teacher_subject_grades'),
      'subjectBlockedSlots': await db.rows('subject_blocked_slots'),
      'days': await db.rows('school_days', orderBy: 'position'),
      'slots': await db.rows('time_slots', orderBy: 'position'),
      'entries': await db.entriesDetailed(versionId: versionId),
      'requirements': await db.requirementsDetailed(),
      'availability': await db.rows('teacher_availability'),
      'yearId': yearId,
    };
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: FutureBuilder<Map<String, Object?>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.hasError)
          return emptyState(
            icon: Icons.error_outline,
            title: 'تعذر تحميل الجدول',
            message: '${snapshot.error}',
          );
        if (!snapshot.hasData &&
            snapshot.connectionState != ConnectionState.done)
          return Center(child: CircularProgressIndicator());
        if (!snapshot.hasData)
          return emptyState(
            icon: Icons.info_outline,
            title: 'لا توجد بيانات',
            message: 'لم تُرجع قاعدة البيانات بيانات للجدول. حدّث الصفحة وحاول مرة أخرى.',
          );
        final data = snapshot.data!;
        if (widget.searchPage) return _searchOverview(data);
        final table = _previewTable(data);
        if (MediaQuery.sizeOf(context).width <= 1100 ||
            InterfaceSettings.instance.reading)
          return table;
        final entries = (data['entries'] as List).cast<Map<String, Object?>>();
        final selected = entries
            .where((e) => _entryKey(e) == _detailKey)
            .firstOrNull;
        return Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(child: table),
            const VerticalDivider(width: 1),
            SizedBox(
              width: 290,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: selected == null
                    ? Text('اختر حصة من الجدول لعرض تفاصيلها هنا.')
                    : _detailContent(selected, data),
              ),
            ),
          ],
        );
      },
    ),
  );

  Widget _tableActions() => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      IconButton(
        tooltip: 'تحديث',
        onPressed: _isGenerating ? null : () => setState(_reload),
        icon: const Icon(Icons.refresh),
      ),
      PopupMenuButton<String>(
        enabled: !_isGenerating,
        tooltip: 'أدوات الجدول',
        onSelected: (value) {
          if (value == 'undo') _undoManualEdit();
          if (value == 'advanced') _generateAutomatically(advanced: true);
          if (value == 'constraints') _explainCurrentConstraints();
          if (value == 'preflight') _runPreflightOnly();
          if (value == 'zoom')
            setState(() => _cellScale = _cellScale == 1 ? 1.25 : 1);
        },
        itemBuilder: (_) => [
          PopupMenuItem(
            value: 'undo',
            enabled: DatabaseService.instance.canUndoManualEdit,
            child: const Text('تراجع عن آخر تعديل يدوي'),
          ),
          PopupMenuItem(
            value: 'advanced',
            child: Text('خيارات البحث ومقارنة الحلول'),
          ),
          PopupMenuItem(value: 'constraints', child: Text('شرح القيود')),
          PopupMenuItem(value: 'preflight', child: Text('فحص قبل التوزيع')),
          PopupMenuItem(
            value: 'zoom',
            child: Text('تكبير / تصغير خلايا الجدول'),
          ),
        ],
      ),
    ],
  );

  Widget _searchOverview(Map<String, Object?> data) {
    final entries = (data['entries'] as List).cast<Map<String, Object?>>();
    final requirements = (data['requirements'] as List)
        .cast<Map<String, Object?>>();
    final requested = requirements.fold<int>(
      0,
      (n, r) => n + _asInt(r['weekly_lessons']),
    );
    final pins = entries.where((e) => _asInt(e['is_locked']) == 1).length;
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        pageHeading(
          'توزيع الأسبوع كاملاً',
          'يبحث المحرك في أيام الأسبوع كلها ويعيد ترتيب الحصص بما يتوافق مع القيود الحالية.',
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Wrap(
              spacing: 30,
              runSpacing: 18,
              children: [
                _ResultMetric(value: '$requested', label: 'حصة مطلوبة'),
                _ResultMetric(
                  value: '${entries.length}',
                  label: 'في الجدول الحالي',
                ),
                _ResultMetric(value: '$pins', label: 'حصة مثبتة'),
              ],
            ),
          ),
        ),
        SizedBox(height: 18),
        FilledButton.icon(
          onPressed: _isGenerating ? null : _generateAutomatically,
          icon: const Icon(Icons.auto_awesome),
          label: Text(_isGenerating ? 'جارٍ البحث…' : 'إصلاح الجدول ثم تحسينه'),
        ),
        SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: _isGenerating
              ? null
              : () => _generateAutomatically(advanced: true),
          icon: const Icon(Icons.compare_arrows),
          label: Text('أولويات البحث ومقارنة الحلول'),
        ),
        SizedBox(height: 18),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.fact_check_outlined),
                title: Text('فحص جاهزية المدرسة'),
                subtitle: Text('مراجعة المعلمين والمتطلبات والسعة المتاحة'),
                trailing: const Icon(Icons.chevron_left),
                onTap: _isGenerating ? null : _runPreflightOnly,
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.lightbulb_outline),
                title: Text('شرح القيود'),
                subtitle: Text('ما الذي يمنع الحل وما التعديل المقترح؟'),
                trailing: const Icon(Icons.chevron_left),
                onTap: _isGenerating ? null : _explainCurrentConstraints,
              ),
            ],
          ),
        ),
        SizedBox(height: 16),
        Text(
          'تظهر متابعة البحث وأزرار الإيقاف والاستئناف أثناء العمل. تُفعّل النتيجة الكاملة بعد التحقق منها، وتبقى النسخة السابقة في الأرشيف.',
        ),
      ],
    );
  }

  Color _subjectColor(
    Map<String, Object?>? entry,
    List<Map<String, Object?>> subjects,
  ) {
    final subjectId = entry == null ? null : _asInt(entry['subject_id']);
    // Consistent, accessible colors across editor, teacher view and PDF.
    // Historic backups store the same blue value for all subjects; ignore it.
    return Color(TimetablePalette.accent(subjectId ?? 1));
  }

  int? _highlightSubject;
  Widget _previewTable(Map<String, Object?> data) {
    List<Map<String, Object?>> rows(String key) =>
        (data[key] as List).cast<Map<String, Object?>>();
    final sections = rows('sections'),
        teachers = rows('teachers'),
        subjects = rows('subjects'),
        entries = rows('entries'),
        requirements = rows('requirements');
    final days = rows('days')
        .where(
          (d) =>
              d['is_active'] == 1 || entries.any((e) => e['day_id'] == d['id']),
        )
        .toList();
    final slots = rows('slots')
        .where(
          (s) =>
              s['kind'] == 'lesson' ||
              entries.any((e) => e['slot_id'] == s['id']),
        )
        .toList();
    if (sections.isEmpty || days.isEmpty || slots.isEmpty)
      return emptyState(
        icon: Icons.calendar_month_outlined,
        title: 'أكمل بيانات المدرسة',
        message: 'أضف الصفوف من إعداد الجدول > الصفوف والشعب، وأوقات الدوام من إعدادات المدرسة.',
      );
    final section = sections.firstWhere(
      (s) => s['id'] == _sectionFilter,
      orElse: () => sections.first,
    );
    final day = days.firstWhere(
      (d) => d['id'] == _dayFilter,
      orElse: () => days.first,
    );
    final teacher = teachers.isEmpty
        ? <String, Object?>{}
        : teachers.firstWhere(
            (t) => t['id'] == _teacherFilter,
            orElse: () => teachers.first,
          );
    final isDaily = _viewMode == 'day', isTeacher = _viewMode == 'teacher';
    final chosen = isDaily
        ? day['id']
        : isTeacher
        ? teacher['id']
        : section['id'];
    final options = isDaily
        ? days
        : isTeacher
        ? teachers
        : sections;
    final version = (data['version'] as Map).cast<String, Object?>();
    final requested = requirements.fold<int>(
      0,
      (sum, r) => sum + _asInt(r['weekly_lessons']),
    );
    final width = _viewMode == 'list'
        ? (MediaQuery.sizeOf(context).width - 84).clamp(180.0, 900.0)
        : ((MediaQuery.sizeOf(context).width > 700 ? 148.0 : 126.0) *
                  _cellScale)
              .clamp(104.0, 240.0);
    final height =
        (_viewMode == 'list'
            ? (InterfaceSettings.instance.compact ? 88.0 : 112.0)
            : (InterfaceSettings.instance.compact ? 140.0 : 156.0)) *
        _cellScale *
        MediaQuery.textScalerOf(context).scale(1).clamp(1.0, 1.4);
    Widget header(String title, [String subtitle = '']) => SizedBox(
      width: width,
      height: 62,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          ),
          if (subtitle.isNotEmpty)
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 10,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
        ],
      ),
    );
    Widget cell(
      Map<String, Object?> currentDay,
      Map<String, Object?> slot,
      Map<String, Object?>? currentSection,
    ) {
      final matching = entries
          .where(
            (e) =>
                e['day_id'] == currentDay['id'] &&
                e['slot_id'] == slot['id'] &&
                (isTeacher
                    ? e['teacher_id'] == teacher['id']
                    : e['section_id'] == currentSection?['id']),
          )
          .toList();
      final allowed =
          currentSection != null &&
          slot['kind'] == 'lesson' &&
          _asInt(slot['is_available'], fallback: 1) == 1 &&
          _isAllowedLessonCell(
            section: currentSection,
            day: currentDay,
            slot: slot,
            allDays: rows('days'),
            allSlots: rows('slots'),
            requirements: requirements,
          );
      Future<void> edit(Map<String, Object?>? entry) async {
        final target = entry == null
            ? currentSection
            : sections.firstWhere(
                (s) => s['id'] == entry['section_id'],
                orElse: () => <String, Object?>{},
              );
        if (target == null || target.isEmpty) return;
        if (entry == null && !allowed) return;
        await _editCell(
          target,
          currentDay,
          slot,
          entry,
          rows('slots'),
          entries,
          requirements,
          subjects,
          teachers,
          rows('qualifications'),
          rows('teacherGrades'),
          rows('teacherSubjectGrades'),
          rows('days'),
        );
      }

      Widget lesson(Map<String, Object?> e) {
        final color = _subjectColor(e, subjects);
        final swapSelected = _swapFirst?['id'] == e['id'];
        final swapReason = _swapFirst == null || swapSelected
            ? null
            : const LessonSwapService().validate(data, _swapFirst!, e);
        final scheme = Theme.of(context).colorScheme;
        final focused =
            e['section_id'] == _highlightSectionId &&
            e['day_id'] == _highlightDayId &&
            e['slot_id'] == _highlightSlotId;
        final content = Opacity(
          opacity:
              _highlightSubject != null && e['subject_id'] != _highlightSubject
              ? .3
              : 1,
          child: Material(
            color: swapSelected || _flashKey == _entryKey(e)
                ? Theme.of(context).colorScheme.primaryContainer
                : _viewMode == 'list'
                ? Color.alphaBlend(color.withValues(alpha: .07), scheme.surface)
                : Theme.of(context).brightness == Brightness.dark
                    ? Color.alphaBlend(
                        color.withValues(alpha: .18), scheme.surface)
                    : Color(TimetablePalette.tint(_asInt(e['subject_id']))),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(
                _viewMode == 'list'
                    ? InterfaceSettings.instance.design.round * .7
                    : 15,
              ),
              side: BorderSide(
                color: swapSelected
                    ? scheme.primary
                    : _swapFirst != null
                    ? (swapReason == null ? Colors.teal : scheme.outlineVariant)
                    : focused
                    ? Colors.orange
                    : _viewMode == 'list'
                    ? Theme.of(context).colorScheme.outlineVariant
                    : Colors.transparent,
                width: swapSelected || focused ? 2 : 1,
              ),
            ),
            child: InkWell(
              borderRadius: BorderRadius.circular(15),
              key: ValueKey(
                'lesson-${e['section_id']}-${e['day_id']}-${e['slot_id']}',
              ),
              onTap: _swapping ? null : () => _tapLesson(e, data),
              onLongPress: _changingPin || _isGenerating || _swapping
                  ? null
                  : () => _togglePin(e),
              child: Stack(
                children: [
                  if (_viewMode == 'list')
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(40, 12, 16, 12),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '${e['subject_name'] ?? 'مادة'}',
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurface,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    '${e['teacher_name'] ?? 'غير مسند'} · ${slot['start_time']}',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceVariant,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              key: ValueKey('lesson-details-${e['id']}'),
                              tooltip: 'تفاصيل الحصة',
                              onPressed: _swapping
                                  ? null
                                  : () => _openDetails(e, data),
                              icon: Icon(
                                Icons.info_outline,
                                size: 20,
                                color: scheme.primary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  else
                    WeeklyLessonContent(
                      subject: '${e['subject_name'] ?? 'مادة'}',
                      teacher: isTeacher
                          ? '${displayGradeName(e['grade_name'])} · ${e['section_name'] ?? ''}'
                          : '${e['teacher_name'] ?? 'غير مسند'}',
                      time: '${slot['start_time']} – ${slot['end_time']}',
                      color: Theme.of(context).brightness == Brightness.dark
                          ? scheme.onSurface
                          : color,
                    ),
                  if (_viewMode != 'list')
                    Positioned(
                      top: 0,
                      right: 0,
                      child: IconButton(
                        tooltip: 'تفاصيل الحصة',
                        constraints: const BoxConstraints.tightFor(
                          width: 32,
                          height: 32,
                        ),
                        padding: EdgeInsets.zero,
                        visualDensity: VisualDensity.compact,
                        onPressed: _swapping
                            ? null
                            : () => _openDetails(e, data),
                        icon: const Icon(Icons.info_outline, size: 16),
                      ),
                    ),
                  if (_swapFirst != null)
                    Positioned(
                      bottom: 3,
                      right: 8,
                      left: 38,
                      child: Text(
                        swapSelected
                            ? '✓ الأولى'
                            : swapReason == null
                            ? '⇄ مناسب'
                            : 'غير متاح',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 10,
                          color: swapSelected || swapReason == null
                              ? scheme.primary
                              : scheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  if (_changingPin && _pinningEntryId == _asInt(e['id']))
                    const Positioned(
                      bottom: 8,
                      right: 8,
                      child: SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    ),
                  if (_asInt(e['is_locked']) == 1)
                    Positioned(
                      top: 7,
                      left: 7,
                      child: Icon(Icons.lock_outline, size: 12, color: color),
                    ),
                ],
              ),
            ),
          ),
        );
        if (_asInt(e['is_locked']) == 1 ||
            isTeacher ||
            _changingPin ||
            _isGenerating ||
            _swapFirst != null ||
            _swapping)
          return content;
        return Stack(
          fit: StackFit.expand,
          children: [
            content,
            Positioned(
              bottom: 2,
              left: 2,
              child: Tooltip(
                message: 'اسحب من هنا لنقل الحصة',
                child: LongPressDraggable<Map<String, Object?>>(
                  data: Map.from(e),
                  feedback: _dragFeedback(e),
                  childWhenDragging: const Icon(
                    Icons.drag_indicator,
                    color: Colors.grey,
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(10),
                    child: Icon(Icons.drag_indicator, size: 20),
                  ),
                ),
              ),
            ),
          ],
        );
      }

      final content = matching.isEmpty
          ? Material(
              color: Theme.of(context).colorScheme.surfaceContainerHigh,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
                side: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
              ),
              child: InkWell(
                onTap: allowed ? () => edit(null) : null,
                child: Center(
                  child: Text(
                    allowed ? '—' : 'غير متاحة',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      fontSize: 11,
                    ),
                  ),
                ),
              ),
            )
          : matching.length == 1
          ? lesson(matching.first)
          : SingleChildScrollView(
              child: Column(
                children: [
                  Text(
                    'تعارض: أكثر من حصة',
                    style: TextStyle(color: Colors.red, fontSize: 10),
                  ),
                  for (final e in matching)
                    SizedBox(height: height, child: lesson(e)),
                ],
              ),
            );
      return SizedBox(
        width: width,
        height: height,
        child: DragTarget<Map<String, Object?>>(
          onWillAcceptWithDetails: (d) =>
              allowed &&
              matching.isEmpty &&
              _asInt(d.data['is_locked']) != 1 &&
              d.data['section_id'] == currentSection['id'],
          onAcceptWithDetails: (d) => _moveEntryToCell(
            source: d.data,
            section: currentSection!,
            day: currentDay,
            slot: slot,
            allDays: rows('days'),
            allSlots: rows('slots'),
          ),
          builder: (context, candidates, rejected) => DecoratedBox(
            decoration: BoxDecoration(
              border: candidates.isEmpty
                  ? null
                  : Border.all(
                      color: Theme.of(context).colorScheme.primary,
                      width: 2,
                    ),
            ),
            child: content,
          ),
        ),
      );
    }

    if (_viewMode == 'list') {
      void changeSection(int delta) {
        final i = sections.indexWhere((s) => s['id'] == section['id']);
        setState(() {
          _swapFirst = null;
          _sectionFilter = _asInt(
            sections[(i + delta + sections.length) % sections.length]['id'],
          );
        });
      }

      return Column(
        children: [
          Padding(
            key: const ValueKey('sticky-table-controls'),
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Container(
              padding: const EdgeInsets.all(13),
              decoration: JadwaliVisuals.panel(context),
              child: Material(type: MaterialType.transparency,
                child: Column(children: [
                  Align(alignment: AlignmentDirectional.centerStart,
                    child: Text('عرض حسب اليوم والصف',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800,
                        color: Theme.of(context).colorScheme.onSurface))),
                  const SizedBox(height: 5),
                  Align(alignment: AlignmentDirectional.centerStart,
                    child: Text('اضغط على أي حصة لفتح أدواتها والإصلاح، دون تغيير بقية الجدول.',
                      style: TextStyle(fontSize: 10,
                        color: Theme.of(context).colorScheme.onSurfaceVariant))),
                  const SizedBox(height: 12),
                Row(
                  children: [
                    IconButton(
                      tooltip: 'الصف السابق',
                      onPressed: () => changeSection(-1),
                      icon: const Icon(Icons.chevron_right),
                    ),
                    Expanded(
                      child: DropdownButtonFormField<int>(
                        key: ValueKey('class-selector-${section['id']}'),
                        initialValue: section['id'] as int,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'الصف / الشعبة',
                        ),
                        items: [
                          for (final s in sections)
                            DropdownMenuItem(
                              value: s['id'] as int,
                              child: Text(
                                'الصف ${displayGradeName(s['grade_name'])} · ${s['section_name']}',
                              ),
                            ),
                        ],
                        onChanged: (v) => setState(() {
                          _swapFirst = null;
                          _sectionFilter = v;
                        }),
                      ),
                    ),
                    IconButton(
                      tooltip: 'الصف التالي',
                      onPressed: () => changeSection(1),
                      icon: const Icon(Icons.chevron_left),
                    ),
                  ],
                ),
                SizedBox(height: 16),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      for (final mode in [
                        ('list', 'حصص اليوم'),
                        ('section', 'الأسبوع'),
                        ('teacher', 'المعلم'),
                        ('day', 'جميع الصفوف'),
                      ])
                        ChoiceChip(
                          label: Text(mode.$2),
                          selected: _viewMode == mode.$1,
                          onSelected: (_) =>
                              setState(() => _viewMode = mode.$1),
                        ),
                    ],
                  ),
                ),
                SizedBox(height: 10),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      for (final d in days)
                        Padding(
                          padding: const EdgeInsetsDirectional.only(end: 6),
                          child: ChoiceChip(
                            label: Text('${d['name']}'),
                            selected: day['id'] == d['id'],
                            onSelected: (_) =>
                                setState(() => _dayFilter = d['id'] as int),
                          ),
                        ),
                    ],
                  ),
                ),
                SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${day['name']}',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                    _tableActions(),
                  ],
                ),
                SizedBox(height: 10),
                _readingTools(),
                _swapBanner(),
              ])),
            ),
          ),
          Expanded(
            child: ListView(
              key: const ValueKey('daily-lessons'),
              padding: const EdgeInsets.fromLTRB(18, 4, 18, 18),
              children: [
                for (final slot in slots)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: InterfaceSettings.instance.design.soft(
                              Theme.of(context).brightness == Brightness.dark,
                            ),
                            borderRadius: BorderRadius.circular(13),
                          ),
                          child: Text(
                            '${slots.indexOf(slot) + 1}',
                            style: TextStyle(
                              color: Theme.of(context).colorScheme.primary,
                              fontSize: 14,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(child: cell(day, slot, section)),
                      ],
                    ),
                  ),
                Text(
                  'المس حصتين للتبديل. اضغط مطولاً للقفل أو فك القفل. افتح التفاصيل من زر المعلومات.',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _readingTools(),
        pageHeading(
          'الجدول الدراسي',
          'بطاقات ملونة مع عرض حسب اليوم والصف. اضغط على الحصة لفتح أدواتها والإصلاح الذكي.',
          trailing: _tableActions(),
        ),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: FilledButton.icon(
            onPressed: _isGenerating ? null : _generateAutomatically,
            icon: const Icon(Icons.auto_awesome_outlined, size: 16),
            label: Text(_isGenerating ? 'جارٍ التوزيع…' : 'توزيع الحصص'),
          ),
        ),
        SizedBox(height: 20),
        PreviewStats(
          distributed: entries.length,
          requiredCount: requested,
          sections: sections.length,
          teachers: teachers.length,
        ),
        SizedBox(height: 20),
        Text(
          'النسخة النشطة: ${version['name'] ?? 'لم ينشأ جدول بعد'}',
          style: TextStyle(
            fontSize: 12,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 12),
        _swapBanner(),
        PreviewPanel(
          title: isDaily
              ? 'جدول يوم ${day['name']}'
              : isTeacher
              ? 'جدول ${teacher['name'] ?? 'المعلم'}'
              : 'الصف ${displayGradeName(section['grade_name'])} · الشعبة ${section['section_name']}',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                color: Theme.of(context).colorScheme.surfaceContainerHigh,
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    Wrap(
                      spacing: 4,
                      children: [
                        for (final mode in [
                          ('list', 'حصص اليوم'),
                          ('section', 'جدول الصف'),
                          ('day', 'عرض يومي'),
                          ('teacher', 'جدول المعلم'),
                        ])
                          ChoiceChip(
                            showCheckmark: false,
                            label: Text(
                              mode.$2,
                              style: TextStyle(fontSize: 11),
                            ),
                            selected: _viewMode == mode.$1,
                            onSelected: (_) =>
                                setState(() => _viewMode = mode.$1),
                          ),
                      ],
                    ),
                    SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<int>(
                            key: ValueKey('$_viewMode-$chosen'),
                            initialValue: chosen as int?,
                            isExpanded: true,
                            decoration: InputDecoration(
                              labelText: isDaily
                                  ? 'اليوم'
                                  : isTeacher
                                  ? 'المعلم'
                                  : 'الصف / الشعبة',
                            ),
                            items: [
                              for (final o in options)
                                DropdownMenuItem(
                                  value: o['id'] as int,
                                  child: Text(
                                    isDaily || isTeacher
                                        ? '${o['name']}'
                                        : '${displayGradeName(o['grade_name'])} / ${o['section_name']}',
                                    style: TextStyle(fontSize: 12),
                                  ),
                                ),
                            ],
                            onChanged: (v) => setState(() {
                              if (isDaily) {
                                _dayFilter = v;
                              } else if (isTeacher) {
                                _teacherFilter = v;
                              } else {
                                _swapFirst = null;
                                _sectionFilter = v;
                              }
                            }),
                          ),
                        ),
                        IconButton(
                          tooltip: 'تصغير الخلايا',
                          onPressed: _cellScale <= .8
                              ? null
                              : () => setState(
                                  () => _cellScale =
                                      ((_cellScale * 10).round() - 1).clamp(
                                        8,
                                        15,
                                      ) /
                                      10,
                                ),
                          icon: const Icon(Icons.remove, size: 18),
                        ),
                        IconButton(
                          tooltip: 'تكبير الخلايا',
                          onPressed: _cellScale >= 1.5
                              ? null
                              : () => setState(
                                  () => _cellScale =
                                      ((_cellScale * 10).round() + 1).clamp(
                                        8,
                                        15,
                                      ) /
                                      10,
                                ),
                          icon: const Icon(Icons.add, size: 18),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          SizedBox(
                            width: 70,
                            child: Text(
                              isDaily ? 'الحصة' : 'اليوم / الحصة',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 11,
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurfaceVariant,
                              ),
                            ),
                          ),
                          for (final c in isDaily ? sections : slots)
                            Padding(
                              padding: const EdgeInsets.all(2),
                              child: header(
                                isDaily
                                    ? displayGradeName(c['grade_name'])
                                    : '${c['name']}',
                                isDaily
                                    ? 'الشعبة ${c['section_name']}'
                                    : '${c['start_time'] ?? ''} – ${c['end_time'] ?? ''}',
                              ),
                            ),
                        ],
                      ),
                      for (final row in isDaily ? slots : days)
                        Row(
                          children: [
                            SizedBox(
                              width: 70,
                              child: Text(
                                '${row['name']}',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            for (final col in isDaily ? sections : slots)
                              Padding(
                                padding: const EdgeInsets.all(2),
                                child: cell(
                                  isDaily ? day : row,
                                  isDaily ? row : col,
                                  isTeacher
                                      ? null
                                      : isDaily
                                      ? col
                                      : section,
                                ),
                              ),
                          ],
                        ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(15),
                color: Theme.of(context).colorScheme.surfaceContainerHigh,
                child: Text(
                  'اضغط الحصة لتعديلها أو تثبيتها. اضغط مطولاً لقفلها أو فك القفل. انقلها من مقبض السحب إلى خلية فارغة. · ${entries.where((e) => _asInt(e['is_locked']) == 1).length} حصص مثبتة',
                  style: TextStyle(
                    fontSize: 10,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 16),
        Wrap(
          spacing: 12,
          runSpacing: 8,
          children: [
            for (final subject in subjects)
              ActionChip(
                avatar: CircleAvatar(
                  radius: 4,
                  backgroundColor: _subjectColor({
                    'subject_id': subject['id'],
                  }, subjects),
                ),
                label: Text(
                  '${subject['name']}',
                  style: TextStyle(fontSize: 11),
                ),
                onPressed: () => setState(
                  () => _highlightSubject = _highlightSubject == subject['id']
                      ? null
                      : subject['id'] as int,
                ),
              ),
          ],
        ),
      ],
    );
  }

  Widget _dragFeedback(Map<String, Object?> entry) => Material(
    color: Colors.transparent,
    child: Opacity(
      opacity: .9,
      child: SizedBox(
        width: 128,
        height: 58,
        child: Card(
          color: const Color(0xFF28314F),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(6),
              child: Text(
                '${entry['subject_name']}\n${entry['teacher_name'] ?? 'غير مسند'}',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );

  bool _isAllowedLessonCell({
    required Map<String, Object?> section,
    required Map<String, Object?> day,
    required Map<String, Object?> slot,
    required List<Map<String, Object?>> allDays,
    required List<Map<String, Object?>> allSlots,
    required List<Map<String, Object?>> requirements,
  }) {
    final lessonSlots =
        allSlots
            .where(
              (s) =>
                  s['kind'] == 'lesson' &&
                  _asInt(s['is_available'], fallback: 1) == 1,
            )
            .toList()
          ..sort((a, b) => TimetableOrdering.compare(a, b));
    final rank = lessonSlots.indexWhere(
      (s) => _asInt(s['id']) == _asInt(slot['id']),
    );
    if (rank < 0 || rank > 6) return false;
    final activeDays = allDays
        .where((candidate) => _asInt(candidate['is_active'], fallback: 1) == 1)
        .toList();
    final weeklyDemand = requirements
        .where((req) => _asInt(req['section_id']) == _asInt(section['id']))
        .fold<int>(0, (sum, req) => sum + _asInt(req['weekly_lessons']));
    return rank < SchoolTimetablePolicy.dailyLimit(
      section: section, day: day, activeDays: activeDays,
      lessonSlots: lessonSlots, weeklyDemand: weeklyDemand,
    );
  }

  Future<void> _editCell(
    Map<String, Object?> section,
    Map<String, Object?> day,
    Map<String, Object?> slot,
    Map<String, Object?>? entry,
    List<Map<String, Object?>> slots,
    List<Map<String, Object?>> allEntries,
    List<Map<String, Object?>> allRequirements,
    List<Map<String, Object?>> allSubjects,
    List<Map<String, Object?>> allTeachers,
    List<Map<String, Object?>> qualifications,
    List<Map<String, Object?>> teacherGrades,
    List<Map<String, Object?>> teacherSubjectGrades,
    List<Map<String, Object?>> allDays,
  ) async {
    final sectionId = section['id'] as int;
    final orderedLessonSlots =
        slots
            .where(
              (s) =>
                  s['kind'] == 'lesson' &&
                  _asInt(s['is_available'], fallback: 1) == 1,
            )
            .toList()
          ..sort((a, b) => TimetableOrdering.compare(a, b));
    final periodRank = orderedLessonSlots.indexWhere(
      (s) => s['id'] == slot['id'],
    );
    if (periodRank < 0 || !_isAllowedLessonCell(
          section: section, day: day, slot: slot,
          allDays: allDays, allSlots: slots,
          requirements: allRequirements,
        )) {
      showMessage(context,
        'هذه الحصة خارج الحد المخصص لهذا الصف في هذا اليوم. '
        'يمكنك تغيير العدد من إعداد الجدول > الحصص المخصصة لكل صف.',
        error: true);
      return;
    }
    final sectionRequirements = allRequirements
        .where((r) => r['section_id'] == sectionId)
        .toList();
    final subjectIds = sectionRequirements.map((r) => r['subject_id']).toSet();
    final availableSubjects = subjectIds.isEmpty
        ? allSubjects
        : allSubjects.where((s) => subjectIds.contains(s['id'])).toList();
    if (availableSubjects.isEmpty) {
      showMessage(context, 'أضف مادة أولاً.');
      return;
    }
    int? selectedSubject =
        entry?['subject_id'] as int? ?? availableSubjects.first['id'] as int;
    int? selectedTeacher = entry?['teacher_id'] as int?;
    final assignmentPolicy = TeacherAssignmentPolicy(
      qualifications: qualifications,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
    );
    final sectionGradeId = _asInt(section['grade_id']);
    final result = await showDialog<Map<String, Object?>>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, update) {
          final qualifiedIds = qualifications
              .where((q) => q['subject_id'] == selectedSubject)
              .map((q) => q['teacher_id'])
              .toSet();
          final teacherOptions = allTeachers
              .where(
                (t) =>
                    qualifiedIds.contains(t['id']) &&
                    selectedSubject != null &&
                    assignmentPolicy.isGradeAllowed(
                      _asInt(t['id']),
                      selectedSubject!,
                      sectionGradeId,
                    ),
              )
              .toList();
          final selectedTeacherAvailable =
              selectedTeacher == null ||
              teacherOptions.any((t) => t['id'] == selectedTeacher);
          return AlertDialog(
            title: Text(entry == null ? 'إضافة حصة' : 'تعديل الحصة'),
            content: SizedBox(
              width: 400,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      '${displayGradeName(section['grade_name'])} - ${section['section_name']}\n${day['name']} • ${slot['name']} (${slot['start_time']}–${slot['end_time']})',
                      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                    ),
                  ),
                  SizedBox(height: 12),
                  DropdownButtonFormField<int>(
                    initialValue: selectedSubject,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'المادة',
                      prefixIcon: Icon(
                        Icons.menu_book_rounded,
                        color: Color(0xFF8A63C7),
                      ),
                    ),
                    items: availableSubjects.map((subject) {
                      final subjectColor = _subjectColor(subject, allSubjects);
                      return DropdownMenuItem<int>(
                        value: subject['id'] as int,
                        child: Row(
                          children: [
                            Container(
                              width: 9,
                              height: 28,
                              decoration: BoxDecoration(
                                color: subjectColor,
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                            SizedBox(width: 9),
                            Expanded(
                              child: Text(
                                '${subject['name']}',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                    onChanged: (v) => update(() {
                      selectedSubject = v;
                      selectedTeacher = null;
                    }),
                  ),
                  SizedBox(height: 10),
                  DropdownButtonFormField<int?>(
                    key: ValueKey(selectedSubject),
                    initialValue: selectedTeacherAvailable
                        ? selectedTeacher
                        : null,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'المعلم المسموح للمادة والصف',
                      prefixIcon: Icon(
                        Icons.person_pin_circle_outlined,
                        color: Color(0xFF16845B),
                      ),
                    ),
                    items: [
                      const DropdownMenuItem<int?>(
                        value: null,
                        child: Row(
                          children: [
                            Icon(
                              Icons.person_off_outlined,
                              color: Color(0xFFB87419),
                              size: 19,
                            ),
                            SizedBox(width: 8),
                            Text('غير مسند حالياً'),
                          ],
                        ),
                      ),
                      ...teacherOptions.map(
                        (t) => DropdownMenuItem<int?>(
                          value: t['id'] as int,
                          child: Row(
                            children: [
                              const Icon(
                                Icons.person_outline_rounded,
                                color: Color(0xFF16845B),
                                size: 19,
                              ),
                              SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  '${t['name']}',
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                    onChanged: (v) => update(() => selectedTeacher = v),
                  ),
                  if (teacherOptions.isEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 9),
                      child: Text(
                        qualifiedIds.isEmpty
                            ? 'لا يوجد معلم مؤهل لهذه المادة. يمكن إبقاء الحصة دون معلم، لكن لا يجوز إسنادها إلى معلم غير مؤهل.'
                            : 'لا يوجد معلم مسموح له بهذه المادة في الصف المحدد. راجع «البيانات > المعلمون» لتصحيح صفوف المادة؛ لن يُسمح بحفظ إسناد مخالف.',
                        style: TextStyle(
                          color: Colors.deepOrange,
                          fontSize: 12,
                        ),
                      ),
                    ),
                ],
              ),
            ),
            actions: [
              if (entry != null)
                TextButton.icon(
                  onPressed: () => Navigator.pop(ctx, {'toggle_lock': true}),
                  icon: Icon(
                    _asInt(entry['is_locked']) == 1
                        ? Icons.lock_open
                        : Icons.lock,
                  ),
                  label: Text(
                    _asInt(entry['is_locked']) == 1
                        ? 'إزالة التثبيت'
                        : 'تثبيت الحصة',
                  ),
                ),
              if (entry != null && _asInt(entry['is_locked']) != 1)
                TextButton(
                  onPressed: () => Navigator.pop(ctx, {'delete': true}),
                  child: Text('حذف الحصة', style: TextStyle(color: Colors.red)),
                ),
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text('إلغاء'),
              ),
              FilledButton(
                onPressed: _asInt(entry?['is_locked']) == 1
                    ? null
                    : () => Navigator.pop(ctx, {
                        'subject_id': selectedSubject,
                        'teacher_id': selectedTeacher,
                      }),
                child: Text('حفظ'),
              ),
            ],
          );
        },
      ),
    );
    if (result == null) return;
    if (result['toggle_lock'] == true) {
      try {
        final yearId = await DatabaseService.instance.activeYearId();
        if (yearId == null) throw StateError('لا يوجد عام نشط.');
        await DatabaseService.instance.setEntryLock(
          yearId: yearId,
          sectionId: sectionId,
          dayId: _asInt(day['id']),
          slotId: _asInt(slot['id']),
          locked: _asInt(entry?['is_locked']) != 1,
        );
        if (mounted) {
          setState(_reload);
          widget.onChanged();
          showMessage(context, 'تم تحديث تثبيت الحصة.');
        }
      } catch (error) {
        if (mounted) showMessage(context, '$error', error: true);
      }
      return;
    }
    if (_asInt(entry?['is_locked']) == 1) {
      if (mounted)
        showMessage(context, 'أزل تثبيت الحصة قبل تعديلها أو حذفها.');
      return;
    }
    if (result['delete'] == true) {
      if (!await confirmAction(
        context,
        'حذف الحصة',
        'هل تريد حذف الحصة المحددة؟',
      ))
        return;
      try {
        final db = await DatabaseService.instance.database;
        final yearId = await DatabaseService.instance.activeYearId();
        final versionId = yearId == null
            ? null
            : await DatabaseService.instance.ensureEditableActiveVersion(
                yearId,
              );
        if (versionId == null)
          throw StateError('لا توجد نسخة نشطة قابلة للتعديل.');
        final cloned = await db.query(
          'timetable_entries',
          where: 'version_id=? AND section_id=? AND day_id=? AND slot_id=?',
          whereArgs: [versionId, sectionId, day['id'], slot['id']],
          limit: 1,
        );
        if (cloned.isEmpty)
          throw StateError('لم يتم العثور على الحصة في نسخة العمل.');
        final deleted = await db.delete(
          'timetable_entries',
          where: 'id=? AND is_locked=0',
          whereArgs: [cloned.first['id']],
        );
        if (deleted != 1)
          throw StateError('الحصة مثبتة أو تغيرت؛ لم يتم حذفها.');
        await db.update(
          'timetable_versions',
          {
            'status': 'قيد التعديل',
            'updated_at': DateTime.now().toIso8601String(),
          },
          where: 'id=?',
          whereArgs: [versionId],
        );
        if (mounted) {
          showMessage(context, 'تم حذف الحصة.');
          setState(_reload);
          widget.onChanged();
        }
      } catch (e) {
        if (mounted) showMessage(context, 'تعذر حذف الحصة: $e', error: true);
      }
      return;
    }
    final newEntry = <String, Object?>{
      'id': entry?['id'] ?? -1,
      'section_id': sectionId,
      'subject_id': result['subject_id'],
      'teacher_id': result['teacher_id'],
      'room_id': entry?['room_id'],
      'day_id': day['id'],
      'slot_id': slot['id'],
      'version_id':
          entry?['version_id'] ??
          (await DatabaseService.instance.activeVersionId(
            await DatabaseService.instance.activeYearId(),
          )),
      'subject_name': availableSubjects.firstWhere(
        (s) => s['id'] == result['subject_id'],
      )['name'],
      'section_name': section['section_name'],
      'grade_id': section['grade_id'],
      'grade_name': section['grade_name'],
      'teacher_name': result['teacher_id'] == null
          ? null
          : allTeachers.firstWhere(
              (t) => t['id'] == result['teacher_id'],
            )['name'],
    };
    if (newEntry['version_id'] == null) {
      showMessage(context, 'لا يوجد عام دراسي نشط.', error: true);
      return;
    }
    final entriesForScan =
        allEntries.where((e) => e['id'] != entry?['id']).toList()
          ..add(newEntry);
    final slotsForScan = slots;
    final dbService = DatabaseService.instance;
    final scanSections = await dbService.sectionsDetailed();
    final scanTeacherGrades = await dbService.rows('teacher_grades');
    final scanTeacherSubjectGrades = await dbService.rows(
      'teacher_subject_grades',
    );
    final scanBlockedSlots = await dbService.rows('subject_blocked_slots');
    final scanAvailability = await dbService.rows('teacher_availability');
    const conflictScanner = ConflictDetectionService();
    final issues = conflictScanner.scan(
      entries: entriesForScan,
      requirements: allRequirements,
      sections: scanSections,
      slots: slotsForScan,
      teachers: allTeachers,
      qualifications: qualifications,
      days: allDays,
      teacherGrades: scanTeacherGrades,
      teacherSubjectGrades: scanTeacherSubjectGrades,
      subjectBlockedSlots: scanBlockedSlots,
      teacherAvailability: scanAvailability,
      enforceQualifications: true,
    );
    final baselineIssues = conflictScanner.scan(
      entries: allEntries,
      requirements: allRequirements,
      sections: scanSections,
      slots: slotsForScan,
      teachers: allTeachers,
      qualifications: qualifications,
      days: allDays,
      teacherGrades: scanTeacherGrades,
      teacherSubjectGrades: scanTeacherSubjectGrades,
      subjectBlockedSlots: scanBlockedSlots,
      teacherAvailability: scanAvailability,
      enforceQualifications: true,
    );
    bool existedBefore(ConflictIssue issue) => baselineIssues.any(
      (before) =>
          before.type == issue.type &&
          before.message == issue.message &&
          before.sectionId == issue.sectionId &&
          before.teacherId == issue.teacherId &&
          before.subjectId == issue.subjectId &&
          before.dayId == issue.dayId &&
          before.slotId == issue.slotId,
    );
    final newCoverageWarnings = issues
        .where(
          (i) =>
              i.type == 'توزيع المادة على كل أيام الأسبوع' &&
              i.sectionId == sectionId &&
              !existedBefore(i),
        )
        .toList();
    final blockers = <ConflictIssue>[
      ...issues.where(
        (i) =>
            i.severity == 'خطأ مانع' &&
            i.dayId == day['id'] &&
            i.slotId == slot['id'] &&
            // Actual cell/teacher conflicts remain blocked; missing day coverage alone
            // is a quality issue that can be repaired by the distribution engine later.
            (i.sectionId == sectionId ||
                (result['teacher_id'] != null &&
                    i.teacherId == result['teacher_id'])),
      ),
    ];
    if (blockers.isNotEmpty) {
      if (mounted)
        await showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text('لا يمكن حفظ الحصة بسبب تعارض'),
            content: SizedBox(
              width: 420,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: blockers
                    .map(
                      (i) => ListTile(
                        leading: const Icon(
                          Icons.error_outline,
                          color: Colors.red,
                        ),
                        title: Text(i.type),
                        subtitle: Text(i.message),
                      ),
                    )
                    .toList(),
              ),
            ),
            actions: [
              FilledButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text('رجوع للتعديل'),
              ),
            ],
          ),
        );
      return;
    }
    try {
      final yearId = await DatabaseService.instance.activeYearId();
      if (yearId == null) throw StateError('لا يوجد عام دراسي نشط.');
      final writableVersionId = await DatabaseService.instance
          .ensureEditableActiveVersion(yearId);
      if (writableVersionId == null)
        throw StateError('لا توجد نسخة نشطة قابلة للتعديل.');
      int? targetEntryId;
      if (entry != null) {
        final db = await DatabaseService.instance.database;
        final cloned = await db.query(
          'timetable_entries',
          where: 'version_id=? AND section_id=? AND day_id=? AND slot_id=?',
          whereArgs: [writableVersionId, sectionId, day['id'], slot['id']],
          limit: 1,
        );
        if (cloned.isNotEmpty) targetEntryId = cloned.first['id'] as int;
      }
      final values = Map<String, Object?>.from(newEntry)
        ..['version_id'] = writableVersionId
        ..remove('id')
        ..remove('subject_name')
        ..remove('section_name')
        ..remove('teacher_name');
      await DatabaseService.instance.saveEntry(values, entryId: targetEntryId);
      if (mounted) {
        _flash({
          'section_id': sectionId,
          'day_id': day['id'],
          'slot_id': slot['id'],
        });
        _offerUndo(
          newCoverageWarnings.isNotEmpty
              ? 'تم حفظ الحصة. توجد ملاحظة حول توزيع مادة على كل أيام الدوام؛ استخدم «توزيع الحصص» لإعادة التوازن قبل الاعتماد.'
              : result['teacher_id'] == null
              ? 'حُفظت الحصة دون معلم؛ راجع التحذيرات قبل الاعتماد.'
              : 'تم حفظ الحصة دون تعارضات مانعة.',
        );
        setState(_reload);
        widget.onChanged();
      }
    } catch (e) {
      if (mounted)
        showMessage(
          context,
          'تعذر حفظ الحصة. قد تكون الخلية مشغولة: $e',
          error: true,
        );
    }
  }

  PreflightResult _inspectBeforeScheduling(Map<String, Object?> data) {
    final result = const PreflightInspectionService().inspect(
      sections: (data['sections'] as List).cast<Map<String, Object?>>(),
      requirements: (data['requirements'] as List).cast<Map<String, Object?>>(),
      teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
      subjects: (data['subjects'] as List).cast<Map<String, Object?>>(),
      qualifications: (data['qualifications'] as List)
          .cast<Map<String, Object?>>(),
      teacherGrades: (data['teacherGrades'] as List)
          .cast<Map<String, Object?>>(),
      teacherSubjectGrades: (data['teacherSubjectGrades'] as List)
          .cast<Map<String, Object?>>(),
      days: (data['days'] as List).cast<Map<String, Object?>>(),
      slots: (data['slots'] as List).cast<Map<String, Object?>>(),
      currentEntries: (data['entries'] as List).cast<Map<String, Object?>>(),
      availability: (data['availability'] as List).cast<Map<String, Object?>>(),
      subjectBlockedSlots: (data['subjectBlockedSlots'] as List)
          .cast<Map<String, Object?>>(),
    );
    if (data['yearId'] != null) return result;
    return PreflightResult([
      ...result.findings,
      const PreflightFinding(
        code: 'no_active_year',
        title: 'لا يوجد عام دراسي نشط',
        message: 'لم يتم تحديد عام دراسي نشط لحفظ النسخة الناتجة.',
        recommendation: 'اختر عاماً دراسياً نشطاً من إعدادات المدرسة.',
        blocking: true,
        category: 'الإعدادات',
      ),
    ]);
  }

  Future<bool> _showPreflight(
    PreflightResult result, {
    required bool allowContinue,
  }) async {
    if (!mounted) return false;
    final decision = await showDialog<bool>(
      context: context,
      barrierDismissible: !result.findings.any((f) => f.blocking),
      builder: (ctx) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.fact_check_outlined, color: Color(0xFF6655BE)),
            SizedBox(width: 8),
            Expanded(child: Text('الفحص الذكي قبل التوزيع')),
          ],
        ),
        content: SizedBox(
          width: 560,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  children: [
                    Chip(
                      avatar: const Icon(
                        Icons.error_outline,
                        size: 17,
                        color: Colors.red,
                      ),
                      label: Text('موانع: ${result.blockers}'),
                    ),
                    Chip(
                      avatar: const Icon(
                        Icons.info_outline,
                        size: 17,
                        color: Colors.deepOrange,
                      ),
                      label: Text('ملاحظات: ${result.warnings}'),
                    ),
                  ],
                ),
                SizedBox(height: 8),
                Text(
                  result.canStart
                      ? 'انتهى الفحص الأولي. ستُعرض نتيجة التوزيع وحصصه المتبقية قبل أي حفظ.'
                      : 'لا يمكن بدء التوزيع لأن هناك متطلبات أساسية مفقودة. أصلح الموانع أولاً.',
                ),
                if (result.findings.isEmpty)
                  Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: ListTile(
                      leading: Icon(Icons.check_circle, color: Colors.green),
                      title: Text('لم تُكتشف مشكلات في الإعدادات الأساسية.'),
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                ...result.findings
                    .take(18)
                    .map(
                      (f) => Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: f.blocking
                                ? const Color(0xFFFFECEC)
                                : const Color(0xFFFFF7E8),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: f.blocking
                                  ? const Color(0xFFE4A0A0)
                                  : const Color(0xFFE8D09B),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Icon(
                                    f.blocking
                                        ? Icons.error_outline
                                        : Icons.warning_amber_outlined,
                                    size: 18,
                                    color: f.blocking
                                        ? Colors.red
                                        : Colors.deepOrange,
                                  ),
                                  SizedBox(width: 6),
                                  Expanded(
                                    child: Text(
                                      f.title,
                                      style: TextStyle(
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 4),
                              Text(f.message, style: TextStyle(fontSize: 12)),
                              SizedBox(height: 4),
                              Text(
                                'الإجراء المقترح: ${f.recommendation}',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                if (result.findings.length > 18)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      'وتوجد ${result.findings.length - 18} ملاحظات إضافية.',
                      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                    ),
                  ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('إغلاق'),
          ),
          if (allowContinue && result.canStart)
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text('متابعة إلى التوزيع'),
            ),
        ],
      ),
    );
    return decision == true && result.canStart;
  }

  Future<void> _runPreflightOnly() async {
    try {
      final data = await _loadData();
      final result = _inspectBeforeScheduling(data);
      await _showPreflight(result, allowContinue: false);
    } catch (e) {
      if (mounted)
        showMessage(context, 'تعذر إكمال الفحص المسبق: $e', error: true);
    }
  }

  Future<Map<String, Object?>?> _chooseSafeMoveAlternative({
    required Map<String, Object?> sourceEntry,
    required Map<String, Object?> section,
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> requirements,
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> qualifications,
    required List<Map<String, Object?>> teacherGrades,
    required List<Map<String, Object?>> teacherSubjectGrades,
    required List<Map<String, Object?>> subjectBlockedSlots,
    required List<Map<String, Object?>> availability,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    required List<dynamic> blockers,
  }) async {
    final sectionId = _asInt(section['id']);
    final entryId = _asInt(sourceEntry['id']);
    final teacherId = sourceEntry['teacher_id'] == null
        ? null
        : _asInt(sourceEntry['teacher_id']);
    final sectionEntries = entries
        .where((e) => _asInt(e['section_id']) == sectionId)
        .toList();
    final otherEntries = entries
        .where((e) => _asInt(e['id']) != entryId)
        .toList();
    final activeDays = days
        .where((d) => _asInt(d['is_active'], fallback: 1) == 1)
        .toList();
    final lessonSlots =
        slots
            .where(
              (slot) =>
                  slot['kind'] == 'lesson' &&
                  _asInt(slot['is_available'], fallback: 1) == 1,
            )
            .toList()
          ..sort((a, b) => TimetableOrdering.compare(a, b));
    final rankBySlot = <int, int>{
      for (var i = 0; i < lessonSlots.length; i++)
        _asInt(lessonSlots[i]['id']): i,
    };
    final blocked = <String>{
      for (final row in subjectBlockedSlots)
        '${_asInt(row['subject_id'])}:${_asInt(row['slot_id'])}',
    };
    final alternatives = <Map<String, Object?>>[];
    const hardIssues = <String>{
      'تعارض المعلم',
      'تعارض الشعبة',
      'تعارض القاعة',
      'تأهيل المعلم',
      'الصف غير مسموح للمعلم',
      'تعذر تحديد صف الشعبة',
      'فترة غير متاحة',
      'المعلم غير متاح في الفترة',
      'المادة في فترة ممنوعة',
      'يوم غير مفعل',
      'يوم غير معروف',
      'فترة غير معروفة',
      'متطلبات مكررة',
      'عدد حصص مطلوب غير صالح',
      'تكرار المادة خارج الفترة السادسة أو السابعة',
      'الحصة السابعة خارج الصف السادس يوم الأحد',
      'الحصة السابعة دون اضطرار',
      'تجاوز الحصة السابعة',
    };
    const softRuleTypes = <String>{
      'تكرار المادة يومياً',
      'تجاوز الحد اليومي',
      'حصص متتالية زائدة',
    };
    final scanner = const ConflictDetectionService();
    final baselineIssues = scanner.scan(
      entries: entries,
      requirements: requirements,
      sections: [section],
      slots: slots,
      teachers: teachers,
      qualifications: qualifications,
      days: days,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
      subjectBlockedSlots: subjectBlockedSlots,
      teacherAvailability: availability,
    );
    bool existedBefore(ConflictIssue issue) => baselineIssues.any(
      (before) =>
          before.type == issue.type &&
          before.message == issue.message &&
          before.sectionId == issue.sectionId &&
          before.teacherId == issue.teacherId &&
          before.subjectId == issue.subjectId &&
          before.dayId == issue.dayId,
    );

    final availabilityPolicy = TeacherAvailabilityPolicy(availability);
    for (final day in activeDays) {
      for (final slot in lessonSlots) {
        final dayId = _asInt(day['id']);
        final slotId = _asInt(slot['id']);
        if (dayId == _asInt(sourceEntry['day_id']) &&
            slotId == _asInt(sourceEntry['slot_id']))
          continue;
        if (sectionEntries.any(
          (e) =>
              _asInt(e['day_id']) == dayId &&
              _asInt(e['slot_id']) == slotId &&
              _asInt(e['id']) != entryId,
        ))
          continue;
        final rank = rankBySlot[slotId] ?? 0;
        if (rank > 6) continue;
        if (rank >= 6 &&
            !_isAllowedLessonCell(
              section: section,
              day: day,
              slot: slot,
              allDays: days,
              allSlots: slots,
              requirements: requirements,
            ))
          continue;
        if (teacherId != null &&
            !availabilityPolicy.isAvailable(
              teacherId: teacherId,
              dayId: dayId,
              slotId: slotId,
              gradeId: _asInt(section['grade_id']),
              subjectId: _asInt(sourceEntry['subject_id']),
            ))
          continue;
        if (blocked.contains('${_asInt(sourceEntry['subject_id'])}:$slotId'))
          continue;

        final candidate = Map<String, Object?>.from(sourceEntry)
          ..['day_id'] = dayId
          ..['slot_id'] = slotId;
        final prospective = [...otherEntries, candidate];
        final issues = scanner.scan(
          entries: prospective,
          requirements: requirements,
          sections: [section],
          slots: slots,
          teachers: teachers,
          qualifications: qualifications,
          days: days,
          teacherGrades: teacherGrades,
          teacherSubjectGrades: teacherSubjectGrades,
          subjectBlockedSlots: subjectBlockedSlots,
          teacherAvailability: availability,
        );
        final hasBlockingIssue = issues.any(
          (issue) =>
              issue.dayId == dayId &&
              (issue.sectionId == sectionId ||
                  (teacherId != null && issue.teacherId == teacherId)) &&
              ((issue.severity == 'خطأ مانع' &&
                      hardIssues.contains(issue.type) &&
                      issue.slotId == slotId) ||
                  (softRuleTypes.contains(issue.type) &&
                      !existedBefore(issue))),
        );
        if (!hasBlockingIssue) {
          alternatives.add({
            'day': day,
            'slot': slot,
            'day_id': dayId,
            'slot_id': slotId,
          });
        }
      }
    }

    if (!mounted) return null;
    final chosen = await showDialog<Map<String, Object?>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('تعذر نقل الحصة إلى هذه الخلية'),
        content: SizedBox(
          width: 460,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'أسباب رفض النقل:',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
                SizedBox(height: 6),
                ...blockers
                    .take(4)
                    .map(
                      (issue) => Padding(
                        padding: const EdgeInsets.only(bottom: 7),
                        child: Text(
                          '• ${issue.type}: ${issue.message}',
                          style: TextStyle(fontSize: 12),
                        ),
                      ),
                    ),
                const Divider(),
                Text(
                  alternatives.isEmpty
                      ? 'لم أعثر على خلية بديلة آمنة للحصة. راجع صلاحية المعلم والفترات المتاحة ثم أعد المحاولة.'
                      : 'هذه خلايا بديلة اجتازت فحص التعارضات. اختر واحدة لنقل الحصة إليها:',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                ...alternatives.take(12).map((alternative) {
                  final d = alternative['day'] as Map<String, Object?>;
                  final sl = alternative['slot'] as Map<String, Object?>;
                  return ListTile(
                    dense: true,
                    leading: const Icon(
                      Icons.check_circle_outline,
                      color: Colors.green,
                    ),
                    title: Text('${d['name']} — ${sl['name']}'),
                    subtitle: Text(
                      '${sl['start_time'] ?? ''}–${sl['end_time'] ?? ''}',
                    ),
                    onTap: () => Navigator.pop(ctx, alternative),
                  );
                }),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text('إلغاء')),
        ],
      ),
    );
    return chosen;
  }

  Future<void> _moveEntryToCell({
    required Map<String, Object?> source,
    required Map<String, Object?> section,
    required Map<String, Object?> day,
    required Map<String, Object?> slot,
    required List<Map<String, Object?>> allDays,
    required List<Map<String, Object?>> allSlots,
  }) async {
    final sectionId = _asInt(section['id']);
    final sourceDayId = _asInt(source['day_id']);
    final sourceSlotId = _asInt(source['slot_id']);
    final targetDayId = _asInt(day['id']);
    final targetSlotId = _asInt(slot['id']);
    if (sourceDayId == targetDayId && sourceSlotId == targetSlotId) return;
    try {
      final data = await _loadData();
      final entries = (data['entries'] as List).cast<Map<String, Object?>>();
      final sourceMatches = entries
          .where(
            (e) =>
                _asInt(e['section_id']) == sectionId &&
                _asInt(e['day_id']) == sourceDayId &&
                _asInt(e['slot_id']) == sourceSlotId,
          )
          .toList();
      if (sourceMatches.isEmpty)
        throw StateError(
          'لم تعد الحصة المصدر موجودة في النسخة الحالية. حدّث الجدول وحاول مجدداً.',
        );
      final sourceEntry = sourceMatches.first;
      final targetSlotMatches = allSlots
          .where((s) => _asInt(s['id']) == targetSlotId)
          .toList();
      final targetSlot = targetSlotMatches.isEmpty
          ? null
          : targetSlotMatches.first;
      if (targetSlot == null ||
          targetSlot['kind'] != 'lesson' ||
          _asInt(targetSlot['is_available'], fallback: 1) == 0) {
        throw StateError('الفترة المستهدفة ليست فترة تدريس متاحة.');
      }
      if (!_isAllowedLessonCell(
        section: section,
        day: day,
        slot: targetSlot,
        allDays: allDays,
        allSlots: allSlots,
        requirements: (data['requirements'] as List)
            .cast<Map<String, Object?>>(),
      )) {
        throw StateError(
          'لا يمكن نقل الحصة إلى هذه الفترة؛ الحصة السابعة مخصصة للصف السادس يوم الأحد فقط، وعند الحاجة.',
        );
      }
      final occupied = entries.any(
        (e) =>
            _asInt(e['section_id']) == sectionId &&
            _asInt(e['day_id']) == targetDayId &&
            _asInt(e['slot_id']) == targetSlotId,
      );
      if (occupied)
        throw StateError(
          'الخلية المستهدفة مشغولة. انقل الحصة إلى خلية فارغة أولاً؛ لا يتم استبدال الحصص تلقائياً.',
        );
      final candidate = Map<String, Object?>.from(sourceEntry)
        ..['day_id'] = targetDayId
        ..['slot_id'] = targetSlotId;
      final prospective =
          entries
              .where((e) => _asInt(e['id']) != _asInt(sourceEntry['id']))
              .toList()
            ..add(candidate);
      final requirementsForScan = (data['requirements'] as List)
          .cast<Map<String, Object?>>();
      final teachersForScan = (data['teachers'] as List)
          .cast<Map<String, Object?>>();
      final qualificationsForScan = (data['qualifications'] as List)
          .cast<Map<String, Object?>>();
      final teacherGradesForScan = (data['teacherGrades'] as List)
          .cast<Map<String, Object?>>();
      final teacherSubjectGradesForScan = (data['teacherSubjectGrades'] as List)
          .cast<Map<String, Object?>>();
      final blockedSlotsForScan = (data['subjectBlockedSlots'] as List)
          .cast<Map<String, Object?>>();
      final scanner = const ConflictDetectionService();
      final scanIssues = scanner.scan(
        entries: prospective,
        requirements: requirementsForScan,
        sections: (data['sections'] as List).cast<Map<String, Object?>>(),
        slots: allSlots,
        teachers: teachersForScan,
        qualifications: qualificationsForScan,
        days: allDays,
        teacherGrades: teacherGradesForScan,
        teacherSubjectGrades: teacherSubjectGradesForScan,
        subjectBlockedSlots: blockedSlotsForScan,
        teacherAvailability: (data['availability'] as List)
            .cast<Map<String, Object?>>(),
      );
      final baselineIssues = scanner.scan(
        entries: entries,
        requirements: requirementsForScan,
        sections: (data['sections'] as List).cast<Map<String, Object?>>(),
        slots: allSlots,
        teachers: teachersForScan,
        qualifications: qualificationsForScan,
        days: allDays,
        teacherGrades: teacherGradesForScan,
        teacherSubjectGrades: teacherSubjectGradesForScan,
        subjectBlockedSlots: blockedSlotsForScan,
        teacherAvailability: (data['availability'] as List)
            .cast<Map<String, Object?>>(),
      );
      final teacherId = sourceEntry['teacher_id'] == null
          ? null
          : _asInt(sourceEntry['teacher_id']);
      const hardIssueTypes = {
        'تعارض المعلم',
        'تعارض الشعبة',
        'تعارض القاعة',
        'تأهيل المعلم',
        'الصف غير مسموح للمعلم',
        'تعذر تحديد صف الشعبة',
        'فترة غير متاحة',
        'المعلم غير متاح في الفترة',
        'المادة في فترة ممنوعة',
        'يوم غير مفعل',
        'يوم غير معروف',
        'فترة غير معروفة',
        'متطلبات مكررة',
        'عدد حصص مطلوب غير صالح',
        'تكرار المادة خارج الفترة السادسة أو السابعة',
        'الحصة السابعة خارج الصف السادس يوم الأحد',
        'الحصة السابعة دون اضطرار',
        'تجاوز الحصة السابعة',
      };
      const softRuleTypes = {
        'تكرار المادة يومياً',
        'تجاوز الحد اليومي',
        'حصص متتالية زائدة',
      };
      bool relatedOnTargetDay(ConflictIssue issue) =>
          issue.dayId == targetDayId &&
          (issue.sectionId == sectionId ||
              (teacherId != null && issue.teacherId == teacherId));
      bool existedBefore(ConflictIssue issue) => baselineIssues.any(
        (before) =>
            before.type == issue.type &&
            before.message == issue.message &&
            before.sectionId == issue.sectionId &&
            before.teacherId == issue.teacherId &&
            before.subjectId == issue.subjectId &&
            before.dayId == issue.dayId,
      );
      final sourceSubjectId = _asInt(sourceEntry['subject_id']);
      final newCoverageIssue = scanIssues
          .where(
            (issue) =>
                issue.type == 'توزيع المادة على كل أيام الأسبوع' &&
                issue.sectionId == sectionId &&
                issue.subjectId == sourceSubjectId &&
                !existedBefore(issue),
          )
          .toList();
      final blockers = <ConflictIssue>[
        ...scanIssues.where(
          (issue) =>
              relatedOnTargetDay(issue) &&
              ((issue.severity == 'خطأ مانع' &&
                      issue.slotId == targetSlotId &&
                      hardIssueTypes.contains(issue.type)) ||
                  (softRuleTypes.contains(issue.type) &&
                      !existedBefore(issue))),
        ),
        ...newCoverageIssue,
      ];
      if (blockers.isNotEmpty) {
        final alternative = await _chooseSafeMoveAlternative(
          sourceEntry: sourceEntry,
          section: section,
          entries: entries,
          requirements: (data['requirements'] as List)
              .cast<Map<String, Object?>>(),
          teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
          qualifications: (data['qualifications'] as List)
              .cast<Map<String, Object?>>(),
          teacherGrades: (data['teacherGrades'] as List)
              .cast<Map<String, Object?>>(),
          teacherSubjectGrades: (data['teacherSubjectGrades'] as List)
              .cast<Map<String, Object?>>(),
          subjectBlockedSlots: (data['subjectBlockedSlots'] as List)
              .cast<Map<String, Object?>>(),
          availability: (data['availability'] as List)
              .cast<Map<String, Object?>>(),
          days: allDays,
          slots: allSlots,
          blockers: blockers,
        );
        if (alternative == null || !mounted) return;
        await _moveEntryToCell(
          source: sourceEntry,
          section: section,
          day: alternative['day'] as Map<String, Object?>,
          slot: alternative['slot'] as Map<String, Object?>,
          allDays: allDays,
          allSlots: allSlots,
        );
        return;
      }
      final yearId = data['yearId'] as int?;
      if (yearId == null) throw StateError('لا يوجد عام دراسي نشط.');
      final versionId = await DatabaseService.instance
          .ensureEditableActiveVersion(yearId);
      if (versionId == null)
        throw StateError('لا توجد نسخة عمل قابلة للتعديل.');
      final db = await DatabaseService.instance.database;
      final actual = await db.query(
        'timetable_entries',
        where: 'version_id=? AND section_id=? AND day_id=? AND slot_id=?',
        whereArgs: [versionId, sectionId, sourceDayId, sourceSlotId],
        limit: 1,
      );
      if (actual.isEmpty)
        throw StateError(
          'تعذر العثور على الحصة في نسخة العمل بعد التحقق. لم يُنفّذ النقل.',
        );
      await DatabaseService.instance.saveEntry({
        'day_id': targetDayId,
        'slot_id': targetSlotId,
        'version_id': versionId,
      }, entryId: _asInt(actual.first['id']));
      if (mounted) {
        _flash({
          'section_id': sectionId,
          'day_id': targetDayId,
          'slot_id': targetSlotId,
        });
        _offerUndo(
          'نُقلت الحصة إلى ${day['name']}، ${slot['name']} بعد فحص التعارضات.',
        );
        setState(_reload);
        widget.onChanged();
      }
    } catch (e) {
      if (mounted) showMessage(context, 'لم يتم نقل الحصة: $e', error: true);
    }
  }

  Map<String, Object?> _searchInput(Map<String, Object?> data) => {
    for (final key in [
      'sections',
      'requirements',
      'teachers',
      'qualifications',
      'teacherGrades',
      'teacherSubjectGrades',
      'subjectBlockedSlots',
      'days',
      'slots',
    ])
      key: data[key],
    'teacherAvailability': data['availability'],
    'softPriorities': Map<String, int>.from(
      InterfaceSettings.instance.softPriorities,
    ),
    'subjects': data['subjects'],
    'subjectPreferences': data['subjects'],
    'initialPlacements': data['entries'],
    'lockedPlacements': _schedulerMapList(data['entries'])
        .where((e) => _asInt(e['is_locked']) == 1)
        .toList(),
  };

  Future<void> _explainCurrentConstraints() async {
    try {
      final data = await _loadData();
      final reasons = const ConstraintExplanationService().explain(
        _searchInput(data),
      );
      if (mounted)
        await showConstraintExplanations(
          context,
          reasons,
          input: _searchInput(data),
        );
    } catch (error) {
      if (mounted) showMessage(context, '$error', error: true);
    }
  }

  Future<Map<String, Object?>?> _searchOptions() {
    var profile = 'minimal_changes';
    var seconds = 30;
    final weights = Map<String, int>.from(
      InterfaceSettings.instance.softPriorities,
    );
    return showDialog<Map<String, Object?>>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, update) => AlertDialog(
          title: Text('خيارات توزيع الحصص'),
          content: SizedBox(
            width: 430,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButtonFormField<String>(
                    initialValue: profile,
                    decoration: const InputDecoration(labelText: 'الأولوية'),
                    items: const [
                      DropdownMenuItem(
                        value: 'all',
                        child: Text('مقارنة الأولويات الثلاث'),
                      ),
                      DropdownMenuItem(
                        value: 'minimal_changes',
                        child: Text('أقل تغييرات على الجدول الحالي'),
                      ),
                      DropdownMenuItem(
                        value: 'teacher_gaps',
                        child: Text('تقليل فراغات المعلمين'),
                      ),
                      DropdownMenuItem(
                        value: 'balanced_subjects',
                        child: Text('توازن توقيت المواد'),
                      ),
                    ],
                    onChanged: (value) {
                      if (value != null) update(() => profile = value);
                    },
                  ),
                  SizedBox(height: 16),
                  DropdownButtonFormField<int>(
                    initialValue: seconds,
                    decoration: const InputDecoration(
                      labelText: 'وقت البحث لكل أولوية',
                    ),
                    items: const [
                      DropdownMenuItem(value: 30, child: Text('30 ثانية')),
                      DropdownMenuItem(value: 60, child: Text('دقيقة')),
                      DropdownMenuItem(value: 180, child: Text('3 دقائق')),
                    ],
                    onChanged: (value) {
                      if (value != null) update(() => seconds = value);
                    },
                  ),
                  ExpansionTile(
                    title: const Text('تفضيلات متقدمة'),
                    subtitle: const Text(
                      'رغبات مرنة؛ المنع والأقفال إلزاميان دائماً',
                    ),
                    children: [
                      for (final item in const {
                        'spacing': 'فصل حصتي المادة',
                        'gaps': 'تقليل فراغات المعلمين',
                        'balance': 'توازن الأيام والمواد',
                      }.entries)
                        DropdownButtonFormField<int>(
                          initialValue: weights[item.key],
                          isExpanded: true,
                          decoration: InputDecoration(labelText: item.value),
                          items: const [
                            DropdownMenuItem(value: 1, child: Text('عادية')),
                            DropdownMenuItem(value: 2, child: Text('مهمة')),
                            DropdownMenuItem(
                              value: 3,
                              child: Text('مهمة جداً'),
                            ),
                          ],
                          onChanged: (v) {
                            if (v != null) update(() => weights[item.key] = v);
                          },
                        ),
                    ],
                  ),
                  SizedBox(height: 12),
                  Text(
                    'الحصص المثبتة تبقى في مكانها. يمكنك إيقاف البحث ومراجعة أفضل نتيجة. قد تتطابق الحلول عندما تكون القيود شديدة.',
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () {
                InterfaceSettings.instance.softPriorities = weights;
                InterfaceSettings.instance.save();
                Navigator.pop(dialogContext, {
                  'profile': profile,
                  'seconds': seconds,
                });
              },
              child: Text('بدء البحث'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _generateAutomatically({bool advanced = false}) async {
    if (_isGenerating) return;
    setState(() => _isGenerating = true);
    try {
      final data = await _loadData();
      final preflight = _inspectBeforeScheduling(data);
      final continueAfterPreflight = !advanced && preflight.canStart
          ? true
          : await _showPreflight(preflight, allowContinue: true);
      if (!continueAfterPreflight) return;
      final yearId = data['yearId'] as int?;
      if (yearId == null) throw StateError('أنشئ عاماً دراسياً نشطاً أولاً.');
      // الجدولة التلقائية تخص المدرسة كلها دائماً، ولا تتأثر بمرشح العرض الذي قد يعرض شعبة واحدة.
      final allSections = (data['sections'] as List)
          .cast<Map<String, Object?>>();
      final allRequirements = (data['requirements'] as List)
          .cast<Map<String, Object?>>();
      if (allSections.isEmpty || allRequirements.isEmpty)
        throw StateError(
          'أضف الشعب وحدد الحصص الأسبوعية المطلوبة لكل مادة قبل بدء الجدولة.',
        );
      if (!advanced) {
        final proofs = const ConstraintExplanationService()
            .explain(_searchInput(data))
            .where((reason) => reason.proven)
            .toList();
        if (proofs.isNotEmpty) {
          if (mounted)
            await showConstraintExplanations(
              context,
              proofs,
              input: _searchInput(data),
            );
          return;
        }
      }
      final options = advanced
          ? await _searchOptions()
          : <String, Object?>{'profile': 'minimal_changes', 'seconds': 60};
      if (options == null || !mounted) return;
      final input = _searchInput(data);
      final profiles = options['profile'] == 'all'
          ? const ['minimal_changes', 'teacher_gaps', 'balanced_subjects']
          : ['${options['profile']}'];
      final alternatives = await showScheduleSearchDialog(
        context,
        input: {
          ...input,
          'initialPlacements': input['initialPlacements'],
          'nodeLimit': 600000,
          'timeLimitMs': (options['seconds'] as int) * 1000,
        },
        profiles: profiles,
      );
      if (alternatives == null || alternatives.isEmpty || !mounted) return;
      for (final alternative in alternatives) {
        alternative['quality'] = ScheduleComparisonService.evaluate(
          entries: _schedulerMapList(alternative['placements']),
          slots: _schedulerMapList(data['slots']),
          days: _schedulerMapList(data['days']),
          requirements: allRequirements,
          before: _schedulerMapList(data['entries']),
        ).toMap();
      }
      for (var i = alternatives.length - 1; i > 0; i--) {
        for (var j = 0; j < i; j++) {
          if (const ScheduleComparisonService()
                  .compare(
                    _schedulerMapList(alternatives[i]['placements']),
                    _schedulerMapList(alternatives[j]['placements']),
                  )
                  .changedLessonCount ==
              0) {
            alternatives[j]['label'] =
                '${alternatives[j]['label']} / ${alternatives[i]['label']} (نفس الجدول)';
            alternatives.removeAt(i);
            break;
          }
        }
      }
      final selectedIndex = alternatives.length == 1
          ? 0
          : await showScheduleAlternativesDialog(
              context,
              alternatives: alternatives,
            );
      if (selectedIndex == null || !mounted) return;
      final generated = alternatives[selectedIndex];
      final result = SchedulerResult(
        placements: _schedulerMapList(generated['placements']),
        unscheduled: (generated['unscheduled'] as List).cast<String>(),
        requestedCount: generated['requestedCount'] as int,
        exploredNodes: generated['exploredNodes'] as int,
        searchLimitReached: generated['searchLimitReached'] as bool,
        dailySpreadIssues: (generated['dailySpreadIssues'] as List? ?? const [])
            .cast<String>(),
      );
      final fixedRows = _schedulerMapList(input['lockedPlacements']);
      bool samePlace(Map<String, Object?> a, Map<String, Object?> b) => const [
        'section_id',
        'subject_id',
        'teacher_id',
        'day_id',
        'slot_id',
        'room_id',
      ].every((key) => a[key] == b[key]);
      if (!fixedRows.every(
        (fixed) => result.placements.any((entry) => samePlace(entry, fixed)),
      )) {
        final explanations = const ConstraintExplanationService().explain(
          input,
        );
        if (mounted) await showConstraintExplanations(context, explanations);
        throw StateError(
          'لم توجد نتيجة تحافظ على كل الحصص المثبتة. يمكنك مواصلة البحث أو إزالة التثبيت عن الحصص المتعارضة.',
        );
      }
      // لا نثق بنتيجة محرك التوزيع وحدها: نفحص كل الحصص المراد حفظها
      // بمحرك التعارضات نفسه قبل عرض خيار الحفظ، ونمنع حفظ أي إسناد مخالف.
      final generatedIssues = const ConflictDetectionService().scan(
        entries: result.placements,
        requirements: allRequirements,
        sections: allSections,
        slots: (data['slots'] as List).cast<Map<String, Object?>>(),
        teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
        qualifications: (data['qualifications'] as List)
            .cast<Map<String, Object?>>(),
        days: (data['days'] as List).cast<Map<String, Object?>>(),
        teacherGrades: (data['teacherGrades'] as List)
            .cast<Map<String, Object?>>(),
        teacherSubjectGrades: (data['teacherSubjectGrades'] as List)
            .cast<Map<String, Object?>>(),
        subjectBlockedSlots: (data['subjectBlockedSlots'] as List)
            .cast<Map<String, Object?>>(),
        teacherAvailability: (data['availability'] as List)
            .cast<Map<String, Object?>>(),
        enforceQualifications: true,
      );
      // No assignment conflict may be saved. A shortage is tolerated only
      // for an explicitly incomplete draft; it must block any claimed-complete
      // result and is still shown as a blocking issue when the draft is opened.
      final dailySpreadBlockers = generatedIssues
          .where(
            (issue) =>
                issue.severity == 'خطأ مانع' &&
                issue.type == 'توزيع المادة على كل أيام الأسبوع',
          )
          .toList();
      // Completeness means more than meeting the raw lesson count. The final
      // independent checker can discover a daily-coverage violation even when
      // every requested lesson has a placement; such a result must be saved only
      // as an inactive draft, not rejected as an assignment conflict.
      final isComplete = result.complete && dailySpreadBlockers.isEmpty;
      final dailySpreadMessages = <String>{
        ...result.dailySpreadIssues,
        ...dailySpreadBlockers.map((issue) => issue.message),
      }.toList();
      final assignmentBlockers = generatedIssues
          .where(
            (issue) =>
                issue.type != 'تكرار توقيت المادة في أيام متتالية' &&
                // Shortage and daily-spread findings describe an incomplete result.
                // They remain visible, but do not block saving a clearly labelled,
                // inactive draft. Real teacher/section assignment clashes still block.
                !(!isComplete &&
                    (issue.type == 'نقص الحصص' ||
                        issue.type == 'توزيع المادة على كل أيام الأسبوع')),
          )
          .toList();
      if (assignmentBlockers.isNotEmpty) {
        final details = assignmentBlockers
            .take(8)
            .map((issue) => '• ${issue.type}: ${issue.message}')
            .join('\n');
        throw StateError(
          'أوقف الحفظ لأن الفحص النهائي اكتشف تعارضات في التوزيع الآلي:\n$details',
        );
      }
      if (!mounted) return;
      final fairnessNotes = generatedIssues
          .where((issue) => issue.type == 'تكرار توقيت المادة في أيام متتالية')
          .toList();

      final approve = !advanced && isComplete
          ? true
          : await showDialog<bool>(
              context: context,
              barrierDismissible: false,
              builder: (ctx) => AlertDialog(
                title: Text(
                  isComplete
                      ? 'نتيجة الجدولة مكتملة'
                      : 'نتيجة جزئية — تحتاج مراجعة',
                ),
                content: SizedBox(
                  width: 460,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: _ResultMetric(
                                label: 'المطلوب',
                                value: '${result.requestedCount}',
                              ),
                            ),
                            Expanded(
                              child: _ResultMetric(
                                label: 'الموزع',
                                value: '${result.placements.length}',
                              ),
                            ),
                            Expanded(
                              child: _ResultMetric(
                                label: 'المتبقي',
                                value:
                                    '${result.requestedCount - result.placements.length}',
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Text(
                          'عُقد البحث المفحوصة: ${result.exploredNodes}${result.searchLimitReached ? ' (وصل البحث إلى الحد المحدد)' : ''}',
                        ),
                        if (dailySpreadMessages.isNotEmpty) ...[
                          SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFF4DF),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: const Color(0xFFE9C16A),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'تغطية الأيام تحتاج إلى استكمال',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    color: Color(0xFF805400),
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  'حتى إذا وُزّع العدد الأسبوعي كاملاً، لا يُعد الجدول مكتملاً إن غابت مادة مطلوب لها خمس حصص أسبوعياً أو أكثر عن أحد أيام الدوام. يمكنك حفظ هذه النتيجة كمسودة غير نشطة.',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Color(0xFF805400),
                                  ),
                                ),
                                ...dailySpreadMessages
                                    .take(6)
                                    .map(
                                      (message) => Padding(
                                        padding: const EdgeInsets.only(top: 4),
                                        child: Text(
                                          '• $message',
                                          style: TextStyle(
                                            fontSize: 11,
                                            color: Color(0xFF805400),
                                          ),
                                        ),
                                      ),
                                    ),
                                if (dailySpreadMessages.length > 6)
                                  Text(
                                    '... و${dailySpreadMessages.length - 6} ملاحظات أخرى',
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: Color(0xFF805400),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ],
                        if (fairnessNotes.isNotEmpty) ...[
                          SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFF4DF),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: const Color(0xFFE9C16A),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.balance_rounded,
                                      color: Color(0xFF9A6500),
                                      size: 18,
                                    ),
                                    SizedBox(width: 6),
                                    Expanded(
                                      child: Text(
                                        'ملاحظات عدالة التوزيع: ${fairnessNotes.length}',
                                        style: TextStyle(
                                          fontWeight: FontWeight.w900,
                                          color: Color(0xFF805400),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 4),
                                Text(
                                  'هذه ليست تعارضات مانعة؛ تعني أن المادة ظهرت في الفترة نفسها بيومين متتاليين. حاول المحرك تقليلها، لكن قد تبقى عندما تمنع القيود الأخرى البدائل.',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Color(0xFF805400),
                                  ),
                                ),
                                ...fairnessNotes
                                    .take(4)
                                    .map(
                                      (issue) => Padding(
                                        padding: const EdgeInsets.only(top: 4),
                                        child: Text(
                                          '• ${issue.message}',
                                          style: TextStyle(
                                            fontSize: 11,
                                            color: Color(0xFF805400),
                                          ),
                                        ),
                                      ),
                                    ),
                                if (fairnessNotes.length > 4)
                                  Text(
                                    '... و${fairnessNotes.length - 4} ملاحظات أخرى',
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: Color(0xFF805400),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ],
                        SizedBox(height: 10),
                        Text(
                          'يُسند التطبيق المعلمين تلقائياً وفق الاختصاصات والصفوف والنصاب والإتاحة. ويقارن محرك التوزيع حلولاً متعددة ضمن حد البحث لتحسين عدالة توزيع المواد والفترات. لا يسمح المحرك إطلاقاً بتزامن حصتين للمعلم نفسه؛ عند تعذر الحل تُحفظ النتيجة الجزئية مسودة فقط. الجدولة تشمل جميع شعب المدرسة ولا تتأثر بمرشح العرض.',
                        ),
                        SizedBox(height: 8),
                        Text(
                          isComplete
                              ? 'تم إسناد جميع الحصص إلى معلمين مؤهلين مع استيفاء التغطية المطلوبة للأيام. يمكنك حفظ الجدول الكامل كنسخة جديدة.'
                              : 'لم يكتمل الجدول أو لم تُستوفَ تغطية الأيام. راجع الأسباب أدناه؛ لن تتغير النسخة الحالية إلا إذا اخترت صراحة حفظ التوزيع المتاح كمسودة غير نشطة.',
                        ),
                        if (result.unscheduled.isNotEmpty) ...[
                          SizedBox(height: 12),
                          Text(
                            'الحصص غير الموزعة والأسباب',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.deepOrange,
                            ),
                          ),
                          ...result.unscheduled
                              .take(12)
                              .map(
                                (reason) => Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Icon(
                                        Icons.warning_amber,
                                        size: 18,
                                        color: Colors.deepOrange,
                                      ),
                                      SizedBox(width: 6),
                                      Expanded(
                                        child: Text(
                                          reason,
                                          style: TextStyle(fontSize: 12),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                          if (result.unscheduled.length > 12)
                            Text(
                              '... و${result.unscheduled.length - 12} حالات أخرى',
                            ),
                        ],
                      ],
                    ),
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () => showConstraintExplanations(
                      ctx,
                      const ConstraintExplanationService().explain({
                        ...input,
                        'searchLimitReached': result.searchLimitReached,
                      }),
                    ),
                    child: Text('شرح القيود والاقتراحات'),
                  ),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    child: Text('إغلاق دون حفظ'),
                  ),
                  if (isComplete)
                    FilledButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: Text('حفظ الجدول الكامل'),
                    )
                  else if (result.placements.isNotEmpty)
                    FilledButton.tonal(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: Text('حفظ المتاح كمسودة ناقصة'),
                    ),
                ],
              ),
            );
      if (approve == true) {
        {
          final reviewed = await showScheduleComparisonDialog(
            context,
            before: _schedulerMapList(data['entries']),
            after: result.placements,
            sections: allSections,
            teachers: _schedulerMapList(data['teachers']),
            subjects: _schedulerMapList(data['subjects']),
            days: _schedulerMapList(data['days']),
            slots: _schedulerMapList(data['slots']),
          );
          if (reviewed != true || !mounted) return;
        }
        final fresh = await _loadData();
        if (fresh['yearId'] != data['yearId'] ||
            fresh['versionId'] != data['versionId'] ||
            jsonEncode(_searchInput(fresh)) != jsonEncode(input)) {
          throw StateError(
            'تغيرت بيانات المدرسة أو الجدول أثناء البحث. أعد التوزيع لمراجعة النتيجة وفق البيانات الحالية.',
          );
        }
        final safeEntries = result.placements
            .map(
              (entry) => <String, Object?>{
                for (final key in [
                  'section_id',
                  'subject_id',
                  'teacher_id',
                  'day_id',
                  'slot_id',
                  'room_id',
                ])
                  key: entry[key],
                'is_locked': fixedRows.any((fixed) => samePlace(entry, fixed))
                    ? 1
                    : 0,
              },
            )
            .toList();
        final activeYear = (data['year'] as Map)['name']?.toString() ?? 'العام';
        final newId = await DatabaseService.instance.saveAsNewVersion(
          yearId: yearId,
          name:
              '${isComplete ? 'الجدول الأسبوعي التلقائي' : 'توزيع جزئي غير مكتمل'} ${DateTime.now().toString().substring(0, 16)}',
          entries: safeEntries,
          activate: isComplete,
          requireComplete: isComplete,
          expectedActiveVersionId: data['versionId'] as int?,
          notes: isComplete
              ? 'جدول كامل لجميع الشعب للعام $activeYear؛ الأولوية: ${generated['label'] ?? 'توزيع متوازن'}.'
              : 'توزيع آلي جزئي للعام $activeYear: وُزعت ${result.placements.length} من ${result.requestedCount} حصة. مسودة غير نشطة؛ بقي الجدول السابق نشطاً. يجب مراجعة الحصص المتبقية قبل الاعتماد.',
        );
        if (mounted)
          showMessage(
            context,
            isComplete
                ? 'تم توزيع ${result.placements.length}/${result.requestedCount} حصة واستبدال الجدول المعروض بالنسخة رقم $newId. النسخة السابقة محفوظة في الأرشيف.'
                : 'تم حفظ التوزيع الجزئي في النسخة رقم $newId كمسودة غير مكتملة. راجع فحص التعارضات وأكمل الحصص المتبقية.',
            error: !isComplete,
          );
        setState(_reload);
        widget.onChanged();
      }
    } catch (e) {
      if (mounted) showMessage(context, '$e', error: true);
    } finally {
      if (mounted) setState(() => _isGenerating = false);
    }
  }
}

class _ResultMetric extends StatelessWidget {
  const _ResultMetric({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Column(
    children: [
      Text(
        value,
        style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w800,
          color: Theme.of(context).colorScheme.onSurface,
        ),
      ),
      Text(label, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12)),
    ],
  );
}
