import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/core/jadwali_visuals.dart';
import 'package:iraqi_school_timetable/core/theme.dart';

void main() {
  testWidgets('timetable overview uses readable dark text on a dark tile', (tester) async {
    final theme = buildAppTheme(dark: true);
    await tester.pumpWidget(MaterialApp(
      theme: theme,
      home: Scaffold(body: JadwaliWeekPreview(
        dayId: 1,
        entries: [
          {
            'day_id': 1,
            'slot_id': 1,
            'slot_name': 'الأولى',
            'section_id': 1,
            'section_name': 'أ',
            'grade_name': 'الأول',
            'subject_id': 3,
            'subject_name': 'الرياضيات',
          },
        ],
      )),
    ));
    expect(find.text('الرياضيات'), findsOneWidget);
    final text = tester.widget<Text>(find.text('الرياضيات'));
    expect(text.style?.color, theme.colorScheme.onSurface);
    expect(tester.takeException(), isNull);
  });
}
