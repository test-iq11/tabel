import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/minimal_change_repair_service.dart';

void main() {
  const service = MinimalChangeRepairService();

  Map<String, Object?> school({
    required List<Map<String, Object?>> entries,
    List<Map<String, Object?>> blocked = const [],
    List<Map<String, Object?>> availability = const [],
  }) => {
    'entries': entries,
    'sections': [{'id': 1, 'grade_id': 101, 'max_daily_lessons': 6}],
    'days': [{'id': 1, 'name': 'الأحد', 'position': 1, 'is_active': 1}],
    'slots': [
      for (var i = 1; i <= 3; i++)
        {'id': i, 'name': 'الفترة $i', 'position': i, 'kind': 'lesson', 'is_available': 1},
    ],
    'teachers': [
      for (var i = 1; i <= 3; i++)
        {'id': i, 'name': 'المعلم $i', 'weekly_load': 10, 'max_daily_lessons': 6},
    ],
    'qualifications': [
      for (var i = 1; i <= 3; i++) {'teacher_id': i, 'subject_id': i},
    ],
    'teacherGrades': <Map<String, Object?>>[],
    'teacherSubjectGrades': [
      for (var i = 1; i <= 3; i++)
        {'teacher_id': i, 'subject_id': i, 'grade_id': 101},
    ],
    'requirements': [
      for (var i = 1; i <= entries.length; i++)
        {'section_id': 1, 'subject_id': i, 'weekly_lessons': 1,
         'allow_same_day': 0, 'max_daily_lessons': 1, 'grade_id': 101},
    ],
    'subjectBlockedSlots': blocked,
    'availability': availability,
  };

  List<Map<String, Object?>> three() => [
    for (var i = 1; i <= 3; i++)
      {'id': i, 'section_id': 1, 'subject_id': i, 'teacher_id': i,
       'room_id': null, 'day_id': 1, 'slot_id': i, 'is_locked': 0},
  ];

  test('discovers valid three-lesson cycle, without altering original board', () {
    final original = three();
    final data = school(entries: original, blocked: [
      {'subject_id': 1, 'slot_id': 1}, {'subject_id': 1, 'slot_id': 3},
      {'subject_id': 2, 'slot_id': 1}, {'subject_id': 2, 'slot_id': 2},
      {'subject_id': 3, 'slot_id': 2}, {'subject_id': 3, 'slot_id': 3},
    ]);
    final result = service.find(data: data, targetEntryId: 1);
    expect(result.options, isNotEmpty);
    final choice = result.options.first;
    expect(choice.moved, hasLength(3));
    expect(choice.placements.map((e) => e['slot_id']), [2, 3, 1]);
    expect(choice.remainingBlockers, 0);
    expect(original.map((e) => e['slot_id']), [1, 2, 3]);
    expect(original.every((e) => e['teacher_id'] == e['subject_id']), isTrue);
  });

  test('never moves a locked lesson, even when a cycle would solve it', () {
    final original = three();
    original[1]['is_locked'] = 1;
    final data = school(entries: original, blocked: [
      {'subject_id': 1, 'slot_id': 1}, {'subject_id': 1, 'slot_id': 3},
      {'subject_id': 2, 'slot_id': 1}, {'subject_id': 2, 'slot_id': 2},
      {'subject_id': 3, 'slot_id': 2}, {'subject_id': 3, 'slot_id': 3},
    ]);
    final result = service.find(data: data, targetEntryId: 1);
    expect(result.options, isEmpty);
  });

  test('prioritizes a two-lesson direct swap after teacher availability change', () {
    final board = three();
    final data = school(entries: board, availability: [
      {'teacher_id': 1, 'day_id': 1, 'slot_id': 1, 'is_available': 0},
    ]);
    final result = service.find(data: data, targetEntryId: 1);
    expect(result.options, isNotEmpty);
    expect(result.options.first.moved, hasLength(2));
    expect(result.options.first.unchanged, 1);
    expect(result.options.first.placements.first['slot_id'], 2);
  });

  test('reports an impossible teacher capacity without changing conditions', () {
    final board = three().take(2).map((e) => {...e, 'teacher_id': 1}).toList();
    final data = school(entries: board, availability: [
      {'teacher_id': 1, 'day_id': 1, 'slot_id': 2, 'is_available': 0},
      {'teacher_id': 1, 'day_id': 1, 'slot_id': 3, 'is_available': 0},
    ]);
    final notes = service.capacityDiagnostics(data, teacherId: 1);
    expect(notes.any((s) => s.contains('2 حصص') && s.contains('1 فترات')), isTrue);
    expect((data['availability'] as List).length, 2);
  });
}
