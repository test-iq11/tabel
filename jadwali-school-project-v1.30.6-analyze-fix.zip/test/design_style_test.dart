import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iraqi_school_timetable/core/design_style.dart';
import 'package:iraqi_school_timetable/core/interface_settings.dart';
import 'package:iraqi_school_timetable/core/theme.dart';
import 'package:iraqi_school_timetable/services/design_export_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('HTML theme schema round trips all design options', () {
    final d = const DesignStyle()
        .preset(3)
        .change('pattern', 'dots')
        .change('radius', 16.0)
        .change('motion', false);
    final decoded = DesignExportService.decode(DesignExportService.encode(d));
    expect(decoded.toMap(), d.toMap());
    expect(buildAppTheme(design: decoded).colorScheme.primary, decoded.accent);
    expect(
      buildAppTheme(design: decoded).textTheme.bodyMedium!.fontFamily,
      'JadwaliStudio',
    );
  });
  test('bad imported values are bounded and executable colors rejected', () {
    final d = DesignStyle.fromMap({
      'a': 'url(javascript:bad)',
      'radius': -40,
      'density': 900,
      'angle': double.infinity,
      'pattern': 'unknown',
      'motion': 'false',
    });
    expect(d.a, const DesignStyle().a);
    expect(d.radius, 0);
    expect(d.density, 115);
    expect(d.angle, 125);
    expect(d.pattern, 'rings');
    expect(d.motion, true);
    expect(
      () => DesignExportService.decode('{"format":"school-backup","theme":{}}'),
      throwsFormatException,
    );
  });
  test('contrast protection handles black to white and all presets', () {
    for (final d in [
      const DesignStyle(a: Colors.white, b: Colors.black),
      for (var i = 0; i < 8; i++) const DesignStyle().preset(i),
    ]) {
      final c = d.heroColors;
      expect(DesignStyle.contrast(c.$3, c.$1), greaterThanOrEqualTo(4.5));
      expect(DesignStyle.contrast(c.$3, c.$2), greaterThanOrEqualTo(4.5));
    }
  });
  test(
    'rapid customization persists final snapshot and preserves priorities',
    () async {
      SharedPreferences.setMockInitialValues({});
      final ui = InterfaceSettings();
      ui.softPriorities['spacing'] = 3;
      for (var i = 0; i < 15; i++) {
        ui.design = ui.design.change('radius', i * 2);
        ui.save();
      }
      ui.design = ui.design.preset(4).change('pattern', 'lines');
      await ui.save();
      final restored = InterfaceSettings();
      await restored.load();
      expect(restored.design.toMap(), ui.design.toMap());
      expect(restored.softPriorities['spacing'], 3);
      ui.dispose();
      restored.dispose();
    },
  );
  test('malformed stored design does not prevent app startup', () async {
    SharedPreferences.setMockInitialValues({'ui_design_v2': 'not json'});
    final ui = InterfaceSettings();
    await ui.load();
    expect(ui.design.accent, const Color(0xff525fe8));
    expect(ui.palette, 'indigo');
    ui.dispose();
  });
  test('HTML export includes font and safe bootstrap without actual school timetable', () async {
    final s = await DesignExportService.html(
      design: const DesignStyle().preset(2),
      schoolName: '</script><script>bad()</script>',
      dark: true,
      fontScale: 1.2,
    );
    expect(s, contains('data:font/ttf;base64,'));
    expect(s, contains('window.JADWALI_DESIGN='));
    expect(s, contains(r'\u003c/script\u003e'));
    expect(s, contains('"font":120.0'));
    final p = RegExp(r'data:font/ttf;base64,([^\x27]+)').firstMatch(s)!;
    expect(
      base64Decode(p.group(1)!),
      File('assets/fonts/UI-Regular.ttf').readAsBytesSync(),
    );
    expect(s, contains('"accent":"#326d9b"'));
  });
}
