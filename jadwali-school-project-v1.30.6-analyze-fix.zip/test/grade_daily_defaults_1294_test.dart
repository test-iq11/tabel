import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:iraqi_school_timetable/services/school_timetable_policy.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  test('fresh Iraqi primary school defaults to six lessons with a sixth Sunday seventh slot', () async {
    sqfliteFfiInit();
    final directory = await Directory.systemTemp.createTemp('jadwali-grade-limits-');
    final service = DatabaseService.withStorage(
      factory: databaseFactoryFfi,
      directory: directory.path,
    );
    addTearDown(() async {
      await service.close();
      await directory.delete(recursive: true);
    });

    final grades = await service.gradesDetailed();
    final slots = (await service.rows('time_slots'))
        .where((row) => row['kind'] == 'lesson' && row['is_available'] == 1)
        .toList();
    final days = (await service.rows('school_days'))
        .where((row) => row['is_active'] == 1)
        .toList();
    expect(grades, hasLength(6));
    expect(slots, hasLength(7));
    expect(grades.every((grade) => grade['max_daily_lessons'] == 6), isTrue);

    final sixth = grades.singleWhere((grade) =>
        SchoolTimetablePolicy.isSixthGrade({
          'grade_name': grade['name'], 'grade_position': grade['position'],
        }));
    final section = <String, Object?>{
      'grade_name': sixth['name'],
      'grade_position': sixth['position'],
      'max_daily_lessons': 6,
    };
    final sunday = days.singleWhere(SchoolTimetablePolicy.isSunday);
    expect(SchoolTimetablePolicy.normalDailyLimit(
      section: section, lessonSlotCount: slots.length), 6);
    expect(SchoolTimetablePolicy.canUseSeventhPeriod(
      section: section, day: sunday, activeDays: days,
      lessonSlots: slots, weeklyDemand: 31,
    ), isTrue);
    expect(SchoolTimetablePolicy.canUseSeventhPeriod(
      section: section, day: sunday, activeDays: days,
      lessonSlots: slots, weeklyDemand: 30,
    ), isFalse);
    expect(SchoolTimetablePolicy.canUseSeventhPeriod(
      section: section, day: days.firstWhere((day) => !SchoolTimetablePolicy.isSunday(day)),
      activeDays: days, lessonSlots: slots, weeklyDemand: 31,
    ), isFalse);
    final first = grades.firstWhere((grade) => grade['position'] == 0);
    expect(SchoolTimetablePolicy.canUseSeventhPeriod(
      section: {'grade_name': first['name'], 'max_daily_lessons': 6},
      day: sunday, activeDays: days, lessonSlots: slots, weeklyDemand: 31,
    ), isFalse);
  });
}
