import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:iraqi_school_timetable/features/setup/grade_daily_lessons_page.dart';
import 'package:iraqi_school_timetable/services/school_timetable_policy.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory folder;
  late DatabaseService db;
  late List<Map<String, Object?>> grades;
  late List<Map<String, Object?>> days;

  setUpAll(() async {
    sqfliteFfiInit();
    folder = await Directory.systemTemp.createTemp('jadwali-grade-weekday-');
    db = DatabaseService.withStorage(
      factory: databaseFactoryFfi,
      directory: folder.path,
    );
    grades = await db.gradesDetailed();
    days = await db.rows('school_days', orderBy: 'position');
  });
  tearDownAll(() async {
    await db.close();
    await folder.delete(recursive: true);
  });

  testWidgets('tapping a grade card edits Tuesday without changing Monday',
      (tester) async {
    final firstId = grades.first['id'] as int;
    final monday = days[1]['id'] as int;
    final tuesday = days[2]['id'] as int;
    Map<int, int>? submitted;
    var changes = 0;
    await tester.pumpWidget(MaterialApp(
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(body: GradeDailyLessonsPage(
          database: db,
          saveDayLimits: (gradeId, values) {
            expect(gradeId, firstId);
            submitted = Map<int, int>.from(values);
            return SynchronousFuture<void>(null);
          },
          onChanged: () => changes++,
          onSchoolTimes: () {},
        )),
      ),
    ));
    final card = find.byKey(ValueKey('tap-grade-daily-$firstId'));
    for (var i = 0; i < 40 && card.evaluate().isEmpty; i++) {
      await tester.runAsync(() => Future<void>.delayed(
          const Duration(milliseconds: 30)));
      await tester.pump(const Duration(milliseconds: 100));
    }
    expect(card, findsOneWidget);
    await tester.tap(card);
    await tester.pumpAndSettle();
    expect(find.text('حصص ${grades.first['name']}'), findsOneWidget);
    expect(find.byKey(ValueKey('decrease-day-$firstId-$tuesday')),
        findsOneWidget);
    await tester.tap(find.byKey(ValueKey('decrease-day-$firstId-$tuesday')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('save-grade-day-limits')));
    await tester.pumpAndSettle();
    for (var attempt = 0; attempt < 30 && submitted == null; attempt++) {
      await tester.pump(const Duration(milliseconds: 50));
    }
    expect(submitted, isNotNull, reason: 'The save action must be invoked.');
    expect(submitted![monday], 6,
        reason: 'Changing Tuesday must not modify Monday.');
    expect(submitted![tuesday], 5);
    for (var attempt = 0; attempt < 30 && changes == 0; attempt++) {
      await tester.pump(const Duration(milliseconds: 50));
    }
    expect(changes, 1,
        reason: 'The owning screen must refresh once after a saved change.');
    expect(tester.takeException(), isNull);
  });

  test('SQLite persists each weekday independently for grade and sections',
      () async {
    final gradeId = grades.first['id'] as int;
    final dbh = await db.database;
    final sectionId = await dbh.insert('sections', {
      'grade_id': gradeId,
      'name': 'اختبار الأيام المستقلة',
      'max_daily_lessons': 6,
    });
    try {
      final values = {for (final day in days) day['id'] as int: 6};
      final monday = days[1]['id'] as int;
      final tuesday = days[2]['id'] as int;
      values[tuesday] = 4;
      await db.updateGradeDayLimits(gradeId, values);
      final currentGrade = (await db.gradesDetailed())
          .singleWhere((grade) => grade['id'] == gradeId);
      final section = (await dbh.query('sections', where: 'id=?',
          whereArgs: [sectionId])).single;
      expect(SchoolTimetablePolicy.configuredDayLimit(
          section: currentGrade, day: days[1]), 6);
      expect(SchoolTimetablePolicy.configuredDayLimit(
          section: currentGrade, day: days[2]), 4);
      expect(SchoolTimetablePolicy.configuredDayLimit(
          section: section, day: days[1]), 6);
      expect(SchoolTimetablePolicy.configuredDayLimit(
          section: section, day: days[2]), 4);
      final otherGrade = (await db.gradesDetailed())
          .firstWhere((grade) => grade['id'] != gradeId);
      expect(SchoolTimetablePolicy.configuredDayLimit(
          section: otherGrade, day: days[2]), isNot(4));
      final audit = await dbh.query('audit_log',
          where: 'action=? AND entity_id=?',
          whereArgs: ['تعديل الحصص اليومية لكل يوم', gradeId]);
      expect(audit, isNotEmpty);
      expect(values[monday], 6);
    } finally {
      await db.updateGradeDailyLimit(gradeId, 6);
      await dbh.delete('sections', where: 'id=?', whereArgs: [sectionId]);
    }
  });

  test('saving active days preserves a disabled day and section inheritance',
      () async {
    final id = grades.first['id'] as int;
    final hiddenDay = days.last['id'] as int;
    final editedDay = days.first['id'] as int;
    final dbh = await db.database;
    final original = (await dbh.query('school_days', where: 'id=?',
        whereArgs: [hiddenDay])).single;
    int? sectionId;
    try {
      await db.updateGradeDayLimits(id, {hiddenDay: 3});
      await dbh.update('school_days', {'is_active': 0},
          where: 'id=?', whereArgs: [hiddenDay]);
      await db.updateGradeDayLimits(id, {editedDay: 5});
      final grade = (await db.gradesDetailed())
          .singleWhere((row) => row['id'] == id);
      expect(SchoolTimetablePolicy.configuredDayLimit(
          section: grade, day: days.last), 3);
      expect(SchoolTimetablePolicy.configuredDayLimit(
          section: grade, day: days.first), 5);
      sectionId = await dbh.insert('sections', {
        'grade_id': id, 'name': 'اختبار الاحتفاظ باليوم المعطل',
        'max_daily_lessons': 6,
      });
      final section = (await dbh.query('sections', where: 'id=?',
          whereArgs: [sectionId])).single;
      expect(SchoolTimetablePolicy.configuredDayLimit(
          section: section, day: days.last), 3);
      await db.updateGradeDayLimits(id, {editedDay: 4});
      final updated = (await dbh.query('sections', where: 'id=?',
          whereArgs: [sectionId])).single;
      expect(SchoolTimetablePolicy.configuredDayLimit(
          section: updated, day: days.first), 4);
      expect(SchoolTimetablePolicy.configuredDayLimit(
          section: updated, day: days.last), 3);
    } finally {
      await dbh.update('school_days', {'is_active': original['is_active']},
          where: 'id=?', whereArgs: [hiddenDay]);
      if (sectionId != null) {
        await dbh.delete('sections', where: 'id=?', whereArgs: [sectionId]);
      }
      await db.updateGradeDailyLimit(id, 6);
    }
  });

  test('invalid daily number rolls back without overwriting earlier values',
      () async {
    final id = grades.first['id'] as int;
    final before = (await db.gradesDetailed())
        .firstWhere((grade) => grade['id'] == id)['daily_limits_json'];
    await expectLater(
        db.updateGradeDayLimits(id, {days[0]['id'] as int: 8}),
        throwsA(isA<ArgumentError>()));
    final after = (await db.gradesDetailed())
        .firstWhere((grade) => grade['id'] == id)['daily_limits_json'];
    expect(after, before);
  });
}
