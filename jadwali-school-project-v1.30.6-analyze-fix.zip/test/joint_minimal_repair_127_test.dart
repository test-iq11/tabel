import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/minimal_change_repair_service.dart';
import 'package:iraqi_school_timetable/services/repair_history_service.dart';

void main() {
  const repair = MinimalChangeRepairService();
  Map<String, Object?> buildSchool({bool lockFirst = false}) {
    final entries = <Map<String, Object?>>[
      for (var i = 1; i <= 6; i++)
        <String, Object?>{
          'id': i,
          'section_id': i <= 3 ? 1 : 2,
          'subject_id': i,
          'teacher_id': i,
          'room_id': null,
          'day_id': 1,
          'slot_id': ((i - 1) % 3) + 1,
          'is_locked': lockFirst && i == 1 ? 1 : 0,
        },
    ];
    return {
      'entries': entries,
      'sections': [
        {'id': 1, 'grade_id': 101, 'name': 'الأول', 'max_daily_lessons': 6},
        {'id': 2, 'grade_id': 102, 'name': 'الثاني', 'max_daily_lessons': 6},
      ],
      'days': [{'id': 1, 'name': 'الأحد', 'is_active': 1, 'position': 1}],
      'slots': [
        for (var i = 1; i <= 4; i++)
          {'id': i, 'name': 'الحصة $i', 'position': i,
           'kind': 'lesson', 'is_available': 1},
      ],
      'teachers': [
        for (var i = 1; i <= 6; i++)
          {'id': i, 'name': 'معلم $i', 'weekly_load': 10,
           'max_daily_lessons': 6},
      ],
      'qualifications': [
        for (var i = 1; i <= 6; i++)
          {'teacher_id': i, 'subject_id': i},
      ],
      'teacherGrades': <Map<String, Object?>>[],
      'teacherSubjectGrades': [
        for (var i = 1; i <= 6; i++)
          {'teacher_id': i, 'subject_id': i,
           'grade_id': i <= 3 ? 101 : 102},
      ],
      'requirements': [
        for (var i = 1; i <= 6; i++)
          {'section_id': i <= 3 ? 1 : 2, 'subject_id': i,
           'weekly_lessons': 1, 'grade_id': i <= 3 ? 101 : 102,
           'allow_same_day': 0, 'max_daily_lessons': 1},
      ],
      'subjectBlockedSlots': [
        {'subject_id': 1, 'slot_id': 1},
        {'subject_id': 4, 'slot_id': 1},
      ],
      'availability': <Map<String, Object?>>[],
    };
  }

  test('repairs two independent blockers jointly with minimum changed lessons', () {
    final data = buildSchool();
    final original = MinimalChangeRepairService.rows(data, 'entries');
    final before = repair.scan(data, original)
        .where((issue) => issue.severity == 'خطأ مانع').length;
    expect(before, greaterThanOrEqualTo(2));
    final found = repair.findAffected(
      data: data, maxRounds: 4, beamWidth: 3, maxExplored: 1400,
    );
    expect(found.options, isNotEmpty);
    final chosen = found.options.first;
    expect(chosen.remainingBlockers, 0);
    expect(chosen.moved, hasLength(2));
    expect(chosen.unchanged, 4);
    expect(chosen.placements[0]['slot_id'], 4);
    expect(chosen.placements[3]['slot_id'], 4);
    expect(original[0]['slot_id'], 1);
    expect(original[3]['slot_id'], 1);
  });

  test('joint repair never changes a locked lesson', () {
    final data = buildSchool(lockFirst: true);
    final found = repair.findAffected(data: data, maxRounds: 3);
    for (final choice in found.options) {
      expect(choice.placements.first['slot_id'], 1);
      expect(choice.moved, isNot(contains(0)));
    }
  });

  test('early diagnostics prove section and blocked-subject capacity deficits', () {
    final data = buildSchool();
    (data['requirements'] as List).add({
      'section_id': 1, 'subject_id': 1,
      'weekly_lessons': 5,
    });
    final notes = repair.feasibilityDiagnostics(data);
    expect(notes.any((s) => s.contains('عجز مؤكد في الأول')), isTrue);
    expect(notes.any((s) => s.contains('عجز مؤكد للمادة 1')), isTrue);
    expect((data['subjectBlockedSlots'] as List), hasLength(2));
  });

  test('search exhaustion is distinguished from proven impossibility', () {
    final data = buildSchool();
    final result = repair.findAffected(data: data, maxExplored: 0);
    expect(result.options, isEmpty);
    expect(result.limitReached, isTrue);
    expect(result.diagnostics.join(' '), contains('حد البحث'));
  });

  test('repair history tags correctly identify only a valid source version', () {
    const history = RepairHistoryService();
    final note = history.note(
      sourceVersionId: 41, moved: 2, remaining: 0, reason: 'إصلاح جماعي',
    );
    expect(history.sourceVersionId(note), 41);
    expect(history.sourceVersionId('أرشيف عادي'), isNull);
    expect(history.sourceVersionId('[JADWALI_MIN_REPAIR_SOURCE:0]'), isNull);
  });
}
