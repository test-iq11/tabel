import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iraqi_school_timetable/core/interface_settings.dart';
import 'package:iraqi_school_timetable/core/jadwali_palettes.dart';
import 'package:iraqi_school_timetable/core/jadwali_visuals.dart';
import 'package:iraqi_school_timetable/core/theme.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('the HTML palettes are complete and are persisted without touching data', () async {
    SharedPreferences.setMockInitialValues({});
    final ui = InterfaceSettings();
    await ui.load();
    expect(ui.palette, 'indigo');
    expect(ui.design.accent, const Color(0xff525fe8));
    expect(JadwaliPalettes.palettes.length, 18);
    ui.applyPalette('purple');
    await ui.save();
    final saved = InterfaceSettings();
    await saved.load();
    expect(saved.palette, 'purple');
    expect(saved.design.accent, const Color(0xff8754be));
    saved.setMotion(false);
    await saved.save();
    final next = InterfaceSettings();
    await next.load();
    expect(next.design.motion, isFalse);
    expect(buildAppTheme(design: next.design).colorScheme.primary, next.design.accent);
    ui.dispose();
    saved.dispose();
    next.dispose();
  });

  testWidgets('all color choices are interactive and accessible', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final ui = InterfaceSettings.instance;
    await ui.load();
    await tester.pumpWidget(MaterialApp(
      theme: buildAppTheme(design: ui.design),
      home: const Scaffold(body: JadwaliPaletteSelector()),
    ));
    expect(find.byKey(const ValueKey('palette-indigo')), findsOneWidget);
    expect(find.byKey(const ValueKey('palette-teal')), findsOneWidget);
    expect(find.byKey(const ValueKey('palette-purple')), findsOneWidget);
    expect(find.byKey(const ValueKey('palette-blue')), findsOneWidget);
    expect(find.byKey(const ValueKey('palette-coral')), findsOneWidget);
    expect(find.byKey(const ValueKey('palette-forest')), findsOneWidget);
    expect(find.byKey(const ValueKey('palette-berry')), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('palette-teal')));
    await tester.pump();
    expect(ui.palette, 'teal');
  });
}
