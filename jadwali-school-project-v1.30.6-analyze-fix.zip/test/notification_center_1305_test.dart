import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/core/jadwali_palettes.dart';
import 'package:iraqi_school_timetable/core/theme.dart';
import 'package:iraqi_school_timetable/features/notifications/jadwali_notification_center.dart';
import 'package:iraqi_school_timetable/services/conflict_detection_service.dart';

void main() {
  test('all eighteen approved palettes retain unique identifiers and colours', () {
    expect(JadwaliPalettes.palettes.length, 18);
    expect(JadwaliPalettes.palettes.keys.toSet().length, 18);
    expect(JadwaliPalettes.palettes['forest']?.$1, 'أخضر الغابة');
    expect(JadwaliPalettes.palettes['berry']?.$2, const Color(0xff923f74));
  });

  test('the bell reports only real status, never invented sample counts', () {
    final missing = JadwaliNotificationData.fromCurrentStatus(
      summary: {'الحصص المطلوبة': 30, 'الحصص المتبقية': 4},
      hasActiveTimetable: true,
      issues: const [ConflictIssue(
        type: 'تعارض معلمين',
        severity: 'خطأ مانع',
        message: 'المعلم لديه حصتان في الوقت نفسه',
      )],
    );
    expect(missing.items.any((n) => n.title.contains('4 حصة')), isTrue);
    expect(missing.blockers, 1);
    expect(missing.items.any((n) => n.destination == 6), isTrue);
    final empty = JadwaliNotificationData.fromCurrentStatus(
      summary: const {'الحصص المطلوبة': 0, 'الحصص المتبقية': 0},
      hasActiveTimetable: false,
      issues: const [],
    );
    expect(empty.items.first.destination, 13);
    expect(empty.items.first.title, contains('الحصص المطلوبة'));
  });

  testWidgets('theme surfaces and labels stay readable in dark mode', (tester) async {
    final dark = buildAppTheme(dark: true);
    expect(dark.colorScheme.surface, isNot(dark.scaffoldBackgroundColor));
    expect(dark.colorScheme.surfaceContainerHigh, isNot(Colors.white));
    expect(dark.colorScheme.onSurface.computeLuminance(), greaterThan(.55));
    expect(dark.colorScheme.surface.computeLuminance(), lessThan(.06));
    await tester.pumpWidget(MaterialApp(
      theme: dark,
      home: Scaffold(body: Builder(builder: (context) => Container(
        color: Theme.of(context).colorScheme.surface,
        child: Text('الوضع الليلي',
          style: TextStyle(color: Theme.of(context).colorScheme.onSurface)),
      ))),
    ));
    expect(find.text('الوضع الليلي'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('notification bell opens live notices and follows the selected problem', (tester) async {
    int? destination;
    await tester.pumpWidget(MaterialApp(
      theme: buildAppTheme(dark: true),
      home: Scaffold(body: Builder(builder: (ctx) => TextButton(
        onPressed: () => showDialog<void>(
          context: ctx,
          builder: (_) => JadwaliNotificationPanel(
            repository: const _FixtureRepository(),
            onNavigate: (id) => destination = id,
          ),
        ),
        child: const Text('افتح الجرس'),
      ))),
    ));
    await tester.tap(find.text('افتح الجرس'));
    await tester.pumpAndSettle();
    expect(find.text('تنبيهات جدولي'), findsOneWidget);
    expect(find.text('تعارض المعلم'), findsOneWidget);
    expect(find.byKey(const ValueKey('live-notification-list')), findsOneWidget);
    await tester.tap(find.text('تعارض المعلم'));
    await tester.pumpAndSettle();
    expect(destination, 6);
    expect(find.byKey(const ValueKey('live-notification-list')), findsNothing);
    expect(tester.takeException(), isNull);
  });
}

class _FixtureRepository extends JadwaliNotificationRepository {
  const _FixtureRepository();

  @override
  Future<JadwaliNotificationData> load() async =>
      JadwaliNotificationData.fromCurrentStatus(
        summary: const {'الحصص المطلوبة': 30, 'الحصص المتبقية': 2},
        hasActiveTimetable: true,
        issues: const [ConflictIssue(
          type: 'تعارض المعلم',
          severity: 'خطأ مانع',
          message: 'الحصتان متزامنتان للمعلم نفسه',
        )],
      );
}
