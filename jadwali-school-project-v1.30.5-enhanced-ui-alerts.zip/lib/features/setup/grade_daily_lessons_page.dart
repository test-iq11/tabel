import 'dart:convert';

import 'package:flutter/material.dart';

import '../../data/database_service.dart';
import '../../services/school_timetable_policy.dart';

/// Daily lesson settings are individual to each (grade, school day) pair.
/// They are persisted to SQLite for the grade and inherited by its sections.
/// The numbers are limits, not new subject requirements; changing them never
/// silently rewrites the already approved timetable.
class GradeDailyLessonsPage extends StatefulWidget {
  const GradeDailyLessonsPage({
    required this.onChanged,
    required this.onSchoolTimes,
    this.database,
    this.saveDayLimits,
    super.key,
  });

  final VoidCallback onChanged;
  final VoidCallback onSchoolTimes;
  final DatabaseService? database;
  final Future<void> Function(int gradeId, Map<int, int> values)? saveDayLimits;

  @override
  State<GradeDailyLessonsPage> createState() => _GradeDailyLessonsPageState();
}

class _GradeDailyLessonsPageState extends State<GradeDailyLessonsPage> {
  late Future<List<List<Map<String, Object?>>>> _data;
  bool _saving = false;
  DatabaseService get _db => widget.database ?? DatabaseService.instance;

  @override
  void initState() {
    super.initState();
    _data = _load();
  }

  Future<List<List<Map<String, Object?>>>> _load() async => [
    await _db.gradesDetailed(),
    await _db.rows('school_days', orderBy: 'position'),
    await _db.rows('time_slots', orderBy: 'position'),
  ];

  int _integer(Object? value, {int fallback = 0}) =>
      value is num ? value.toInt() : int.tryParse('$value') ?? fallback;

  bool _sixth(Map<String, Object?> grade) =>
      SchoolTimetablePolicy.isSixthGrade({
        'grade_name': grade['name'],
        'grade_position': grade['position'],
      });

  int _limit(Map<String, Object?> grade, Map<String, Object?> day) {
    final explicit = SchoolTimetablePolicy.configuredDayLimit(
      section: grade, day: day,
    );
    if (explicit != null) return explicit;
    if (_sixth(grade) && SchoolTimetablePolicy.isSunday(day)) return 7;
    final ordinary = _integer(grade['max_daily_lessons'], fallback: 6);
    return ordinary.clamp(0, 6).toInt();
  }

  Future<void> _edit(Map<String, Object?> grade,
      List<Map<String, Object?>> days, int slotsAvailable) async {
    final values = <int, int>{
      for (final day in days) _integer(day['id']): _limit(grade, day),
    };
    final initial = Map<int, int>.from(values);
    final chosen = await showDialog<Map<int, int>>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, update) => AlertDialog(
          insetPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 20),
          contentPadding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
          title: Text('حصص ${grade['name']}'),
          content: SizedBox(
            width: 316,
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Text('حدد عدد الحصص لكل يوم بصورة مستقلة'),
                const SizedBox(height: 12),
                for (final day in days)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(children: [
                      Expanded(child: Text('${day['name']}',
                        style: Theme.of(context).textTheme.bodyMedium)),
                      IconButton(
                        key: ValueKey('decrease-day-${grade['id']}-${day['id']}'),
                        tooltip: 'تقليل حصص ${day['name']}',
                        onPressed: values[_integer(day['id'])]! > 0
                            ? () => update(() => values[_integer(day['id'])] =
                                values[_integer(day['id'])]! - 1)
                            : null,
                        icon: const Icon(Icons.remove_circle_outline),
                      ),
                      SizedBox(width: 30, child: Text(
                        '${values[_integer(day['id'])]}',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.titleMedium,
                      )),
                      IconButton(
                        key: ValueKey('increase-day-${grade['id']}-${day['id']}'),
                        tooltip: 'زيادة حصص ${day['name']}',
                        onPressed: values[_integer(day['id'])]! < 7
                            ? () => update(() => values[_integer(day['id'])] =
                                values[_integer(day['id'])]! + 1)
                            : null,
                        icon: const Icon(Icons.add_circle_outline),
                      ),
                    ]),
                  ),
                const SizedBox(height: 10),
                Text('المجموع الأسبوعي الأقصى: '
                    '${values.values.fold<int>(0, (a, b) => a + b)} حصة',
                    style: Theme.of(context).textTheme.titleSmall),
                if (values.values.any((v) => v > slotsAvailable))
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      'تنبيه: عدد الفترات الدراسية المفعلة حاليًا '
                      '$slotsAvailable فقط. فعّل الفترات الناقصة من إعدادات المدرسة.',
                      style: TextStyle(color: Theme.of(context).colorScheme.error),
                    ),
                  ),
                const SizedBox(height: 10),
                const Text('تُطبق الأعداد على جميع شعب هذا الصف. '
                    'لن يُعدل الجدول الحالي تلقائيًا، وقد تحتاج إلى تشغيل الإصلاح.',
                    textAlign: TextAlign.start),
              ]),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext),
                child: const Text('إلغاء')),
            FilledButton(
              key: const ValueKey('save-grade-day-limits'),
              onPressed: () => Navigator.pop(dialogContext,
                  Map<int, int>.from(values)),
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
    if (chosen == null || !mounted) return;
    if (chosen.keys.every((id) => chosen[id] == initial[id])) return;
    setState(() => _saving = true);
    try {
      final writer = widget.saveDayLimits ?? _db.updateGradeDayLimits;
      await writer(_integer(grade['id']), chosen);
      widget.onChanged();
      if (!mounted) return;
      setState(() => _data = _load());
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('تم حفظ حصص الأيام لهذا الصف وجميع شعبه. '
            'راجع التعارضات عند تعديل جدول قائم.'),
      ));
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('تعذر حفظ حصص الأيام: $error'),
      ));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _reset() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('استعادة حصص الأيام الافتراضية'),
        content: const Text('6 حصص لجميع الصفوف في جميع أيام الدوام، '
            'و7 حصص للسادس يوم الأحد. لن يُمسّ الجدول الموجود.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('استعادة')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _saving = true);
    try {
      final db = await _db.database;
      await db.transaction((txn) async {
        final grades = await txn.query('grades');
        final days = await txn.query('school_days');
        for (final grade in grades) {
          final values = <String, int>{
            for (final day in days)
              '${day['id']}':
                  (SchoolTimetablePolicy.isSixthGrade({
                            'grade_name': grade['name'],
                            'grade_position': grade['position'],
                          }) && SchoolTimetablePolicy.isSunday(day))
                      ? 7 : 6,
          };
          final encoded = jsonEncode(values);
          await txn.update('grades',
              {'max_daily_lessons': 6, 'daily_limits_json': encoded},
              where: 'id=?', whereArgs: [grade['id']]);
          await txn.update('sections',
              {'max_daily_lessons': 6, 'daily_limits_json': encoded},
              where: 'grade_id=?', whereArgs: [grade['id']]);
        }
        await txn.insert('audit_log', {
          'action': 'استعادة حصص الأيام الافتراضية',
          'entity': 'grades', 'entity_id': 0,
          'details': '6 حصص يوميًا، والسادس يوم الأحد 7',
          'created_at': DateTime.now().toIso8601String(),
        });
      });
      widget.onChanged();
      if (!mounted) return;
      setState(() => _data = _load());
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('حُفظت الأعداد الافتراضية لكل يوم وصف.'),
      ));
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('تعذرت استعادة الأعداد: $error'),
      ));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) =>
      FutureBuilder<List<List<Map<String, Object?>>>>(
    future: _data,
    builder: (context, snapshot) {
      if (snapshot.hasError) return Center(child: Text('تعذر قراءة الصفوف: ${snapshot.error}'));
      if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
      final grades = snapshot.data![0];
      final days = snapshot.data![1]
          .where((day) => _integer(day['is_active'], fallback: 1) == 1)
          .toList();
      final slotsAvailable = snapshot.data![2]
          .where((slot) => slot['kind'] == 'lesson' &&
              _integer(slot['is_available'], fallback: 1) == 1).length;
      final scheme = Theme.of(context).colorScheme;
      const tones = <Color>[
        Color(0xff5f66d6), Color(0xff12968b), Color(0xffd38655),
        Color(0xff9272c9), Color(0xff367fba), Color(0xffb56c92),
      ];
      return ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Icon(Icons.view_week_rounded, color: scheme.primary),
          const SizedBox(width: 10),
          Expanded(child: Text('الحصص المخصصة لكل صف',
              style: Theme.of(context).textTheme.titleLarge)),
        ]),
        const SizedBox(height: 8),
        Text('اضغط على الصف وعدل عدد الحصص للأحد والاثنين وبقية الأيام '
            'كلًّا على حدة. الافتراضي: 6، والسادس يوم الأحد 7.',
            style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 12),
        if (slotsAvailable < 7) Card(
          color: scheme.tertiaryContainer.withValues(alpha: .40),
          child: Padding(padding: const EdgeInsets.all(12), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('يوجد $slotsAvailable فترة مفعّلة فقط. '
                  'فعّل الفترات الإضافية إن كنت تحتاج أكثر.',
                  style: TextStyle(color: scheme.onSurface)),
              TextButton.icon(onPressed: widget.onSchoolTimes,
                  icon: const Icon(Icons.schedule),
                  label: const Text('فتح إعدادات المدرسة والأوقات')),
            ],
          )),
        ),
        for (var i = 0; i < grades.length; i++)
          Padding(padding: const EdgeInsets.only(bottom: 12), child: Card(
            child: InkWell(
              key: ValueKey('tap-grade-daily-${grades[i]['id']}'),
              borderRadius: BorderRadius.circular(18),
              onTap: _saving ? null : () => _edit(grades[i], days, slotsAvailable),
              child: Padding(padding: const EdgeInsets.all(15), child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Container(padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: tones[i % tones.length].withValues(alpha: .12),
                        borderRadius: BorderRadius.circular(12)),
                      child: Icon(Icons.school_outlined,
                          color: tones[i % tones.length])),
                    const SizedBox(width: 10),
                    Expanded(child: Text('${grades[i]['name']}',
                      style: Theme.of(context).textTheme.titleMedium)),
                    IconButton(
                      key: ValueKey('edit-grade-daily-${grades[i]['id']}'),
                      tooltip: 'تعديل حصص الأيام',
                      icon: Icon(Icons.edit_outlined,
                          color: tones[i % tones.length]),
                      onPressed: _saving ? null : () =>
                          _edit(grades[i], days, slotsAvailable),
                    ),
                  ]),
                  const SizedBox(height: 10),
                  Wrap(spacing: 7, runSpacing: 7, children: [
                    for (final day in days)
                      Chip(
                        label: Text('${day['name']} · ${_limit(grades[i], day)}'),
                        backgroundColor: scheme.surfaceContainerHighest
                            .withValues(alpha: .48),
                      ),
                  ]),
                  const SizedBox(height: 8),
                  Text('المجموع الأسبوعي الأقصى: '
                      '${days.fold<int>(0, (sum, day) => sum + _limit(grades[i], day))} حصة',
                      style: Theme.of(context).textTheme.bodySmall),
                ])),
            ),
          )),
        OutlinedButton.icon(
          key: const ValueKey('restore-default-grade-periods'),
          onPressed: _saving ? null : _reset,
          icon: const Icon(Icons.restore_outlined),
          label: const Text('استعادة العدد الافتراضي لجميع الصفوف'),
        ),
        const SizedBox(height: 10),
        Text('العدد يحدد الحد الأقصى للحصص الممكن وضعها في ذلك اليوم '
            'لكل شعبة، ولا يغيّر نصاب المواد الأسبوعي. '
            'بعد التعديل افحص الجدول الحالي وأصلح التعارضات عند الحاجة.',
            style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 70),
      ]);
    },
  );
}
