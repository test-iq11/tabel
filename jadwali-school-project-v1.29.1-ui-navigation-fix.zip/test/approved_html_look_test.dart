import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/core/html_dashboard_hero.dart';

void main() {
  testWidgets('approved HTML banner has live repair, timetable and customization actions',
      (tester) async {
    var repaired = 0;
    var opened = 0;
    var customized = 0;
    tester.view.physicalSize = const Size(320, 740);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(MaterialApp(
      theme: ThemeData(useMaterial3: true),
      home: Scaffold(body: SingleChildScrollView(
        child: HtmlDashboardHero(
          onRepair: () => repaired++,
          onTimetable: () => opened++,
          onCustomize: () => customized++,
        ),
      )),
    ));
    expect(find.byKey(const ValueKey('html-dashboard-hero')), findsOneWidget);
    await tester.tap(find.text('استكشف الإصلاح الذكي'));
    await tester.pump();
    expect(repaired, 1);
    await tester.tap(find.byKey(const ValueKey('customize-school-card')));
    await tester.pump();
    expect(customized, 1);
    await tester.ensureVisible(find.text('فتح الجدول الدراسي'));
    await tester.tap(find.text('فتح الجدول الدراسي'));
    await tester.pump();
    expect(opened, 1);
    expect(tester.takeException(), isNull);
  });
}
