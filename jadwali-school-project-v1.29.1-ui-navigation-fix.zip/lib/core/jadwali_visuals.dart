import 'package:flutter/material.dart';

import 'interface_settings.dart';
import 'jadwali_palettes.dart';
import 'timetable_palette.dart';

/// Colors and motion shared by the HTML-inspired Flutter interface.
/// No scheduling, database or export logic lives in this file.
class JadwaliVisuals {
  const JadwaliVisuals._();
  static const palettes = JadwaliPalettes.palettes;

  static Color ink(BuildContext context) => Theme.of(context).colorScheme.onSurface;
  static Color muted(BuildContext context) => Theme.of(context).colorScheme.onSurfaceVariant;
  static bool motion(BuildContext context) => !MediaQuery.disableAnimationsOf(context) &&
      InterfaceSettings.instance.design.motion;

  static BoxDecoration panel(BuildContext context, {double radius = 22, bool shadow = true}) {
    final c = Theme.of(context).colorScheme;
    return BoxDecoration(
      color: c.surface,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: c.outlineVariant.withValues(alpha: .8)),
      boxShadow: shadow ? [BoxShadow(
        color: Theme.of(context).brightness == Brightness.dark
            ? const Color(0x18000000) : const Color(0x0D24365B),
        blurRadius: 25,
        offset: const Offset(0, 9),
      )] : null,
    );
  }
}

/// An HTML-inspired metric card backed by *real* database values.
class JadwaliStatCard extends StatelessWidget {
  const JadwaliStatCard({super.key, required this.value, required this.caption,
    required this.icon, required this.tint});
  final String value, caption;
  final IconData icon;
  final Color tint;
  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    return Container(
      padding: EdgeInsets.all(16 * InterfaceSettings.instance.design.density / 100),
      decoration: JadwaliVisuals.panel(context),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: tint.withValues(alpha: .12), borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, size: 20, color: tint)),
        const SizedBox(height: 10),
        Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
        Text(caption, style: TextStyle(fontSize: 11, color: c.onSurfaceVariant)),
      ]),
    );
  }
}

/// Compact live timetable preview. Keeps subject colors identical to editor/export.
class JadwaliWeekPreview extends StatelessWidget {
  const JadwaliWeekPreview({super.key, required this.entries, required this.dayId, this.onOpenSection});
  final List<Map<String, Object?>> entries;
  final Object? dayId;
  final ValueChanged<int>? onOpenSection;

  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme;
    final today = entries.where((e) => e['day_id'] == dayId).toList();
    final uniqueSections = <int, String>{};
    final uniqueSlots = <int, String>{};
    for (final e in today) {
      final section = e['section_id'];
      final slot = e['slot_id'];
      if (section is int) {
        uniqueSections[section] = '${e['grade_name'] ?? ''} ${e['section_name'] ?? ''}'.trim();
      }
      if (slot is int) uniqueSlots[slot] = '${e['slot_name'] ?? ''}';
    }
    final sections = (uniqueSections.entries.toList()
      ..sort((a, b) => a.key.compareTo(b.key))).take(3).toList();
    final slots = (uniqueSlots.entries.toList()
      ..sort((a, b) => a.key.compareTo(b.key))).take(6).toList();
    if (sections.isEmpty || slots.isEmpty) {
      return Padding(padding: const EdgeInsets.symmetric(vertical: 24),
        child: Column(children: [Icon(Icons.calendar_month_outlined, size: 33, color: c.primary),
          const SizedBox(height: 8), const Text('سيظهر هنا جزء من جدولك بعد توزيع الحصص'),
        ]));
    }
    return SingleChildScrollView(scrollDirection: Axis.horizontal,
      child: ConstrainedBox(constraints: const BoxConstraints(minWidth: 540),
        child: Table(
          defaultVerticalAlignment: TableCellVerticalAlignment.middle,
          columnWidths: {0: const FixedColumnWidth(116), for (var i = 1; i <= slots.length; i++) i: const FixedColumnWidth(94)},
          children: [
            TableRow(children: [
              _header('الصف / الحصة', context),
              for (final s in slots) _header(s.value, context),
            ]),
            for (final section in sections)
              TableRow(children: [
                InkWell(onTap: onOpenSection == null ? null : () => onOpenSection!(section.key),
                  child: _cell(section.value, context, c.surfaceContainerHighest, c.onSurface, bold: true)),
                for (final slot in slots) Builder(builder: (context) {
                  final matches = today.where((e) => e['section_id'] == section.key && e['slot_id'] == slot.key);
                  if (matches.isEmpty) return _cell('—', context, c.surface, c.onSurfaceVariant);
                  final entry = matches.first;
                  final subjectId = entry['subject_id'] is int ? entry['subject_id'] as int : 1;
                  return _cell('${entry['subject_name'] ?? 'حصة'}', context,
                    Color(TimetablePalette.tint(subjectId)), Color(TimetablePalette.accent(subjectId)), bold: true);
                }),
              ]),
          ],
        ),
      ),
    );
  }

  Widget _header(String text, BuildContext context) => Padding(
    padding: const EdgeInsets.all(4),
    child: Container(padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(11)),
      child: Text(text, textAlign: TextAlign.center, maxLines: 2,
        overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800))),
  );

  Widget _cell(String text, BuildContext context, Color background, Color color, {bool bold = false}) =>
    Padding(padding: const EdgeInsets.all(4), child: Container(
      constraints: const BoxConstraints(minHeight: 56),
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 9),
      decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withValues(alpha: .08))),
      child: Text(text, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis,
        style: TextStyle(color: color, fontWeight: bold ? FontWeight.w700 : FontWeight.w400, fontSize: 10)),
    ));
}

/// Accessible swatch shared by settings and the HTML-inspired appearance panel.
class JadwaliPaletteSelector extends StatelessWidget {
  const JadwaliPaletteSelector({super.key});
  @override
  Widget build(BuildContext context) {
    final ui = InterfaceSettings.instance;
    return Wrap(spacing: 9, runSpacing: 12, children: [
      for (final p in JadwaliVisuals.palettes.entries)
        Tooltip(message: p.value.$1, child: Semantics(
          label: 'لون ${p.value.$1}', selected: ui.palette == p.key,
          child: InkWell(
            key: ValueKey('palette-${p.key}'),
            borderRadius: BorderRadius.circular(15),
            onTap: () => ui.applyPalette(p.key),
            child: AnimatedContainer(duration: JadwaliVisuals.motion(context)
                ? const Duration(milliseconds: 220) : Duration.zero,
              height: 47, width: 47,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [p.value.$2, p.value.$3]),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: ui.palette == p.key ? Theme.of(context).colorScheme.onSurface : Colors.white.withValues(alpha: .4), width: ui.palette == p.key ? 3 : 1),
                boxShadow: ui.palette == p.key ? [BoxShadow(color: p.value.$2.withValues(alpha: .24), blurRadius: 13)] : null,
              ),
              child: const Icon(Icons.check, color: Colors.white, size: 26),
            ),
          ),
        )),
    ]);
  }
}
