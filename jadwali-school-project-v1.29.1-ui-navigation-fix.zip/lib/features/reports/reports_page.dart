import 'package:flutter/foundation.dart';

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/ui_helpers.dart';
import '../../core/preview_widgets.dart';
import '../../data/database_service.dart';
import '../../services/file_save_service.dart';
import '../../services/pdf_report_service.dart';
import '../../services/reference_office_service.dart';
import '../../services/reference_timetable_layout.dart';
import '../../services/teacher_workload_service.dart';

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key, this.onChanged});
  final VoidCallback? onChanged;
  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  late Future<Map<String, Object?>> _future;
  final _number = TextEditingController(text: '1');
  final _date = TextEditingController();
  final _manager = TextEditingController();
  String _kind = 'timetable', _scope = 'school', _paper = 'A3';
  int? _sectionId, _teacherId;
  int _currentStep = 1;
  bool _template = true, _busy = false, _showHtmlPreview = false;
  Map<String, Object?>? _swapFirst;
  bool _reportUndoAvailable = false;

  Future<void> _tapReportLesson(
    Map<String, Object?> entry,
    Map<String, Object?> data,
  ) async {
    if (_busy) return;
    if (_swapFirst == null) {
      if (entry['is_locked'] == 1) {
        showMessage(
          context,
          'هذه الحصة مقفلة. افتح قفلها من صفحة الجدول أولاً.',
        );
        return;
      }
      setState(() => _swapFirst = Map.from(entry));
      return;
    }
    if (_swapFirst!['id'] == entry['id']) {
      setState(() => _swapFirst = null);
      return;
    }
    var committed = false;
    setState(() => _busy = true);
    try {
      await DatabaseService.instance.swapLessons(
        yearId: data['yearId'] as int,
        first: _swapFirst!,
        second: Map.from(entry),
      );
      committed = true;
      final updated = await _load();
      if (!mounted) return;
      setState(() {
        _swapFirst = null;
        _reportUndoAvailable = true;
        _future = SynchronousFuture(updated);
      });
      widget.onChanged?.call();
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            content: const Text(
              'تم تبديل الحصتين وتحديث التقرير والجدول النشط.',
            ),
            action: SnackBarAction(label: 'تراجع', onPressed: _undoReportSwap),
          ),
        );
    } catch (error) {
      if (!mounted) return;
      if (committed) {
        setState(() {
          _swapFirst = null;
          _reportUndoAvailable = true;
          _future = _load();
        });
        widget.onChanged?.call();
        showMessage(
          context,
          'تم حفظ التبديل؛ حدّث معاينة التقرير لإظهار التغيير.',
        );
        return;
      }
      setState(() => _busy = false);
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('هذا التبديل غير متاح'),
          content: Text(
            '${error is StateError ? error.message : error}\n\nلم تتغير الحصص. اختر مادة أخرى.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('اختيار حصة أخرى'),
            ),
          ],
        ),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _undoReportSwap() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await DatabaseService.instance.undoLastManualEdit();
      final updated = await _load();
      if (!mounted) return;
      setState(() {
        _swapFirst = null;
        _reportUndoAvailable = false;
        _future = SynchronousFuture(updated);
      });
      widget.onChanged?.call();
      showMessage(context, 'أُعيدت الحصتان في الجدول والتقرير.');
    } catch (error) {
      if (mounted)
        showMessage(
          context,
          'تعذر التراجع: ${error is StateError ? error.message : error}',
          error: true,
        );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _reportSwapControls() => Container(
    key: const ValueKey('report-swap-controls'),
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.primaryContainer
          .withValues(alpha: .35),
      borderRadius: BorderRadius.circular(14),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          _swapFirst == null
              ? 'المس المادة الأولى ثم مادة مختلفة للتبديل'
              : '${_swapFirst!['subject_name']} · ${_swapFirst!['day_name']} · ${_swapFirst!['slot_name']}',
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
        ),
        const SizedBox(height: 4),
        const Text(
          'التبديل داخل الصف والشعبة نفسيهما، ويحدّث الجدول النشط. يمكنك التراجع قبل تصدير التقرير؛ شكل الورقة لا يتغير.',
          style: TextStyle(fontSize: 11),
        ),
        Wrap(
          spacing: 8,
          children: [
            if (_swapFirst != null)
              TextButton(
                onPressed: _busy
                    ? null
                    : () => setState(() => _swapFirst = null),
                child: const Text('إلغاء الاختيار'),
              ),
            if (_reportUndoAvailable)
              TextButton.icon(
                key: const ValueKey('report-undo'),
                onPressed: _busy ? null : _undoReportSwap,
                icon: const Icon(Icons.undo, size: 18),
                label: const Text('تراجع عن التبديل'),
              ),
          ],
        ),
      ],
    ),
  );
  static const _types = {
    'timetable': 'جدول الحصص',
    'workload': 'نصاب المعلمين',
    'requirements': 'الحصص المطلوبة',
  };

  @override
  void initState() {
    super.initState();
    _future = _load();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _manager.text = prefs.getString('report_manager') ?? '';
      _date.text = prefs.getString('report_effective_date') ?? '';
      _number.text = prefs.getString('report_number') ?? '1';
    });
  }

  @override
  void dispose() {
    _number.dispose();
    _date.dispose();
    _manager.dispose();
    super.dispose();
  }

  Future<Map<String, Object?>> _load() async {
    final db = DatabaseService.instance;
    final yearId = await db.activeYearId();
    final id = await db.activeVersionId(yearId);
    final versions = await db.rows('timetable_versions');
    return {
      'yearId': yearId,
      'settings': await db.getSettings(),
      'version':
          versions.where((v) => v['id'] == id).firstOrNull ??
          <String, Object?>{},
      'entries': await db.entriesDetailed(versionId: id),
      'sections': await db.sectionsDetailed(),
      'teachers': await db.rows('teachers', orderBy: 'name'),
      'requirements': await db.requirementsDetailed(),
      'days': await db.rows('school_days', orderBy: 'position'),
      'slots': await db.rows('time_slots', orderBy: 'position'),
    };
  }

  List<Map<String, Object?>> _rows(Map<String, Object?> data, String key) =>
      (data[key] as List).cast<Map<String, Object?>>();
  String _school(Map<String, Object?> data) =>
      '${(data['settings'] as Map)['school_name'] ?? 'مدرستي'}';
  ReferenceTimetableLayout _layout(Map<String, Object?> data) {
    var entries = _rows(data, 'entries');
    var sections = _rows(data, 'sections');
    if (_scope == 'section' && _sectionId != null) {
      sections = sections.where((s) => s['id'] == _sectionId).toList();
      entries = entries.where((e) => e['section_id'] == _sectionId).toList();
    }
    if (_scope == 'teacher' && _teacherId != null) {
      entries = entries.where((e) => e['teacher_id'] == _teacherId).toList();
      final ids = entries.map((e) => e['section_id']).toSet();
      sections = sections.where((s) => ids.contains(s['id'])).toList();
    }
    return ReferenceTimetableLayout(
      entries: entries,
      sections: sections,
      days: _rows(data, 'days'),
      slots: _rows(data, 'slots'),
      templateColumns: _template && _scope == 'school',
    );
  }

  List<List<String>> _listReport(Map<String, Object?> data) {
    if (_kind == 'workload') {
      final load = const TeacherWorkloadService().calculate(
        teachers: _rows(data, 'teachers'),
        entries: _rows(data, 'entries'),
        days: _rows(data, 'days'),
        slots: _rows(data, 'slots'),
      );
      return [
        [
          'المعلم',
          'النصاب',
          'الموزع',
          'المتبقي',
          'الزيادة',
          'أيام التدريس',
          'الفجوات',
        ],
        for (final row in load)
          [
            for (final key in [
              'teacher_name',
              'target_load',
              'assigned_lessons',
              'remaining',
              'overload',
              'days_with_lessons',
              'gaps',
            ])
              '${row[key] ?? ''}',
          ],
      ];
    }
    final entries = _rows(data, 'entries');
    return [
      ['الصف', 'الشعبة', 'المادة', 'المطلوب', 'الموزع', 'المتبقي'],
      for (final req in _rows(data, 'requirements'))
        [
          '${req['grade_name'] ?? ''}',
          '${req['section_name'] ?? ''}',
          '${req['subject_name'] ?? ''}',
          '${req['weekly_lessons']}',
          '${entries.where((e) => e['section_id'] == req['section_id'] && e['subject_id'] == req['subject_id']).length}',
          '${ReferenceTimetableLayout.number(req['weekly_lessons']) - entries.where((e) => e['section_id'] == req['section_id'] && e['subject_id'] == req['subject_id']).length}',
        ],
    ];
  }

  Future<void> _export(
    Map<String, Object?> data,
    String format, {
    bool preview = false,
  }) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      // Capture a single set of options before awaiting preferences or export.
      final layout = _layout(data),
          school = _school(data),
          title = _types[_kind]!;
      final number = _number.text.trim(),
          date = _date.text.trim(),
          manager = _manager.text.trim();
      final timetable = _kind == 'timetable', paper = _paper;
      final rows = timetable
          ? layout.classGroups.expand((g) => layout.rows(g)).toList()
          : _listReport(data);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('report_manager', manager);
      await prefs.setString('report_effective_date', date);
      await prefs.setString('report_number', number);
      final pdf = PdfReportService();
      Uint8List bytes;
      if (format == 'pdf') {
        final size = paper == 'A4'
            ? PdfPageFormat.a4.landscape
            : PdfPageFormat.a3.landscape;
        bytes = timetable
            ? await pdf.buildReferenceTimetablePdf(
                layout: layout,
                schoolName: school,
                reportNumber: number,
                effectiveDate: date,
                managerName: manager,
                pageFormat: size,
              )
            : await pdf.buildListReportPdf(
                title: title,
                schoolName: school,
                rows: rows,
                pageFormat: size,
              );
      } else if (format == 'csv') {
        String quote(String text) => '"${text.replaceAll('"', '""')}"';
        bytes = Uint8List.fromList(
          utf8.encode(
            '\uFEFF${rows.map((r) => r.map(quote).join(',')).join('\r\n')}',
          ),
        );
      } else {
        const office = ReferenceOfficeService();
        bytes = timetable
            ? office.timetable(
                layout: layout,
                schoolName: school,
                word: format == 'docx',
                paper: paper,
                number: number,
                date: date,
                manager: manager,
              )
            : office.list(
                title: title,
                schoolName: school,
                rows: rows,
                word: format == 'docx',
                paper: paper,
              );
      }
      if (preview) {
        await pdf.preview(bytes);
      } else {
        final path = await FileSaveService().saveBytes(
          dialogTitle: 'حفظ $title',
          fileName: '$title-$paper.$format',
          allowedExtensions: [format],
          bytes: bytes,
        );
        if (path != null && mounted)
          showMessage(context, 'تم حفظ التقرير: $path');
      }
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر إنشاء التقرير: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _step(int number, String title, List<Widget> children) => Card(
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 15,
                backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                child: Text(
                  '$number',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                    fontSize: 13,
                  ),
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
          SizedBox(height: 16),
          ...children,
        ],
      ),
    ),
  );

  // On narrow phones the report wizard action must remain available even
  // when ListView has not built its off-screen footer yet.
  Widget _stepNavigation(bool ready) => Row(
    children: [
      if (_currentStep > 1)
        OutlinedButton(
          onPressed: () => setState(() => _currentStep--),
          child: const Text('السابق'),
        ),
      const Spacer(),
      if (_currentStep < 3)
        FilledButton(
          onPressed: ready ? () => setState(() => _currentStep++) : null,
          child: Text(
            _currentStep == 1
                ? 'التالي: المحتوى والورق'
                : 'معاينة التقرير',
          ),
        ),
    ],
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    body: FutureBuilder<Map<String, Object?>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.hasError)
          return emptyState(
            icon: Icons.error_outline,
            title: 'تعذر تحميل التقارير',
            message: '${snapshot.error}',
          );
        if (!snapshot.hasData)
          return Center(child: CircularProgressIndicator());
        final data = snapshot.data!;
        final sections = _rows(data, 'sections'),
            teachers = _rows(data, 'teachers');
        if (!sections.any((s) => s['id'] == _sectionId))
          _sectionId = sections.isEmpty ? null : sections.first['id'] as int;
        if (!teachers.any((s) => s['id'] == _teacherId))
          _teacherId = teachers.isEmpty ? null : teachers.first['id'] as int;
        final version = data['version'] as Map;
        final ready =
            _kind != 'timetable' ||
            (_scope != 'section' || _sectionId != null) &&
                (_scope != 'teacher' || _teacherId != null);
        final compactPhone = MediaQuery.sizeOf(context).width < 360;
        return Stack(
          children: [
            AbsorbPointer(
              absorbing: _busy,
              child: ListView(
                padding: const EdgeInsets.all(16),
                // Build the step and report cells eagerly. The full-sized
                // preview must be findable when a user selects a cell even
                // when it starts below the viewport on a small phone.
                children: [Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                  pageHeading(
                    'تقارير أنيقة، بالشكل المعتمد',
                    'ألوان موحدة لكل يوم على جميع صفوفه وحصصه، مع فواصل واضحة بين الصفوف والأيام.',
                    trailing: IconButton(
                      tooltip: 'تحديث البيانات',
                      onPressed: _busy
                          ? null
                          : () => setState(() {
                              _swapFirst = null;
                              _future = _load();
                            }),
                      icon: const Icon(Icons.refresh),
                    ),
                  ),
                  // Keep the wizard action near the heading so it exists
                  // in the widget tree and remains reachable before the
                  // lengthy HTML-inspired report cards. Small phones use a
                  // safe-area footer below instead.
                  if (!compactPhone)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _stepNavigation(ready),
                    ),
                  Wrap(spacing: 10, runSpacing: 10, children: [
                    OutlinedButton.icon(
                      onPressed: ready && !_busy ? () => _export(data, 'pdf', preview: true) : null,
                      icon: const Icon(Icons.print_outlined),
                      label: const Text('طباعة المعاينة')),
                    FilledButton.icon(
                      onPressed: ready && !_busy ? () => _export(data, 'csv') : null,
                      icon: const Icon(Icons.download_outlined),
                      label: const Text('تصدير CSV الفعلي')),
                  ]),
                  const SizedBox(height: 16),
                  LayoutBuilder(builder: (context, bounds) {
                    final items = const [
                      ('Word', 'التنسيق المعتمد كما هو', Icons.description_outlined, Color(0xff277bc9)),
                      ('PDF', 'معاينة وطباعة واضحة', Icons.picture_as_pdf_outlined, Color(0xffe36b6f)),
                      ('Excel', 'جداول منظمة بالفواصل', Icons.grid_on_outlined, Color(0xff13a78c)),
                    ];
                    final horizontal = bounds.maxWidth >= 780;
                    return Wrap(spacing: 14, runSpacing: 14,
                      children: [for (final item in items)
                        Container(width: horizontal ? (bounds.maxWidth - 28) / 3 : bounds.maxWidth,
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.surface,
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                            boxShadow: const [BoxShadow(color: Color(0x0C24365B),
                              blurRadius: 22, offset: Offset(0, 8))]),
                          child: Row(children: [
                            Container(width: 55, height: 55,
                              decoration: BoxDecoration(color: item.$4.withValues(alpha: .11),
                                borderRadius: BorderRadius.circular(15)),
                              child: Icon(item.$3, color: item.$4, size: 26)),
                            const SizedBox(width: 16),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item.$1, style: const TextStyle(fontSize: 17,
                                  fontWeight: FontWeight.w900)),
                                const SizedBox(height: 5),
                                Text(item.$2, style: TextStyle(fontSize: 11,
                                  color: Theme.of(context).colorScheme.onSurfaceVariant)),
                              ])),
                          ]),
                        )],
                    );
                  }),
                  const SizedBox(height: 14),
                  Material(
                    color: Theme.of(context).colorScheme.surface,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22),
                      side: BorderSide(color: Theme.of(context).colorScheme.outlineVariant)),
                    child: Column(children: [
                      ListTile(
                        key: const ValueKey('html-real-report-preview'),
                        leading: Icon(Icons.table_chart_outlined,
                          color: Theme.of(context).colorScheme.primary),
                        title: const Text('معاينة الجدول المدرسي الحالي',
                          style: TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: const Text('ألوان الأيام والفواصل من التقرير المعتمد — بيانات المدرسة الحقيقية'),
                        trailing: Icon(_showHtmlPreview
                          ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down),
                        onTap: () => setState(() => _showHtmlPreview = !_showHtmlPreview),
                      ),
                      if (_showHtmlPreview) ...[
                        const Divider(height: 1),
                        Padding(padding: const EdgeInsets.all(12),
                          child: ReferenceTimetablePreview(
                            layout: _layout(data),
                            school: _school(data),
                            number: _number.text,
                            date: _date.text,
                            manager: _manager.text,
                          )),
                      ],
                    ]),
                  ),
                  const SizedBox(height: 17),
                  Text('إعداد التقرير الحقيقي · ${version['name'] ?? 'لا توجد نسخة نشطة'}',
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      for (var i = 1; i <= 3; i++)
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.all(4),
                            child: AnimatedContainer(
                              duration: MediaQuery.disableAnimationsOf(context)
                                  ? Duration.zero
                                  : const Duration(milliseconds: 200),
                              height: 4,
                              decoration: BoxDecoration(
                                color: i <= _currentStep
                                    ? Theme.of(context).colorScheme.primary
                                    : previewLine,
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  SizedBox(height: 16),
                  Text(
                    'الخطوة $_currentStep من ٣',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      fontSize: 11,
                    ),
                  ),
                  SizedBox(height: 12),
                  if (_currentStep == 1)
                    _step(1, 'اختر التقرير', [
                      for (final type in _types.entries)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Material(
                            color: _kind == type.key
                                ? Theme.of(context).colorScheme.primary
                                      .withValues(alpha: .08)
                                : Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                              side: BorderSide(
                                color: _kind == type.key
                                    ? Theme.of(context).colorScheme.primary
                                    : previewLine,
                              ),
                            ),
                            child: ListTile(
                              leading: Icon(
                                type.key == 'timetable'
                                    ? Icons.calendar_month_outlined
                                    : type.key == 'workload'
                                    ? Icons.people_outline
                                    : Icons.fact_check_outlined,
                              ),
                              title: Text(
                                type.value,
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              subtitle: Text(
                                type.key == 'timetable'
                                    ? 'الأيام والفترات والصفوف والمعلمون'
                                    : type.key == 'workload'
                                    ? 'النصاب والموزع والحدود اليومية'
                                    : 'المطلوب والموزع وقواعد المواد',
                                style: TextStyle(fontSize: 11),
                              ),
                              onTap: () => setState(() => _kind = type.key),
                            ),
                          ),
                        ),
                    ]),
                  SizedBox(height: 12),
                  if (_currentStep == 2)
                    _step(2, 'حدّد المحتوى والورق', [
                      if (_kind == 'timetable') ...[
                        Wrap(
                          spacing: 8,
                          runSpacing: 6,
                          children: [
                            for (final s in {
                              'school': 'المدرسة كاملة',
                              'section': 'صف وشعبة',
                              'teacher': 'حصص معلم',
                            }.entries)
                              ChoiceChip(
                                label: Text(s.value),
                                selected: _scope == s.key,
                                onSelected: (_) =>
                                    setState(() => _scope = s.key),
                              ),
                          ],
                        ),
                        SizedBox(height: 12),
                        if (_scope == 'section')
                          DropdownButtonFormField<int>(
                            key: ValueKey('report-section-$_sectionId'),
                            initialValue: _sectionId,
                            isExpanded: true,
                            decoration: const InputDecoration(
                              labelText: 'الصف والشعبة',
                            ),
                            items: sections
                                .map(
                                  (s) => DropdownMenuItem(
                                    value: s['id'] as int,
                                    child: Text(
                                      '${displayGradeName(s['grade_name'])} / ${s['section_name']}',
                                    ),
                                  ),
                                )
                                .toList(),
                            onChanged: (id) => setState(() => _sectionId = id),
                          ),
                        if (_scope == 'teacher')
                          DropdownButtonFormField<int>(
                            key: ValueKey('report-teacher-$_teacherId'),
                            initialValue: _teacherId,
                            isExpanded: true,
                            decoration: const InputDecoration(
                              labelText: 'المعلم',
                            ),
                            items: teachers
                                .map(
                                  (t) => DropdownMenuItem(
                                    value: t['id'] as int,
                                    child: Text('${t['name']}'),
                                  ),
                                )
                                .toList(),
                            onChanged: (id) => setState(() => _teacherId = id),
                          ),
                        if (_scope == 'school')
                          SwitchListTile(
                            contentPadding: EdgeInsets.zero,
                            title: Text('القالب المرجعي: ١٢ خانة صف'),
                            subtitle: Text(
                              'يمكن إيقافه لتوسيع الصفوف الموجودة فقط.',
                            ),
                            value: _template,
                            onChanged: (v) => setState(() => _template = v),
                          ),
                        ExpansionTile(
                          tilePadding: EdgeInsets.zero,
                          title: Text('عنوان التقرير والتوقيع'),
                          children: [
                            TextField(
                              controller: _number,
                              decoration: const InputDecoration(
                                labelText: 'رقم الجدول',
                              ),
                              onChanged: (_) => setState(() {}),
                            ),
                            SizedBox(height: 10),
                            TextField(
                              controller: _date,
                              decoration: const InputDecoration(
                                labelText: 'يعمل بموجبه اعتباراً من تاريخ',
                              ),
                              onChanged: (_) => setState(() {}),
                            ),
                            SizedBox(height: 10),
                            TextField(
                              controller: _manager,
                              decoration: const InputDecoration(
                                labelText: 'مدير المدرسة',
                              ),
                              onChanged: (_) => setState(() {}),
                            ),
                            SizedBox(height: 12),
                          ],
                        ),
                      ],
                      Wrap(
                        spacing: 8,
                        children: [
                          for (final paper in ['A3', 'A4'])
                            ChoiceChip(
                              label: Text('$paper أفقي'),
                              selected: _paper == paper,
                              onSelected: (_) => setState(() => _paper = paper),
                            ),
                        ],
                      ),
                    ]),
                  SizedBox(height: 12),
                  if (_currentStep == 3)
                    _step(3, 'عاين واحفظ', [
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          FilledButton.icon(
                            onPressed: ready
                                ? () => _export(data, 'pdf', preview: true)
                                : null,
                            icon: const Icon(Icons.print_outlined),
                            label: Text('معاينة وطباعة'),
                          ),
                          for (final format in {
                            'pdf': 'PDF',
                            'docx': 'Word',
                            'xlsx': 'Excel',
                            'csv': 'CSV',
                          }.entries)
                            OutlinedButton(
                              onPressed: ready
                                  ? () => _export(data, format.key)
                                  : null,
                              child: Text(format.value),
                            ),
                        ],
                      ),
                      SizedBox(height: 14),
                      if (_kind == 'timetable') ...[
                        Text(
                          'لون موحّد لكل يوم عبر جميع الصفوف، وفواصل فارغة بين الصفوف والأيام. تظهر الحصص الإضافية في يومها الفعلي.',
                        ),
                        SizedBox(height: 12),
                        _reportSwapControls(),
                        ReferenceTimetablePreview(
                          onLessonTap: (entry) => _tapReportLesson(entry, data),
                          selectedEntryId: _swapFirst?['id'] as int?,
                          layout: _layout(data),
                          school: _school(data),
                          number: _number.text,
                          date: _date.text,
                          manager: _manager.text,
                        ),
                      ] else
                        _listPreview(_listReport(data)),
                    ]),
                  SizedBox(height: 16),
                  SizedBox(height: compactPhone ? 90 : 24),
                  ],
                )],
              ),
            ),
            if (compactPhone)
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: AbsorbPointer(
                  absorbing: _busy,
                  child: Material(
                    color: Theme.of(context).colorScheme.surface,
                    child: SafeArea(
                      top: false,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                        child: _stepNavigation(ready),
                      ),
                    ),
                  ),
                ),
              ),
            if (_busy)
              const Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: LinearProgressIndicator(),
              ),
          ],
        );
      },
    ),
  );

  Widget _listPreview(List<List<String>> rows) => SingleChildScrollView(
    scrollDirection: Axis.horizontal,
    child: DataTable(
      columns: rows.first.map((s) => DataColumn(label: Text(s))).toList(),
      rows: rows
          .skip(1)
          .map((r) => DataRow(cells: r.map((s) => DataCell(Text(s))).toList()))
          .toList(),
    ),
  );
}

class ReferenceTimetablePreview extends StatelessWidget {
  const ReferenceTimetablePreview({
    required this.layout,
    required this.school,
    required this.number,
    required this.date,
    required this.manager,
    this.onLessonTap,
    this.selectedEntryId,
    super.key,
  });
  final ReferenceTimetableLayout layout;
  final String school, number, date, manager;
  final ValueChanged<Map<String, Object?>>? onLessonTap;
  final int? selectedEntryId;

  Widget _interactiveLesson(
    Map<String, Object?>? section,
    Map<String, Object?> day,
    Map<String, Object?> slot,
    Widget child,
  ) {
    final entries = layout.entriesAt(section, day, slot);
    if (entries.length != 1 || onLessonTap == null) return child;
    final entry = entries.single;
    final selected = selectedEntryId != null && entry['id'] == selectedEntryId;
    return Semantics(
      button: true,
      selected: selected,
      label:
          '${entry['subject_name']}، ${entry['teacher_name']}، ${layout.sectionTitle(section!)}، ${day['name']}، الحصة ${layout.lessonNumber(slot)}',
      child: GestureDetector(
        key: ValueKey(
          'report-lesson-${entry['section_id']}-${entry['day_id']}-${entry['slot_id']}',
        ),
        behavior: HitTestBehavior.opaque,
        onTap: () => onLessonTap!(entry),
        child: Container(
          foregroundDecoration: selected
              ? BoxDecoration(
                  border: Border.all(color: const Color(0xff167f80), width: 2),
                )
              : null,
          child: child,
        ),
      ),
    );
  }

  Widget _cell(
    String text,
    double width,
    double height, {
    bool shade = false,
    Color? fill,
    bool rotate = false,
  }) => Container(
    width: width,
    height: height,
    alignment: Alignment.center,
    decoration: BoxDecoration(
      color: fill ?? (shade ? const Color(0xFFE6E6E6) : Colors.white),
      border: Border.all(color: Colors.black54, width: .5),
    ),
    padding: const EdgeInsets.symmetric(horizontal: 3),
    child: rotate
        ? RotatedBox(
            quarterTurns: 3,
            child: Text(
              text,
              style: TextStyle(color: Colors.black, fontSize: 12),
            ),
          )
        : Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black, fontSize: 11),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
  );
  @override
  Widget build(BuildContext context) => Column(
    children: [
      for (final group in layout.classGroups)
        Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  SizedBox(
                    width: 96 + group.length * 152 + (group.length - 1) * 12,
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            'إدارة مدرسة: $school',
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            'جدول الدروس الاسبوعي رقم ($number)',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            'يعمل بموجبه اعتباراً من تاريخ $date',
                            textAlign: TextAlign.end,
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 14),
                  Row(
                    children: [
                      _cell('الأيام', 60, 64),
                      _cell('الدرس', 36, 64, shade: true),
                      for (var gi = 0; gi < group.length; gi++) ...[
                        if (gi > 0) SizedBox(width: 12),
                        Column(
                          children: [
                            _cell(
                              group[gi] == null
                                  ? ''
                                  : layout.sectionTitle(group[gi]!),
                              152,
                              32,
                            ),
                            Row(
                              children: [
                                _cell('المادة', 76, 32, shade: true),
                                _cell('المعلم', 76, 32, shade: true),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                  for (final day in layout.days) ...[
                    if (day != layout.days.first) SizedBox(height: 12),
                    Row(
                      children: [
                        _cell(
                          '${day['name']}',
                          60,
                          layout.periodsForDay(day, group).length * 36.0,
                          rotate: true,
                          fill: Color(layout.dayColor(day)),
                        ),
                        Column(
                          children: [
                            for (final slot in layout.periodsForDay(day, group))
                              _cell(
                                ReferenceTimetableLayout.arabic(
                                  layout.lessonNumber(slot),
                                ),
                                36,
                                36,
                                fill: Color(layout.dayColor(day)),
                              ),
                          ],
                        ),
                        for (var gi = 0; gi < group.length; gi++) ...[
                          if (gi > 0) SizedBox(width: 12),
                          Column(
                            children: [
                              for (final slot in layout.periodsForDay(
                                day,
                                group,
                              ))
                                _interactiveLesson(
                                  group[gi],
                                  day,
                                  slot,
                                  Row(
                                    children: [
                                      _cell(
                                        layout.cellText(
                                          group[gi],
                                          day,
                                          slot,
                                          teacher: false,
                                        ),
                                        76,
                                        36,
                                        fill: Color(layout.dayColor(day)),
                                      ),
                                      _cell(
                                        layout.cellText(
                                          group[gi],
                                          day,
                                          slot,
                                          teacher: true,
                                        ),
                                        76,
                                        36,
                                        fill: Color(layout.dayColor(day)),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ],
                  SizedBox(height: 12),
                  Text(
                    'مدير المدرسة: $manager',
                    style: TextStyle(color: Colors.black),
                  ),
                ],
              ),
            ),
          ),
        ),
    ],
  );
}
