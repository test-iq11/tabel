import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';

void main() {
  const scheduler = AutoSchedulerService(nodeLimit: 5000);

  test('يوزع حصتين على يومين دون تكرار المادة في اليوم نفسه', () {
    final result = scheduler.generate(
      sections: [{'id': 1, 'section_name': 'أ', 'max_daily_lessons': 6}],
      requirements: [{'section_id': 1, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 2, 'max_daily_lessons': 2, 'allow_same_day': 0}],
      teachers: [{'id': 5, 'name': 'معلم الرياضيات', 'weekly_load': 20, 'max_daily_lessons': 5, 'max_consecutive_lessons': 4}],
      qualifications: [{'teacher_id': 5, 'subject_id': 2}],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}, {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1}],
      slots: [{'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1}],
    );
    expect(result.complete, isTrue);
    expect(result.placements, hasLength(2));
    expect(result.placements.map((e) => e['day_id']).toSet(), hasLength(2));
    expect(result.placements.map((e) => e['teacher_id']).toSet(), equals({5}));
  });


  test('يوزّع المعلم المؤهل تلقائياً على أكثر من شعبة دون تعارض زمني', () {
    final result = scheduler.generate(
      sections: [
        {'id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 6},
        {'id': 2, 'grade_name': 'الثاني', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 2, 'max_daily_lessons': 2, 'allow_same_day': 0},
        {'section_id': 2, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 2, 'max_daily_lessons': 2, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 5, 'name': 'معلم الرياضيات', 'weekly_load': 4, 'max_daily_lessons': 2, 'max_consecutive_lessons': 0},
      ],
      qualifications: [{'teacher_id': 5, 'subject_id': 2}],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'name': 'الثانية', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    expect(result.complete, isTrue);
    expect(result.placements, hasLength(4));
    expect(result.placements.map((e) => e['teacher_id']).toSet(), equals({5}));
    expect(result.placements.map((e) => e['section_id']).toSet(), equals({1, 2}));
    final teacherCells = result.placements.map((e) => '${e['teacher_id']}:${e['day_id']}:${e['slot_id']}').toList();
    expect(teacherCells.toSet().length, teacherCells.length);
  });

  test('لا يدّعي اكتمال الجدول عندما لا يوجد معلم مؤهل', () {
    final result = scheduler.generate(
      sections: [{'id': 1, 'section_name': 'أ'}],
      requirements: [{'section_id': 1, 'subject_id': 2, 'subject_name': 'العلوم', 'weekly_lessons': 1}],
      teachers: [{'id': 5, 'name': 'معلم'}],
      qualifications: [],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}],
      slots: [{'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1}],
    );
    expect(result.complete, isFalse);
    expect(result.placements, isEmpty);
    expect(result.unscheduled, isNotEmpty);
  });
  test('يشرح عند تجاوز متطلبات الشعبة عدد الخانات المتاحة ويولد التوزيع الممكن', () {
    final result = const AutoSchedulerService(nodeLimit: 5000).generate(
      sections: [
        {'id': 1, 'stage_name': 'الابتدائية', 'grade_name': 'الأول الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 1},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 4, 'max_daily_lessons': 1, 'allow_same_day': 0},
        {'section_id': 1, 'subject_id': 3, 'subject_name': 'العلوم', 'weekly_lessons': 4, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 5, 'name': 'معلم مؤهل', 'weekly_load': 10, 'max_daily_lessons': 1, 'max_consecutive_lessons': 0},
        {'id': 6, 'name': 'معلم ثانٍ', 'weekly_load': 10, 'max_daily_lessons': 1, 'max_consecutive_lessons': 0},
      ],
      qualifications: [
        {'teacher_id': 5, 'subject_id': 2},
        {'teacher_id': 6, 'subject_id': 3},
      ],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 2, 'is_active': 1},
        {'id': 4, 'name': 'الأربعاء', 'position': 3, 'is_active': 1},
        {'id': 5, 'name': 'الخميس', 'position': 4, 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    expect(result.placements, hasLength(5));
    expect(result.complete, isFalse);
    expect(result.unscheduled.any((item) => item.contains('الصف الأول الابتدائي') && item.contains('المتاح 5 خانة')), isTrue);
  });
  test('يحترم صفوف المعلم ويعيد استخدام المعلم عبر الصفوف المسموح بها', () {
    final result = scheduler.generate(
      sections: [
        {'id': 1, 'grade_id': 101, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 6},
        {'id': 2, 'grade_id': 102, 'grade_name': 'الثاني', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 1},
        {'section_id': 2, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 1},
      ],
      teachers: [
        {'id': 5, 'name': 'معلم الصف الأول', 'weekly_load': 5, 'max_daily_lessons': 5, 'max_consecutive_lessons': 0},
        {'id': 6, 'name': 'معلم الصف الثاني', 'weekly_load': 5, 'max_daily_lessons': 5, 'max_consecutive_lessons': 0},
      ],
      qualifications: [{'teacher_id': 5, 'subject_id': 2}, {'teacher_id': 6, 'subject_id': 2}],
      teacherGrades: [{'teacher_id': 5, 'grade_id': 101}, {'teacher_id': 6, 'grade_id': 102}],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'name': 'الثانية', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    expect(result.complete, isTrue);
    expect(result.placements.where((e) => e['section_id'] == 1).single['teacher_id'], 5);
    expect(result.placements.where((e) => e['section_id'] == 2).single['teacher_id'], 6);
  });


  test('يحدد الصفوف المسموحة لكل مادة بشكل مستقل للمعلم نفسه', () {
    final result = scheduler.generate(
      sections: [
        {'id': 1, 'grade_id': 101, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 6},
        {'id': 2, 'grade_id': 102, 'grade_name': 'الثاني', 'section_name': 'أ', 'max_daily_lessons': 6},
        {'id': 3, 'grade_id': 103, 'grade_name': 'الثالث', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'الإنكليزية', 'weekly_lessons': 1},
        {'section_id': 2, 'subject_id': 2, 'subject_name': 'الإنكليزية', 'weekly_lessons': 1},
        {'section_id': 3, 'subject_id': 2, 'subject_name': 'الإنكليزية', 'weekly_lessons': 1},
      ],
      teachers: [{'id': 5, 'name': 'جليل', 'weekly_load': 5, 'max_daily_lessons': 5, 'max_consecutive_lessons': 0}],
      qualifications: [{'teacher_id': 5, 'subject_id': 2}],
      teacherSubjectGrades: [
        {'teacher_id': 5, 'subject_id': 2, 'grade_id': 101},
        {'teacher_id': 5, 'subject_id': 2, 'grade_id': 102},
      ],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'name': 'الثانية', 'position': 1, 'kind': 'lesson', 'is_available': 1},
        {'id': 3, 'name': 'الثالثة', 'position': 2, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(result.placements, hasLength(2));
    expect(result.placements.map((p) => p['section_id']).toSet(), equals({1, 2}));
    expect(result.unscheduled, isNotEmpty);
  });

  test('لا يضع مادة في فترة حظرها المستخدم', () {
    final result = scheduler.generate(
      sections: [{'id': 1, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 5}],
      requirements: [{'section_id': 1, 'subject_id': 2, 'subject_name': 'الأخلاقية', 'weekly_lessons': 1}],
      teachers: [{'id': 7, 'name': 'معلم المادة', 'weekly_load': 5, 'max_daily_lessons': 5}],
      qualifications: [{'teacher_id': 7, 'subject_id': 2}],
      subjectBlockedSlots: [{'subject_id': 2, 'slot_id': 2}],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'name': 'الثانية', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(result.complete, isTrue);
    expect(result.placements.single['slot_id'], 1);
  });

}
