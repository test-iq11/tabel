import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/conflict_detection_service.dart';

void main() {
  const service = ConflictDetectionService();

  test('يكتشف تعارض المعلم في اليوم والفترة نفسيهما', () {
    final issues = service.scan(
      entries: [
        {'id': 1, 'section_id': 1, 'subject_id': 10, 'teacher_id': 7, 'day_id': 1, 'slot_id': 1, 'section_name': 'أ', 'teacher_name': 'أحمد'},
        {'id': 2, 'section_id': 2, 'subject_id': 11, 'teacher_id': 7, 'day_id': 1, 'slot_id': 1, 'section_name': 'ب', 'teacher_name': 'أحمد'},
      ],
      qualifications: [
        {'teacher_id': 7, 'subject_id': 10},
        {'teacher_id': 7, 'subject_id': 11},
      ],
    );
    expect(issues.any((issue) => issue.type == 'تعارض المعلم' && issue.severity == 'خطأ مانع'), isTrue);
  });


  test('يكشف تعارضات ما قبل الحفظ حتى عندما لا تحمل الحصص معرفات قاعدة البيانات', () {
    final issues = service.scan(
      entries: [
        {'section_id': 1, 'subject_id': 10, 'teacher_id': 7, 'day_id': 1, 'slot_id': 1},
        {'section_id': 2, 'subject_id': 11, 'teacher_id': 7, 'day_id': 1, 'slot_id': 1},
        {'section_id': 1, 'subject_id': 12, 'teacher_id': 8, 'day_id': 1, 'slot_id': 1},
      ],
      qualifications: [
        {'teacher_id': 7, 'subject_id': 10},
        {'teacher_id': 7, 'subject_id': 11},
        {'teacher_id': 8, 'subject_id': 12},
      ],
    );
    expect(issues.any((i) => i.type == 'تعارض المعلم' && i.teacherId == 7 && i.severity == 'خطأ مانع'), isTrue);
    expect(issues.any((i) => i.type == 'تعارض الشعبة' && i.sectionId == 1 && i.severity == 'خطأ مانع'), isTrue);
  });

  test('يعطي تحذيراً عند وجود حصة بلا معلم', () {
    final issues = service.scan(entries: [
      {'id': 1, 'section_id': 1, 'subject_id': 10, 'teacher_id': null, 'day_id': 1, 'slot_id': 1, 'subject_name': 'الرياضيات'},
    ]);
    expect(issues.any((issue) => issue.type == 'حصة بلا معلم' && issue.severity == 'تحذير'), isTrue);
  });

  test('يكتشف أن الفترة ليست فترة تدريس', () {
    final issues = service.scan(
      entries: [{'id': 1, 'section_id': 1, 'subject_id': 10, 'teacher_id': null, 'day_id': 1, 'slot_id': 4}],
      slots: [{'id': 4, 'name': 'الاستراحة', 'kind': 'break', 'is_available': 0}],
    );
    expect(issues.any((issue) => issue.type == 'فترة غير متاحة' && issue.severity == 'خطأ مانع'), isTrue);
  });

  test('يوضح الصف والشعبة وعدد الحصص، ولا يحذر عن مادة لم تسجل كمتطلب', () {
    final issues = service.scan(
      entries: const [],
      requirements: [
        {'section_id': 1, 'subject_id': 20, 'subject_name': 'الأخلاقية', 'stage_name': 'الابتدائية', 'grade_name': 'الأول الابتدائي', 'section_name': 'أ', 'weekly_lessons': 2},
        {'section_id': 2, 'subject_id': 20, 'subject_name': 'الأخلاقية', 'stage_name': 'الابتدائية', 'grade_name': 'الثاني الابتدائي', 'section_name': 'ب', 'weekly_lessons': 2},
      ],
    );
    final missing = issues.where((issue) => issue.type == 'نقص الحصص').toList();
    expect(missing, hasLength(2));
    expect(missing.every((issue) => issue.message.contains('المطلوب 2') && issue.message.contains('الموزع 0') && issue.message.contains('الشعبة')), isTrue);
    expect(missing.any((issue) => issue.message.contains('الثالث الابتدائي')), isFalse);
    expect(missing.first.suggestion, contains('البيانات > الحصص المطلوبة'));
  });

  test('ينبه بوضوح إذا تجاوز مجموع الحصص المطلوبة سعة الشعبة الأسبوعية', () {
    final issues = service.scan(
      entries: const [],
      requirements: [
        {'section_id': 7, 'subject_id': 1, 'subject_name': 'العربية', 'stage_name': 'الابتدائية', 'grade_name': 'الرابع الابتدائي', 'section_name': 'ب', 'section_max_daily_lessons': 1, 'weekly_lessons': 3},
        {'section_id': 7, 'subject_id': 2, 'subject_name': 'الرياضيات', 'stage_name': 'الابتدائية', 'grade_name': 'الرابع الابتدائي', 'section_name': 'ب', 'section_max_daily_lessons': 1, 'weekly_lessons': 2},
      ],
      days: [
        {'id': 1, 'name': 'الأحد', 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الأولى', 'kind': 'lesson', 'is_available': 1},
      ],
    );
    final issue = issues.firstWhere((item) => item.type == 'الحصص المطلوبة تتجاوز سعة الشعبة');
    expect(issue.message, contains('الصف الرابع الابتدائي'));
    expect(issue.message, contains('الشعبة ب'));
    expect(issue.message, contains('5 حصة أسبوعياً'));
    expect(issue.message, contains('2 خانة فقط'));
  });

  test('لا يصدر نقص حصص لمتطلب عدده صفر ولا توجد له حصص موزعة', () {
    final issues = service.scan(
      entries: const [],
      requirements: [
        {'section_id': 3, 'subject_id': 20, 'subject_name': 'الأخلاقية', 'grade_name': 'الثالث الابتدائي', 'section_name': 'أ', 'weekly_lessons': 0},
      ],
    );
    expect(issues.where((issue) => issue.type == 'نقص الحصص'), isEmpty);
  });

  test('يكشف إسناد المعلم إلى صف لم يُسمح له بتدريسه', () {
    final issues = service.scan(
      entries: [{'id': 1, 'section_id': 3, 'grade_id': 22, 'subject_id': 5, 'teacher_id': 8, 'day_id': 1, 'slot_id': 1, 'grade_name': 'الثالث', 'section_name': 'أ', 'teacher_name': 'سالم'}],
      qualifications: [{'teacher_id': 8, 'subject_id': 5}],
      teacherGrades: [{'teacher_id': 8, 'grade_id': 11}],
    );
    expect(issues.any((i) => i.type == 'الصف غير مسموح للمعلم' && i.severity == 'خطأ مانع'), isTrue);
  });

  test('يوضح اسم المادة عند منع المعلم من تدريس صف معين', () {
    final issues = service.scan(
      entries: [
        {'id': 1, 'section_id': 3, 'grade_id': 22, 'subject_id': 5, 'teacher_id': 8,
         'day_id': 1, 'slot_id': 1, 'grade_name': 'الثالث', 'section_name': 'أ',
         'teacher_name': 'سالم', 'subject_name': 'الرياضيات'},
      ],
      qualifications: [{'teacher_id': 8, 'subject_id': 5}],
      teacherSubjectGrades: [{'teacher_id': 8, 'subject_id': 5, 'grade_id': 11}],
    );
    final issue = issues.firstWhere((i) => i.type == 'الصف غير مسموح للمعلم');
    expect(issue.message, contains('الرياضيات'));
    expect(issue.message, contains('الثالث'));
    expect(issue.suggestion, contains('هذه المادة تحديداً'));
  });

  test('يقبل الصف المحدد لنفس المادة في إعدادات المعلم', () {
    final issues = service.scan(
      entries: [
        {'id': 1, 'section_id': 3, 'grade_id': 22, 'subject_id': 5, 'teacher_id': 8,
         'day_id': 1, 'slot_id': 1, 'grade_name': 'الرابع', 'section_name': 'أ',
         'teacher_name': 'سالم', 'subject_name': 'الرياضيات'},
      ],
      qualifications: [{'teacher_id': 8, 'subject_id': 5}],
      teacherSubjectGrades: [{'teacher_id': 8, 'subject_id': 5, 'grade_id': 22}],
    );
    expect(issues.any((i) => i.type == 'الصف غير مسموح للمعلم'), isFalse);
  });


  test('يعتمد صف الشعبة الحالي ولا يخلط معه الصف المخزن قديماً في الحصة', () {
    final issues = service.scan(
      entries: [
        {
          'id': 21, 'section_id': 3,
          // صف الشعبة الحالي هو الأول، بينما نسخة الصف القديمة داخل سجل الحصة تقول الرابع.
          'grade_id': 1, 'section_grade_id': 1, 'stored_grade_id': 4,
          'grade_name': 'الأول الابتدائي', 'section_grade_name': 'الأول الابتدائي',
          'stored_grade_name': 'الرابع الابتدائي', 'section_name': 'أ',
          'subject_id': 5, 'subject_name': 'اللغة العربية', 'teacher_id': 8,
          'teacher_name': 'طالب', 'day_id': 1, 'day_name': 'الأحد',
          'slot_id': 1, 'slot_name': 'الأولى',
        },
      ],
      qualifications: [{'teacher_id': 8, 'subject_id': 5}],
      teacherSubjectGrades: [{'teacher_id': 8, 'subject_id': 5, 'grade_id': 1}],
    );

    expect(issues.any((i) => i.type == 'الصف غير مسموح للمعلم'), isFalse);
    final mismatch = issues.firstWhere((i) => i.type == 'عدم تطابق صف الحصة المحفوظ');
    expect(mismatch.severity, 'تحذير');
    expect(mismatch.message, contains('الأول الابتدائي'));
    expect(mismatch.message, contains('الرابع الابتدائي'));
  });

  test('يذكر اليوم والفترة في مخالفة صلاحية المادة والصف', () {
    final issues = service.scan(
      entries: [
        {
          'id': 22, 'section_id': 9, 'grade_id': 4, 'section_grade_id': 4,
          'grade_name': 'الرابع الابتدائي', 'section_grade_name': 'الرابع الابتدائي',
          'section_name': 'أ', 'subject_id': 5, 'subject_name': 'اللغة العربية',
          'teacher_id': 8, 'teacher_name': 'طالب', 'day_id': 1,
          'day_name': 'الأحد', 'slot_id': 1, 'slot_name': 'الأولى',
        },
      ],
      qualifications: [{'teacher_id': 8, 'subject_id': 5}],
      teacherSubjectGrades: [{'teacher_id': 8, 'subject_id': 5, 'grade_id': 1}],
    );
    final issue = issues.firstWhere((i) => i.type == 'الصف غير مسموح للمعلم');
    expect(issue.message, contains('الأحد'));
    expect(issue.message, contains('الأولى'));
  });

  test('يكشف وضع مادة في فترة حظرها المستخدم', () {
    final issues = service.scan(
      entries: [{'id': 1, 'section_id': 3, 'grade_id': 22, 'subject_id': 5, 'teacher_id': null, 'day_id': 1, 'slot_id': 6, 'section_name': 'أ', 'subject_name': 'الأخلاقية'}],
      slots: [{'id': 6, 'name': 'الحصة السادسة', 'kind': 'lesson', 'is_available': 1}],
      subjectBlockedSlots: [{'subject_id': 5, 'slot_id': 6}],
    );
    expect(issues.any((i) => i.type == 'المادة في فترة ممنوعة' && i.severity == 'خطأ مانع'), isTrue);
  });


  test('يمنع اعتماد الحصة إذا تعذر تحديد الصف الفعلي للشعبة', () {
    final issues = service.scan(
      entries: [
        {
          'id': 1, 'section_id': 99, 'section_grade_id': 0, 'grade_id': 0,
          'subject_id': 2, 'teacher_id': 4, 'day_id': 1, 'slot_id': 1,
          'section_name': 'أ', 'subject_name': 'اللغة العربية', 'teacher_name': 'طالب',
        },
      ],
      qualifications: const [{'teacher_id': 4, 'subject_id': 2}],
      teacherSubjectGrades: const [{'teacher_id': 4, 'subject_id': 2, 'grade_id': 1}],
    );
    expect(issues.any((i) => i.type == 'تعذر تحديد صف الشعبة' && i.severity == 'خطأ مانع'), isTrue);
  });


  test('يمنع إسناد المعلم للمادة نفسها في صف غير مصرح به ضمن بيانات مختلفة للصف المحفوظ', () {
    final issues = service.scan(
      entries: [
        {
          'id': 1,
          'section_id': 9,
          'grade_id': 4,
          'section_grade_id': 4,
          'subject_id': 2,
          'teacher_id': 4,
          'day_id': 1,
          'slot_id': 1,
          'section_name': 'أ',
          'teacher_name': 'طالب',
          'subject_name': 'اللغة العربية',
          'section_grade_name': 'الرابع الابتدائي',
        },
      ],
      qualifications: [
        {'teacher_id': 4, 'subject_id': 2},
      ],
      teacherSubjectGrades: [
        {'teacher_id': 4, 'subject_id': 2, 'grade_id': 1},
      ],
      enforceQualifications: true,
    );
    final issue = issues.firstWhere((i) => i.type == 'الصف غير مسموح للمعلم');
    expect(issue.severity, 'خطأ مانع');
    expect(issue.message, contains('طالب'));
    expect(issue.message, contains('اللغة العربية'));
    expect(issue.message, contains('الرابع الابتدائي'));
  });

}
