import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/conflict_detection_service.dart';

void main() {
  const service = ConflictDetectionService();

  test('يكتشف تعارض المعلم في اليوم والفترة نفسيهما', () {
    final issues = service.scan(
      entries: [
        {'id': 1, 'section_id': 1, 'subject_id': 10, 'teacher_id': 7, 'day_id': 1, 'slot_id': 1, 'section_name': 'أ', 'teacher_name': 'أحمد'},
        {'id': 2, 'section_id': 2, 'subject_id': 11, 'teacher_id': 7, 'day_id': 1, 'slot_id': 1, 'section_name': 'ب', 'teacher_name': 'أحمد'},
      ],
      qualifications: [
        {'teacher_id': 7, 'subject_id': 10},
        {'teacher_id': 7, 'subject_id': 11},
      ],
    );
    expect(issues.any((issue) => issue.type == 'تعارض المعلم' && issue.severity == 'خطأ مانع'), isTrue);
  });

  test('يعطي تحذيراً عند وجود حصة بلا معلم', () {
    final issues = service.scan(entries: [
      {'id': 1, 'section_id': 1, 'subject_id': 10, 'teacher_id': null, 'day_id': 1, 'slot_id': 1, 'subject_name': 'الرياضيات'},
    ]);
    expect(issues.any((issue) => issue.type == 'حصة بلا معلم' && issue.severity == 'تحذير'), isTrue);
  });

  test('يكتشف أن الفترة ليست فترة تدريس', () {
    final issues = service.scan(
      entries: [{'id': 1, 'section_id': 1, 'subject_id': 10, 'teacher_id': null, 'day_id': 1, 'slot_id': 4}],
      slots: [{'id': 4, 'name': 'الاستراحة', 'kind': 'break', 'is_available': 0}],
    );
    expect(issues.any((issue) => issue.type == 'فترة غير متاحة' && issue.severity == 'خطأ مانع'), isTrue);
  });

  test('يوضح الصف والشعبة وعدد الحصص، ولا يحذر عن مادة لم تسجل كمتطلب', () {
    final issues = service.scan(
      entries: const [],
      requirements: [
        {'section_id': 1, 'subject_id': 20, 'subject_name': 'الأخلاقية', 'stage_name': 'الابتدائية', 'grade_name': 'الأول الابتدائي', 'section_name': 'أ', 'weekly_lessons': 2},
        {'section_id': 2, 'subject_id': 20, 'subject_name': 'الأخلاقية', 'stage_name': 'الابتدائية', 'grade_name': 'الثاني الابتدائي', 'section_name': 'ب', 'weekly_lessons': 2},
      ],
    );
    final missing = issues.where((issue) => issue.type == 'نقص الحصص').toList();
    expect(missing, hasLength(2));
    expect(missing.every((issue) => issue.message.contains('المطلوب 2') && issue.message.contains('الموزع 0') && issue.message.contains('الشعبة')), isTrue);
    expect(missing.any((issue) => issue.message.contains('الثالث الابتدائي')), isFalse);
    expect(missing.first.suggestion, contains('البيانات > الحصص المطلوبة'));
  });

  test('ينبه بوضوح إذا تجاوز مجموع الحصص المطلوبة سعة الشعبة الأسبوعية', () {
    final issues = service.scan(
      entries: const [],
      requirements: [
        {'section_id': 7, 'subject_id': 1, 'subject_name': 'العربية', 'stage_name': 'الابتدائية', 'grade_name': 'الرابع الابتدائي', 'section_name': 'ب', 'section_max_daily_lessons': 1, 'weekly_lessons': 3},
        {'section_id': 7, 'subject_id': 2, 'subject_name': 'الرياضيات', 'stage_name': 'الابتدائية', 'grade_name': 'الرابع الابتدائي', 'section_name': 'ب', 'section_max_daily_lessons': 1, 'weekly_lessons': 2},
      ],
      days: [
        {'id': 1, 'name': 'الأحد', 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الأولى', 'kind': 'lesson', 'is_available': 1},
      ],
    );
    final issue = issues.firstWhere((item) => item.type == 'الحصص المطلوبة تتجاوز سعة الشعبة');
    expect(issue.message, contains('الصف الرابع الابتدائي'));
    expect(issue.message, contains('الشعبة ب'));
    expect(issue.message, contains('5 حصة أسبوعياً'));
    expect(issue.message, contains('2 خانة فقط'));
  });

  test('لا يصدر نقص حصص لمتطلب عدده صفر ولا توجد له حصص موزعة', () {
    final issues = service.scan(
      entries: const [],
      requirements: [
        {'section_id': 3, 'subject_id': 20, 'subject_name': 'الأخلاقية', 'grade_name': 'الثالث الابتدائي', 'section_name': 'أ', 'weekly_lessons': 0},
      ],
    );
    expect(issues.where((issue) => issue.type == 'نقص الحصص'), isEmpty);
  });

  test('يكشف إسناد المعلم إلى صف لم يُسمح له بتدريسه', () {
    final issues = service.scan(
      entries: [{'id': 1, 'section_id': 3, 'grade_id': 22, 'subject_id': 5, 'teacher_id': 8, 'day_id': 1, 'slot_id': 1, 'grade_name': 'الثالث', 'section_name': 'أ', 'teacher_name': 'سالم'}],
      qualifications: [{'teacher_id': 8, 'subject_id': 5}],
      teacherGrades: [{'teacher_id': 8, 'grade_id': 11}],
    );
    expect(issues.any((i) => i.type == 'الصف غير مسموح للمعلم' && i.severity == 'خطأ مانع'), isTrue);
  });

  test('يوضح اسم المادة عند منع المعلم من تدريس صف معين', () {
    final issues = service.scan(
      entries: [
        {'id': 1, 'section_id': 3, 'grade_id': 22, 'subject_id': 5, 'teacher_id': 8,
         'day_id': 1, 'slot_id': 1, 'grade_name': 'الثالث', 'section_name': 'أ',
         'teacher_name': 'سالم', 'subject_name': 'الرياضيات'},
      ],
      qualifications: [{'teacher_id': 8, 'subject_id': 5}],
      teacherSubjectGrades: [{'teacher_id': 8, 'subject_id': 5, 'grade_id': 11}],
    );
    final issue = issues.firstWhere((i) => i.type == 'الصف غير مسموح للمعلم');
    expect(issue.message, contains('الرياضيات'));
    expect(issue.message, contains('الثالث'));
    expect(issue.suggestion, contains('هذه المادة تحديداً'));
  });

  test('يقبل الصف المحدد لنفس المادة في إعدادات المعلم', () {
    final issues = service.scan(
      entries: [
        {'id': 1, 'section_id': 3, 'grade_id': 22, 'subject_id': 5, 'teacher_id': 8,
         'day_id': 1, 'slot_id': 1, 'grade_name': 'الرابع', 'section_name': 'أ',
         'teacher_name': 'سالم', 'subject_name': 'الرياضيات'},
      ],
      qualifications: [{'teacher_id': 8, 'subject_id': 5}],
      teacherSubjectGrades: [{'teacher_id': 8, 'subject_id': 5, 'grade_id': 22}],
    );
    expect(issues.any((i) => i.type == 'الصف غير مسموح للمعلم'), isFalse);
  });

  test('يكشف وضع مادة في فترة حظرها المستخدم', () {
    final issues = service.scan(
      entries: [{'id': 1, 'section_id': 3, 'grade_id': 22, 'subject_id': 5, 'teacher_id': null, 'day_id': 1, 'slot_id': 6, 'section_name': 'أ', 'subject_name': 'الأخلاقية'}],
      slots: [{'id': 6, 'name': 'الحصة السادسة', 'kind': 'lesson', 'is_available': 1}],
      subjectBlockedSlots: [{'subject_id': 5, 'slot_id': 6}],
    );
    expect(issues.any((i) => i.type == 'المادة في فترة ممنوعة' && i.severity == 'خطأ مانع'), isTrue);
  });

}
