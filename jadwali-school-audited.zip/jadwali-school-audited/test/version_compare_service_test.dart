import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/version_compare_service.dart';

Map<String, Object?> entry({
  required int section,
  required int day,
  required int slot,
  required int subject,
  int? teacher,
  String? subjectName,
  String? teacherName,
}) =>
    {
      'section_id': section,
      'day_id': day,
      'slot_id': slot,
      'subject_id': subject,
      'teacher_id': teacher,
      'subject_name': subjectName ?? 'مادة $subject',
      'teacher_name': teacherName ?? (teacher == null ? '' : 'معلم $teacher'),
      'section_name': 'أ',
      'grade_name': 'الأول الابتدائي',
      'day_name': 'يوم$day',
      'slot_name': 'الحصة $slot',
    };

void main() {
  const service = VersionCompareService();

  test('نسختان متطابقتان لا تنتجان فروقاً', () {
    final a = [entry(section: 1, day: 1, slot: 1, subject: 5, teacher: 2)];
    final result = service.compare(before: a, after: a.map(Map<String, Object?>.from).toList());
    expect(result.isEmpty, isTrue);
    expect(result.summary, 'النسختان متطابقتان.');
  });

  test('يكتشف الحصة المضافة والمحذوفة بأسماء مقروءة', () {
    final result = service.compare(
      before: [entry(section: 1, day: 1, slot: 1, subject: 5, teacher: 2, subjectName: 'الرياضيات', teacherName: 'سارة')],
      after: [entry(section: 1, day: 2, slot: 3, subject: 6, teacher: 3, subjectName: 'العلوم', teacherName: 'علي')],
    );
    expect(result.added, 1);
    expect(result.removed, 1);
    expect(result.moved, 0);
    final addedText = result.changes.firstWhere((c) => c.kind == 'مضافة').description;
    expect(addedText, contains('العلوم'));
    expect(addedText, contains('علي'));
    expect(addedText, contains('الأول الابتدائي / أ'));
    expect(addedText, isNot(contains(':')));
  });

  test('الحصة نفسها في موضع مختلف تُعد منقولة لا حذفاً وإضافة', () {
    final result = service.compare(
      before: [entry(section: 1, day: 1, slot: 1, subject: 5, teacher: 2, subjectName: 'الرياضيات')],
      after: [entry(section: 1, day: 3, slot: 2, subject: 5, teacher: 2, subjectName: 'الرياضيات')],
    );
    expect(result.moved, 1);
    expect(result.added, 0);
    expect(result.removed, 0);
    expect(result.changes.single.description, contains('نُقلت'));
  });

  test('تغيير المعلم في الخانة نفسها يُعد تعديلاً', () {
    final result = service.compare(
      before: [entry(section: 1, day: 1, slot: 1, subject: 5, teacher: 2, teacherName: 'سارة')],
      after: [entry(section: 1, day: 1, slot: 1, subject: 5, teacher: 3, teacherName: 'علي')],
    );
    expect(result.changed, 1);
    final text = result.changes.single.description;
    expect(text, contains('سارة'));
    expect(text, contains('علي'));
  });

  test('الملخص يعد كل نوع', () {
    final result = service.compare(
      before: [
        entry(section: 1, day: 1, slot: 1, subject: 5, teacher: 2),
        entry(section: 1, day: 1, slot: 2, subject: 6, teacher: 2),
      ],
      after: [
        entry(section: 1, day: 1, slot: 1, subject: 5, teacher: 9),
        entry(section: 1, day: 2, slot: 4, subject: 7, teacher: 4),
      ],
    );
    expect(result.summary, 'مضافة 1 • محذوفة 1 • منقولة 0 • معدلة 1');
  });
}
