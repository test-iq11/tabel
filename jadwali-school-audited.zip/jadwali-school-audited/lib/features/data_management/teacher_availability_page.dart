import 'package:flutter/material.dart';

import '../../core/ui_helpers.dart';
import '../../data/database_service.dart';

/// يحدد الفترات التي لا يستطيع المعلم التدريس فيها.
///
/// القاعدة المخزنة في `teacher_availability`: وجود صف بقيمة `is_available = 0`
/// يعني أن الفترة ممنوعة للمعلم، وغياب الصف يعني أنها متاحة. المحرك الآلي وفاحص
/// التعارضات يقرآن هذه البيانات نفسها.
class TeacherAvailabilityPage extends StatefulWidget {
  const TeacherAvailabilityPage({required this.teacher, super.key});

  final Map<String, Object?> teacher;

  @override
  State<TeacherAvailabilityPage> createState() => _TeacherAvailabilityPageState();
}

class _TeacherAvailabilityPageState extends State<TeacherAvailabilityPage> {
  List<Map<String, Object?>> _days = const [];
  List<Map<String, Object?>> _slots = const [];
  final Set<String> _blocked = <String>{};
  bool _loaded = false;
  bool _saving = false;
  bool _dirty = false;
  String? _error;

  int get _teacherId => _asInt(widget.teacher['id']);

  static int _asInt(Object? value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? 0;
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final db = DatabaseService.instance;
      final days = (await db.rows('school_days', orderBy: 'position'))
          .where((d) => _asInt(d['is_active']) == 1)
          .toList();
      final slots = (await db.rows('time_slots', orderBy: 'position'))
          .where((s) => s['kind'] == 'lesson' && (s['is_available'] == null || _asInt(s['is_available']) == 1))
          .toList();
      final rows = await db.rows('teacher_availability');
      final blocked = <String>{};
      for (final row in rows) {
        if (_asInt(row['teacher_id']) != _teacherId) continue;
        if (row['is_available'] != null && _asInt(row['is_available']) == 0) {
          blocked.add('${_asInt(row['day_id'])}:${_asInt(row['slot_id'])}');
        }
      }
      if (!mounted) return;
      setState(() {
        _days = days;
        _slots = slots;
        _blocked
          ..clear()
          ..addAll(blocked);
        _loaded = true;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = '$e';
        _loaded = true;
      });
    }
  }

  String _key(Map<String, Object?> day, Map<String, Object?> slot) =>
      '${_asInt(day['id'])}:${_asInt(slot['id'])}';

  void _toggle(String key, bool blocked) {
    setState(() {
      if (blocked) {
        _blocked.add(key);
      } else {
        _blocked.remove(key);
      }
      _dirty = true;
    });
  }

  void _setDay(Map<String, Object?> day, bool blocked) {
    setState(() {
      for (final slot in _slots) {
        final key = _key(day, slot);
        if (blocked) {
          _blocked.add(key);
        } else {
          _blocked.remove(key);
        }
      }
      _dirty = true;
    });
  }

  Future<void> _save() async {
    final db = DatabaseService.instance;
    setState(() => _saving = true);
    try {
      // تنبيه المستخدم إذا كانت لديه حصص محفوظة في فترات سيمنعها الآن.
      final yearId = await db.activeYearId();
      final versionId = await db.activeVersionId(yearId);
      var affected = 0;
      if (versionId != null) {
        final entries = await db.entriesDetailed(versionId: versionId);
        for (final entry in entries) {
          if (_asInt(entry['teacher_id']) != _teacherId) continue;
          if (_blocked.contains('${_asInt(entry['day_id'])}:${_asInt(entry['slot_id'])}')) affected++;
        }
      }
      if (affected > 0 && mounted) {
        final proceed = await confirmAction(
          context,
          'حصص حالية في فترات ممنوعة',
          'لدى المعلم $affected حصة محفوظة في فترات اخترتَ منعها. لن تُحذف، لكنها ستظهر كأخطاء مانعة في فحص التعارضات حتى تنقلها. هل تريد المتابعة؟',
        );
        if (!proceed) {
          if (mounted) setState(() => _saving = false);
          return;
        }
      }
      final database = await db.database;
      await database.transaction((txn) async {
        await txn.delete('teacher_availability', where: 'teacher_id=?', whereArgs: [_teacherId]);
        for (final key in _blocked) {
          final parts = key.split(':');
          if (parts.length != 2) continue;
          await txn.insert('teacher_availability', {
            'teacher_id': _teacherId,
            'day_id': int.parse(parts[0]),
            'slot_id': int.parse(parts[1]),
            'is_available': 0,
          });
        }
      });
      await db.log('تعديل', 'teacher_availability', _teacherId, 'فترات ممنوعة: ${_blocked.length}');
      if (!mounted) return;
      setState(() {
        _dirty = false;
        _saving = false;
      });
      showMessage(context, 'تم حفظ إتاحة المعلم (${_blocked.length} فترة ممنوعة).');
      Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        showMessage(context, 'تعذر حفظ إتاحة المعلم: $e', error: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final name = '${widget.teacher['name'] ?? ''}';
    return PopScope(
      canPop: !_dirty,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        final leave = await confirmAction(context, 'تعديلات غير محفوظة', 'لديك تعديلات لم تُحفظ. هل تريد الخروج وتجاهلها؟');
        if (leave && context.mounted) Navigator.pop(context);
      },
      child: Scaffold(
        appBar: AppBar(title: Text('إتاحة المعلم: $name')),
        body: !_loaded
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? emptyState(icon: Icons.error_outline, title: 'تعذر تحميل البيانات', message: _error!)
                : (_days.isEmpty || _slots.isEmpty)
                    ? emptyState(
                        icon: Icons.schedule_outlined,
                        title: 'لا توجد فترات دراسية',
                        message: 'فعّل أيام الدوام وأضف فترات من نوع حصة في «المدرسة والأوقات» أولاً.',
                      )
                    : ListView(
                        padding: const EdgeInsets.fromLTRB(16, 16, 16, 110),
                        children: [
                          pageHeading(
                            'الفترات التي لا يستطيع التدريس فيها',
                            'اضغط على الفترة لمنعها (تظهر باللون الأحمر). الفترات غير المحددة تبقى متاحة. المحرك الآلي وفحص التعارضات يحترمان هذه الفترات.',
                          ),
                          for (final day in _days)
                            Card(
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(children: [
                                      Expanded(
                                        child: Text('${day['name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: Color(0xFF183B66))),
                                      ),
                                      TextButton(onPressed: () => _setDay(day, true), child: const Text('منع اليوم')),
                                      TextButton(onPressed: () => _setDay(day, false), child: const Text('إتاحة اليوم')),
                                    ]),
                                    Wrap(
                                      spacing: 8,
                                      runSpacing: 4,
                                      children: [
                                        for (final slot in _slots)
                                          FilterChip(
                                            label: Text('${slot['name']}'),
                                            selected: _blocked.contains(_key(day, slot)),
                                            selectedColor: const Color(0xFFFFCDD2),
                                            checkmarkColor: const Color(0xFFC62828),
                                            onSelected: (value) => _toggle(_key(day, slot), value),
                                          ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          const SizedBox(height: 8),
                          Text('عدد الفترات الممنوعة: ${_blocked.length}', style: const TextStyle(color: Colors.black54)),
                        ],
                      ),
        floatingActionButton: _loaded && _error == null && _days.isNotEmpty && _slots.isNotEmpty
            ? FloatingActionButton.extended(
                onPressed: (_saving || !_dirty) ? null : _save,
                icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_outlined),
                label: Text(_dirty ? 'حفظ الإتاحة' : 'لا تغييرات'),
              )
            : null,
      ),
    );
  }
}
