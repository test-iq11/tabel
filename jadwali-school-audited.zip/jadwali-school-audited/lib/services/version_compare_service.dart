/// نوع التغيير بين نسختين من الجدول.
class VersionChange {
  const VersionChange({required this.kind, required this.description, this.sectionName = ''});

  /// مضافة | محذوفة | منقولة | معدلة
  final String kind;
  final String description;
  final String sectionName;
}

class VersionComparison {
  const VersionComparison(this.changes);

  final List<VersionChange> changes;

  int count(String kind) => changes.where((c) => c.kind == kind).length;
  int get added => count('مضافة');
  int get removed => count('محذوفة');
  int get moved => count('منقولة');
  int get changed => count('معدلة');
  bool get isEmpty => changes.isEmpty;

  String get summary => isEmpty
      ? 'النسختان متطابقتان.'
      : 'مضافة $added • محذوفة $removed • منقولة $moved • معدلة $changed';
}

/// مقارنة نظيفة بين نسختين: تعرض ما تغيّر عند الانتقال من [before] إلى [after]
/// بأسماء الشعب والأيام والفترات والمواد والمعلمين بدلاً من المعرّفات الداخلية.
class VersionCompareService {
  const VersionCompareService();

  VersionComparison compare({
    required List<Map<String, Object?>> before,
    required List<Map<String, Object?>> after,
  }) {
    final beforeByCell = {for (final e in before) _cell(e): e};
    final afterByCell = {for (final e in after) _cell(e): e};
    final removed = <Map<String, Object?>>[];
    final added = <Map<String, Object?>>[];
    final changes = <VersionChange>[];

    for (final item in beforeByCell.entries) {
      final other = afterByCell[item.key];
      if (other == null) {
        removed.add(item.value);
      } else if (_differs(item.value, other)) {
        changes.add(VersionChange(
          kind: 'معدلة',
          sectionName: _section(item.value),
          description:
              'الشعبة ${_section(item.value)}، ${_when(item.value)}: كانت ${_what(item.value)} وأصبحت ${_what(other)}.',
        ));
      }
    }
    for (final item in afterByCell.entries) {
      if (!beforeByCell.containsKey(item.key)) added.add(item.value);
    }

    // حصة محذوفة وأخرى مضافة بالشعبة والمادة والمعلم نفسها تعني نقل الحصة.
    final unmatchedAdded = List<Map<String, Object?>>.from(added);
    final stillRemoved = <Map<String, Object?>>[];
    for (final r in removed) {
      final index = unmatchedAdded.indexWhere((a) =>
          _text(a['section_id']) == _text(r['section_id']) &&
          _text(a['subject_id']) == _text(r['subject_id']) &&
          _text(a['teacher_id']) == _text(r['teacher_id']));
      if (index >= 0) {
        final target = unmatchedAdded.removeAt(index);
        changes.add(VersionChange(
          kind: 'منقولة',
          sectionName: _section(r),
          description:
              '${_subject(r)} للشعبة ${_section(r)} نُقلت من ${_when(r)} إلى ${_when(target)}.',
        ));
      } else {
        stillRemoved.add(r);
      }
    }
    for (final r in stillRemoved) {
      changes.add(VersionChange(
        kind: 'محذوفة',
        sectionName: _section(r),
        description: 'حُذفت ${_what(r)} من الشعبة ${_section(r)}، ${_when(r)}.',
      ));
    }
    for (final a in unmatchedAdded) {
      changes.add(VersionChange(
        kind: 'مضافة',
        sectionName: _section(a),
        description: 'أُضيفت ${_what(a)} إلى الشعبة ${_section(a)}، ${_when(a)}.',
      ));
    }
    return VersionComparison(changes);
  }

  String _text(Object? value) => value == null ? '' : '$value';

  String _cell(Map<String, Object?> e) => '${_text(e['section_id'])}:${_text(e['day_id'])}:${_text(e['slot_id'])}';

  bool _differs(Map<String, Object?> a, Map<String, Object?> b) =>
      _text(a['subject_id']) != _text(b['subject_id']) ||
      _text(a['teacher_id']) != _text(b['teacher_id']) ||
      _text(a['room_id']) != _text(b['room_id']);

  String _section(Map<String, Object?> e) {
    final grade = _text(e['grade_name']).trim();
    final section = _text(e['section_name']).trim();
    final label = [if (grade.isNotEmpty) grade, if (section.isNotEmpty) section].join(' / ');
    return label.isEmpty ? 'رقم ${_text(e['section_id'])}' : label;
  }

  String _subject(Map<String, Object?> e) {
    final name = _text(e['subject_name']).trim();
    return name.isEmpty ? 'مادة ${_text(e['subject_id'])}' : name;
  }

  String _what(Map<String, Object?> e) {
    final teacher = _text(e['teacher_name']).trim();
    return teacher.isEmpty ? 'حصة ${_subject(e)}' : 'حصة ${_subject(e)} ($teacher)';
  }

  String _when(Map<String, Object?> e) {
    final day = _text(e['day_name']).trim();
    final slot = _text(e['slot_name']).trim();
    final parts = [
      if (day.isNotEmpty) 'يوم $day',
      if (slot.isNotEmpty) slot,
    ];
    return parts.isEmpty ? 'الفترة ${_text(e['slot_id'])}' : parts.join(' - ');
  }
}
