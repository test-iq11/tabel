import 'teacher_assignment_policy.dart';

/// خدمة مستقلة لفحص الجدول؛ لا تعتمد على واجهات Flutter أو قاعدة البيانات مباشرة.
class ConflictIssue {
  const ConflictIssue({
    required this.type,
    required this.severity,
    required this.message,
    this.sectionId,
    this.teacherId,
    this.dayId,
    this.slotId,
    this.subjectId,
    this.suggestion,
  });

  final String type;
  final String severity; // خطأ مانع | تحذير | ملاحظة
  final String message;
  final int? sectionId;
  final int? teacherId;
  final int? dayId;
  final int? slotId;
  final int? subjectId;
  final String? suggestion;
}

class ConflictDetectionService {
  const ConflictDetectionService();

  List<ConflictIssue> scan({
    required List<Map<String, Object?>> entries,
    List<Map<String, Object?>> requirements = const [],
    List<Map<String, Object?>> slots = const [],
    List<Map<String, Object?>> teachers = const [],
    List<Map<String, Object?>> qualifications = const [],
    List<Map<String, Object?>> days = const [],
    List<Map<String, Object?>> teacherGrades = const [],
    List<Map<String, Object?>> teacherSubjectGrades = const [],
    List<Map<String, Object?>> subjectBlockedSlots = const [],
    List<Map<String, Object?>> teacherAvailability = const [],
    bool enforceQualifications = true,
  }) {
    final issues = <ConflictIssue>[];
    final sectionCells = <String, Map<String, Object?>>{};
    final teacherCells = <String, Map<String, Object?>>{};
    final roomCells = <String, Map<String, Object?>>{};
    final slotById = {for (final s in slots) _int(s['id']): s};
    final teacherById = {for (final t in teachers) _int(t['id']): t};
    final assignmentPolicy = TeacherAssignmentPolicy(
      qualifications: qualifications,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
    );
    // Generated placements have no database IDs until they are saved. Treat
    // a missing ID as a distinct row when checking collisions; comparing
    // _int(null) == _int(null) would otherwise hide duplicates in pre-save scans.
    bool isDifferentEntry(Map<String, Object?> previous, Map<String, Object?> current) {
      final previousId = _nullableInt(previous['id']);
      final currentId = _nullableInt(current['id']);
      return previousId == null || currentId == null || previousId != currentId;
    }
    final blockedSubjectSlots = <String>{
      for (final row in subjectBlockedSlots) '${_int(row['subject_id'])}:${_int(row['slot_id'])}',
    };
    int entrySectionGradeId(Map<String, Object?> entry) => _int(
      entry['section_grade_id'],
      fallback: _int(entry['grade_id']),
    );
    final gradeBySection = <int, int>{};
    for (final req in requirements) {
      final gradeId = _int(req['grade_id']);
      if (gradeId > 0) gradeBySection[_int(req['section_id'])] = gradeId;
    }
    for (final entry in entries) {
      // عند تعارض قيمة محفوظة قديمة مع قيمة صف الشعبة، نعتمد صف الشعبة.
      final gradeId = entrySectionGradeId(entry);
      if (gradeId > 0) gradeBySection[_int(entry['section_id'])] = gradeId;
    }
    final inactiveDays = <int>{for (final d in days) if (_int(d['is_active'], fallback: 1) == 0) _int(d['id'])};
    // صف بقيمة is_available = 0 يعني أن المعلم لا يستطيع التدريس في هذه الفترة.
    final unavailableTeacherCells = <String>{
      for (final row in teacherAvailability)
        if (_int(row['is_available'], fallback: 1) == 0)
          '${_int(row['teacher_id'])}:${_int(row['day_id'])}:${_int(row['slot_id'])}',
    };

    // تداخل الأوقات نفسها خطأ في إعداد الفترات حتى قبل توزيع الحصص.
    for (var i = 0; i < slots.length; i++) {
      final a = slots[i];
      final aStart = _minutes(a['start_time']);
      final aEnd = _minutes(a['end_time']);
      if (aStart == null || aEnd == null || aEnd <= aStart) continue;
      for (var j = i + 1; j < slots.length; j++) {
        final b = slots[j];
        final bStart = _minutes(b['start_time']);
        final bEnd = _minutes(b['end_time']);
        if (bStart == null || bEnd == null || bEnd <= bStart) continue;
        if (aStart < bEnd && bStart < aEnd) {
          issues.add(ConflictIssue(
            type: 'تداخل أوقات الفترات', severity: 'خطأ مانع',
            message: 'الفترتان ${a['name'] ?? a['id']} و${b['name'] ?? b['id']} متداخلتان زمنياً.',
            slotId: _int(b['id']), suggestion: 'عدّل بداية أو نهاية إحدى الفترتين حتى لا تتداخلا.',
          ));
        }
      }
    }

    for (final entry in entries) {
      final sectionId = _int(entry['section_id']);
      final teacherId = _nullableInt(entry['teacher_id']);
      final subjectId = _int(entry['subject_id']);
      final dayId = _int(entry['day_id']);
      final slotId = _int(entry['slot_id']);
      final roomId = _nullableInt(entry['room_id']);
      final sectionGradeId = entrySectionGradeId(entry);
      final storedGradeId = _int(entry['stored_grade_id']);
      final key = '$dayId:$slotId';
      if (storedGradeId > 0 && sectionGradeId > 0 && storedGradeId != sectionGradeId) {
        final actualGradeName = entry['section_grade_name'] ?? entry['grade_name'] ?? 'رقم $sectionGradeId';
        final storedGradeName = entry['stored_grade_name'] ?? 'رقم $storedGradeId';
        issues.add(ConflictIssue(
          type: 'عدم تطابق صف الحصة المحفوظ', severity: 'تحذير',
          message: 'الحصة في ${entry['section_name'] ?? 'الشعبة $sectionId'} تابعة حالياً للصف $actualGradeName، لكن سجل الحصة القديم يحمل الصف $storedGradeName.',
          sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId, subjectId: subjectId,
          suggestion: 'فُحصت صلاحية المعلم وفق صف الشعبة الحالي. افتح هذه الخانة من الجدول وأعد حفظها لتحديث بيانات الصف القديمة؛ وإذا لم تكن هذه الحصة مقصودة لهذه الشعبة، صحح إسنادها.',
        ));
      }
      if (inactiveDays.contains(dayId)) {
        issues.add(ConflictIssue(
          type: 'يوم غير مفعل', severity: 'خطأ مانع',
          message: 'توجد حصة في يوم تم تعطيله من إعدادات المدرسة.',
          sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId, subjectId: subjectId,
          suggestion: 'انقل الحصة إلى يوم دوام فعّال أو أعد تفعيل اليوم.',
        ));
      }
      final sectionKey = '$sectionId:$key';
      final previousSection = sectionCells[sectionKey];
      if (previousSection != null && isDifferentEntry(previousSection, entry)) {
        issues.add(ConflictIssue(
          type: 'تعارض الشعبة', severity: 'خطأ مانع',
          message: 'الشعبة ${entry['section_name'] ?? sectionId} لديها أكثر من حصة في الفترة نفسها.',
          sectionId: sectionId, dayId: dayId, slotId: slotId,
          suggestion: 'انقل إحدى الحصتين إلى فترة فارغة.',
        ));
      } else {
        sectionCells[sectionKey] = entry;
      }

      if (teacherId != null) {
        final teacherKey = '$teacherId:$key';
        final previousTeacher = teacherCells[teacherKey];
        if (previousTeacher != null && isDifferentEntry(previousTeacher, entry)) {
          issues.add(ConflictIssue(
            type: 'تعارض المعلم', severity: 'خطأ مانع',
            message: 'المعلم ${entry['teacher_name'] ?? teacherId} مكلّف بأكثر من حصة في الوقت نفسه.',
            sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId,
            subjectId: subjectId, suggestion: 'اختر معلماً مؤهلاً آخر أو انقل إحدى الحصتين.',
          ));
        } else {
          teacherCells[teacherKey] = entry;
        }
        if (unavailableTeacherCells.contains('$teacherId:$dayId:$slotId')) {
          final dayName = (entry['day_name'] ?? '').toString().trim();
          final slotName = (entry['slot_name'] ?? '').toString().trim();
          final when = [if (dayName.isNotEmpty) 'يوم $dayName', if (slotName.isNotEmpty) 'الفترة $slotName'].join('، ');
          issues.add(ConflictIssue(
            type: 'المعلم غير متاح', severity: 'خطأ مانع',
            message: 'المعلم ${entry['teacher_name'] ?? teacherId} غير متاح للتدريس${when.isEmpty ? '' : ' في $when'}.',
            sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId, subjectId: subjectId,
            suggestion: 'انقل الحصة إلى فترة يكون فيها المعلم متاحاً، أو عدّل فترات المنع من «البيانات > المعلمون > الفترات الممنوعة».',
          ));
        }
        if (enforceQualifications && !assignmentPolicy.isSubjectQualified(teacherId, subjectId)) {
          issues.add(ConflictIssue(
            type: 'تأهيل المعلم', severity: 'خطأ مانع',
            message: 'المعلم ${entry['teacher_name'] ?? teacherId} غير مسجل ضمن مؤهلي مادة ${entry['subject_name'] ?? subjectId}.',
            sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId,
            subjectId: subjectId, suggestion: 'أضف تأهيل المعلم لهذه المادة أو اختر معلماً مؤهلاً.',
          ));
        }
        final gradeId = sectionGradeId > 0 ? sectionGradeId : (gradeBySection[sectionId] ?? 0);
        if (enforceQualifications && gradeId <= 0) {
          final dayName = (entry['day_name'] ?? '').toString().trim();
          final slotName = (entry['slot_name'] ?? '').toString().trim();
          final when = [if (dayName.isNotEmpty) 'يوم $dayName', if (slotName.isNotEmpty) 'الفترة $slotName'].join('، ');
          issues.add(ConflictIssue(
            type: 'تعذر تحديد صف الشعبة', severity: 'خطأ مانع',
            message: 'لا يمكن التحقق من صلاحية ${entry['teacher_name'] ?? 'المعلم $teacherId'} لمادة ${entry['subject_name'] ?? subjectId} لأن صف الشعبة غير محدد${when.isEmpty ? '' : '، $when'}.',
            sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId,
            subjectId: subjectId,
            suggestion: 'تحقق من ربط الشعبة بصف صحيح في إدارة البيانات، ثم أعد فحص الجدول.',
          ));
        } else if (enforceQualifications && !assignmentPolicy.isGradeAllowed(teacherId, subjectId, gradeId)) {
          final matchingRequirements = requirements.where((r) => _int(r['section_id']) == sectionId).toList();
          final req = matchingRequirements.isEmpty ? null : matchingRequirements.first;
          final gradeName = entry['section_grade_name'] ?? entry['grade_name'] ?? req?['grade_name'] ?? 'رقم $gradeId';
          final dayName = (entry['day_name'] ?? '').toString().trim();
          final slotName = (entry['slot_name'] ?? '').toString().trim();
          final when = [if (dayName.isNotEmpty) 'يوم $dayName', if (slotName.isNotEmpty) 'الفترة $slotName'].join('، ');
          issues.add(ConflictIssue(
            type: 'الصف غير مسموح للمعلم', severity: 'خطأ مانع',
            message: 'المعلم ${entry['teacher_name'] ?? teacherId} غير مسموح له بتدريس مادة ${entry['subject_name'] ?? subjectId} في الصف $gradeName، ضمن الشعبة ${entry['section_name'] ?? sectionId}${when.isEmpty ? '' : '، $when'}.',
            sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId,
            subjectId: subjectId,
            suggestion: 'تحقق من صلاحية هذه المادة تحديداً لهذا الصف من «البيانات > المعلمون». إذا كان المعلم لا يدرّس هذه الحصة، غيّر المعلم المسند إليها من صفحة الجدول.',
          ));
        }
      } else {
        issues.add(ConflictIssue(
          type: 'حصة بلا معلم', severity: 'تحذير',
          message: 'حصة ${entry['subject_name'] ?? subjectId} في ${entry['section_name'] ?? sectionId} غير مسندة إلى معلم.',
          sectionId: sectionId, dayId: dayId, slotId: slotId, subjectId: subjectId,
          suggestion: 'أسند الحصة إلى معلم مؤهل قبل اعتماد الجدول.',
        ));
      }

      if (roomId != null) {
        final roomKey = '$roomId:$key';
        final priorRoom = roomCells[roomKey];
        if (priorRoom != null && isDifferentEntry(priorRoom, entry)) {
          issues.add(ConflictIssue(
            type: 'تعارض القاعة', severity: 'خطأ مانع',
            message: 'القاعة ${entry['room_name'] ?? roomId} مستخدمة في حصتين متزامنتين.',
            sectionId: sectionId, dayId: dayId, slotId: slotId,
            suggestion: 'اختر قاعة أخرى أو انقل إحدى الحصتين.',
          ));
        } else {
          roomCells[roomKey] = entry;
        }
      }

      final slot = slotById[slotId];
      if (slot != null && (slot['kind'] != 'lesson' || _int(slot['is_available']) == 0)) {
        issues.add(ConflictIssue(
          type: 'فترة غير متاحة', severity: 'خطأ مانع',
          message: 'الحصة مدرجة في ${slot['name'] ?? 'فترة غير متاحة'} وليست فترة تدريس متاحة.',
          sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId,
          subjectId: subjectId, suggestion: 'انقل الحصة إلى فترة دراسية متاحة.',
        ));
      }
      if (blockedSubjectSlots.contains('$subjectId:$slotId')) {
        final sectionLabel = entry['section_name'] ?? 'الشعبة $sectionId';
        issues.add(ConflictIssue(
          type: 'المادة في فترة ممنوعة', severity: 'خطأ مانع',
          message: 'مادة ${entry['subject_name'] ?? subjectId} في ${slot?['name'] ?? 'الفترة $slotId'} غير مسموحة للشعبة $sectionLabel.',
          sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId, subjectId: subjectId,
          suggestion: 'انقل المادة إلى فترة أخرى أو عدّل الفترات الممنوعة للمادة من «البيانات > المواد».',
        ));
      }
    }

    // مقارنة الحصص الفعلية مع الحصص المطلوبة لكل شعبة ومادة.
    final actual = <String, int>{};
    for (final entry in entries) {
      final key = '${_int(entry['section_id'])}:${_int(entry['subject_id'])}';
      actual[key] = (actual[key] ?? 0) + 1;
    }
    for (final req in requirements) {
      final sectionId = _int(req['section_id']);
      final subjectId = _int(req['subject_id']);
      final required = _int(req['weekly_lessons']).clamp(0, 1000).toInt();
      final placed = actual['$sectionId:$subjectId'] ?? 0;
      // عدم وجود متطلب أو تسجيل صفر حصص يعني أن المادة غير مطلوبة لهذه الشعبة؛
      // لا نعرض تحذيراً عن مادة لم يسجل المستخدم أنها تُدرّس في هذا الصف.
      if (required == 0 && placed == 0) continue;
      final stage = (req['stage_name'] ?? '').toString().trim();
      final grade = (req['grade_name'] ?? '').toString().trim();
      final section = (req['section_name'] ?? 'الشعبة $sectionId').toString().trim();
      final location = [
        if (stage.isNotEmpty) 'المرحلة $stage',
        if (grade.isNotEmpty) 'الصف $grade',
        'الشعبة $section',
      ].join('، ');
      final subject = (req['subject_name'] ?? 'المادة $subjectId').toString();
      final label = '$location، مادة $subject';
      if (placed < required) {
        final subjectTeacherIds = qualifications.where((q) => _int(q['subject_id']) == subjectId)
            .map((q) => _int(q['teacher_id'])).toSet();
        final reqGradeId = _int(req['grade_id']);
        final teachersAllowedForGrade = subjectTeacherIds.where((teacherId) =>
          reqGradeId > 0 && assignmentPolicy.isSubjectQualified(teacherId, subjectId) &&
            assignmentPolicy.isGradeAllowed(teacherId, subjectId, reqGradeId)).toList();
        final activeLessonSlots = slots.where((slot) => slot['kind'] == 'lesson' && _int(slot['is_available'], fallback: 1) == 1).toList();
        final blockedCount = activeLessonSlots.where((slot) => blockedSubjectSlots.contains('$subjectId:${_int(slot['id'])}')).length;
        final String causeSuggestion;
        if (subjectTeacherIds.isEmpty) {
          causeSuggestion = 'لا يوجد معلم مسجّل لاختصاص مادة $subject. إذا كانت المادة مطلوبة لهذه الشعبة، افتح «البيانات > المعلمون» وأضفها إلى اختصاص معلم، وتأكد من تحديد الصف لهذه المادة. وإذا لم تكن المادة مقررة لهذا الصف، افتح «البيانات > الحصص المطلوبة» وتأكد من عدم وجود متطلب لها. هذا يوضح سبب بقاء الحصص المطلوبة دون توزيع.';
        } else if (teachersAllowedForGrade.isEmpty) {
          causeSuggestion = 'يوجد معلمون مؤهلون لمادة $subject، لكن لا يوجد بينهم معلم مسموح له بتدريس الصف $grade في هذه الشعبة. افتح «البيانات > المعلمون» وحدد هذا الصف لدى معلم مناسب أو فعّل «جميع الصفوف».';
        } else if (activeLessonSlots.isNotEmpty && blockedCount >= activeLessonSlots.length) {
          causeSuggestion = 'مادة $subject ممنوعة في جميع فترات التدريس المتاحة. افتح «البيانات > المواد» واسمح بفترة تدريس واحدة على الأقل.';
        } else {
          causeSuggestion = 'المادة مسجلة كمطلوبة لهذه الشعبة، لكن لم تُوزّع جميع حصصها. أكمل ${required - placed} حصة متبقية، ثم أعد فحص الجدول.';
        }
        final suggestion = '$causeSuggestion إذا كانت مادة $subject غير مقررة فعلاً في $location، فصحّح المتطلب من «البيانات > الحصص المطلوبة» واحذف المتطلب لهذه الشعبة أو اجعل العدد 0. أما إذا كانت مقررة، فأبقِ المتطلب وأصلح السبب المذكور أعلاه. المواد التي لا يوجد لها متطلب مسجل أو التي سجّل عددها 0 لا تُعد نقصاً.';
        issues.add(ConflictIssue(
          type: 'نقص الحصص', severity: 'تحذير',
          message: '$label: المطلوب $required حصة أسبوعياً، الموزع $placed، المتبقي ${required - placed}.',
          sectionId: sectionId, subjectId: subjectId,
          suggestion: suggestion,
        ));
      } else if (placed > required) {
        issues.add(ConflictIssue(
          type: 'حصص زائدة', severity: 'تحذير',
          message: '$label: المطلوب $required حصة أسبوعياً، الموزع $placed، الزائد ${placed - required}.',
          sectionId: sectionId, subjectId: subjectId,
          suggestion: 'احذف أو أعد إسناد ${placed - required} حصة زائدة، أو صحّح العدد المطلوب إذا كان المنهج يتطلب ذلك.',
        ));
      }
    }

    // اكتشاف تجاوز مجموع الحصص المطلوبة سعة الجدول الأسبوعي للشعبة.
    // يعتمد فقط على المتطلبات المسجلة لهذه الشعبة؛ لا يفترض مواداً منهجية غير مدخلة.
    final requestedBySection = <int, int>{};
    final sectionRequirementSample = <int, Map<String, Object?>>{};
    for (final req in requirements) {
      final sectionId = _int(req['section_id']);
      requestedBySection[sectionId] = (requestedBySection[sectionId] ?? 0) +
          _int(req['weekly_lessons']).clamp(0, 1000).toInt();
      sectionRequirementSample.putIfAbsent(sectionId, () => req);
    }
    final activeDayCount = days.where((d) => _int(d['is_active'], fallback: 1) == 1).length;
    final lessonSlotCount = slots.where((s) =>
        s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1).length;
    if (activeDayCount > 0 && lessonSlotCount > 0) {
      for (final item in requestedBySection.entries) {
        final sample = sectionRequirementSample[item.key]!;
        final configuredDailyLimit = _int(sample['section_max_daily_lessons'], fallback: lessonSlotCount);
        final effectiveDailyLimit = configuredDailyLimit > 0
            ? (configuredDailyLimit < lessonSlotCount ? configuredDailyLimit : lessonSlotCount)
            : lessonSlotCount;
        final capacity = activeDayCount * effectiveDailyLimit;
        if (item.value <= capacity) continue;
        final stage = (sample['stage_name'] ?? '').toString().trim();
        final grade = (sample['grade_name'] ?? '').toString().trim();
        final section = (sample['section_name'] ?? 'الشعبة ${item.key}').toString().trim();
        final location = [if (stage.isNotEmpty) 'المرحلة $stage', if (grade.isNotEmpty) 'الصف $grade', 'الشعبة $section'].join('، ');
        issues.add(ConflictIssue(
          type: 'الحصص المطلوبة تتجاوز سعة الشعبة', severity: 'تحذير',
          message: '$location: مجموع المواد المسجلة ${item.value} حصة أسبوعياً، بينما سعة الدوام $capacity خانة فقط ($activeDayCount أيام × $effectiveDailyLimit حصص يومياً).',
          sectionId: item.key,
          suggestion: 'راجع مجموع المواد في «البيانات > الحصص المطلوبة». إذا كانت الأعداد صحيحة، أضف فترات تدريس يومية أو عدّل حد الحصص اليومي؛ لا يمكن ملء جدول كامل ما دام المطلوب أكبر من السعة.',
        ));
      }
    }

    // حدود النصاب الأسبوعي للمعلمين.
    final weeklyCounts = <int, int>{};
    final dailyCounts = <String, int>{};
    final teacherDaySlots = <String, List<int>>{};
    final subjectDailyCounts = <String, int>{};
    final requirementByKey = <String, Map<String, Object?>>{
      for (final r in requirements) '${_int(r['section_id'])}:${_int(r['subject_id'])}': r,
    };
    for (final entry in entries) {
      final teacherId = _nullableInt(entry['teacher_id']);
      if (teacherId == null) continue;
      final key = '$teacherId:${_int(entry['day_id'])}';
      dailyCounts[key] = (dailyCounts[key] ?? 0) + 1;
      weeklyCounts[teacherId] = (weeklyCounts[teacherId] ?? 0) + 1;
      final pos = slotById[_int(entry['slot_id'])]?['position'];
      if (pos is int) (teacherDaySlots[key] ??= <int>[]).add(pos);
    }
    for (final item in weeklyCounts.entries) {
      final teacher = teacherById[item.key];
      final limit = teacher == null ? 0 : _int(teacher['weekly_load']);
      if (limit > 0 && item.value > limit) {
        issues.add(ConflictIssue(
          type: 'تجاوز النصاب الأسبوعي', severity: 'تحذير',
          message: 'المعلم ${teacher?['name'] ?? item.key} لديه ${item.value} حصة، متجاوزاً النصاب المسجل ${limit}.',
          teacherId: item.key, suggestion: 'أعد توزيع بعض الحصص أو عدّل النصاب إذا كانت سياسة المدرسة تسمح.',
        ));
      }
    }
    for (final entry in entries) {
      final key = '${_int(entry['section_id'])}:${_int(entry['subject_id'])}:${_int(entry['day_id'])}';
      subjectDailyCounts[key] = (subjectDailyCounts[key] ?? 0) + 1;
    }
    for (final item in subjectDailyCounts.entries) {
      final parts = item.key.split(':').map(int.parse).toList();
      final req = requirementByKey['${parts[0]}:${parts[1]}'];
      if (req == null) continue;
      final maxDaily = _int(req['max_daily_lessons'], fallback: 2);
      final repeatAllowed = _int(req['allow_same_day']) == 1;
      final limit = repeatAllowed ? (maxDaily <= 0 ? 1 : maxDaily) : 1;
      if (item.value > limit) {
        issues.add(ConflictIssue(
          type: 'تكرار المادة يومياً', severity: 'تحذير',
          message: 'تكررت ${req['subject_name'] ?? 'المادة ${parts[1]}'} في الشعبة ${req['section_name'] ?? parts[0]} ${item.value} مرات في اليوم نفسه (الحد $limit).',
          sectionId: parts[0], subjectId: parts[1], dayId: parts[2],
          suggestion: 'وزّع حصص المادة على أيام مختلفة أو راجع حد التكرار اليومي.',
        ));
      }
    }
    for (final item in teacherDaySlots.entries) {
      final parts = item.key.split(':');
      final teacherId = int.parse(parts[0]);
      final dayId = int.parse(parts[1]);
      final teacher = teacherById[teacherId];
      final maxConsecutive = teacher == null ? 0 : _int(teacher['max_consecutive_lessons']);
      if (maxConsecutive > 0) {
        final positions = [...item.value]..sort();
        var run = positions.isEmpty ? 0 : 1;
        var longest = run;
        for (var i = 1; i < positions.length; i++) {
          run = positions[i] == positions[i - 1] + 1 ? run + 1 : 1;
          if (run > longest) longest = run;
        }
        if (longest > maxConsecutive) {
          issues.add(ConflictIssue(
            type: 'حصص متتالية زائدة', severity: 'تحذير',
            message: 'لدى المعلم ${teacher?['name'] ?? teacherId} ${longest} حصص متتالية في اليوم رقم $dayId، والحد $maxConsecutive.',
            teacherId: teacherId, dayId: dayId, suggestion: 'أدخل فترة فاصلة أو أعد توزيع حصة على يوم آخر.',
          ));
        }
      }
    }
    for (final item in dailyCounts.entries) {
      final parts = item.key.split(':');
      final teacherId = int.parse(parts[0]);
      final dayId = int.parse(parts[1]);
      final teacher = teacherById[teacherId];
      final limit = teacher == null ? 0 : _int(teacher['max_daily_lessons']);
      if (limit > 0 && item.value > limit) {
        issues.add(ConflictIssue(
          type: 'تجاوز الحد اليومي', severity: 'تحذير',
          message: 'تجاوز المعلم ${teacher?['name'] ?? teacherId} الحد اليومي في اليوم رقم $dayId (${item.value} من $limit).',
          teacherId: teacherId, dayId: dayId,
          suggestion: 'انقل بعض حصص المعلم إلى يوم آخر.',
        ));
      }
    }
    return issues;
  }

  static int? _minutes(Object? value) {
    if (value is! String) return null;
    final parts = value.split(':');
    if (parts.length != 2) return null;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null || hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
    return hour * 60 + minute;
  }
  static int _int(Object? value, {int fallback = 0}) => value is int ? value : int.tryParse('$value') ?? fallback;
  static int? _nullableInt(Object? value) => value == null ? null : _int(value);
}
