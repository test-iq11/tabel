import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf_text_shaper/pdf_text_shaper.dart';
import 'package:printing/printing.dart';

import 'conflict_detection_service.dart';

/// يصدّر شبكة الجدول الأسبوعي لجميع الشعب إلى PDF أفقي قابل للطباعة.
class PdfReportService {
  Future<ShapedFont> _arabicFont() async {
    final data = await rootBundle.load('assets/fonts/Arabic-Regular.ttf');
    return ShapedFont.fromBytes(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      name: 'Noto Naskh Arabic',
    );
  }

  pw.Widget _text(
    String value, {
    required ShapedFont font,
    double size = 10,
    PdfColor color = PdfColors.black,
    ShapedTextAlign align = ShapedTextAlign.center,
  }) {
    // The bundled font has a limited glyph map. Normalize punctuation first,
    // then remove any code point unsupported by that exact font so text entered
    // by users cannot make PDF generation fail at runtime.
    final normalized = value
        .replaceAll(RegExp(r'[\u002D\u2010-\u2015\u2212]'), ' إلى ')
        .replaceAll('/', ' أو ')
        .replaceAll('|', '،')
        .replaceAll('•', '،')
        .replaceAll('·', '،')
        .replaceAll(RegExp(r'[()\[\]{}]'), ' ')
        .replaceAll('_', ' ')
        .replaceAll('%', ' بالمئة ')
        .replaceAll('+', ' زائد ');
    final safeValue = String.fromCharCodes(normalized.runes.where((rune) =>
        rune == 10 || rune == 9 || _fontHasGlyph(rune)));
    return ShapedText(
      safeValue,
      style: ShapedTextStyle(
        font: font,
        fontSize: size,
        color: color,
        direction: ShapedTextDirection.rightToLeft,
        align: align,
        preserveUnicodeText: true,
      ),
    );
  }

  Future<Uint8List> buildTimetablePdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<Map<String, Object?>> entries,
    List<Map<String, Object?>> sections = const [],
    List<Map<String, Object?>> days = const [],
    List<Map<String, Object?>> slots = const [],
    PdfPageFormat? pageFormat,
    String title = 'الجدول الأسبوعي الشامل لجميع الصفوف والشعب',
  }) async {
    final font = await _arabicFont();
    try {
      final pdf = pw.Document();
      final format = pageFormat ?? PdfPageFormat.a3.landscape;
      final orderedDays = days.where((d) => _int(d['is_active'], fallback: 1) == 1).toList()
        ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));
      final orderedSlots = slots.where((s) => s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1).toList()
        ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));
      final orderedEntries = [...entries]..sort((a, b) {
        final section = '${a['grade_name'] ?? ''} ${a['section_name'] ?? ''}'.compareTo('${b['grade_name'] ?? ''} ${b['section_name'] ?? ''}');
        if (section != 0) return section;
        final day = _int(a['day_position']).compareTo(_int(b['day_position']));
        if (day != 0) return day;
        return _int(a['slot_position']).compareTo(_int(b['slot_position']));
      });

      final reportSections = <Map<String, Object?>>[];
      if (sections.isNotEmpty) {
        reportSections.addAll(sections);
      } else {
        final seen = <int>{};
        for (final entry in orderedEntries) {
          final id = _int(entry['section_id']);
          if (seen.add(id)) {
            reportSections.add({'id': id, 'grade_name': entry['grade_name'] ?? '', 'section_name': entry['section_name'] ?? 'الشعبة $id'});
          }
        }
      }
      // Preserve the database's pedagogical order (stage, grade position, section).
      final entryByCell = <String, Map<String, Object?>>{};
      for (final entry in orderedEntries) {
        entryByCell['${_int(entry['section_id'])}:${_int(entry['day_id'])}:${_int(entry['slot_id'])}'] = entry;
      }

      // One compact row per section, with all periods stacked inside each day cell.
      // This is substantially more readable than repeating every section once per period.
      final columns = 1 + orderedDays.length;
      final availableWidth = format.width - 28;
      final sectionWidth = availableWidth * 0.13;
      final dayWidth = (availableWidth - sectionWidth) / (orderedDays.isEmpty ? 1 : orderedDays.length);
      final widths = <int, pw.TableColumnWidth>{
        for (var i = 0; i < columns - 1; i++) i: pw.FixedColumnWidth(dayWidth),
        columns - 1: pw.FixedColumnWidth(sectionWidth),
      };

      pw.Widget cell(String text, {bool header = false, bool filled = false, bool section = false}) {
        final background = header
            ? const PdfColor.fromInt(0xFF183B66)
            : filled
                ? const PdfColor.fromInt(0xFFE7F1FC)
                : section
                    ? const PdfColor.fromInt(0xFFDCE9F8)
                    : const PdfColor.fromInt(0xFFFAFBFD);
        return pw.Container(
          alignment: pw.Alignment.center,
          padding: const pw.EdgeInsets.symmetric(horizontal: 2, vertical: 2),
          decoration: pw.BoxDecoration(color: background),
          child: _text(text, font: font, size: header ? 7 : 5.5,
              color: header ? PdfColors.white : const PdfColor.fromInt(0xFF18324D)),
        );
      }

      final rows = <pw.TableRow>[];
      rows.add(pw.TableRow(children: [
        ...orderedDays.reversed.map((day) => cell('${day['name'] ?? ''}', header: true)),
        cell('الصف والشعبة', header: true),
      ]));

      if (reportSections.isEmpty || orderedDays.isEmpty || orderedSlots.isEmpty) {
        rows.add(pw.TableRow(children: [
          ...List.generate(orderedDays.length, (_) => cell('لا توجد بيانات')),
          cell(reportSections.isEmpty ? 'لا توجد شعب' : 'الجدول', section: true),
        ]));
      } else {
        for (final section in reportSections) {
          final sectionId = _int(section['id']);
          final gradeName = _displayGradeName('${section['grade_name'] ?? ''}');
          final sectionName = '${section['section_name'] ?? 'الشعبة $sectionId'}';
          final label = [gradeName, sectionName].where((v) => v.trim().isNotEmpty).join('\n');
          final dayCells = orderedDays.reversed.map((day) {
            final lines = <String>[];
            for (final slot in orderedSlots) {
              final entry = entryByCell['$sectionId:${_int(day['id'])}:${_int(slot['id'])}'];
              final start = '${slot['start_time'] ?? ''}'.trim();
              final end = '${slot['end_time'] ?? ''}'.trim();
              final time = start.isEmpty && end.isEmpty ? '' : 'من $start إلى $end';
              if (entry == null) {
                lines.add('${slot['name'] ?? 'حصة'}: فارغ${time.isEmpty ? '' : '، $time'}');
              } else {
                final subject = '${entry['subject_name'] ?? 'مادة'}'.trim();
                final teacher = '${entry['teacher_name'] ?? ''}'.trim();
                final room = '${entry['room_name'] ?? ''}'.trim();
                final details = <String>[subject, if (teacher.isNotEmpty) teacher, if (room.isNotEmpty) room, if (time.isNotEmpty) time];
                lines.add('${slot['name'] ?? 'حصة'}: ${details.join('، ')}');
              }
            }
            return cell(lines.join('\n'), filled: true);
          }).toList();
          rows.add(pw.TableRow(children: [...dayCells, cell(label, section: true)]));
        }
      }

      pdf.addPage(pw.Page(
        pageFormat: format,
        margin: const pw.EdgeInsets.all(14),
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            _text(schoolName, font: font, size: 14, color: const PdfColor.fromInt(0xFF183B66)),
            _text(title, font: font, size: 10, color: const PdfColor.fromInt(0xFF23354B)),
            _text('العام الدراسي: $academicYear، النسخة: $versionName، الحالة: $status', font: font, size: 8),
            pw.SizedBox(height: 5),
            pw.Expanded(
              child: pw.FittedBox(
                fit: pw.BoxFit.contain,
                child: pw.Table(
                  columnWidths: widths,
                  border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.35),
                  defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
                  children: rows,
                ),
              ),
            ),
            pw.SizedBox(height: 2),
            _text('تاريخ التقرير: ${_dateStamp(DateTime.now())}', font: font, size: 6),
          ],
        ),
      ));
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  // ---------------------------------------------------------------------------
  // تقارير إضافية: جداول المعلمين، نصاب المعلمين، التعارضات.
  // ---------------------------------------------------------------------------

  /// يلف النص الطويل على أسطر قصيرة (ShapedText لا يضمن اللف داخل الخلايا).
  String _wrap(String text, int maxChars) {
    final words = text.replaceAll('\n', ' ').split(RegExp(r'\s+')).where((w) => w.isNotEmpty);
    final lines = <String>[];
    var current = '';
    for (final word in words) {
      if (current.isEmpty) {
        current = word;
      } else if (current.length + 1 + word.length <= maxChars) {
        current = '$current $word';
      } else {
        lines.add(current);
        current = word;
      }
    }
    if (current.isNotEmpty) lines.add(current);
    return lines.join('\n');
  }

  /// جدول عام: الأعمدة تُمرَّر بترتيب القراءة (من اليمين إلى اليسار) ويُرسم معكوساً.
  pw.Widget _simpleGrid({
    required ShapedFont font,
    required List<String> headers,
    required List<List<String>> rows,
    required List<double> flex,
    double size = 8,
    double headerSize = 8.5,
  }) {
    final count = headers.length;
    final order = List<int>.generate(count, (i) => count - 1 - i);
    final widths = <int, pw.TableColumnWidth>{
      for (var i = 0; i < count; i++) i: pw.FlexColumnWidth(flex[order[i]]),
    };
    pw.Widget cell(String value, {bool header = false, bool alt = false}) => pw.Container(
          alignment: pw.Alignment.center,
          padding: const pw.EdgeInsets.symmetric(horizontal: 3, vertical: 3),
          decoration: pw.BoxDecoration(
            color: header
                ? const PdfColor.fromInt(0xFF183B66)
                : alt
                    ? const PdfColor.fromInt(0xFFF0F5FB)
                    : const PdfColor.fromInt(0xFFFFFFFF),
          ),
          child: _text(value,
              font: font,
              size: header ? headerSize : size,
              color: header ? PdfColors.white : const PdfColor.fromInt(0xFF18324D)),
        );
    final tableRows = <pw.TableRow>[
      pw.TableRow(repeat: true, children: [for (final i in order) cell(headers[i], header: true)]),
      for (var r = 0; r < rows.length; r++)
        pw.TableRow(children: [
          for (final i in order) cell(i < rows[r].length ? rows[r][i] : '', alt: r.isOdd),
        ]),
    ];
    return pw.Table(
      columnWidths: widths,
      border: pw.TableBorder.all(color: PdfColors.grey500, width: 0.4),
      defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
      children: tableRows,
    );
  }

  pw.Widget _reportHeader(ShapedFont font, String schoolName, String title, String subtitle) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: [
          _text(schoolName, font: font, size: 14, color: const PdfColor.fromInt(0xFF183B66)),
          _text(title, font: font, size: 11, color: const PdfColor.fromInt(0xFF23354B)),
          _text(subtitle, font: font, size: 8),
          pw.SizedBox(height: 6),
        ],
      );

  List<Map<String, Object?>> _activeDays(List<Map<String, Object?>> days) =>
      days.where((d) => _int(d['is_active'], fallback: 1) == 1).toList()
        ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));

  List<Map<String, Object?>> _lessonSlots(List<Map<String, Object?>> slots) =>
      slots.where((s) => s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1).toList()
        ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));

  /// صفحة مستقلة لكل معلم لديه حصص: الأيام أعمدة والفترات صفوف.
  Future<Uint8List> buildTeacherTimetablesPdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    PdfPageFormat? pageFormat,
  }) async {
    final font = await _arabicFont();
    try {
      final pdf = pw.Document();
      final format = pageFormat ?? PdfPageFormat.a4.landscape;
      final orderedDays = _activeDays(days);
      final orderedSlots = _lessonSlots(slots);
      final byTeacher = <int, List<Map<String, Object?>>>{};
      for (final entry in entries) {
        final id = _int(entry['teacher_id']);
        if (id > 0) byTeacher.putIfAbsent(id, () => <Map<String, Object?>>[]).add(entry);
      }
      var pages = 0;
      for (final teacher in teachers) {
        final id = _int(teacher['id']);
        final mine = byTeacher[id] ?? const <Map<String, Object?>>[];
        if (mine.isEmpty || orderedDays.isEmpty || orderedSlots.isEmpty) continue;
        final byCell = <String, List<Map<String, Object?>>>{};
        for (final entry in mine) {
          byCell
              .putIfAbsent('${_int(entry['day_id'])}:${_int(entry['slot_id'])}', () => <Map<String, Object?>>[])
              .add(entry);
        }
        final rows = <List<String>>[];
        for (final slot in orderedSlots) {
          final time = '${slot['start_time'] ?? ''} - ${slot['end_time'] ?? ''}'.trim();
          final row = <String>['${slot['name'] ?? 'حصة'}\n$time'];
          for (final day in orderedDays) {
            final here = byCell['${_int(day['id'])}:${_int(slot['id'])}'];
            if (here == null || here.isEmpty) {
              row.add('');
            } else {
              row.add(here
                  .map((e) => '${e['subject_name'] ?? ''}\n${_displayGradeName('${e['grade_name'] ?? ''}')} ${e['section_name'] ?? ''}'.trim())
                  .join('\n'));
            }
          }
          rows.add(row);
        }
        final load = _int(teacher['weekly_load']);
        pdf.addPage(pw.Page(
          pageFormat: format,
          margin: const pw.EdgeInsets.all(24),
          build: (context) => pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.stretch,
            children: [
              _reportHeader(font, schoolName, 'جدول المعلم: ${teacher['name'] ?? ''}',
                  'العام الدراسي: $academicYear، النسخة: $versionName، الحالة: $status'),
              _simpleGrid(
                font: font,
                headers: ['الفترة', for (final d in orderedDays) '${d['name'] ?? ''}'],
                rows: rows,
                flex: [1.2, for (final _ in orderedDays) 2],
                size: 9,
                headerSize: 10,
              ),
              pw.SizedBox(height: 8),
              _text(
                'عدد الحصص الأسبوعية: ${mine.length}${load > 0 ? '، النصاب: $load، المتبقي: ${load - mine.length}' : ''}',
                font: font,
                size: 9,
              ),
              pw.Spacer(),
              _text('تاريخ التقرير: ${_dateStamp(DateTime.now())}', font: font, size: 6),
            ],
          ),
        ));
        pages++;
      }
      if (pages == 0) {
        pdf.addPage(pw.Page(
          pageFormat: format,
          build: (context) => pw.Center(child: _text('لا توجد حصص مسندة إلى معلمين في هذه النسخة.', font: font, size: 12)),
        ));
      }
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  /// نصاب كل معلم: المطلوب والموزع والمتبقي وتوزيعه على الأيام.
  Future<Uint8List> buildTeacherQuotaPdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> days,
    List<Map<String, Object?>> subjects = const [],
    List<Map<String, Object?>> qualifications = const [],
    PdfPageFormat? pageFormat,
  }) async {
    final font = await _arabicFont();
    try {
      final pdf = pw.Document();
      final format = pageFormat ?? PdfPageFormat.a4.landscape;
      final orderedDays = _activeDays(days);
      final subjectNames = {for (final s in subjects) _int(s['id']): '${s['name'] ?? ''}'};
      final perTeacher = <int, int>{};
      final perTeacherDay = <String, int>{};
      for (final entry in entries) {
        final id = _int(entry['teacher_id']);
        if (id <= 0) continue;
        perTeacher[id] = (perTeacher[id] ?? 0) + 1;
        final key = '$id:${_int(entry['day_id'])}';
        perTeacherDay[key] = (perTeacherDay[key] ?? 0) + 1;
      }
      final rows = <List<String>>[];
      var totalQuota = 0;
      var totalAssigned = 0;
      for (final teacher in teachers) {
        final id = _int(teacher['id']);
        final quota = _int(teacher['weekly_load']);
        final assigned = perTeacher[id] ?? 0;
        totalQuota += quota;
        totalAssigned += assigned;
        final names = qualifications
            .where((q) => _int(q['teacher_id']) == id)
            .map((q) => subjectNames[_int(q['subject_id'])] ?? '')
            .where((n) => n.isNotEmpty)
            .join('، ');
        rows.add([
          '${teacher['name'] ?? ''}',
          _wrap(names.isEmpty ? '—' : names, 28),
          '$quota',
          '$assigned',
          quota > 0 ? '${quota - assigned}' : '—',
          for (final day in orderedDays) '${perTeacherDay['$id:${_int(day['id'])}'] ?? 0}',
        ]);
      }
      pdf.addPage(pw.MultiPage(
        pageFormat: format,
        margin: const pw.EdgeInsets.all(24),
        header: (context) => _reportHeader(font, schoolName, 'تقرير نصاب المعلمين',
            'العام الدراسي: $academicYear، النسخة: $versionName، الحالة: $status'),
        footer: (context) => _text('صفحة ${context.pageNumber} من ${context.pagesCount}', font: font, size: 7),
        build: (context) => [
          if (rows.isEmpty)
            _text('لا يوجد معلمون مسجلون.', font: font, size: 12)
          else ...[
            _simpleGrid(
              font: font,
              headers: ['المعلم', 'المواد', 'النصاب', 'الموزع', 'المتبقي', for (final d in orderedDays) '${d['name'] ?? ''}'],
              rows: rows,
              flex: [2.4, 3.2, 1, 1, 1, for (final _ in orderedDays) 1],
              size: 8.5,
            ),
            pw.SizedBox(height: 8),
            _text('مجموع النصاب: $totalQuota، مجموع الحصص الموزعة: $totalAssigned', font: font, size: 9),
          ],
        ],
      ));
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  /// تقرير التعارضات والتحذيرات: التصنيف والنوع والوصف والاقتراح.
  Future<Uint8List> buildConflictsPdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<ConflictIssue> issues,
    PdfPageFormat? pageFormat,
  }) async {
    final font = await _arabicFont();
    try {
      final pdf = pw.Document();
      final format = pageFormat ?? PdfPageFormat.a4.landscape;
      final blocking = issues.where((i) => i.severity == 'خطأ مانع').length;
      final warnings = issues.where((i) => i.severity == 'تحذير').length;
      final notes = issues.length - blocking - warnings;
      final order = {'خطأ مانع': 0, 'تحذير': 1};
      final sorted = [...issues]..sort((a, b) => (order[a.severity] ?? 2).compareTo(order[b.severity] ?? 2));
      final rows = <List<String>>[
        for (final issue in sorted)
          [issue.severity, _wrap(issue.type, 16), _wrap(issue.message, 70), _wrap(issue.suggestion ?? '', 42)],
      ];
      pdf.addPage(pw.MultiPage(
        pageFormat: format,
        margin: const pw.EdgeInsets.all(24),
        header: (context) => _reportHeader(font, schoolName, 'تقرير التعارضات والتحذيرات',
            'العام الدراسي: $academicYear، النسخة: $versionName، الحالة: $status'),
        footer: (context) => _text('صفحة ${context.pageNumber} من ${context.pagesCount}', font: font, size: 7),
        build: (context) => [
          _text('أخطاء مانعة: $blocking، تحذيرات: $warnings، ملاحظات: $notes', font: font, size: 10),
          pw.SizedBox(height: 6),
          if (rows.isEmpty)
            _text('لا توجد تعارضات أو تحذيرات. الجدول سليم وفق الفحوصات الحالية.', font: font, size: 12)
          else
            _simpleGrid(
              font: font,
              headers: ['التصنيف', 'النوع', 'الوصف', 'الاقتراح'],
              rows: rows,
              flex: [1, 1.5, 6, 4],
              size: 8,
            ),
        ],
      ));
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  String _displayGradeName(String value) => value.replaceFirst(RegExp(r'^\s*الصف\s+'), '').replaceFirst(RegExp(r'\s+الابتدائي\s*$'), '').trim();

  String _dateStamp(DateTime date) => '${date.year}.${date.month.toString().padLeft(2, '0')}.${date.day.toString().padLeft(2, '0')}';

  // Character ranges were derived from assets/fonts/Arabic-Regular.ttf's cmap.
  bool _fontHasGlyph(int rune) {
    const ranges = <List<int>>[
      [0, 0], [13, 13], [32, 33], [44, 44], [46, 46], [48, 58], [160, 160],
      [171, 171], [187, 187], [1536, 1540], [1542, 1563], [1566, 1791], [1872, 1919],
      [2208, 2208], [2210, 2220], [2276, 2302], [8203, 8209], [8271, 8271],
      [9676, 9676], [11841, 11841], [64336, 64449], [64467, 64831],
      [64848, 64911], [64914, 64967], [65008, 65021], [65136, 65140],
      [65142, 65276], [65279, 65279],
    ];
    for (final range in ranges) {
      if (rune >= range[0] && rune <= range[1]) return true;
    }
    return false;
  }

  Future<String?> savePdf(Uint8List bytes, {String fileName = 'الجدول-المدرسي.pdf'}) async {
    return FilePicker.platform.saveFile(
      dialogTitle: 'حفظ تقرير PDF',
      fileName: fileName,
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      bytes: bytes,
    );
  }

  Future<void> preview(Uint8List bytes) async {
    await Printing.layoutPdf(onLayout: (_) async => bytes);
  }

  int _int(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
