import 'conflict_detection_service.dart';
import 'teacher_assignment_policy.dart';

class PreflightFinding {
  const PreflightFinding({
    required this.code,
    required this.title,
    required this.message,
    required this.recommendation,
    this.blocking = false,
    this.category = 'الإعدادات',
  });

  final String code;
  final String title;
  final String message;
  final String recommendation;
  final bool blocking;
  final String category;
}

class PreflightResult {
  const PreflightResult(this.findings);
  final List<PreflightFinding> findings;
  bool get canStart => !findings.any((finding) => finding.blocking);
  int get blockers => findings.where((finding) => finding.blocking).length;
  int get warnings => findings.where((finding) => !finding.blocking).length;
}

/// Checks configuration before the scheduler performs an expensive search.
/// It never changes school data and deliberately distinguishes fatal setup
/// omissions from recoverable problems that can yield a partial draft.
class PreflightInspectionService {
  const PreflightInspectionService();

  PreflightResult inspect({
    required List<Map<String, Object?>> sections,
    required List<Map<String, Object?>> requirements,
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> subjects,
    required List<Map<String, Object?>> qualifications,
    required List<Map<String, Object?>> teacherGrades,
    required List<Map<String, Object?>> teacherSubjectGrades,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    required List<Map<String, Object?>> currentEntries,
    List<Map<String, Object?>> availability = const [],
    List<Map<String, Object?>> subjectBlockedSlots = const [],
  }) {
    final out = <PreflightFinding>[];
    final activeDays = days.where((d) => _int(d['is_active'], fallback: 1) == 1).toList();
    final lessonSlots = slots.where((s) => s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1).toList()
      ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));
    final sectionById = {for (final row in sections) _int(row['id']): row};
    final subjectById = {for (final row in subjects) _int(row['id']): row};
    final policy = TeacherAssignmentPolicy(
      qualifications: qualifications,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
    );

    void add(String code, String title, String message, String recommendation,
        {bool blocking = false, String category = 'الإعدادات'}) {
      out.add(PreflightFinding(code: code, title: title, message: message,
          recommendation: recommendation, blocking: blocking, category: category));
    }

    if (sections.isEmpty) {
      add('no_sections', 'لا توجد شعب', 'لم تُسجّل أي شعبة في المدرسة.',
          'أضف الصفوف والشعب من إدارة البيانات قبل تشغيل التوزيع.', blocking: true);
    }
    if (activeDays.isEmpty) {
      add('no_days', 'لا توجد أيام دوام فعّالة', 'لا يوجد يوم دوام فعّال يمكن توزيع الحصص عليه.',
          'فعّل أيام الدوام المطلوبة في إعدادات المدرسة.', blocking: true);
    }
    if (lessonSlots.isEmpty) {
      add('no_slots', 'لا توجد فترات تدريس متاحة', 'لا توجد فترة من نوع حصة ومفعّلة للتدريس.',
          'أضف الفترات الدراسية أو فعّل الفترات الموجودة.', blocking: true);
    }
    if (teachers.isEmpty) {
      add('no_teachers', 'لا يوجد معلمون', 'قائمة المعلمين فارغة، ولذلك لن يمكن إسناد الحصص.',
          'أضف المعلمين وسجّل المواد التي يدرّسونها.', blocking: false);
    }
    if (requirements.isEmpty) {
      add('no_requirements', 'الحصص المطلوبة غير مسجلة', 'لم تُسجّل أي متطلبات أسبوعية للمواد والشعب.',
          'أكمل «البيانات > الحصص المطلوبة». يمكن التوزيع اليدوي، لكن لا يمكن إنشاء توزيع آلي مفيد.', blocking: true);
    }

    final qualifiedTeacherIds = qualifications.map((row) => _int(row['teacher_id'])).toSet();
    for (final teacher in teachers) {
      final teacherId = _int(teacher['id']);
      final teacherName = '${teacher['name'] ?? 'المعلم $teacherId'}';
      if (!qualifiedTeacherIds.contains(teacherId)) {
        add('teacher_without_subjects', 'معلم بلا اختصاصات مسجلة',
            '$teacherName لا يملك أي مادة مسجلة ضمن اختصاصاته، لذلك لن يمكن إسناد حصص إليه.',
            'افتح «البيانات > المعلمون» وسجّل المواد التي يدرّسها فعلياً، ثم حدّد الصفوف المسموحة لكل مادة.', category: 'إعداد المعلمين');
      }
      if (_int(teacher['weekly_load']) <= 0) {
        add('teacher_without_weekly_load', 'النصاب الأسبوعي للمعلم غير محدد',
            'لم يُضبط نصاب أسبوعي موجب للمعلم $teacherName. قد يوزع عليه المحرك حصصاً، لكن تقرير النصاب لن يستطيع مقارنة التوزيع بهدف صحيح.',
            'أدخل النصاب الأسبوعي المعتمد لهذا المعلم من «البيانات > المعلمون»، أو اترك الملاحظة ظاهرة إذا كان النصاب غير معتمد بعد.', category: 'إعداد المعلمين');
      }
    }

    final reqBySection = <int, List<Map<String, Object?>>>{};
    for (final req in requirements) {
      (reqBySection[_int(req['section_id'])] ??= <Map<String, Object?>>[]).add(req);
    }
    final activeDayCount = activeDays.length;
    final availableSlotCount = lessonSlots.length;
    for (final section in sections) {
      final id = _int(section['id']);
      final sectionRequirements = reqBySection[id] ?? const <Map<String, Object?>>[];
      if (sectionRequirements.isEmpty) {
        add('section_without_requirements', 'شعبة بلا متطلبات',
            'لم تُسجّل حصص أسبوعية مطلوبة للصف ${section['grade_name'] ?? ''}، الشعبة ${section['section_name'] ?? id}.',
            'أضف المواد وعدد حصصها الأسبوعية لهذه الشعبة.');
      }
      final weeklyTotal = sectionRequirements.fold<int>(0, (sum, req) => sum + _int(req['weekly_lessons']));
      final maxDaily = _int(section['max_daily_lessons'], fallback: 6).clamp(1, 7);
      final dailyCapacity = availableSlotCount < maxDaily ? availableSlotCount : maxDaily;
      final weeklyCapacity = activeDayCount * dailyCapacity;
      if (weeklyTotal > weeklyCapacity && activeDayCount > 0 && availableSlotCount > 0) {
        add('section_over_capacity', 'مجموع متطلبات الشعبة يتجاوز السعة',
            'الصف ${section['grade_name'] ?? ''}، الشعبة ${section['section_name'] ?? id}: مجموع المطلوب $weeklyTotal حصة أسبوعياً، لكن السعة الحالية $weeklyCapacity فقط.',
            'راجع مجموع الحصص المطلوبة والفترات المتاحة والحد اليومي. لا يعدّل الفاحص النصاب تلقائياً.', category: 'السعة');
      }
    }

    final activeSubjectBlocked = <String>{
      for (final row in subjectBlockedSlots)
        '${_int(row['subject_id'])}:${_int(row['slot_id'])}',
    };
    final availabilityRowsByTeacher = <int, List<Map<String, Object?>>>{};
    for (final row in availability) {
      (availabilityRowsByTeacher[_int(row['teacher_id'])] ??= <Map<String, Object?>>[]).add(row);
    }

    for (final req in requirements) {
      final weekly = _int(req['weekly_lessons']);
      if (weekly <= 0) continue;
      final sectionId = _int(req['section_id']);
      final subjectId = _int(req['subject_id']);
      final section = sectionById[sectionId];
      final subject = subjectById[subjectId];
      final sectionName = '${req['grade_name'] ?? section?['grade_name'] ?? 'صف غير محدد'}، الشعبة ${req['section_name'] ?? section?['section_name'] ?? sectionId}';
      final subjectName = '${req['subject_name'] ?? subject?['name'] ?? 'المادة $subjectId'}';

      if (section == null) {
        add('orphan_section_requirement', 'متطلب مرتبط بشعبة غير موجودة',
            'متطلب مادة $subjectName يشير إلى شعبة غير موجودة في قاعدة البيانات.',
            'راجع سجل الحصص المطلوبة وأعد ربط المتطلب بشعبة موجودة.', category: 'سلامة البيانات');
        continue;
      }
      if (subject == null) {
        add('orphan_subject_requirement', 'متطلب مرتبط بمادة غير موجودة',
            'متطلب $sectionName يشير إلى مادة غير موجودة.',
            'اختر مادة موجودة أو أصلح بيانات المتطلب.', category: 'سلامة البيانات');
        continue;
      }

      final subjectAllowedSlotCount = lessonSlots.where((slot) =>
          !activeSubjectBlocked.contains('$subjectId:${_int(slot['id'])}')).length;
      final configuredSubjectDaily = _int(req['max_daily_lessons'], fallback: 2);
      final subjectDailyLimit = _int(req['allow_same_day']) == 1
          ? (configuredSubjectDaily > 0 ? configuredSubjectDaily : 1)
          : 1;
      final effectiveSubjectDaily = subjectAllowedSlotCount < subjectDailyLimit
          ? subjectAllowedSlotCount
          : subjectDailyLimit;
      final subjectWeeklyCapacity = activeDayCount * effectiveSubjectDaily;
      if (activeDayCount > 0 && weekly > subjectWeeklyCapacity) {
        add('requirement_rule_capacity', 'عدد حصص المادة يتجاوز قيدها الأسبوعي',
            '$sectionName، مادة $subjectName: المطلوب $weekly حصة أسبوعياً، لكن القيد الحالي يسمح بحد أقصى $subjectWeeklyCapacity حصة (${activeDayCount} أيام × $effectiveSubjectDaily في اليوم).',
            'راجع عدد الحصص وقاعدة تكرار المادة في اليوم والفترات الممنوعة. لن يغيّر الفاحص القواعد تلقائياً.', category: 'السعة');
      }

      final maxDaily = _int(section['max_daily_lessons'], fallback: 6).clamp(1, 7);
      final dailyCapacity = availableSlotCount < maxDaily ? availableSlotCount : maxDaily;
      final weeklyCapacity = activeDayCount * dailyCapacity;
      if (activeDayCount > 0 && availableSlotCount > 0 && weekly > weeklyCapacity) {
        add('requirement_over_capacity', 'متطلبات المادة تتجاوز السعة الأسبوعية للشعبة',
            '$sectionName، مادة $subjectName: المطلوب $weekly حصة أسبوعياً، بينما السعة العامة للشعبة وفق الأيام والفترات والحد اليومي الحالي $weeklyCapacity فقط.',
            'راجع عدد الحصص المطلوبة، وأيام الدوام، والفترات المتاحة والحد اليومي للشعبة. لا يغيّر الفاحص هذه الإعدادات تلقائياً.', category: 'السعة');
      }

      final subjectQualified = qualifications
          .where((q) => _int(q['subject_id']) == subjectId)
          .map((q) => _int(q['teacher_id']))
          .toSet();
      if (subjectQualified.isEmpty) {
        add('no_subject_teacher', 'لا يوجد معلم مؤهل للمادة',
            '$sectionName، مادة $subjectName: لا يوجد معلم مسجل ضمن مؤهلي المادة.',
            'من «البيانات > المعلمون»، سجّل المعلمين المؤهلين للمادة.');
        continue;
      }
      final gradeId = _int(section['grade_id'], fallback: _int(req['grade_id']));
      if (gradeId <= 0) {
        add('unknown_grade', 'تعذّر تحديد صف الشعبة',
            'لا يمكن التحقق من صلاحية معلمي مادة $subjectName لأن الصف الفعلي للشعبة غير محدد.',
            'أصلح ارتباط الشعبة بالصف قبل إنشاء التوزيع.', category: 'سلامة البيانات');
        continue;
      }
      final allowed = subjectQualified.where((teacherId) => policy.isGradeAllowed(teacherId, subjectId, gradeId)).toList();
      if (allowed.isEmpty) {
        add('no_teacher_allowed_grade', 'لا يوجد معلم مسموح له بالمادة والصف',
            '$sectionName، مادة $subjectName: يوجد معلمون مؤهلون للمادة، لكن لا أحد منهم يملك صلاحية تدريسها في هذا الصف.',
            'عدّل صفوف هذه المادة للمعلمين من إدارة البيانات فقط إذا كان ذلك صحيحاً مدرسياً؛ لا يوسّع التطبيق الصلاحيات تلقائياً.', category: 'صلاحيات');
        continue;
      }
      final nonBlockedSlots = lessonSlots.where((slot) => !activeSubjectBlocked.contains('$subjectId:${_int(slot['id'])}')).length;
      if (nonBlockedSlots == 0) {
        add('subject_all_slots_blocked', 'جميع فترات المادة ممنوعة',
            '$sectionName، مادة $subjectName: كل فترات التدريس المتاحة ممنوعة لهذه المادة.',
            'عدّل الفترات الممنوعة للمادة أو أضف فترة مسموحة.', category: 'قيود الجدولة');
      }

      // A weekly limit lower than the requested count, or no possible day/slot,
      // is a recoverable issue; the scheduler may still place some lessons.
      final possibleByAvailability = allowed.any((teacherId) {
        final rows = availabilityRowsByTeacher[teacherId];
        if (rows == null || rows.isEmpty) return true;
        final closed = rows.where((r) => _int(r['is_available'], fallback: 1) == 0)
            .map((r) => '${_int(r['day_id'])}:${_int(r['slot_id'])}').toSet();
        return activeDays.any((day) => lessonSlots.any((slot) =>
            !closed.contains('${_int(day['id'])}:${_int(slot['id'])}') &&
            !activeSubjectBlocked.contains('$subjectId:${_int(slot['id'])}')));
      });
      if (!possibleByAvailability) {
        add('no_teacher_slot', 'لا توجد فترة متاحة لمعلمي المادة',
            '$sectionName، مادة $subjectName: المعلمون المسموحون غير متاحين في كل الخانات المتوافقة مع قيود المادة.',
            'راجع إتاحة المعلمين والفترات الممنوعة للمادة.', category: 'قيود الجدولة');
      }
    }

    // Existing collisions are shown before regeneration, but are not hard stops:
    // a newly generated version may repair an old timetable.
    if (currentEntries.isNotEmpty) {
      final issues = const ConflictDetectionService().scan(
        entries: currentEntries,
        requirements: requirements,
        slots: slots,
        teachers: teachers,
        qualifications: qualifications,
        days: days,
        teacherGrades: teacherGrades,
        teacherSubjectGrades: teacherSubjectGrades,
        subjectBlockedSlots: subjectBlockedSlots,
      );
      final relevant = issues.where((issue) => {
        'تعارض المعلم', 'تعارض الشعبة', 'تعارض القاعة', 'تأهيل المعلم',
        'الصف غير مسموح للمعلم', 'تعذر تحديد صف الشعبة', 'فترة غير متاحة',
        'المادة في فترة ممنوعة', 'يوم غير مفعل', 'نقص الحصص', 'حصص زائدة',
        'الحصص المطلوبة تتجاوز سعة الشعبة', 'تجاوز النصاب الأسبوعي',
        'تكرار المادة يومياً', 'تجاوز الحد اليومي', 'حصص متتالية زائدة',
      }.contains(issue.type)).toList();
      if (relevant.isNotEmpty) {
        final sample = relevant.take(5).map((issue) => '${issue.type}: ${issue.message}').join('\n');
        add('current_timetable_issues', 'توجد مشكلات في الجدول الحالي',
            'الفحص المسبق وجد ${relevant.length} ملاحظة/تعارضاً في النسخة الحالية. هذه النتائج تخص النسخة الحالية ولا تعني أن التوزيع الجديد سيكررها.\n$sample',
            'يمكن متابعة التوليد لإنشاء نسخة جديدة؛ راجع نتائج التوزيع الجديد قبل حفظه أو اعتماده.', category: 'الجدول الحالي');
      }
    }

    return PreflightResult(List<PreflightFinding>.unmodifiable(out));
  }

  static int _int(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
