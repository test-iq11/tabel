import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf_text_shaper/pdf_text_shaper.dart';
import 'package:printing/printing.dart';

import 'timetable_report_layout.dart';

/// يصدّر شبكة الجدول الأسبوعي لجميع الشعب إلى PDF أفقي قابل للطباعة.
class PdfReportService {
  Future<ShapedFont> _arabicFont() async {
    final data = await rootBundle.load('assets/fonts/Arabic-Regular.ttf');
    return ShapedFont.fromBytes(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      name: 'Noto Naskh Arabic',
    );
  }

  pw.Widget _text(
    String value, {
    required ShapedFont font,
    double size = 10,
    PdfColor color = PdfColors.black,
    ShapedTextAlign align = ShapedTextAlign.center,
  }) {
    // The bundled font has a limited glyph map. Normalize punctuation first,
    // then remove any code point unsupported by that exact font so text entered
    // by users cannot make PDF generation fail at runtime.
    final normalized = value
        .replaceAll(RegExp(r'[\u002D\u2010-\u2015\u2212]'), ' إلى ')
        .replaceAll('/', ' أو ')
        .replaceAll('|', '،')
        .replaceAll('•', '،')
        .replaceAll('·', '،')
        .replaceAll(RegExp(r'[()\[\]{}]'), ' ')
        .replaceAll('_', ' ')
        .replaceAll('%', ' بالمئة ')
        .replaceAll('+', ' زائد ');
    final safeValue = String.fromCharCodes(normalized.runes.where((rune) =>
        rune == 10 || rune == 9 || _fontHasGlyph(rune)));
    return ShapedText(
      safeValue,
      style: ShapedTextStyle(
        font: font,
        fontSize: size,
        color: color,
        direction: ShapedTextDirection.rightToLeft,
        align: align,
        preserveUnicodeText: true,
      ),
    );
  }

  Future<Uint8List> buildTimetablePdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<Map<String, Object?>> entries,
    List<Map<String, Object?>> sections = const [],
    List<Map<String, Object?>> days = const [],
    List<Map<String, Object?>> slots = const [],
    PdfPageFormat? pageFormat,
    String title = 'الجدول الأسبوعي الشامل',
  }) async {
    final font = await _arabicFont();
    try {
      final pdf = pw.Document();
      final format = pageFormat ?? PdfPageFormat.a3.landscape;
      final layout = TimetableReportLayout(
        entries: entries,
        sections: sections,
        days: days,
        slots: slots,
      );
      const periodWidth = 92.0;

      pw.Widget cell(String text, {bool header = false, bool period = false}) {
        final background = header
            ? const PdfColor.fromInt(0xFF183B66)
            : period
                ? const PdfColor.fromInt(0xFFDCE9F8)
                : const PdfColor.fromInt(0xFFFAFBFD);
        return pw.Container(
          alignment: pw.Alignment.center,
          padding: const pw.EdgeInsets.symmetric(horizontal: 3, vertical: 3),
          decoration: pw.BoxDecoration(color: background),
          child: _text(
            text,
            font: font,
            size: header ? 7.2 : (period ? 6.6 : 7),
            color: header ? PdfColors.white : const PdfColor.fromInt(0xFF18324D),
          ),
        );
      }

      final reportBlocks = <pw.Widget>[];
      for (final section in layout.sections) {
        reportBlocks.add(pw.Container(
          width: double.infinity,
          padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 4),
          decoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFFDCE9F8)),
          child: _text(layout.sectionTitle(section), font: font, size: 9.2, color: const PdfColor.fromInt(0xFF183B66)),
        ));
        reportBlocks.add(pw.SizedBox(height: 2));
        final tableRows = <pw.TableRow>[
          pw.TableRow(children: [
            cell('الحصة والوقت', header: true),
            ...layout.days.map((day) => cell('${day['name'] ?? ''}', header: true)),
          ]),
          ...layout.slots.map((slot) => pw.TableRow(children: [
            cell(layout.periodLabel(slot), period: true),
            ...layout.days.map((day) => cell(layout.lessonCell(section, day, slot))),
          ])),
        ];
        reportBlocks.add(pw.Table(
          columnWidths: <int, pw.TableColumnWidth>{
            0: const pw.FixedColumnWidth(periodWidth),
            for (var i = 0; i < layout.days.length; i++) i + 1: const pw.FlexColumnWidth(1),
          },
          border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.45),
          defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
          children: tableRows,
        ));
        reportBlocks.add(pw.SizedBox(height: 8));
      }
      if (reportBlocks.isEmpty) {
        reportBlocks.add(_text('لا توجد شعب أو فترات تدريس متاحة. راجع إعدادات المدرسة.', font: font, size: 9));
      }

      pdf.addPage(pw.MultiPage(
        pageFormat: format,
        margin: const pw.EdgeInsets.all(14),
        header: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            _text(schoolName, font: font, size: 13.5, color: const PdfColor.fromInt(0xFF183B66)),
            _text(title, font: font, size: 9.5, color: const PdfColor.fromInt(0xFF23354B)),
            _text('العام الدراسي: $academicYear، النسخة: $versionName، الحالة: $status', font: font, size: 7.2),
            pw.SizedBox(height: 5),
          ],
        ),
        footer: (context) => pw.Align(
          alignment: pw.Alignment.centerRight,
          child: _text('تاريخ التقرير: ${_dateStamp(DateTime.now())} • صفحة ${context.pageNumber} من ${context.pagesCount}', font: font, size: 6),
        ),
        build: (context) => reportBlocks,
      ));
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  String _dateStamp(DateTime date) => '${date.year}.${date.month.toString().padLeft(2, '0')}.${date.day.toString().padLeft(2, '0')}';

  // Character ranges were derived from assets/fonts/Arabic-Regular.ttf's cmap.
  bool _fontHasGlyph(int rune) {
    const ranges = <List<int>>[
      [0, 0], [13, 13], [32, 33], [44, 44], [46, 46], [48, 58], [160, 160],
      [171, 171], [187, 187], [1536, 1540], [1542, 1563], [1566, 1791], [1872, 1919],
      [2208, 2208], [2210, 2220], [2276, 2302], [8203, 8209], [8271, 8271],
      [9676, 9676], [11841, 11841], [64336, 64449], [64467, 64831],
      [64848, 64911], [64914, 64967], [65008, 65021], [65136, 65140],
      [65142, 65276], [65279, 65279],
    ];
    for (final range in ranges) {
      if (rune >= range[0] && rune <= range[1]) return true;
    }
    return false;
  }

  Future<String?> savePdf(Uint8List bytes, {String fileName = 'الجدول-المدرسي.pdf'}) async {
    return FilePicker.platform.saveFile(
      dialogTitle: 'حفظ تقرير PDF',
      fileName: fileName,
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      bytes: bytes,
    );
  }

  Future<void> preview(Uint8List bytes) async {
    await Printing.layoutPdf(onLayout: (_) async => bytes);
  }

}
