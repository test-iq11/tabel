import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf_text_shaper/pdf_text_shaper.dart';
import 'package:printing/printing.dart';

/// يصدّر شبكة الجدول الأسبوعي لجميع الشعب إلى PDF أفقي قابل للطباعة.
class PdfReportService {
  Future<ShapedFont> _arabicFont() async {
    final data = await rootBundle.load('assets/fonts/Arabic-Regular.ttf');
    return ShapedFont.fromBytes(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      name: 'Noto Naskh Arabic',
    );
  }

  pw.Widget _text(
    String value, {
    required ShapedFont font,
    double size = 10,
    PdfColor color = PdfColors.black,
    ShapedTextAlign align = ShapedTextAlign.center,
  }) {
    // The bundled font has a limited glyph map. Normalize punctuation first,
    // then remove any code point unsupported by that exact font so text entered
    // by users cannot make PDF generation fail at runtime.
    final normalized = value
        .replaceAll(RegExp(r'[\u002D\u2010-\u2015\u2212]'), ' إلى ')
        .replaceAll('/', ' أو ')
        .replaceAll('|', '،')
        .replaceAll('•', '،')
        .replaceAll('·', '،')
        .replaceAll(RegExp(r'[()\[\]{}]'), ' ')
        .replaceAll('_', ' ')
        .replaceAll('%', ' بالمئة ')
        .replaceAll('+', ' زائد ');
    final safeValue = String.fromCharCodes(normalized.runes.where((rune) =>
        rune == 10 || rune == 9 || _fontHasGlyph(rune)));
    return ShapedText(
      safeValue,
      style: ShapedTextStyle(
        font: font,
        fontSize: size,
        color: color,
        direction: ShapedTextDirection.rightToLeft,
        align: align,
        preserveUnicodeText: true,
      ),
    );
  }

  Future<Uint8List> buildTimetablePdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<Map<String, Object?>> entries,
    List<Map<String, Object?>> sections = const [],
    List<Map<String, Object?>> days = const [],
    List<Map<String, Object?>> slots = const [],
    PdfPageFormat? pageFormat,
    String title = 'الجدول الأسبوعي الشامل لجميع الصفوف والشعب',
  }) async {
    final font = await _arabicFont();
    try {
      final pdf = pw.Document();
      final format = pageFormat ?? PdfPageFormat.a3.landscape;
      final orderedDays = days.where((d) => _int(d['is_active'], fallback: 1) == 1).toList()
        ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));
      final orderedSlots = slots.where((s) => s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1).toList()
        ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));
      final orderedEntries = [...entries]..sort((a, b) {
        final section = '${a['grade_name'] ?? ''} ${a['section_name'] ?? ''}'.compareTo('${b['grade_name'] ?? ''} ${b['section_name'] ?? ''}');
        if (section != 0) return section;
        final day = _int(a['day_position']).compareTo(_int(b['day_position']));
        if (day != 0) return day;
        return _int(a['slot_position']).compareTo(_int(b['slot_position']));
      });

      final reportSections = <Map<String, Object?>>[];
      if (sections.isNotEmpty) {
        reportSections.addAll(sections);
      } else {
        final seen = <int>{};
        for (final entry in orderedEntries) {
          final id = _int(entry['section_id']);
          if (seen.add(id)) {
            reportSections.add({'id': id, 'grade_name': entry['grade_name'] ?? '', 'section_name': entry['section_name'] ?? 'الشعبة $id'});
          }
        }
      }
      // Preserve the database's pedagogical order (stage, grade position, section).
      final entryByCell = <String, Map<String, Object?>>{};
      for (final entry in orderedEntries) {
        entryByCell['${_int(entry['section_id'])}:${_int(entry['day_id'])}:${_int(entry['slot_id'])}'] = entry;
      }

      // One compact row per section, with all periods stacked inside each day cell.
      // This is substantially more readable than repeating every section once per period.
      final columns = 1 + orderedDays.length;
      final availableWidth = format.width - 28;
      final sectionWidth = availableWidth * 0.13;
      final dayWidth = (availableWidth - sectionWidth) / (orderedDays.isEmpty ? 1 : orderedDays.length);
      final widths = <int, pw.TableColumnWidth>{
        for (var i = 0; i < columns - 1; i++) i: pw.FixedColumnWidth(dayWidth),
        columns - 1: pw.FixedColumnWidth(sectionWidth),
      };

      pw.Widget cell(String text, {bool header = false, bool filled = false, bool section = false}) {
        final background = header
            ? const PdfColor.fromInt(0xFF183B66)
            : filled
                ? const PdfColor.fromInt(0xFFE7F1FC)
                : section
                    ? const PdfColor.fromInt(0xFFDCE9F8)
                    : const PdfColor.fromInt(0xFFFAFBFD);
        return pw.Container(
          alignment: pw.Alignment.center,
          padding: const pw.EdgeInsets.symmetric(horizontal: 2, vertical: 2),
          decoration: pw.BoxDecoration(color: background),
          child: _text(text, font: font, size: header ? 7 : 5.5,
              color: header ? PdfColors.white : const PdfColor.fromInt(0xFF18324D)),
        );
      }

      final rows = <pw.TableRow>[];
      rows.add(pw.TableRow(children: [
        ...orderedDays.reversed.map((day) => cell('${day['name'] ?? ''}', header: true)),
        cell('الصف والشعبة', header: true),
      ]));

      if (reportSections.isEmpty || orderedDays.isEmpty || orderedSlots.isEmpty) {
        rows.add(pw.TableRow(children: [
          ...List.generate(orderedDays.length, (_) => cell('لا توجد بيانات')),
          cell(reportSections.isEmpty ? 'لا توجد شعب' : 'الجدول', section: true),
        ]));
      } else {
        for (final section in reportSections) {
          final sectionId = _int(section['id']);
          final gradeName = _displayGradeName('${section['grade_name'] ?? ''}');
          final sectionName = '${section['section_name'] ?? 'الشعبة $sectionId'}';
          final label = [gradeName, sectionName].where((v) => v.trim().isNotEmpty).join('\n');
          final dayCells = orderedDays.reversed.map((day) {
            final lines = <String>[];
            for (final slot in orderedSlots) {
              final entry = entryByCell['$sectionId:${_int(day['id'])}:${_int(slot['id'])}'];
              final start = '${slot['start_time'] ?? ''}'.trim();
              final end = '${slot['end_time'] ?? ''}'.trim();
              final time = start.isEmpty && end.isEmpty ? '' : 'من $start إلى $end';
              if (entry == null) {
                lines.add('${slot['name'] ?? 'حصة'}: فارغ${time.isEmpty ? '' : '، $time'}');
              } else {
                final subject = '${entry['subject_name'] ?? 'مادة'}'.trim();
                final teacher = '${entry['teacher_name'] ?? ''}'.trim();
                final room = '${entry['room_name'] ?? ''}'.trim();
                final details = <String>[subject, if (teacher.isNotEmpty) teacher, if (room.isNotEmpty) room, if (time.isNotEmpty) time];
                lines.add('${slot['name'] ?? 'حصة'}: ${details.join('، ')}');
              }
            }
            return cell(lines.join('\n'), filled: true);
          }).toList();
          rows.add(pw.TableRow(children: [...dayCells, cell(label, section: true)]));
        }
      }

      pdf.addPage(pw.Page(
        pageFormat: format,
        margin: const pw.EdgeInsets.all(14),
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            _text(schoolName, font: font, size: 14, color: const PdfColor.fromInt(0xFF183B66)),
            _text(title, font: font, size: 10, color: const PdfColor.fromInt(0xFF23354B)),
            _text('العام الدراسي: $academicYear، النسخة: $versionName، الحالة: $status', font: font, size: 8),
            pw.SizedBox(height: 5),
            pw.Expanded(
              child: pw.FittedBox(
                fit: pw.BoxFit.contain,
                child: pw.Table(
                  columnWidths: widths,
                  border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.35),
                  defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
                  children: rows,
                ),
              ),
            ),
            pw.SizedBox(height: 2),
            _text('تاريخ التقرير: ${_dateStamp(DateTime.now())}', font: font, size: 6),
          ],
        ),
      ));
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  String _displayGradeName(String value) => value.replaceFirst(RegExp(r'^\s*الصف\s+'), '').replaceFirst(RegExp(r'\s+الابتدائي\s*$'), '').trim();

  String _dateStamp(DateTime date) => '${date.year}.${date.month.toString().padLeft(2, '0')}.${date.day.toString().padLeft(2, '0')}';

  // Character ranges were derived from assets/fonts/Arabic-Regular.ttf's cmap.
  bool _fontHasGlyph(int rune) {
    const ranges = <List<int>>[
      [0, 0], [13, 13], [32, 33], [44, 44], [46, 46], [48, 58], [160, 160],
      [171, 171], [187, 187], [1536, 1540], [1542, 1563], [1566, 1791], [1872, 1919],
      [2208, 2208], [2210, 2220], [2276, 2302], [8203, 8209], [8271, 8271],
      [9676, 9676], [11841, 11841], [64336, 64449], [64467, 64831],
      [64848, 64911], [64914, 64967], [65008, 65021], [65136, 65140],
      [65142, 65276], [65279, 65279],
    ];
    for (final range in ranges) {
      if (rune >= range[0] && rune <= range[1]) return true;
    }
    return false;
  }

  Future<String?> savePdf(Uint8List bytes, {String fileName = 'الجدول-المدرسي.pdf'}) async {
    return FilePicker.platform.saveFile(
      dialogTitle: 'حفظ تقرير PDF',
      fileName: fileName,
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      bytes: bytes,
    );
  }

  Future<void> preview(Uint8List bytes) async {
    await Printing.layoutPdf(onLayout: (_) async => bytes);
  }

  int _int(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
