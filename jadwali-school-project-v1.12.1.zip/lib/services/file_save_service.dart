import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';

typedef SaveFileDialog = Future<String?> Function({
  required String dialogTitle,
  required String fileName,
  required List<String> allowedExtensions,
  required Uint8List bytes,
});

/// Mobile pickers save the supplied bytes themselves. Desktop save dialogs
/// select a destination, so explicitly write it before reporting success.
class FileSaveService {
  FileSaveService({SaveFileDialog? dialog, bool? writeSelectedPath})
      : _dialog = dialog ?? _showDialog,
        _writeSelectedPath = writeSelectedPath ??
            (Platform.isWindows || Platform.isLinux || Platform.isMacOS);

  final SaveFileDialog _dialog;
  final bool _writeSelectedPath;

  static Future<String?> _showDialog({
    required String dialogTitle,
    required String fileName,
    required List<String> allowedExtensions,
    required Uint8List bytes,
  }) => FilePicker.platform.saveFile(
        dialogTitle: dialogTitle,
        fileName: fileName,
        type: FileType.custom,
        allowedExtensions: allowedExtensions,
        bytes: bytes,
      );

  Future<String?> saveBytes({
    required String dialogTitle,
    required String fileName,
    required List<String> allowedExtensions,
    required Uint8List bytes,
  }) async {
    final path = await _dialog(
      dialogTitle: dialogTitle,
      fileName: fileName,
      allowedExtensions: allowedExtensions,
      bytes: bytes,
    );
    if (path == null) return null;
    if (_writeSelectedPath) await File(path).writeAsBytes(bytes, flush: true);
    return path;
  }
}
