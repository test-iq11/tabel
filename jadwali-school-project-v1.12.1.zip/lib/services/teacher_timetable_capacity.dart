import '../core/timetable_ordering.dart';
import 'school_timetable_policy.dart';
import 'teacher_assignment_policy.dart';

/// Optimistic teacher capacities using the periods their actual subjects and
/// grades can use. A shortfall is a proof; sufficient capacity is not a proof
/// that all teachers and sections can be scheduled together.
class TeacherTimetableCapacity {
  const TeacherTimetableCapacity();

  Map<int, int> calculate({
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> sections,
    required List<Map<String, Object?>> requirements,
    required List<Map<String, Object?>> qualifications,
    required List<Map<String, Object?>> teacherGrades,
    required List<Map<String, Object?>> teacherSubjectGrades,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    required List<Map<String, Object?>> subjectBlockedSlots,
    required List<Map<String, Object?>> teacherAvailability,
    Map<int, int>? sectionWeeklyDemand,
  }) {
    final activeDays = days.where((d) => _int(d['is_active'], 1) == 1).toList();
    final lessonSlots = slots.where((s) => s['kind'] == 'lesson' &&
        _int(s['is_available'], 1) == 1).toList()..sort(TimetableOrdering.compare);
    final sectionById = {for (final s in sections) _int(s['id']): s};
    final demand = <int, int>{};
    for (final r in requirements) {
      final section = _int(r['section_id']);
      demand[section] = (demand[section] ?? 0) + _int(r['weekly_lessons']).clamp(0, 1000);
    }
    final policy = TeacherAssignmentPolicy(qualifications: qualifications,
      teacherGrades: teacherGrades, teacherSubjectGrades: teacherSubjectGrades);
    final blocked = {for (final b in subjectBlockedSlots)
      '${_int(b['subject_id'])}:${_int(b['slot_id'])}'};
    final unavailable = {for (final a in teacherAvailability)
      if (_int(a['is_available'], 1) == 0)
        '${_int(a['teacher_id'])}:${_int(a['day_id'])}:${_int(a['slot_id'])}'};
    final capacity = <int, int>{};
    for (final teacher in teachers) {
      final id = _int(teacher['id']);
      final eligible = requirements.where((r) {
        final section = sectionById[_int(r['section_id'])];
        return _int(r['weekly_lessons']) > 0 && section != null &&
          policy.isSubjectQualified(id, _int(r['subject_id'])) &&
          policy.isGradeAllowed(id, _int(r['subject_id']), _int(section['grade_id']));
      }).toList();
      var weekly = 0;
      final consecutive = _int(teacher['max_consecutive_lessons']);
      for (final day in activeDays) {
        var run = 0;
        var daily = 0;
        void finishRun() {
          daily += consecutive > 0 ? run - run ~/ (consecutive + 1) : run;
          run = 0;
        }
        for (var rank = 0; rank < lessonSlots.length; rank++) {
          final slot = _int(lessonSlots[rank]['id']);
          final available = !unavailable.contains('$id:${_int(day['id'])}:$slot') &&
            eligible.any((r) {
              if (blocked.contains('${_int(r['subject_id'])}:$slot')) return false;
              final sectionId = _int(r['section_id']);
              final section = sectionById[sectionId]!;
              final normal = SchoolTimetablePolicy.normalDailyLimit(
                section: section, lessonSlotCount: lessonSlots.length);
              return rank < normal || (rank == 6 &&
                SchoolTimetablePolicy.canUseSeventhPeriod(section: section, day: day,
                  activeDays: activeDays, lessonSlots: lessonSlots,
                  weeklyDemand: sectionWeeklyDemand?[sectionId] ?? demand[sectionId] ?? 0));
            });
          if (available) { run++; } else { finishRun(); }
        }
        finishRun();
        final limit = _int(teacher['max_daily_lessons'], 6);
        weekly += limit > 0 && limit < daily ? limit : daily;
      }
      final limit = _int(teacher['weekly_load'], 24);
      capacity[id] = limit > 0 && limit < weekly ? limit : weekly;
    }
    return capacity;
  }
}

int _int(Object? value, [int fallback = 0]) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
