import 'auto_scheduler_service.dart';
import 'conflict_detection_service.dart';
import 'teacher_assignment_policy.dart';

/// A proposal for one weekday occurrence. Availability is applied to this
/// proposal only; the school's recurring teacher availability is never edited.
class TeacherAbsencePlan {
  const TeacherAbsencePlan({
    required this.entries,
    required this.complete,
    required this.affectedCount,
    required this.substitutionCount,
    required this.messages,
    required this.availability,
  });

  final List<Map<String, Object?>> entries;
  final bool complete;
  final int affectedCount;
  final int substitutionCount;
  final List<String> messages;
  final List<Map<String, Object?>> availability;

  Map<String, Object?> toMap() => {
    'entries': entries, 'complete': complete,
    'affectedCount': affectedCount, 'substitutionCount': substitutionCount,
    'messages': messages, 'availability': availability,
  };

  factory TeacherAbsencePlan.fromMap(Map<String, Object?> value) => TeacherAbsencePlan(
    entries: _rows(value['entries']), complete: value['complete'] == true,
    affectedCount: _int(value['affectedCount']),
    substitutionCount: _int(value['substitutionCount']),
    messages: (value['messages'] as List).cast<String>(),
    availability: _rows(value['availability']),
  );
}

class TeacherAbsenceService {
  const TeacherAbsenceService();

  TeacherAbsencePlan plan(
    Map<String, Object?> input, {
    required int teacherId,
    required int dayId,
    List<int> slotIds = const [],
    int nodeLimit = 120000,
  }) {
    List<Map<String, Object?>> rows(String key) => _rows(input[key]);
    final sections = rows('sections');
    final requirements = rows('requirements');
    final teachers = rows('teachers');
    final qualifications = rows('qualifications');
    final teacherGrades = rows('teacherGrades');
    final teacherSubjectGrades = rows('teacherSubjectGrades');
    final blocked = rows('subjectBlockedSlots');
    final days = rows('days');
    final slots = rows('slots');
    final before = rows('entries').map(_placement).toList();
    final locks = <Map<String, Object?>>[];
    for (final row in [
      ...rows('lockedPlacements').map(_placement),
      ...rows('entries').where((e) => _int(e['is_locked']) == 1).map(_placement),
    ]) {
      if (!locks.any((existing) => _samePlacement(existing, row))) locks.add(row);
    }
    final selectedSlots = slotIds.isEmpty
        ? slots.where((s) => s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1)
            .map((s) => _int(s['id'])).toSet()
        : slotIds.toSet();
    final availability = [
      ...rows('teacherAvailability'),
      for (final slot in selectedSlots)
        <String, Object?>{'teacher_id': teacherId, 'day_id': dayId, 'slot_id': slot, 'is_available': 0},
    ];
    TeacherAbsencePlan result({required List<Map<String, Object?>> entries,
        required bool complete, required int affected, required int substitutions,
        required List<String> messages}) => TeacherAbsencePlan(
      entries: entries.map((e) => Map<String, Object?>.from(e)).toList(),
      complete: complete, affectedCount: affected, substitutionCount: substitutions,
      messages: messages, availability: availability,
    );
    if (!teachers.any((t) => _int(t['id']) == teacherId) ||
        !days.any((d) => _int(d['id']) == dayId && _int(d['is_active'], fallback: 1) == 1) ||
        selectedSlots.isEmpty || selectedSlots.any((id) => !slots.any((s) =>
          _int(s['id']) == id && s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1))) {
      return result(entries: const [], complete: false, affected: 0, substitutions: 0,
        messages: const ['اختيار المعلم أو يوم الدوام أو الفترات غير صالح.']);
    }
    final affectedIndices = <int>[
      for (var i = 0; i < before.length; i++)
        if (_int(before[i]['teacher_id']) == teacherId &&
            _int(before[i]['day_id']) == dayId && selectedSlots.contains(_int(before[i]['slot_id']))) i,
    ];
    if (locks.any((e) => _int(e['teacher_id']) == teacherId &&
        _int(e['day_id']) == dayId && selectedSlots.contains(_int(e['slot_id'])))) {
      return result(entries: before, complete: false, affected: affectedIndices.length,
        substitutions: 0, messages: const [
          'توجد حصة مثبتة للمعلم في فترة غيابه. ألغِ تثبيت هذه الحصة أو غيّر فترة الغياب ثم أعد المحاولة.',
        ]);
    }
    List<ConflictIssue> issues(List<Map<String, Object?>> entries) => const ConflictDetectionService().scan(
      entries: entries, requirements: requirements, sections: sections, slots: slots,
      teachers: teachers, qualifications: qualifications, days: days,
      teacherGrades: teacherGrades, teacherSubjectGrades: teacherSubjectGrades,
      subjectBlockedSlots: blocked, teacherAvailability: availability,
    ).where((issue) => issue.type != 'تكرار توقيت المادة في أيام متتالية').toList();
    bool locksMatch(List<Map<String, Object?>> entries) => locks.every((lock) =>
      entries.any((entry) => _samePlacement(entry, lock)));
    if (affectedIndices.isEmpty && issues(before).isEmpty && locksMatch(before)) {
      return result(entries: before, complete: true, affected: 0, substitutions: 0,
        messages: const ['لا توجد حصص للمعلم في الفترات المحددة؛ الجدول لا يحتاج إلى تعديل.']);
    }
    final policy = TeacherAssignmentPolicy(
      qualifications: qualifications, teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
    );
    final sectionById = {for (final s in sections) _int(s['id']): s};
    final working = before.map((e) => Map<String, Object?>.from(e)).toList();
    var attempts = 0;
    final substitutionBudget = nodeLimit.clamp(1, 3000).toInt();
    bool substitute(int index) {
      if (attempts++ >= substitutionBudget) return false;
      if (index == affectedIndices.length) return issues(working).isEmpty && locksMatch(working);
      final rowIndex = affectedIndices[index];
      final entry = working[rowIndex];
      final subject = _int(entry['subject_id']);
      final grade = _int(sectionById[_int(entry['section_id'])]?['grade_id']);
      final eligible = teachers.where((t) {
        final id = _int(t['id']);
        return id != teacherId && policy.isSubjectQualified(id, subject) &&
            policy.isGradeAllowed(id, subject, grade);
      }).toList()..sort((a, b) => _int(a['id']).compareTo(_int(b['id'])));
      for (final teacher in eligible) {
        entry['teacher_id'] = _int(teacher['id']);
        final pendingSlots = affectedIndices.skip(index + 1)
            .map((i) => _int(working[i]['slot_id'])).toSet();
        final valid = issues(working).every((issue) =>
          issue.type == 'المعلم غير متاح في الفترة' && issue.teacherId == teacherId &&
          issue.dayId == dayId && pendingSlots.contains(issue.slotId));
        if (valid && substitute(index + 1)) return true;
      }
      entry['teacher_id'] = teacherId;
      return false;
    }
    if (affectedIndices.isNotEmpty && substitute(0)) {
      return result(entries: working, complete: true, affected: affectedIndices.length,
        substitutions: affectedIndices.length, messages: [
          'وُجد بديل مؤهل لـ${affectedIndices.length} حصة دون تغيير توقيت بقية الدروس.',
        ]);
    }
    // The whole-week solver may exchange other days when substitutions alone
    // cannot cover the absence. It receives the original seed, never a failed
    // intermediate substitution branch.
    final generated = AutoSchedulerService(nodeLimit: nodeLimit).generate(
      sections: sections, requirements: requirements, teachers: teachers,
      qualifications: qualifications, teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades, subjectBlockedSlots: blocked,
      days: days, slots: slots, teacherAvailability: availability,
      initialPlacements: before, lockedPlacements: locks,
    );
    final valid = generated.complete && issues(generated.placements).isEmpty &&
        locksMatch(generated.placements);
    return result(entries: generated.placements, complete: valid,
      affected: affectedIndices.length, substitutions: 0,
      messages: valid
          ? const ['وُجد توزيع كامل يراعي الغياب. قد تشمل التغييرات بقية أيام الأسبوع؛ راجع المقارنة قبل الحفظ.']
          : [
              'لم أجد خطة كاملة ضمن القيود وميزانية البحث. لم تُحذف حصص من الجدول الحالي ولم تتغير إتاحات المعلمين المحفوظة.',
              ...generated.unscheduled,
              ...generated.dailySpreadIssues,
            ]);
  }
}

List<Map<String, Object?>> _rows(Object? value) => (value as List? ?? const [])
    .map((row) => Map<String, Object?>.from(row as Map)).toList();
int _int(Object? value, {int fallback = 0}) => value is num
    ? value.toInt() : int.tryParse('$value') ?? fallback;
Map<String, Object?> _placement(Map<String, Object?> row) => {
  for (final key in ['section_id', 'subject_id', 'teacher_id', 'day_id', 'slot_id', 'room_id']) key: row[key],
};
bool _samePlacement(Map<String, Object?> a, Map<String, Object?> b) =>
    ['section_id', 'subject_id', 'teacher_id', 'day_id', 'slot_id', 'room_id'].every((k) => a[k] == b[k]);
