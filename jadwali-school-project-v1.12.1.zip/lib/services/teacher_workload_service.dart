import '../core/timetable_ordering.dart';
/// Pure calculation of teacher weekly load; suitable for tests and reports.
class TeacherWorkloadService {
  const TeacherWorkloadService();

  List<Map<String, Object?>> calculate({
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
  }) {
    final activeDays = days.where((d) => _int(d['is_active'], fallback: 1) == 1).toList();
    final lessonSlots = slots.where((s) => s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1).toList()
      ..sort((a, b) => TimetableOrdering.compare(a, b));
    final slotOrder = <int, int>{for (var i = 0; i < lessonSlots.length; i++) _int(lessonSlots[i]['id']): i};
    final results = <Map<String, Object?>>[];
    for (final teacher in teachers) {
      final id = _int(teacher['id']);
      final assigned = entries.where((entry) => _int(entry['teacher_id'], fallback: -1) == id).toList();
      final dailyCounts = <int, int>{};
      final occupiedByDay = <int, Set<int>>{};
      for (final entry in assigned) {
        final dayId = _int(entry['day_id']);
        final rank = slotOrder[_int(entry['slot_id'])];
        dailyCounts[dayId] = (dailyCounts[dayId] ?? 0) + 1;
        if (rank != null) (occupiedByDay[dayId] ??= <int>{}).add(rank);
      }
      var gaps = 0;
      for (final occupied in occupiedByDay.values) {
        if (occupied.length < 2) continue;
        final sorted = occupied.toList()..sort();
        gaps += sorted.last - sorted.first + 1 - sorted.length;
      }
      final target = _int(teacher['weekly_load']);
      final actual = assigned.length;
      results.add({
        'teacher_id': id,
        'teacher_name': teacher['name'] ?? 'المعلم $id',
        'target_load': target,
        'assigned_lessons': actual,
        'remaining': actual < target ? target - actual : 0,
        'overload': actual > target ? actual - target : 0,
        'days_with_lessons': dailyCounts.length,
        'active_days': activeDays.length,
        'daily_counts': Map<int, int>.unmodifiable(dailyCounts),
        'gaps': gaps,
      });
    }
    results.sort((a, b) => '${a['teacher_name']}'.compareTo('${b['teacher_name']}'));
    return List<Map<String, Object?>>.unmodifiable(results);
  }

  static int _int(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
