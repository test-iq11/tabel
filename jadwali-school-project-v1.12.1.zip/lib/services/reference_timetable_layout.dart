import 'dart:math' as math;

import '../core/timetable_ordering.dart';
import 'timetable_report_layout.dart';

/// The school's paper form, in logical RTL order: day, period, then a pair
/// (subject, teacher) for each class. Exporters share this model so no format
/// can accidentally drop Sunday period seven or reverse the class order.
class ReferenceTimetableLayout {
  ReferenceTimetableLayout({
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> sections,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    this.templateColumns = true,
  }) : entries = List.unmodifiable(entries) {
    final ordered = TimetableReportLayout(
      entries: entries,
      sections: sections,
      days: days,
      slots: slots,
    );
    this.sections = [...ordered.sections];
    // Include an archived/disabled day or period if it still contains a lesson.
    // A report must faithfully show saved data, even when settings have changed.
    this.days = _usedAndActive(
      days,
      entries,
      'day',
      (row) => number(row['is_active'], 1) == 1,
    );
    this.slots = _usedAndActive(
      slots,
      entries,
      'slot',
      (row) => row['kind'] == 'lesson' && number(row['is_available'], 1) == 1,
    );
    final sectionIds = this.sections.map((s) => number(s['id'])).toSet();
    for (final entry in entries) {
      final id = number(entry['section_id']);
      if (sectionIds.add(id)) {
        this.sections.add({
          'id': id,
          'grade_name': entry['grade_name'] ?? '',
          'section_name': entry['section_name'] ?? 'الشعبة $id',
        });
      }
      final key =
          '${entry['section_id']}:${entry['day_id']}:${entry['slot_id']}';
      (_cells[key] ??= []).add(entry);
    }
  }

  final List<Map<String, Object?>> entries;
  final bool templateColumns;
  late final List<Map<String, Object?>> sections;
  late final List<Map<String, Object?>> days;
  late final List<Map<String, Object?>> slots;
  final _cells = <String, List<Map<String, Object?>>>{};

  static int number(Object? value, [int fallback = 0]) =>
      value is num ? value.toInt() : int.tryParse('$value') ?? fallback;

  static String arabic(Object value) => '$value'.replaceAllMapped(
    RegExp(r'\d'),
    (m) => '٠١٢٣٤٥٦٧٨٩'[int.parse(m[0]!)],
  );

  static List<Map<String, Object?>> _usedAndActive(
    List<Map<String, Object?>> source,
    List<Map<String, Object?>> entries,
    String kind,
    bool Function(Map<String, Object?>) active,
  ) {
    final used = entries.map((e) => number(e['${kind}_id'])).toSet();
    final result = source
        .where((row) => active(row) || used.contains(number(row['id'])))
        .toList();
    final known = result.map((row) => number(row['id'])).toSet();
    for (final entry in entries) {
      final id = number(entry['${kind}_id']);
      if (known.add(id)) {
        result.add({
          'id': id,
          'name':
              entry['${kind}_name'] ?? '${kind == 'day' ? 'يوم' : 'حصة'} $id',
          'position': entry['${kind}_position'] ?? id,
        });
      }
    }
    result.sort(TimetableOrdering.compare);
    return result;
  }

  String sectionTitle(Map<String, Object?> section) {
    final grade =
        '${section['grade_name'] ?? section['section_grade_name'] ?? ''}'
            .replaceFirst(RegExp(r'^\s*الصف\s+'), '')
            .replaceFirst(RegExp(r'\s+الابتدائي\s*$'), '')
            .trim();
    final name = '${section['section_name'] ?? ''}'.trim();
    return [
      if (grade.isNotEmpty) 'الصف $grade',
      if (name.isNotEmpty) name,
    ].join(' / ');
  }

  /// More than twelve classes produce additional pages/sheets; none are clipped.
  List<List<Map<String, Object?>?>> get classGroups {
    final groups = <List<Map<String, Object?>?>>[];
    for (var start = 0; start < math.max(1, sections.length); start += 12) {
      final group = <Map<String, Object?>?>[...sections.skip(start).take(12)];
      final count = templateColumns ? 12 : math.max(1, group.length);
      while (group.length < count) {
        group.add(null);
      }
      groups.add(group);
    }
    return groups;
  }

  List<Map<String, Object?>> periodsForDay(
    Map<String, Object?> day,
    List<Map<String, Object?>?> group,
  ) {
    final ids = group
        .whereType<Map<String, Object?>>()
        .map((s) => number(s['id']))
        .toSet();
    var normal = 0;
    for (final section in group.whereType<Map<String, Object?>>()) {
      normal = math.max(normal, number(section['max_daily_lessons'], 6));
    }
    if (normal <= 0) normal = 6;
    var count = math.min(normal, slots.length);
    for (final entry in entries) {
      if (entry['day_id'] != day['id'] ||
          !ids.contains(number(entry['section_id'])))
        continue;
      final index = slots.indexWhere((s) => s['id'] == entry['slot_id']);
      count = math.max(count, index + 1);
    }
    return slots.take(count).toList();
  }

  List<Map<String, Object?>> entriesAt(
    Map<String, Object?>? section,
    Map<String, Object?> day,
    Map<String, Object?> slot,
  ) => section == null
      ? const []
      : _cells['${section['id']}:${day['id']}:${slot['id']}'] ?? const [];

  String cellText(
    Map<String, Object?>? section,
    Map<String, Object?> day,
    Map<String, Object?> slot, {
    required bool teacher,
  }) => entriesAt(section, day, slot)
      .map(
        (e) =>
            '${e[teacher ? 'teacher_name' : 'subject_name'] ?? (teacher ? 'غير مسند' : 'مادة')}',
      )
      .join('\n');

  int lessonNumber(Map<String, Object?> slot) => slots.indexOf(slot) + 1;
  int rowCount(List<Map<String, Object?>?> group) =>
      days.fold(0, (total, day) => total + periodsForDay(day, group).length);

  // Shared day colors: all classes and both subject/teacher columns use one
  // color for a day. Separators remain white in every export format.
  static const dayColors = <int>[
    0xFFEAF4FF,
    0xFFEBF6EA,
    0xFFFFF3DC,
    0xFFF2EBFA,
    0xFFFCE9ED,
    0xFFE5F5F2,
    0xFFF0F0E6,
  ];
  int dayColor(Map<String, Object?> day) =>
      dayColors[days.indexOf(day).clamp(0, days.length) % dayColors.length];
  static bool separatorColumn(int column) =>
      column >= 4 && (column - 4) % 3 == 0;
  List<Map<String, Object?>?> rowDays(List<Map<String, Object?>?> group) => [
    null,
    null,
    for (var i = 0; i < days.length; i++) ...[
      if (i > 0) null,
      for (final _ in periodsForDay(days[i], group)) days[i],
    ],
  ];
  List<List<String>> separatedRows(List<Map<String, Object?>?> group) {
    List<String> spaced(List<String> row) => [
      row[0],
      row[1],
      for (var i = 0; i < group.length; i++) ...[
        if (i > 0) '',
        row[2 + i * 2],
        row[3 + i * 2],
      ],
    ];
    final raw = rows(group);
    var offset = 2;
    final result = [spaced(raw[0]), spaced(raw[1])];
    for (var i = 0; i < days.length; i++) {
      if (i > 0) result.add(List.filled(result.first.length, ''));
      for (var n = 0; n < periodsForDay(days[i], group).length; n++) {
        result.add(spaced(raw[offset++]));
      }
    }
    return result;
  }

  List<List<String>> rows(List<Map<String, Object?>?> group) => [
    [
      'اليوم',
      'الدرس',
      for (final section in group) ...[
        section == null ? '' : sectionTitle(section),
        '',
      ],
    ],
    [
      '',
      '',
      for (var i = 0; i < group.length; i++) ...['المادة', 'المعلم'],
    ],
    for (final day in days)
      for (final slot in periodsForDay(day, group))
        [
          '${day['name'] ?? ''}',
          arabic(lessonNumber(slot)),
          for (final section in group) ...[
            cellText(section, day, slot, teacher: false),
            cellText(section, day, slot, teacher: true),
          ],
        ],
  ];
}
