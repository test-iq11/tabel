import 'school_timetable_policy.dart';

/// One-off repeat policy for a weekly requirement that cannot fit one lesson
/// per active day. It does not change saved settings: it permits at most a
/// necessary second occurrence only in period 6, or period 7 for the sixth
/// grade on Sunday when that special period is actually needed and configured.
class RequiredRepeatPolicy {
  const RequiredRepeatPolicy._();

  static bool allowsLatePeriodRepeat({
    required Map<String, Object?> requirement,
    required Map<String, Object?> section,
    required List<Map<String, Object?>> activeDays,
    required int sectionWeeklyDemand,
    required List<Map<String, Object?>> lessonSlots,
    required List<Map<String, Object?>> subjectBlockedSlots,
  }) {
    final weekly = _int(requirement['weekly_lessons']);
    if (activeDays.isEmpty || weekly <= activeDays.length ||
        _int(requirement['allow_same_day']) == 1) {
      return false;
    }

    final sectionLimitValue = _int(section['max_daily_lessons'], fallback: 6);
    final sectionDailyLimit = sectionLimitValue > 0
        ? sectionLimitValue
        : lessonSlots.length;
    if (sectionDailyLimit < 6) return false;

    final subjectId = _int(requirement['subject_id']);
    final blocked = <int>{
      for (final row in subjectBlockedSlots)
        if (_int(row['subject_id']) == subjectId) _int(row['slot_id']),
    };

    // Keep one normal-period slot for the first occurrence and a later period
    // for the only implicit duplicate on a day.
    final hasEarlySlot = lessonSlots.asMap().entries.any((entry) =>
        entry.key < 5 && entry.key < sectionDailyLimit &&
        !blocked.contains(_int(entry.value['id'])));

    final seventhPeriodAllowed = SchoolTimetablePolicy.isSixthGrade(section) &&
        SchoolTimetablePolicy.normalDailyLimit(
          section: section,
          lessonSlotCount: lessonSlots.length,
        ) >= 6 &&
        lessonSlots.length >= 7 &&
        activeDays.any(SchoolTimetablePolicy.isSunday) &&
        sectionWeeklyDemand > activeDays.length * 6;
    final hasLateSlot = lessonSlots.asMap().entries.any((entry) {
      final rank = entry.key;
      if (rank != 5 && !(rank == 6 && seventhPeriodAllowed)) return false;
      if (rank >= sectionDailyLimit && !(rank == 6 && seventhPeriodAllowed)) return false;
      return !blocked.contains(_int(entry.value['id']));
    });

    return hasEarlySlot && hasLateSlot;
  }

  static int _int(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
