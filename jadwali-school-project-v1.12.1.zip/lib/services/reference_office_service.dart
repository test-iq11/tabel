import 'dart:convert';
import 'dart:typed_data';

import 'reference_timetable_layout.dart';
import 'report_day_colors.dart';

/// Native, offline OOXML exports. The paper model is shared with PDF and the
/// on-screen preview. No spreadsheet import or external office app is needed.
class ReferenceOfficeService {
  const ReferenceOfficeService();

  Uint8List timetable({
    required ReferenceTimetableLayout layout,
    required String schoolName,
    required bool word,
    String paper = 'A3',
    String number = '1',
    String date = '',
    String manager = '',
  }) {
    final groups = layout.classGroups;
    final pages = <_Sheet>[];
    for (var i = 0; i < groups.length; i++) {
      final group = groups[i];
      final rows = layout.rows(group);
      final merge = <_Merge>[
        const _Merge(0, 0, 1, 0),
        const _Merge(0, 1, 1, 1),
        for (var c = 2; c < rows.first.length; c += 3) _Merge(0, c, 0, c + 1),
      ];
      var start = 2;
      for (final day in layout.days) {
        final count = layout.periodsForDay(day, group).length;
        if (count > 1) merge.add(_Merge(start, 0, start + count - 1, 0));
        start += count + (day != layout.days.last ? 1 : 0);
      }
      pages.add(
        _Sheet(
          rows: rows,
          merges: merge,
          reference: true,
          layout: layout,
          group: group,
          title:
              'جدول الدروس الاسبوعي رقم (${ReferenceTimetableLayout.arabic(number)})',
          school:
              'إدارة مدرسة: ${schoolName.replaceFirst(RegExp(r'^\s*مدرسة\s+'), '')}',
          date: 'يعمل بموجبه اعتباراً من تاريخ $date',
          footer: 'مدير المدرسة: $manager',
        ),
      );
    }
    return word ? _docx(pages, paper) : _xlsx(pages, paper);
  }

  Uint8List list({
    required String title,
    required String schoolName,
    required List<List<String>> rows,
    required bool word,
    String paper = 'A3',
  }) {
    final sheet = _Sheet(
      title: title,
      school: schoolName,
      rows: rows.isEmpty
          ? [
              ['لا توجد بيانات'],
            ]
          : rows,
    );
    return word ? _docx([sheet], paper) : _xlsx([sheet], paper);
  }

  String _x(String s) => s
      .replaceAll(RegExp(r'[\x00-\x08\x0B\x0C\x0E-\x1F]'), '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&apos;');
  String _col(int n) {
    var result = '';
    for (var v = n + 1; v > 0; v = (v - 1) ~/ 26) {
      result = String.fromCharCode(65 + (v - 1) % 26) + result;
    }
    return result;
  }

  Uint8List _xlsx(List<_Sheet> sheets, String paper) {
    const ns = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
    const rel =
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
    final files = <String, String>{
      '[Content_Types].xml':
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${List.generate(sheets.length, (i) => '<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join()}</Types>',
      '_rels/.rels':
          '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="$rel/officeDocument" Target="xl/workbook.xml"/></Relationships>',
      'xl/workbook.xml':
          '<workbook xmlns="$ns" xmlns:r="$rel"><bookViews><workbookView/></bookViews><sheets>${List.generate(sheets.length, (i) => '<sheet name="جدول ${i + 1}" sheetId="${i + 1}" r:id="rId${i + 1}"/>').join()}</sheets></workbook>',
      'xl/_rels/workbook.xml.rels':
          '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${List.generate(sheets.length, (i) => '<Relationship Id="rId${i + 1}" Type="$rel/worksheet" Target="worksheets/sheet${i + 1}.xml"/>').join()}<Relationship Id="styles" Type="$rel/styles" Target="styles.xml"/></Relationships>',
      'xl/styles.xml': _styles(),
    };
    for (var i = 0; i < sheets.length; i++) {
      final sheet = sheets[i];
      final columns = sheet.rows.first.length;
      final last = _col(columns - 1);
      final body = StringBuffer();
      String cell(String value, int row, int col, int style) =>
          '<c r="${_col(col)}$row" s="$style" t="inlineStr"><is><t xml:space="preserve">${_x(value)}</t></is></c>';
      final merges = <String>[];
      body.write('<row r="1" ht="30" customHeight="1">');
      // Three fields occupy the same positions as the supplied landscape form.
      if (columns >= 8) {
        final split = columns ~/ 3;
        body.write(cell(sheet.school, 1, 0, 4));
        body.write(cell(sheet.title, 1, split, 4));
        body.write(cell(sheet.date, 1, split * 2, 4));
        merges.addAll([
          'A1:${_col(split - 1)}1',
          '${_col(split)}1:${_col(split * 2 - 1)}1',
          '${_col(split * 2)}1:${last}1',
        ]);
      } else {
        body.write(
          cell('${sheet.school}\n${sheet.title}\n${sheet.date}', 1, 0, 4),
        );
        if (columns > 1) merges.add('A1:${last}1');
      }
      body.write('</row><row r="2" ht="10" customHeight="1"/>');
      for (var r = 0; r < sheet.rows.length; r++) {
        body.write(
          '<row r="${r + 3}" ht="${sheet.reference && sheet.layout!.separatorRow(r, sheet.group!) ? 9 : (sheet.reference ? 21 : 30)}" customHeight="1">',
        );
        for (var c = 0; c < columns; c++) {
          final covering = sheet.merges.where((m) => m.covers(r, c));
          final merge = covering.isEmpty ? null : covering.first;
          final value = merge != null && (merge.r != r || merge.c != c)
              ? ''
              : sheet.rows[r][c];
          final dayIndex = sheet.layout?.dayIndexAtRow(r, sheet.group!) ?? -1;
          final gapColumn = sheet.reference && r >= 0 && c >= 2 &&
              sheet.layout!.separatorColumn(c, sheet.group!);
          final gapRow = sheet.reference &&
              sheet.layout!.separatorRow(r, sheet.group!);
          final style = sheet.reference
              ? (gapColumn || gapRow
                    ? 0
                    : dayIndex >= 0
                        ? 5 + dayIndex % ReportDayColors.shades.length
                        : c == 0 && r > 1
                            ? 3
                            : c == 1 || r == 1 ? 2 : 1)
              : (r == 0 ? 2 : 1);
          body.write(cell(value, r + 3, c, style));
        }
        body.write('</row>');
      }
      for (final m in sheet.merges) {
        merges.add('${_col(m.c)}${m.r + 3}:${_col(m.endC)}${m.endR + 3}');
      }
      final footerRow = sheet.rows.length + 4;
      body.write(
        '<row r="$footerRow" ht="30" customHeight="1">${cell(sheet.footer, footerRow, 0, 4)}</row>',
      );
      if (columns > 1) merges.add('A$footerRow:$last$footerRow');
      final widths = sheet.reference
          ? '<col min="1" max="1" width="9" customWidth="1"/><col min="2" max="2" width="5" customWidth="1"/>'
            '${List.generate(columns - 2, (i) => '<col min="${i + 3}" max="${i + 3}" width="${sheet.layout!.separatorColumn(i + 2, sheet.group!) ? 3 : 12}" customWidth="1"/>').join()}'
          : '<col min="1" max="$columns" width="22" customWidth="1"/>';
      files['xl/worksheets/sheet${i + 1}.xml'] =
          '<worksheet xmlns="$ns"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:$last$footerRow"/><sheetViews><sheetView rightToLeft="1" showGridLines="0" workbookViewId="0"><pane xSplit="${sheet.reference ? 2 : 0}" ySplit="${sheet.reference ? 4 : 3}" topLeftCell="${sheet.reference ? 'C5' : 'A4'}" activePane="${sheet.reference ? 'bottomRight' : 'bottomLeft'}" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="21"/><cols>$widths</cols><sheetData>$body</sheetData><mergeCells count="${merges.length}">${merges.map((m) => '<mergeCell ref="$m"/>').join()}</mergeCells><pageMargins left="0.25" right="0.25" top="0.3" bottom="0.3" header="0.1" footer="0.1"/><pageSetup paperSize="${paper == 'A4' ? 9 : 8}" orientation="landscape" fitToWidth="1" fitToHeight="${sheet.reference ? 1 : 0}"/></worksheet>';
    }
    return _zip(files);
  }

  String _styles() {
    String style(int fill, int border, {bool rotate = false}) =>
        '<xf numFmtId="0" fontId="0" fillId="$fill" borderId="$border" xfId="0" applyAlignment="1" applyBorder="1" applyFill="1"><alignment horizontal="center" vertical="center" wrapText="1" readingOrder="2"${rotate ? ' textRotation="90"' : ''}/></xf>';
    return '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Arial"/><family val="2"/></font></fonts><fills count="${3 + ReportDayColors.shades.length}"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE4E4E4"/><bgColor indexed="64"/></patternFill></fill>${ReportDayColors.shades.map((hex) => '<fill><patternFill patternType="solid"><fgColor rgb="FF$hex"/><bgColor indexed="64"/></patternFill></fill>').join()}</fills><borders count="2"><border/><border><left style="thin"/><right style="thin"/><top style="thin"/><bottom style="thin"/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${5 + ReportDayColors.shades.length}">${style(0, 0)}${style(0, 1)}${style(2, 1)}${style(0, 1, rotate: true)}${style(0, 0)}${List.generate(ReportDayColors.shades.length, (i) => style(3 + i, 1)).join()}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
  }

  String _paragraph(String value, {int size = 18}) =>
      '<w:p><w:pPr><w:bidi/><w:jc w:val="center"/><w:spacing w:before="0" w:after="0"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:rtl/><w:sz w:val="$size"/><w:szCs w:val="$size"/></w:rPr>${value.split('\n').map((v) => '<w:t xml:space="preserve">${_x(v)}</w:t>').join('<w:br/>')}</w:r></w:p>';

  Uint8List _docx(List<_Sheet> sheets, String paper) {
    final body = StringBuffer();
    final totalWidth = paper == 'A4' ? 15700 : 22600;
    for (var page = 0; page < sheets.length; page++) {
      final sheet = sheets[page];
      if (page > 0) body.write('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
      body.write(
        '<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="$totalWidth" w:type="dxa"/><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid>${List.filled(3, '<w:gridCol w:w="${totalWidth ~/ 3}"/>').join()}</w:tblGrid><w:tr>',
      );
      for (final value in [sheet.school, sheet.title, sheet.date]) {
        body.write(
          '<w:tc><w:tcPr><w:tcW w:w="${totalWidth ~/ 3}" w:type="dxa"/></w:tcPr>${_paragraph(value, size: 20)}</w:tc>',
        );
      }
      body.write('</w:tr></w:tbl>${_paragraph('', size: 6)}');
      final columns = sheet.rows.first.length;
      final widths = sheet.reference
          ? <int>[
              900, 500,
              for (var c = 2; c < columns; c++)
                sheet.layout!.separatorColumn(c, sheet.group!) ? 65 :
                (totalWidth - 1400 - 65 * (sheet.group!.length - 1)) ~/
                  (sheet.group!.length * 2),
            ]
          : List.filled(columns, totalWidth ~/ columns);
      body.write(
        '<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="$totalWidth" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders>${['top', 'bottom', 'left', 'right', 'insideH', 'insideV'].map((side) => '<w:$side w:val="single" w:sz="6" w:color="000000"/>').join()}</w:tblBorders><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:left w:w="20" w:type="dxa"/><w:right w:w="20" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>${widths.map((w) => '<w:gridCol w:w="$w"/>').join()}</w:tblGrid>',
      );
      for (var r = 0; r < sheet.rows.length; r++) {
        body.write(
          '<w:tr><w:trPr><w:cantSplit/>${r < (sheet.reference ? 2 : 1) ? '<w:tblHeader/>' : ''}<w:trHeight w:val="${paper == 'A4' ? 265 : 390}" w:hRule="atLeast"/></w:trPr>',
        );
        for (var c = 0; c < columns; c++) {
          final covering = sheet.merges.where((m) => m.covers(r, c));
          final merge = covering.isEmpty ? null : covering.first;
          if (merge != null && c != merge.c) continue;
          final span = merge == null ? 1 : merge.endC - merge.c + 1;
          final continuation = merge != null && r != merge.r;
          final width = widths.skip(c).take(span).fold(0, (a, b) => a + b);
          final grey = sheet.reference ? (r == 1 || c == 1) : r == 0;
          final dayIndex = sheet.layout?.dayIndexAtRow(r, sheet.group!) ?? -1;
          final isGap = sheet.reference &&
              (sheet.layout!.separatorRow(r, sheet.group!) ||
                  sheet.layout!.separatorColumn(c, sheet.group!));
          final fill = isGap ? 'FFFFFF' : dayIndex >= 0
              ? ReportDayColors.hex(dayIndex)
              : grey ? 'E4E4E4' : 'FFFFFF';
          final gapBorders = isGap
              ? '<w:tcBorders>${['top', 'bottom', 'left', 'right'].map((side) => '<w:$side w:val="nil"/>').join()}</w:tcBorders>'
              : '';
          body.write(
            '<w:tc><w:tcPr><w:tcW w:w="$width" w:type="dxa"/>${span > 1 ? '<w:gridSpan w:val="$span"/>' : ''}${merge != null && merge.endR > merge.r ? '<w:vMerge w:val="${continuation ? 'continue' : 'restart'}"/>' : ''}<w:shd w:fill="$fill"/>$gapBorders<w:vAlign w:val="center"/>${sheet.reference && c == 0 && r > 1 ? '<w:textDirection w:val="btLr"/>' : ''}</w:tcPr>${_paragraph(continuation ? '' : sheet.rows[r][c], size: sheet.reference ? (paper == 'A4' ? 12 : 16) : 18)}</w:tc>',
          );
        }
        body.write('</w:tr>');
      }
      body.write(
        '</w:tbl>${_paragraph('', size: 8)}${_paragraph(sheet.footer, size: 22)}',
      );
    }
    body.write(
      '<w:sectPr><w:pgSz w:w="${paper == 'A4' ? 16838 : 23811}" w:h="${paper == 'A4' ? 11906 : 16838}" w:orient="landscape"/><w:pgMar w:top="400" w:right="500" w:bottom="400" w:left="500" w:header="100" w:footer="100" w:gutter="0"/></w:sectPr>',
    );
    return _zip({
      '[Content_Types].xml': '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>',
      '_rels/.rels': '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
      'word/document.xml':
          '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>$body</w:body></w:document>',
    });
  }

  /// ZIP's stored method keeps this exporter pure Dart and independently
  /// testable. Names are ASCII and file content is UTF-8 XML.
  Uint8List _zip(Map<String, String> files) {
    final out = BytesBuilder(copy: false),
        directory = BytesBuilder(copy: false);
    Uint8List header(int size, void Function(ByteData) write) {
      final bytes = Uint8List(size);
      write(ByteData.sublistView(bytes));
      return bytes;
    }

    for (final file in files.entries) {
      final name = utf8.encode(file.key);
      final bytes = utf8.encode(
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>${file.value}',
      );
      var crc = 0xffffffff;
      for (final b in bytes) {
        crc ^= b;
        for (var i = 0; i < 8; i++) {
          crc = (crc >> 1) ^ ((crc & 1) == 1 ? 0xedb88320 : 0);
        }
      }
      crc = (crc ^ 0xffffffff) & 0xffffffff;
      final offset = out.length;
      out.add(
        header(30, (b) {
          b.setUint32(0, 0x04034b50, Endian.little);
          b.setUint16(4, 20, Endian.little);
          b.setUint16(
            12,
            33,
            Endian.little,
          ); // 1980-01-01, deterministic ZIP date.
          b.setUint32(14, crc, Endian.little);
          b.setUint32(18, bytes.length, Endian.little);
          b.setUint32(22, bytes.length, Endian.little);
          b.setUint16(26, name.length, Endian.little);
        }),
      );
      out.add(name);
      out.add(bytes);
      directory.add(
        header(46, (b) {
          b.setUint32(0, 0x02014b50, Endian.little);
          b.setUint16(4, 20, Endian.little);
          b.setUint16(6, 20, Endian.little);
          b.setUint16(14, 33, Endian.little);
          b.setUint32(16, crc, Endian.little);
          b.setUint32(20, bytes.length, Endian.little);
          b.setUint32(24, bytes.length, Endian.little);
          b.setUint16(28, name.length, Endian.little);
          b.setUint32(42, offset, Endian.little);
        }),
      );
      directory.add(name);
    }
    final offset = out.length, size = directory.length;
    out.add(directory.takeBytes());
    out.add(
      header(22, (b) {
        b.setUint32(0, 0x06054b50, Endian.little);
        b.setUint16(8, files.length, Endian.little);
        b.setUint16(10, files.length, Endian.little);
        b.setUint32(12, size, Endian.little);
        b.setUint32(16, offset, Endian.little);
      }),
    );
    return out.takeBytes();
  }
}

class _Sheet {
  const _Sheet({
    required this.rows,
    this.layout,
    this.group,
    required this.title,
    required this.school,
    this.date = '',
    this.footer = '',
    this.merges = const [],
    this.reference = false,
  });
  final List<List<String>> rows;
  final ReferenceTimetableLayout? layout;
  final List<Map<String, Object?>?>? group;
  final List<_Merge> merges;
  final String title, school, date, footer;
  final bool reference;
}

class _Merge {
  const _Merge(this.r, this.c, this.endR, this.endC);
  final int r, c, endR, endC;
  bool covers(int row, int col) =>
      row >= r && row <= endR && col >= c && col <= endC;
}
