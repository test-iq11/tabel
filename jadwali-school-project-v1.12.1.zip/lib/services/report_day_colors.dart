/// Print-safe, low-saturation backgrounds. Every class and period in the
/// same school day shares a single color in PDF, Excel, Word and preview.
class ReportDayColors {
  static const shades = <String>[
    'E5F3ED', // Sunday — pale mint
    'E7F0FC', // Monday — pale blue
    'FFF0DE', // Tuesday — warm cream
    'F0EAF9', // Wednesday — pale lilac
    'FDEBEA', // Thursday — pale rose
    'EAF3F4', // Friday / additional working day
    'F5F0E2', // Saturday / additional working day
  ];

  static String hex(int index) => shades[index % shades.length];
  static int argb(int index) => int.parse('FF${hex(index)}', radix: 16);
}
