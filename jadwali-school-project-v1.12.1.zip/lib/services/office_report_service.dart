import 'dart:typed_data';

import 'package:archive/archive.dart';

import 'timetable_report_layout.dart';

/// Builds real Microsoft Office Open XML files without relying on an external
/// office application. DOCX/XLSX files retain Arabic text and A3 landscape setup.
class OfficeReportService {
  Future<Uint8List> buildDocx({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> sections,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
  }) async {
    final data = TimetableReportLayout(entries: entries, sections: sections, days: days, slots: slots);
    final body = StringBuffer();
    body.write(_wordParagraph(schoolName, size: 22, bold: true, color: '183B66'));
    body.write(_wordParagraph('الجدول الأسبوعي الشامل', size: 18, bold: true, color: '183B66'));
    body.write(_wordParagraph('العام الدراسي: $academicYear    |    النسخة: $versionName    |    الحالة: $status', size: 13));
    body.write(_wordParagraph('تاريخ التصدير: ${_dateStamp(DateTime.now())}', size: 12));
    body.write(_wordParagraph('الأيام عمودية والصفوف والشعب أفقية', size: 13, bold: true, color: '183B66'));
    body.write(_wordParagraph('', size: 4));

    if (data.sections.isEmpty) {
      body.write(_wordParagraph('لا توجد شعب أو جداول للطباعة. أضف الصفوف والشعب ثم أنشئ الجدول الأسبوعي.', size: 22));
    } else if (data.days.isEmpty || data.slots.isEmpty) {
      body.write(_wordParagraph('لا توجد أيام دوام أو حصص متاحة. راجع إعدادات المدرسة وأوقات الحصص.', size: 22));
    } else {
      body.write(_wordTable(_officeRows(data))); 
    }
    body.write('''<w:sectPr><w:pgSz w:w="23811" w:h="16838" w:orient="landscape"/><w:pgMar w:top="250" w:right="450" w:bottom="250" w:left="450" w:header="120" w:footer="120" w:gutter="0"/><w:cols w:space="720"/><w:docGrid w:linePitch="360"/></w:sectPr>''');

    final archive = Archive();
    _addText(archive, '[Content_Types].xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>''');
    _addText(archive, '_rels/.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>''');
    _addText(archive, 'word/document.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${body.toString()}</w:body></w:document>''');
    _addText(archive, 'word/_rels/document.xml.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>''');
    _addText(archive, 'word/styles.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:eastAsia="Arial" w:cs="Arial"/><w:lang w:val="ar-IQ" w:bidi="ar-IQ"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="80"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/></w:rPr></w:style></w:styles>''');
    _addText(archive, 'docProps/core.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>الجدول الأسبوعي المدرسي</dc:title><dc:creator>جدولي المدرسي</dc:creator><cp:revision>1</cp:revision></cp:coreProperties>''');
    _addText(archive, 'docProps/app.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>جدولي المدرسي</Application></Properties>''');
    return Uint8List.fromList(ZipEncoder().encode(archive));
  }

  Future<Uint8List> buildXlsx({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> sections,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
  }) async {
    final data = TimetableReportLayout(entries: entries, sections: sections, days: days, slots: slots);
    final archive = Archive();
    _addText(archive, '[Content_Types].xml', _xlsxContentTypes(1));
    _addText(archive, '_rels/.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>''');
    _addText(archive, 'xl/workbook.xml', _workbookXml(1));
    _addText(archive, 'xl/_rels/workbook.xml.rels', _workbookRels(1));
    _addText(archive, 'xl/styles.xml', _xlsxStyles());
    final rows = _officeRows(data);
    _addText(archive, 'xl/worksheets/sheet1.xml', _worksheetXml(
      title: 'الجدول الأسبوعي الشامل - الأيام عمودية والصفوف والشعب أفقية',
      schoolName: schoolName,
      metadata: 'العام الدراسي: $academicYear، النسخة: $versionName، الحالة: $status',
      rows: rows,
      columnCount: data.sections.length + 1,
    ));
    return Uint8List.fromList(ZipEncoder().encode(archive));
  }

  /// يحافظ على ترتيب أيام الدوام كما عُرّف في المدرسة (الأحد ثم بقية الأيام).
  /// لا نعكس الأيام داخل التقرير؛ فهي صفوف المصفوفة، بينما الصفوف/الشعب أعمدة.
  List<List<String>> _officeRows(TimetableReportLayout data) =>
      data.rowsForAllSections().map((row) => List<String>.from(row)).toList();

  String _wordParagraph(String text, {int size = 20, bool bold = false, String? color, bool pageBreak = false}) {
    if (pageBreak) return '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
    final safe = _xml(text);
    final colorTag = color == null ? '' : '<w:color w:val="$color"/>';
    return '<w:p><w:pPr><w:bidi/><w:jc w:val="center"/><w:spacing w:after="100"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:eastAsia="Arial" w:cs="Arial"/><w:rtl/><w:sz w:val="$size"/><w:szCs w:val="$size"/>${bold ? '<w:b/><w:bCs/>' : ''}$colorTag</w:rPr><w:t xml:space="preserve">$safe</w:t></w:r></w:p>';
  }

  String _wordTable(List<List<String>> rows) {
    if (rows.isEmpty) return '';
    const total = 22000;
    final columnCount = rows.first.length;
    const dayWidth = 1500;
    final remainingWidth = columnCount > 1 ? total - dayWidth : 0;
    final sectionWidth = columnCount > 1
        ? (remainingWidth / (columnCount - 1)).floor()
        : 0;
    final widths = <int>[
      if (columnCount == 1) total else dayWidth,
      if (columnCount > 1) ...List<int>.filled(columnCount - 1, sectionWidth),
    ];
    final grid = widths.map((w) => '<w:gridCol w:w="$w"/>').join();
    final out = StringBuffer('<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="$total" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:bidiVisual/><w:tblBorders><w:top w:val="single" w:sz="6" w:color="B8C5D4"/><w:left w:val="single" w:sz="6" w:color="B8C5D4"/><w:bottom w:val="single" w:sz="6" w:color="B8C5D4"/><w:right w:val="single" w:sz="6" w:color="B8C5D4"/><w:insideH w:val="single" w:sz="4" w:color="CFD8E3"/><w:insideV w:val="single" w:sz="4" w:color="CFD8E3"/></w:tblBorders><w:tblCellMar><w:top w:w="45" w:type="dxa"/><w:left w:w="45" w:type="dxa"/><w:bottom w:w="45" w:type="dxa"/><w:right w:w="45" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>$grid</w:tblGrid>');
    for (var r = 0; r < rows.length; r++) {
      final row = rows[r];
      final isBand = row.isNotEmpty && row.first.startsWith('جدول ') && row.skip(1).every((v) => v.isEmpty);
      final isHeader = row.isNotEmpty && row.first == 'اليوم';
      final isBlank = row.every((v) => v.isEmpty);
      out.write('<w:tr>');
      if (isBand) {
        out.write('<w:tc><w:tcPr><w:tcW w:w="$total" w:type="dxa"/><w:gridSpan w:val="$columnCount"/><w:shd w:fill="DCE9F8"/><w:vAlign w:val="center"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="center"/><w:spacing w:before="0" w:after="0"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:rtl/><w:b/><w:bCs/><w:sz w:val="15"/><w:color w:val="183B66"/></w:rPr><w:t xml:space="preserve">${_xml(row.first)}</w:t></w:r></w:p></w:tc>');
      } else {
        for (var c = 0; c < row.length; c++) {
          final isPeriod = c == 0 && !isHeader && !isBlank;
          final fill = isHeader ? '183B66' : (isPeriod ? 'DCE9F8' : (isBlank ? 'FFFFFF' : (r.isEven ? 'E7F1FC' : 'FFFFFF')));
          final textColor = isHeader ? 'FFFFFF' : '23354B';
          final fontSize = isHeader ? 13 : (isPeriod ? 11 : 10);
          final boldTag = (isHeader || isPeriod) ? '<w:b/><w:bCs/>' : '';
          final lines = row[c].split('\n');
          final runs = lines.asMap().entries.map((entry) {
            final lineBreak = entry.key == 0 ? '' : '<w:r><w:br/></w:r>';
            return '$lineBreak<w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:rtl/><w:sz w:val="$fontSize"/><w:szCs w:val="$fontSize"/><w:color w:val="$textColor"/>$boldTag</w:rPr><w:t xml:space="preserve">${_xml(entry.value)}</w:t></w:r>';
          }).join();
          out.write('<w:tc><w:tcPr><w:tcW w:w="${widths[c]}" w:type="dxa"/><w:shd w:fill="$fill"/><w:vAlign w:val="center"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="center"/><w:spacing w:before="0" w:after="0" w:line="180" w:lineRule="auto"/></w:pPr>$runs</w:p></w:tc>');
        }
      }
      out.write('</w:tr>');
    }
    out.write('</w:tbl>');
    return out.toString();
  }

  String _xlsxContentTypes(int count) => '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${List.generate(count, (i) => '<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join()}</Types>''';

  String _workbookXml(int count) => '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>${List.generate(count, (i) => '<sheet name="جدول ${i + 1}" sheetId="${i + 1}" r:id="rId${i + 1}"/>').join()}</sheets></workbook>''';

  String _workbookRels(int count) => '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${List.generate(count, (i) => '<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>').join()}<Relationship Id="rId${count + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>''';

  String _xlsxStyles() => '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Arial"/><family val="2"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Arial"/><family val="2"/></font><font><b/><color rgb="FF183B66"/><sz val="14"/><name val="Arial"/><family val="2"/></font></fonts><fills count="5"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF183B66"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE7F1FC"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDCE9F8"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFB8C5D4"/></left><right style="thin"><color rgb="FFB8C5D4"/></right><top style="thin"><color rgb="FFB8C5D4"/></top><bottom style="thin"><color rgb="FFB8C5D4"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="2" fillId="4" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="1" fillId="2" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="3" borderId="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="4" borderId="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>''';

  String _worksheetXml({required String title, required String schoolName, required String metadata, required List<List<String>> rows, required int columnCount}) {
    final allRows = <List<String>>[
      [schoolName],
      [metadata],
      [title],
      if (rows.isNotEmpty) ...rows else ['اليوم', ...List<String>.filled(columnCount > 0 ? columnCount - 1 : 0, '')],
    ];
    final xml = StringBuffer();
    xml.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1" autoPageBreaks="0"/></sheetPr><dimension ref="A1:${_columnName(columnCount)}${allRows.length}"/><sheetViews><sheetView showGridLines="0" rightToLeft="1" workbookViewId="0"><selection activeCell="A1" sqref="A1"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="34"/><cols><col min="1" max="1" width="21" customWidth="1"/>${columnCount > 1 ? '<col min="2" max="$columnCount" width="25" customWidth="1"/>' : ''}</cols><sheetData>');
    final mergedRows = <String>[
      if (columnCount > 1) ...[
        'A1:${_columnName(columnCount)}1',
        'A2:${_columnName(columnCount)}2',
        'A3:${_columnName(columnCount)}3',
      ],
    ];
    for (var r = 0; r < allRows.length; r++) {
      final row = allRows[r];
      final isBand = r >= 3 && row.isNotEmpty && row.first.startsWith('جدول ') && row.skip(1).every((v) => v.isEmpty);
      final isHeader = r >= 3 && row.isNotEmpty && row.first == 'اليوم';
      final isBlank = r >= 3 && row.every((v) => v.isEmpty);
      if (isBand && columnCount > 1) mergedRows.add('A${r + 1}:${_columnName(columnCount)}${r + 1}');
      xml.write('<row r="${r + 1}"${r < 3 ? ' ht="28" customHeight="1"' : (isBand ? ' ht="26" customHeight="1"' : ' ht="38" customHeight="1"')}>');
      final cellCount = r < 3 || isBand ? 1 : columnCount;
      for (var c = 0; c < cellCount; c++) {
        final value = c < row.length ? row[c] : '';
        final style = r == 0 ? 1 : r == 1 ? 0 : r == 2 ? 1 : isBand ? 1 : isHeader ? 2 : isBlank ? 0 : c == 0 ? 4 : (r.isEven ? 3 : 4);
        final ref = '${_columnName(c + 1)}${r + 1}';
        xml.write('<c r="$ref" s="$style" t="inlineStr"><is><t xml:space="preserve">${_xml(value)}</t></is></c>');
      }
      xml.write('</row>');
    }
    final merges = mergedRows.isEmpty ? '' : '<mergeCells count="${mergedRows.length}">${mergedRows.map((range) => '<mergeCell ref="$range"/>').join()}</mergeCells>';
    xml.write('</sheetData>$merges<pageMargins left="0.25" right="0.25" top="0.35" bottom="0.35" header="0.15" footer="0.15"/><pageSetup paperSize="8" orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>');
    return xml.toString();
  }

  String _columnName(int column) {
    var n = column;
    var out = '';
    while (n > 0) {
      final rem = (n - 1) % 26;
      out = String.fromCharCode(65 + rem) + out;
      n = (n - 1) ~/ 26;
    }
    return out;
  }

  String _dateStamp(DateTime date) => '${date.year}.${date.month.toString().padLeft(2, '0')}.${date.day.toString().padLeft(2, '0')}';

  String _xml(String input) => input
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&apos;')
      .replaceAll(RegExp(r'[\x00-\x08\x0B\x0C\x0E-\x1F]'), '');

  void _addText(Archive archive, String name, String content) => archive.addFile(ArchiveFile.string(name, content));
}

