/// قواعد المدرسة الخاصة بتحديد الصف السادس ويوم الأحد والفترة السابعة.
/// تستعملها الجدولة والفحص والواجهة حتى لا تتعارض القواعد بين الأجزاء.
class SchoolTimetablePolicy {
  const SchoolTimetablePolicy._();

  static bool isSixthGrade(Map<String, Object?> section) {
    final name = _normalize(section['grade_name'] ?? section['grade']);
    if (name.contains('السادس') || name.contains('سادس') ||
        name == '6' || name == '٦' || name == 'sixth' ||
        name == 'sixth grade' || name == 'grade 6' || name == 'grade6' ||
        name.contains('الصف 6') || name.contains('الصف ٦')) {
      return true;
    }
    // Compatibility fallback for callers which only provide grade position.
    final position = _int(section['grade_position'], fallback: -1);
    return name.isEmpty && position == 5;
  }

  static bool isSunday(Map<String, Object?> day) {
    final name = _normalize(day['name']);
    if (name.isNotEmpty) {
      return name == 'الاحد' || name.startsWith('الاحد ') || name == 'sunday';
    }
    // Older integrations may provide only the seeded ID/position.
    return _int(day['id'], fallback: -1) == 1 ||
        _int(day['position'], fallback: -1) == 0;
  }

  static bool canUseSeventhPeriod({
    required Map<String, Object?> section,
    required Map<String, Object?> day,
    required List<Map<String, Object?>> activeDays,
    required List<Map<String, Object?>> lessonSlots,
    required int weeklyDemand,
  }) {
    return isSixthGrade(section) &&
        isSunday(day) &&
        normalDailyLimit(section: section, lessonSlotCount: lessonSlots.length) >= 6 &&
        lessonSlots.length >= 7 &&
        activeDays.any(isSunday) &&
        weeklyDemand > activeDays.length * 6;
  }

  static int normalDailyLimit({
    required Map<String, Object?> section,
    required int lessonSlotCount,
  }) {
    final configured = _int(section['max_daily_lessons'], fallback: 6);
    final effective = configured > 0 && configured < lessonSlotCount
        ? configured
        : lessonSlotCount;
    return effective < 6 ? effective : 6;
  }

  static int weeklyCapacity({
    required Map<String, Object?> section,
    required List<Map<String, Object?>> activeDays,
    required List<Map<String, Object?>> lessonSlots,
    required int weeklyDemand,
  }) {
    final normal = normalDailyLimit(
      section: section,
      lessonSlotCount: lessonSlots.length,
    );
    final normalCapacity = activeDays.length * normal;
    final seventhCanBeUsed = isSixthGrade(section) &&
        normal >= 6 &&
        lessonSlots.length >= 7 &&
        activeDays.any(isSunday) &&
        weeklyDemand > activeDays.length * 6;
    return normalCapacity + (seventhCanBeUsed ? 1 : 0);
  }

  static String _normalize(Object? value) {
    var text = (value ?? '').toString().trim().toLowerCase();
    // Remove Arabic diacritics and tatweel, and normalize common alef forms.
    text = text.replaceAll(RegExp(r'[\u064B-\u065F\u0670\u0640]'), '');
    text = text.replaceAll(RegExp(r'[أإآٱ]'), 'ا');
    text = text.replaceAll('ى', 'ي');
    return text.trim();
  }

  static int _int(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
