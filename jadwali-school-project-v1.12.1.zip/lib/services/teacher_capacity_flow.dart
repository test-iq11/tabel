/// Exact maximum flow for the relaxed weekly teacher-assignment problem.
/// Ignoring timetable cells makes this an upper bound, never a feasibility proof.
class TeacherCapacityFlow {
  static int maximum({
    required List<int> demand,
    required List<List<int>> eligibleTeachers,
    required Map<int, int> capacity,
  }) {
    final teacherIds = capacity.keys.toList()..sort();
    final teacherNodes = <int, int>{
      for (var i = 0; i < teacherIds.length; i++)
        teacherIds[i]: demand.length + 1 + i,
    };
    final sink = demand.length + teacherIds.length + 1;
    final edges = List.generate(sink + 1, (_) => <_FlowEdge>[]);
    void connect(int from, int to, int amount) {
      final forward = _FlowEdge(to, edges[to].length, amount);
      final reverse = _FlowEdge(from, edges[from].length, 0);
      edges[from].add(forward);
      edges[to].add(reverse);
    }

    for (var i = 0; i < demand.length; i++) {
      connect(0, i + 1, demand[i]);
      for (final teacher in eligibleTeachers[i].toSet()) {
        final node = teacherNodes[teacher];
        if (node != null) connect(i + 1, node, demand[i]);
      }
    }
    for (final teacher in teacherIds) {
      connect(teacherNodes[teacher]!, sink, capacity[teacher]!);
    }
    var total = 0;
    while (true) {
      final parent = List<int>.filled(sink + 1, -1);
      final via = List<int>.filled(sink + 1, -1);
      final queue = <int>[0];
      parent[0] = 0;
      for (var head = 0; head < queue.length && parent[sink] < 0; head++) {
        final node = queue[head];
        for (var i = 0; i < edges[node].length; i++) {
          final edge = edges[node][i];
          if (edge.remaining <= 0 || parent[edge.to] >= 0) continue;
          parent[edge.to] = node;
          via[edge.to] = i;
          queue.add(edge.to);
        }
      }
      if (parent[sink] < 0) return total;
      var amount = 1 << 60;
      for (var node = sink; node != 0; node = parent[node]) {
        final edge = edges[parent[node]][via[node]];
        if (edge.remaining < amount) amount = edge.remaining;
      }
      for (var node = sink; node != 0; node = parent[node]) {
        final edge = edges[parent[node]][via[node]];
        edge.remaining -= amount;
        edges[node][edge.reverse].remaining += amount;
      }
      total += amount;
    }
  }
}

class _FlowEdge {
  _FlowEdge(this.to, this.reverse, this.remaining);
  final int to;
  final int reverse;
  int remaining;
}
