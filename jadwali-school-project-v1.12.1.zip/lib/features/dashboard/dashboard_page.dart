import 'package:flutter/material.dart';

import '../../core/ui_helpers.dart';
import '../../core/preview_widgets.dart';
import '../../data/database_service.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({
    required this.onNavigate,
    this.onOpenSection,
    super.key,
  });
  final ValueChanged<int> onNavigate;
  final ValueChanged<int>? onOpenSection;
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  late Future<List<dynamic>> _future;
  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() => _future = Future.wait([
    DatabaseService.instance.summary(),
    DatabaseService.instance.sectionsDetailed(),
    DatabaseService.instance.requirementsDetailed(),
  ]);
  @override
  Widget build(BuildContext context) => Scaffold(
    body: FutureBuilder<List<dynamic>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.hasError)
          return emptyState(
            icon: Icons.error_outline,
            title: 'تعذر تحميل الملخص',
            message: '${snapshot.error}',
          );
        if (!snapshot.hasData)
          return const Center(child: CircularProgressIndicator());
        final data = snapshot.data![0] as Map<String, Object?>;
        final sections = (snapshot.data![1] as List)
            .cast<Map<String, Object?>>();
        final reqs = (snapshot.data![2] as List).cast<Map<String, Object?>>();
        int value(String key) => (data[key] as num?)?.toInt() ?? 0;
        final distributed = value('الحصص الموزعة'),
            requiredCount = value('الحصص المطلوبة');
        final rate = requiredCount == 0
            ? 0.0
            : (distributed / requiredCount).clamp(0.0, 1.0);
        final status = PreviewPanel(
          title: 'حالة الجدول',
          child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 4, 22, 24),
            child: Wrap(
              spacing: 28,
              runSpacing: 20,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                SizedBox(
                  width: 154,
                  height: 154,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 130,
                        height: 130,
                        child: CircularProgressIndicator(
                          value: rate,
                          strokeWidth: 12,
                          strokeCap: StrokeCap.round,
                          backgroundColor: previewLine,
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '$distributed',
                            style: const TextStyle(
                              fontSize: 30,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const Text(
                            'حصة موزعة',
                            style: TextStyle(color: previewMuted, fontSize: 12),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 230,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        rate == 1
                            ? 'الأسبوع جاهز للمراجعة'
                            : 'أكمل توزيع الأسبوع',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'حصة لكل متطلب، وعرض واضح لكل صف ومعلم.',
                        style: TextStyle(color: previewMuted, fontSize: 12),
                      ),
                      const SizedBox(height: 14),
                      OutlinedButton(
                        onPressed: () => widget.onNavigate(1),
                        child: const Text('استعراض الحصص'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
        final links = PreviewPanel(
          title: 'انتقل مباشرة',
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Column(
              children: [
                for (final item in [
                  (
                    1,
                    'الجدول الأسبوعي',
                    'شاهد الصفوف والأيام بجانب بعضها',
                    Icons.calendar_month_outlined,
                  ),
                  (
                    2,
                    'المعلمون',
                    'النصاب والاختصاص والجدول الأسبوعي',
                    Icons.people_outline,
                  ),
                  (
                    3,
                    'الحصص المطلوبة',
                    'المواد والصفوف في شبكة قابلة للتعديل',
                    Icons.fact_check_outlined,
                  ),
                ])
                  ListTile(
                    contentPadding: const EdgeInsets.symmetric(vertical: 8),
                    leading: Icon(item.$4),
                    title: Text(
                      item.$2,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    subtitle: Text(
                      item.$3,
                      style: const TextStyle(fontSize: 11, color: previewMuted),
                    ),
                    trailing: const Icon(Icons.arrow_back, size: 16),
                    onTap: () => widget.onNavigate(item.$1),
                  ),
              ],
            ),
          ),
        );
        return RefreshIndicator(
          onRefresh: () async {
            setState(_reload);
            await _future;
          },
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              pageHeading(
                'مدرستك، في نظرة واحدة',
                'تابع الحصص والمعلمين واستعد لأسبوع منظم.',
              ),
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: FilledButton.icon(
                  onPressed: () => widget.onNavigate(1),
                  label: const Text('فتح جدول المدرسة'),
                  icon: const Icon(Icons.arrow_back, size: 16),
                ),
              ),
              const SizedBox(height: 20),
              PreviewStats(
                distributed: distributed,
                requiredCount: requiredCount,
                sections: sections.length,
                teachers: value('عدد المعلمين'),
              ),
              const SizedBox(height: 22),
              LayoutBuilder(
                builder: (context, c) => c.maxWidth > 850
                    ? Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(flex: 8, child: status),
                          const SizedBox(width: 22),
                          Expanded(flex: 5, child: links),
                        ],
                      )
                    : Column(
                        children: [status, const SizedBox(height: 18), links],
                      ),
              ),
              const SizedBox(height: 22),
              PreviewPanel(
                title: 'صفوف المدرسة',
                subtitle: 'اضغط الصف لفتح أسبوعه',
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: PreviewGrid(
                    children: [
                      for (final section in sections)
                        Card(
                          child: InkWell(
                            borderRadius: BorderRadius.circular(12),
                            onTap: () => widget.onOpenSection?.call(
                              section['id'] as int,
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(18),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      const Icon(Icons.menu_book_outlined),
                                      const Spacer(),
                                      const Icon(Icons.arrow_back, size: 16),
                                    ],
                                  ),
                                  const SizedBox(height: 14),
                                  Text(
                                    displayGradeName(section['grade_name']),
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w700,
                                      fontSize: 16,
                                    ),
                                  ),
                                  Text(
                                    'الشعبة ${section['section_name']} · ${reqs.where((r) => r['section_id'] == section['id']).fold<int>(0, (s, r) => s + (r['weekly_lessons'] as int))} حصة مطلوبة',
                                    style: const TextStyle(
                                      color: previewMuted,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    ),
  );
}
