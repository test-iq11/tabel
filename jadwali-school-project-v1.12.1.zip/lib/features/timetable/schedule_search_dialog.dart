import 'dart:async';

import 'package:flutter/material.dart';

import '../../services/schedule_search_controller.dart';

Future<List<Map<String, Object?>>?> showScheduleSearchDialog(
  BuildContext context, {
  required Map<String, Object?> input,
  required List<String> profiles,
}) => showDialog<List<Map<String, Object?>>>(
  context: context,
  barrierDismissible: false,
  builder: (_) => _ScheduleSearchDialog(input: input, profiles: profiles),
);

class _ScheduleSearchDialog extends StatefulWidget {
  const _ScheduleSearchDialog({required this.input, required this.profiles});
  final Map<String, Object?> input;
  final List<String> profiles;
  @override
  State<_ScheduleSearchDialog> createState() => _ScheduleSearchDialogState();
}

class _ScheduleSearchDialogState extends State<_ScheduleSearchDialog> {
  final _controller = ScheduleSearchController();
  StreamSubscription<Map<String, Object?>>? _subscription;
  Timer? _timer;
  List<Map<String, Object?>> _results = [];
  Map<String, Object?> _progress = {};
  String? _error;
  String _profileLabel = 'البحث عن توزيع';
  bool _running = true;
  bool _stoppedByUser = false;
  bool _closing = false;
  int _seconds = 30;

  @override
  void initState() {
    super.initState();
    final configured = widget.input['timeLimitMs'];
    if (configured is num && configured > 0) _seconds = (configured / 1000).ceil();
    _subscription = _controller.events.listen((event) {
      if (!mounted || _closing) return;
      setState(() {
        if (event['type'] == 'progress' || event['type'] == 'starting') _progress = event;
        if (event['type'] == 'profile') _profileLabel = '${event['label'] ?? 'البحث عن توزيع'}';
      });
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _running) setState(() {});
    });
    unawaited(_run(_controller.start({
      ...widget.input,
      'timeLimitMs': widget.input['timeLimitMs'] ?? _seconds * 1000,
    }, profiles: widget.profiles)));
  }

  Future<void> _run(Future<List<Map<String, Object?>>> attempt) async {
    setState(() {
      _running = true;
      _error = null;
    });
    try {
      final results = await attempt;
      if (!mounted || _closing) return;
      setState(() {
        _results = results;
        _running = false;
      });
      if (!_stoppedByUser) {
        _closing = true;
        Navigator.of(context).pop(results);
      }
    } catch (error) {
      if (!mounted || _closing) return;
      setState(() {
        _running = false;
        _error = 'تعذر إكمال البحث: $error';
      });
    }
  }

  Future<void> _stop() async {
    _stoppedByUser = true;
    final results = await _controller.stop();
    if (!mounted || _closing) return;
    setState(() {
      _results = results;
      _running = false;
    });
  }

  void _continue() {
    _stoppedByUser = false;
    unawaited(_run(_controller.continueSearch(timeLimit: Duration(seconds: _seconds))));
  }

  Future<void> _cancel() async {
    if (_closing) return;
    _closing = true;
    await _controller.dispose();
    if (mounted) Navigator.of(context).pop();
  }

  int get _bestCount {
    var count = _number(_progress['bestCount']);
    for (final result in _results) {
      final rows = result['placements'];
      if (rows is List && rows.length > count) count = rows.length;
    }
    return count;
  }

  @override
  Widget build(BuildContext context) {
    final requested = _number(_progress['requestedCount']);
    final elapsed = _controller.elapsedMilliseconds ~/ 1000;
    final durationValues = <int>{30, 60, 180, _seconds}.toList()..sort();
    return AlertDialog(
      title: Text(_running ? 'توزيع الحصص جارٍ' : 'احتُفظ بأفضل نتيجة'),
      content: SizedBox(
        width: 520,
        child: SingleChildScrollView(child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_profileLabel),
            const SizedBox(height: 14),
            LinearProgressIndicator(value: requested > 0 ? (_bestCount / requested).clamp(0.0, 1.0) : null),
            const SizedBox(height: 10),
            Text('الموزع: $_bestCount من $requested حصة'),
            Text('الوقت: ${elapsed ~/ 60}:${(elapsed % 60).toString().padLeft(2, '0')}'),
            const SizedBox(height: 12),
            if (_running)
              const Text('يمكنك إيقاف البحث والاحتفاظ بأفضل توزيع منشور للمراجعة.'),
            if (!_running && _stoppedByUser)
              const Text('تستطيع مراجعة النتيجة أو بدء محاولة أوسع انطلاقاً منها. تُفحص القيود قبل الحفظ.'),
            if (_error != null) Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            if (!_running) ...[
              const SizedBox(height: 12),
              DropdownButtonFormField<int>(
                initialValue: _seconds,
                decoration: const InputDecoration(labelText: 'مدة المحاولة التالية لكل حل'),
                items: durationValues.map((seconds) => DropdownMenuItem(
                  value: seconds,
                  child: Text(seconds < 60 ? '$seconds ثانية' : '${seconds ~/ 60} دقيقة'),
                )).toList(),
                onChanged: (value) { if (value != null) setState(() => _seconds = value); },
              ),
            ],
          ],
        )),
      ),
      actions: [
        TextButton(onPressed: _cancel, child: const Text('إلغاء')),
        if (_running)
          OutlinedButton.icon(onPressed: _stop, icon: const Icon(Icons.stop), label: const Text('إيقاف والاحتفاظ بالأفضل')),
        if (!_running) ...[
          OutlinedButton.icon(onPressed: _continue, icon: const Icon(Icons.play_arrow), label: const Text('متابعة ببحث أوسع')),
          FilledButton(
            onPressed: _results.isEmpty ? null : () {
              _closing = true;
              Navigator.of(context).pop(_results);
            },
            child: const Text('مراجعة أفضل نتيجة'),
          ),
        ],
      ],
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    unawaited(_subscription?.cancel() ?? Future<void>.value());
    unawaited(_controller.dispose());
    super.dispose();
  }
}

int _number(Object? value) => value is num ? value.toInt() : int.tryParse('$value') ?? 0;
