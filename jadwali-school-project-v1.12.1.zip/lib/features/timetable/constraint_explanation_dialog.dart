import 'package:flutter/material.dart';

import '../../services/constraint_explanation_service.dart';

/// Read-only review. Suggestions never change school rules automatically.
Future<void> showConstraintExplanations(
  BuildContext context,
  List<ConstraintExplanation> explanations,
) => showDialog<void>(
  context: context,
  builder: (context) => Directionality(
    textDirection: TextDirection.rtl,
    child: AlertDialog(
      title: const Text('لماذا تعذّر التوزيع؟'),
      content: SizedBox(
        width: 720,
        height: MediaQuery.sizeOf(context).height * .62,
        child: explanations.isEmpty
            ? const Center(child: Text(
                'لم يظهر تعارض مؤكد في فحص السعة والإعدادات. '
                'قد يحتاج المحرك وقتاً أطول للبحث أو تحرير بعض الحصص المثبتة.',
                textAlign: TextAlign.center,
              ))
            : ListView.separated(
                itemCount: explanations.length,
                separatorBuilder: (_, _) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final item = explanations[index];
                  final theme = Theme.of(context);
                  return Card(
                    margin: EdgeInsets.zero,
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Icon(item.proven ? Icons.block_outlined : Icons.search,
                              color: item.proven ? theme.colorScheme.error : theme.colorScheme.primary),
                            const SizedBox(width: 8),
                            Expanded(child: Text(item.title, style: theme.textTheme.titleMedium)),
                          ]),
                          const SizedBox(height: 6),
                          Text(item.proven ? 'تعارض مؤكد بالشروط الحالية' : 'تنبيه بحث؛ ليس إثبات استحالة',
                            style: theme.textTheme.labelMedium),
                          const SizedBox(height: 8),
                          SelectableText(item.reason),
                          if (item.suggestions.isNotEmpty) ...[
                            const SizedBox(height: 10),
                            const Text('تعديلات يمكنك مراجعتها:', style: TextStyle(fontWeight: FontWeight.bold)),
                            for (final suggestion in item.suggestions)
                              Padding(
                                padding: const EdgeInsets.only(top: 6),
                                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  const Icon(Icons.chevron_left, size: 18),
                                  const SizedBox(width: 4),
                                  Expanded(child: Text(suggestion)),
                                ]),
                              ),
                          ],
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق'))],
    ),
  ),
);
