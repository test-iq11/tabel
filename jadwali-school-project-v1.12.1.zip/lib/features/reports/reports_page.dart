import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/ui_helpers.dart';
import '../../data/database_service.dart';
import '../../services/file_save_service.dart';
import '../../services/pdf_report_service.dart';
import '../../services/reference_office_service.dart';
import '../../services/reference_timetable_layout.dart';
import '../../services/report_day_colors.dart';
import '../../services/teacher_workload_service.dart';

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});
  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  late Future<Map<String, Object?>> _future;
  final _number = TextEditingController(text: '1');
  final _date = TextEditingController();
  final _manager = TextEditingController();
  String _kind = 'timetable', _scope = 'school', _paper = 'A3';
  int? _sectionId, _teacherId;
  bool _template = false, _busy = false;
  static const _types = {
    'timetable': 'جدول الحصص',
    'workload': 'نصاب المعلمين',
    'requirements': 'الحصص المطلوبة',
  };

  @override
  void initState() {
    super.initState();
    _future = _load();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _manager.text = prefs.getString('report_manager') ?? '';
      _date.text = prefs.getString('report_effective_date') ?? '';
      _number.text = prefs.getString('report_number') ?? '1';
    });
  }

  @override
  void dispose() {
    _number.dispose();
    _date.dispose();
    _manager.dispose();
    super.dispose();
  }

  Future<Map<String, Object?>> _load() async {
    final db = DatabaseService.instance;
    final id = await db.activeVersionId(await db.activeYearId());
    final versions = await db.rows('timetable_versions');
    return {
      'settings': await db.getSettings(),
      'version':
          versions.where((v) => v['id'] == id).firstOrNull ??
          <String, Object?>{},
      'entries': await db.entriesDetailed(versionId: id),
      'sections': await db.sectionsDetailed(),
      'teachers': await db.rows('teachers', orderBy: 'name'),
      'requirements': await db.requirementsDetailed(),
      'days': await db.rows('school_days', orderBy: 'position'),
      'slots': await db.rows('time_slots', orderBy: 'position'),
    };
  }

  List<Map<String, Object?>> _rows(Map<String, Object?> data, String key) =>
      (data[key] as List).cast<Map<String, Object?>>();
  String _school(Map<String, Object?> data) =>
      '${(data['settings'] as Map)['school_name'] ?? 'مدرستي'}';
  ReferenceTimetableLayout _layout(Map<String, Object?> data) {
    var entries = _rows(data, 'entries');
    var sections = _rows(data, 'sections');
    if (_scope == 'section' && _sectionId != null) {
      sections = sections.where((s) => s['id'] == _sectionId).toList();
      entries = entries.where((e) => e['section_id'] == _sectionId).toList();
    }
    if (_scope == 'teacher' && _teacherId != null) {
      entries = entries.where((e) => e['teacher_id'] == _teacherId).toList();
      final ids = entries.map((e) => e['section_id']).toSet();
      sections = sections.where((s) => ids.contains(s['id'])).toList();
    }
    return ReferenceTimetableLayout(
      entries: entries,
      sections: sections,
      days: _rows(data, 'days'),
      slots: _rows(data, 'slots'),
      templateColumns: _template && _scope == 'school',
    );
  }

  List<List<String>> _listReport(Map<String, Object?> data) {
    if (_kind == 'workload') {
      final load = const TeacherWorkloadService().calculate(
        teachers: _rows(data, 'teachers'),
        entries: _rows(data, 'entries'),
        days: _rows(data, 'days'),
        slots: _rows(data, 'slots'),
      );
      return [
        [
          'المعلم',
          'النصاب',
          'الموزع',
          'المتبقي',
          'الزيادة',
          'أيام التدريس',
          'الفجوات',
        ],
        for (final row in load)
          [
            for (final key in [
              'teacher_name',
              'target_load',
              'assigned_lessons',
              'remaining',
              'overload',
              'days_with_lessons',
              'gaps',
            ])
              '${row[key] ?? ''}',
          ],
      ];
    }
    final entries = _rows(data, 'entries');
    return [
      ['الصف', 'الشعبة', 'المادة', 'المطلوب', 'الموزع', 'المتبقي'],
      for (final req in _rows(data, 'requirements'))
        [
          '${req['grade_name'] ?? ''}',
          '${req['section_name'] ?? ''}',
          '${req['subject_name'] ?? ''}',
          '${req['weekly_lessons']}',
          '${entries.where((e) => e['section_id'] == req['section_id'] && e['subject_id'] == req['subject_id']).length}',
          '${ReferenceTimetableLayout.number(req['weekly_lessons']) - entries.where((e) => e['section_id'] == req['section_id'] && e['subject_id'] == req['subject_id']).length}',
        ],
    ];
  }

  Future<void> _export(
    Map<String, Object?> data,
    String format, {
    bool preview = false,
  }) async {
    setState(() => _busy = true);
    try {
      // Capture a single set of options before awaiting preferences or export.
      final layout = _layout(data),
          school = _school(data),
          title = _types[_kind]!;
      final number = _number.text.trim(),
          date = _date.text.trim(),
          manager = _manager.text.trim();
      final timetable = _kind == 'timetable', paper = _paper;
      final rows = timetable
          ? layout.classGroups.expand((g) => layout.rows(g)).toList()
          : _listReport(data);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('report_manager', manager);
      await prefs.setString('report_effective_date', date);
      await prefs.setString('report_number', number);
      final pdf = PdfReportService();
      Uint8List bytes;
      if (format == 'pdf') {
        final size = paper == 'A4'
            ? PdfPageFormat.a4.landscape
            : PdfPageFormat.a3.landscape;
        bytes = timetable
            ? await pdf.buildReferenceTimetablePdf(
                layout: layout,
                schoolName: school,
                reportNumber: number,
                effectiveDate: date,
                managerName: manager,
                pageFormat: size,
              )
            : await pdf.buildListReportPdf(
                title: title,
                schoolName: school,
                rows: rows,
                pageFormat: size,
              );
      } else if (format == 'csv') {
        String quote(String text) => '"${text.replaceAll('"', '""')}"';
        bytes = Uint8List.fromList(
          utf8.encode(
            '\uFEFF${rows.map((r) => r.map(quote).join(',')).join('\r\n')}',
          ),
        );
      } else {
        const office = ReferenceOfficeService();
        bytes = timetable
            ? office.timetable(
                layout: layout,
                schoolName: school,
                word: format == 'docx',
                paper: paper,
                number: number,
                date: date,
                manager: manager,
              )
            : office.list(
                title: title,
                schoolName: school,
                rows: rows,
                word: format == 'docx',
                paper: paper,
              );
      }
      if (preview) {
        await pdf.preview(bytes);
      } else {
        final path = await FileSaveService().saveBytes(
          dialogTitle: 'حفظ $title',
          fileName: '$title-$paper.$format',
          allowedExtensions: [format],
          bytes: bytes,
        );
        if (path != null && mounted)
          showMessage(context, 'تم حفظ التقرير: $path');
      }
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر إنشاء التقرير: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _step(int number, String title, List<Widget> children) => Card(
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 15,
                backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                child: Text(
                  '$number',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                    fontSize: 13,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    ),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('التقارير'),
      actions: [
        IconButton(
          tooltip: 'تحديث البيانات',
          onPressed: _busy ? null : () => setState(() => _future = _load()),
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: FutureBuilder<Map<String, Object?>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.hasError)
          return emptyState(
            icon: Icons.error_outline,
            title: 'تعذر تحميل التقارير',
            message: '${snapshot.error}',
          );
        if (!snapshot.hasData)
          return const Center(child: CircularProgressIndicator());
        final data = snapshot.data!;
        final sections = _rows(data, 'sections'),
            teachers = _rows(data, 'teachers');
        if (!sections.any((s) => s['id'] == _sectionId))
          _sectionId = sections.isEmpty ? null : sections.first['id'] as int;
        if (!teachers.any((s) => s['id'] == _teacherId))
          _teacherId = teachers.isEmpty ? null : teachers.first['id'] as int;
        final version = data['version'] as Map;
        final ready =
            _kind != 'timetable' ||
            (_scope != 'section' || _sectionId != null) &&
                (_scope != 'teacher' || _teacherId != null);
        return Stack(
          children: [
            AbsorbPointer(
              absorbing: _busy,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  pageHeading(
                    'تقرير واضح وجاهز للطباعة',
                    '${version['name'] ?? 'لا توجد نسخة نشطة'} • ${_rows(data, 'entries').length} حصة محفوظة',
                  ),
                  _step(1, 'اختر التقرير', [
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final type in _types.entries)
                          ChoiceChip(
                            label: Text(type.value),
                            selected: _kind == type.key,
                            onSelected: (_) => setState(() => _kind = type.key),
                          ),
                      ],
                    ),
                  ]),
                  const SizedBox(height: 12),
                  _step(2, 'حدّد المحتوى والورق', [
                    if (_kind == 'timetable') ...[
                      Wrap(
                        spacing: 8,
                        runSpacing: 6,
                        children: [
                          for (final s in {
                            'school': 'المدرسة كاملة',
                            'section': 'صف وشعبة',
                            'teacher': 'حصص معلم',
                          }.entries)
                            ChoiceChip(
                              label: Text(s.value),
                              selected: _scope == s.key,
                              onSelected: (_) => setState(() => _scope = s.key),
                            ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      if (_scope == 'section')
                        DropdownButtonFormField<int>(
                          key: ValueKey('report-section-$_sectionId'),
                          initialValue: _sectionId,
                          isExpanded: true,
                          decoration: const InputDecoration(
                            labelText: 'الصف والشعبة',
                          ),
                          items: sections
                              .map(
                                (s) => DropdownMenuItem(
                                  value: s['id'] as int,
                                  child: Text(
                                    '${displayGradeName(s['grade_name'])} / ${s['section_name']}',
                                  ),
                                ),
                              )
                              .toList(),
                          onChanged: (id) => setState(() => _sectionId = id),
                        ),
                      if (_scope == 'teacher')
                        DropdownButtonFormField<int>(
                          key: ValueKey('report-teacher-$_teacherId'),
                          initialValue: _teacherId,
                          isExpanded: true,
                          decoration: const InputDecoration(
                            labelText: 'المعلم',
                          ),
                          items: teachers
                              .map(
                                (t) => DropdownMenuItem(
                                  value: t['id'] as int,
                                  child: Text('${t['name']}'),
                                ),
                              )
                              .toList(),
                          onChanged: (id) => setState(() => _teacherId = id),
                        ),
                      if (_scope == 'school')
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          title: const Text('القالب المرجعي: ١٢ خانة صف'),
                          subtitle: const Text(
                            'يمكن إيقافه لتوسيع الصفوف الموجودة فقط.',
                          ),
                          value: _template,
                          onChanged: (v) => setState(() => _template = v),
                        ),
                      ExpansionTile(
                        tilePadding: EdgeInsets.zero,
                        title: const Text('عنوان التقرير والتوقيع'),
                        children: [
                          TextField(
                            controller: _number,
                            decoration: const InputDecoration(
                              labelText: 'رقم الجدول',
                            ),
                            onChanged: (_) => setState(() {}),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: _date,
                            decoration: const InputDecoration(
                              labelText: 'يعمل بموجبه اعتباراً من تاريخ',
                            ),
                            onChanged: (_) => setState(() {}),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: _manager,
                            decoration: const InputDecoration(
                              labelText: 'مدير المدرسة',
                            ),
                            onChanged: (_) => setState(() {}),
                          ),
                          const SizedBox(height: 12),
                        ],
                      ),
                    ],
                    Wrap(
                      spacing: 8,
                      children: [
                        for (final paper in ['A3', 'A4'])
                          ChoiceChip(
                            label: Text('$paper أفقي'),
                            selected: _paper == paper,
                            onSelected: (_) => setState(() => _paper = paper),
                          ),
                      ],
                    ),
                  ]),
                  const SizedBox(height: 12),
                  _step(3, 'عاين واحفظ', [
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        FilledButton.icon(
                          onPressed: ready
                              ? () => _export(data, 'pdf', preview: true)
                              : null,
                          icon: const Icon(Icons.print_outlined),
                          label: const Text('معاينة وطباعة'),
                        ),
                        for (final format in {
                          'pdf': 'PDF',
                          'docx': 'Word',
                          'xlsx': 'Excel',
                          'csv': 'CSV',
                        }.entries)
                          OutlinedButton(
                            onPressed: ready
                                ? () => _export(data, format.key)
                                : null,
                            child: Text(format.value),
                          ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    if (_kind == 'timetable') ...[
                      const Text(
                        'الأيام ← الدرس ← الصفوف (المادة ثم المعلم). تظهر الحصص الإضافية في يومها الفعلي.',
                      ),
                      const SizedBox(height: 12),
                      ReferenceTimetablePreview(
                        layout: _layout(data),
                        school: _school(data),
                        number: _number.text,
                        date: _date.text,
                        manager: _manager.text,
                      ),
                    ] else
                      _listPreview(_listReport(data)),
                  ]),
                  const SizedBox(height: 24),
                ],
              ),
            ),
            if (_busy)
              const Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: LinearProgressIndicator(),
              ),
          ],
        );
      },
    ),
  );

  Widget _listPreview(List<List<String>> rows) => SingleChildScrollView(
    scrollDirection: Axis.horizontal,
    child: DataTable(
      columns: rows.first.map((s) => DataColumn(label: Text(s))).toList(),
      rows: rows
          .skip(1)
          .map((r) => DataRow(cells: r.map((s) => DataCell(Text(s))).toList()))
          .toList(),
    ),
  );
}

class ReferenceTimetablePreview extends StatelessWidget {
  const ReferenceTimetablePreview({
    required this.layout,
    required this.school,
    required this.number,
    required this.date,
    required this.manager,
    super.key,
  });
  final ReferenceTimetableLayout layout;
  final String school, number, date, manager;
  Widget _cell(
    String text,
    double width,
    double height, {
    bool shade = false,
    bool rotate = false,
    Color? dayFill,
  }) => Container(
    width: width,
    height: height,
    alignment: Alignment.center,
    decoration: BoxDecoration(
      color: dayFill ?? (shade ? const Color(0xFFE7E7E7) : Colors.white),
      border: Border.all(color: const Color(0xFF9CA9A9), width: .55),
    ),
    padding: const EdgeInsets.symmetric(horizontal: 3),
    child: rotate
        ? RotatedBox(
            quarterTurns: 3,
            child: Text(text,
                style: const TextStyle(color: Color(0xFF18334A), fontSize: 12,
                    fontWeight: FontWeight.bold)),
          )
        : Text(
            text,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Color(0xFF18334A), fontSize: 11),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
  );

  @override
  Widget build(BuildContext context) => Column(
    children: [
      for (final group in layout.classGroups)
        Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  SizedBox(
                    width: 96 + group.length * 152 + (group.length - 1) * 6,
                    child: Row(
                      children: [
                        Expanded(child: Text('إدارة مدرسة: $school',
                            style: const TextStyle(color: Colors.black))),
                        Expanded(child: Text('جدول الدروس الاسبوعي رقم ($number)',
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.black))),
                        Expanded(child: Text('يعمل بموجبه اعتباراً من تاريخ $date',
                            textAlign: TextAlign.end,
                            style: const TextStyle(color: Colors.black))),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      _cell('الأيام', 60, 64),
                      _cell('الدرس', 36, 64, shade: true),
                      for (var i = 0; i < group.length; i++) ...[
                        Column(
                          children: [
                            _cell(group[i] == null ? '' : layout.sectionTitle(group[i]!),
                                152, 32),
                            Row(children: [
                              _cell('المادة', 76, 32, shade: true),
                              _cell('المعلم', 76, 32, shade: true),
                            ]),
                          ],
                        ),
                        if (i < group.length - 1) const SizedBox(width: 6),
                      ],
                    ],
                  ),
                  for (var d = 0; d < layout.days.length; d++) ...[
                    Row(
                      children: [
                        _cell('${layout.days[d]['name']}', 60,
                            layout.periodsForDay(layout.days[d], group).length * 36.0,
                            rotate: true, dayFill: Color(ReportDayColors.argb(d))),
                        Column(children: [
                          for (final slot in layout.periodsForDay(layout.days[d], group))
                            _cell(ReferenceTimetableLayout.arabic(layout.lessonNumber(slot)),
                                36, 36, dayFill: Color(ReportDayColors.argb(d))),
                        ]),
                        for (var i = 0; i < group.length; i++) ...[
                          Column(children: [
                            for (final slot in layout.periodsForDay(layout.days[d], group))
                              Row(children: [
                                _cell(layout.cellText(group[i], layout.days[d], slot, teacher: false),
                                    76, 36, dayFill: Color(ReportDayColors.argb(d))),
                                _cell(layout.cellText(group[i], layout.days[d], slot, teacher: true),
                                    76, 36, dayFill: Color(ReportDayColors.argb(d))),
                              ]),
                          ]),
                          if (i < group.length - 1) const SizedBox(width: 6),
                        ],
                      ],
                    ),
                    if (d < layout.days.length - 1) const SizedBox(height: 10),
                  ],
                  const SizedBox(height: 12),
                  Text('مدير المدرسة: $manager',
                      style: const TextStyle(color: Colors.black)),
                ],
              ),
            ),
          ),
        ),
    ],
  );
}
