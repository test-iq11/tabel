import 'package:flutter/material.dart';

/// Visual tokens taken from the supplied Jadwali interactive HTML reference.
/// Only presentation is changed; schedulers and conflict engines are untouched.
class JadwaliVisual {
  static const teal = Color(0xFF147D76);
  static const tealStrong = Color(0xFF0B655F);
  static const tealSoft = Color(0xFFE8F4F0);
  static const ink = Color(0xFF1D2F43);
  static const navy = Color(0xFF18334A);
  static const muted = Color(0xFF768390);
  static const line = Color(0xFFE6EBEE);
  static const page = Color(0xFFF5F7F8);
}

ThemeData buildAppTheme({String style = 'calm'}) {
  final dark = style == 'dark';
  final accent = style == 'blue'
      ? const Color(0xFF3563CF)
      : style == 'paper'
          ? const Color(0xFF62594D)
          : dark ? const Color(0xFF71C7B9) : JadwaliVisual.teal;
  final navy = dark ? const Color(0xFFE7EEF3)
      : style == 'blue' ? const Color(0xFF182C52)
      : style == 'paper' ? const Color(0xFF343831) : JadwaliVisual.navy;
  final page = dark ? const Color(0xFF111D29)
      : style == 'paper' ? const Color(0xFFF3F1EC)
      : style == 'blue' ? const Color(0xFFF4F6FA) : JadwaliVisual.page;
  final surface = dark ? const Color(0xFF1A2937)
      : style == 'paper' ? const Color(0xFFFFFEFA) : Colors.white;
  final subtle = dark ? const Color(0xFF20313F)
      : style == 'paper' ? const Color(0xFFF8F6F0)
      : style == 'blue' ? const Color(0xFFF8F9FC) : const Color(0xFFF8FAFB);
  final text = dark ? const Color(0xFFE7EEF3) : JadwaliVisual.ink;
  final border = dark ? const Color(0xFF30424F)
      : style == 'paper' ? const Color(0xFFE8E5DC) : JadwaliVisual.line;
  final scheme = ColorScheme.fromSeed(
    seedColor: accent,
    brightness: dark ? Brightness.dark : Brightness.light,
  ).copyWith(primary: accent, onPrimary: dark ? const Color(0xFF112E2B) : Colors.white,
      secondary: accent, surface: surface, onSurface: text,
      outline: border, primaryContainer: dark ? const Color(0xFF274840)
          : style == 'blue' ? const Color(0xFFEDF2FD) : JadwaliVisual.tealSoft);
  OutlineInputBorder inputBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(8), borderSide: BorderSide(color: border));
  return ThemeData(
    useMaterial3: true,
    brightness: dark ? Brightness.dark : Brightness.light,
    fontFamily: 'JadwaliArabic',
    colorScheme: scheme,
    scaffoldBackgroundColor: page,
    dividerTheme: DividerThemeData(color: border, thickness: 1, space: 1),
    appBarTheme: AppBarTheme(
      backgroundColor: page, foregroundColor: navy,
      iconTheme: IconThemeData(color: accent),
      actionsIconTheme: IconThemeData(color: accent),
      surfaceTintColor: Colors.transparent, centerTitle: false,
      elevation: 0, scrolledUnderElevation: 0,
      titleTextStyle: TextStyle(fontFamily: 'JadwaliArabic',fontSize: 21,
          fontWeight: FontWeight.w700,color: navy)),
    iconTheme: IconThemeData(color: accent, size: 21),
    listTileTheme: ListTileThemeData(
      iconColor: const Color(0xFF768390),
      contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9))),
    cardTheme: CardThemeData(
      color: surface,elevation: 0,shadowColor: const Color(0x06223045),
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: border))),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,fillColor: surface,
      border: inputBorder,enabledBorder: inputBorder,
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: accent,width: 1.5)),
      prefixIconColor: accent,suffixIconColor: JadwaliVisual.muted,
      contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11)),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
      backgroundColor: accent,foregroundColor: scheme.onPrimary,
      minimumSize: const Size(44, 42),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(
      foregroundColor: accent, minimumSize: const Size(44, 42),
      side: BorderSide(color: border),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)))),
    chipTheme: ChipThemeData(backgroundColor: subtle,selectedColor: scheme.primaryContainer,
      side: BorderSide(color: border),
      labelStyle: TextStyle(color: text,fontWeight: FontWeight.w500,fontSize: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7))),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: surface,surfaceTintColor: Colors.transparent,
      indicatorColor: scheme.primaryContainer,
      indicatorShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      iconTheme: WidgetStateProperty.resolveWith((states) => IconThemeData(
          color: states.contains(WidgetState.selected) ? accent : JadwaliVisual.muted, size: 22)),
      labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(
          fontFamily: 'JadwaliArabic',fontSize: 11,
          fontWeight: states.contains(WidgetState.selected)
              ? FontWeight.w700 : FontWeight.w400,
          color: states.contains(WidgetState.selected) ? accent : JadwaliVisual.muted))),
    textTheme: TextTheme(
      headlineSmall: TextStyle(fontSize: 26,fontWeight: FontWeight.w700,color: navy),
      titleLarge: TextStyle(fontSize: 21,fontWeight: FontWeight.w700,color: navy),
      titleMedium: TextStyle(fontSize: 16,fontWeight: FontWeight.w700,color: navy),
      bodyMedium: TextStyle(fontSize: 14,height: 1.7,color: text),
      bodySmall: TextStyle(fontSize: 12,height: 1.6,color: dark ? const Color(0xFF9AAAB7) : JadwaliVisual.muted)),
  );
}
