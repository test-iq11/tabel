import 'package:flutter/material.dart';

ThemeData buildAppTheme({String style = 'calm'}) {
  final navy = style == 'blue'
      ? const Color(0xFF182C52)
      : style == 'paper'
      ? const Color(0xFF62594D)
      : const Color(0xFF147D76);
  final blue = style == 'blue'
      ? const Color(0xFF3563CF)
      : style == 'paper'
      ? const Color(0xFF62594D)
      : const Color(0xFF147D76);
  const green = Color(0xFF16845B);
  final scheme =
      ColorScheme.fromSeed(
        seedColor: blue,
        brightness: Brightness.light,
      ).copyWith(
        primary: navy,
        secondary: blue,
        tertiary: green,
        surface: Colors.white,
      );
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'JadwaliUI',
    fontFamilyFallback: const ['JadwaliLatin'],
    colorScheme: scheme,
    scaffoldBackgroundColor: style == 'paper'
        ? const Color(0xFFF3F1EC)
        : const Color(0xFFF5F7F8),
    appBarTheme: AppBarTheme(
      backgroundColor: Color(0xFFF5F7F8),
      foregroundColor: navy,
      iconTheme: IconThemeData(color: blue),
      actionsIconTheme: IconThemeData(color: blue),
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
      titleTextStyle: TextStyle(
        fontFamily: 'JadwaliUI',
        fontFamilyFallback: const ['JadwaliLatin'],
        fontSize: 23,
        fontWeight: FontWeight.w700,
        color: const Color(0xFF1D2F43),
      ),
    ),
    iconTheme: IconThemeData(color: blue),
    listTileTheme: ListTileThemeData(
      iconColor: blue,
      contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 3),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(14)),
      ),
    ),
    dividerTheme: const DividerThemeData(
      color: Color(0xFFE6EBEE),
      thickness: 1,
      space: 1,
    ),
    cardTheme: CardThemeData(
      color: Colors.white,
      elevation: 0,
      shadowColor: const Color(0x140D2340),
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: Color(0xFFE6EBEE)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Color(0xFFD8E0E5)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Color(0xFFD8E0E5)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: blue, width: 1.7),
      ),
      prefixIconColor: blue,
      suffixIconColor: const Color(0xFF768390),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: navy,
        foregroundColor: Colors.white,
        minimumSize: const Size(44, 46),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: navy,
        minimumSize: const Size(44, 44),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: Colors.white,
      selectedColor: const Color(0xFFE8F4F0),
      secondarySelectedColor: const Color(0xFFE8F4F0),
      secondaryLabelStyle: const TextStyle(
        fontFamily: 'JadwaliUI',
        color: Color(0xFF0B655F),
      ),
      labelStyle: const TextStyle(
        fontFamily: 'JadwaliUI',
        fontFamilyFallback: ['JadwaliLatin'],
        color: Color(0xFF1D2F43),
        fontWeight: FontWeight.w600,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white,
      surfaceTintColor: Colors.transparent,
      indicatorColor: const Color(0xFFE8F4F0),
      indicatorShape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      iconTheme: WidgetStateProperty.resolveWith<IconThemeData?>(
        (states) => IconThemeData(
          color: states.contains(WidgetState.selected)
              ? navy
              : const Color(0xFF768390),
          size: 23,
        ),
      ),
      labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>(
        (states) => TextStyle(
          fontSize: 11,
          fontWeight: states.contains(WidgetState.selected)
              ? FontWeight.w800
              : FontWeight.w500,
          color: states.contains(WidgetState.selected)
              ? navy
              : const Color(0xFF768390),
        ),
      ),
    ),
    textTheme: TextTheme(
      headlineSmall: TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.w800,
        color: navy,
      ),
      titleLarge: TextStyle(
        fontSize: 23,
        fontWeight: FontWeight.w700,
        color: const Color(0xFF1D2F43),
      ),
      titleMedium: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: navy,
      ),
      bodyMedium: TextStyle(
        fontSize: 13,
        height: 1.7,
        color: Color(0xFF1D2F43),
      ),
    ),
  );
}
