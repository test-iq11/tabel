/// Lets the shell ask a visible editor to preserve its unsaved input.
class EditorNavigationGuard {
  Future<bool> Function()? beforeLeave;
}
