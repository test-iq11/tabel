#!/usr/bin/env python3
"""Install and verify the requested NDK before Gradle starts (GitHub runner only)."""
import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys


def ndk_problem(directory, version):
    properties = directory / 'source.properties'
    if not properties.is_file():
        return 'source.properties is missing'
    match = re.search(r'^Pkg\.Revision\s*=\s*(\S+)\s*$', properties.read_text(), re.M)
    if match is None or match.group(1) != version:
        return 'NDK revision does not match ' + version
    clang = directory / 'toolchains/llvm/prebuilt/linux-x86_64/bin/clang'
    if not clang.is_file() or not os.access(clang, os.X_OK):
        return 'the clang executable is missing or not executable'
    toolchain = directory / 'build/cmake/android.toolchain.cmake'
    if not toolchain.is_file() or toolchain.stat().st_size == 0:
        return 'the Android CMake toolchain is missing'
    try:
        subprocess.run([str(clang), '--version'], check=True, timeout=30,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    except (OSError, subprocess.SubprocessError) as error:
        return 'clang cannot run: ' + str(error)
    return None


def remove_incomplete(path):
    if path.is_symlink():
        path.unlink()
    elif path.exists():
        shutil.rmtree(path)


def prepare(sdk, version, work, attempts=3):
    if not re.fullmatch(r'\d+\.\d+\.\d+', version):
        raise ValueError('Invalid NDK version')
    sdk = Path(sdk).resolve(strict=True)
    work = Path(work).resolve()
    sdkmanager = sdk / 'cmdline-tools/latest/bin/sdkmanager'
    if not sdkmanager.is_file():
        raise FileNotFoundError('SDK manager not found: ' + str(sdkmanager))
    target = sdk / 'ndk' / version
    problem = ndk_problem(target, version)
    if problem is None:
        print('Verified existing NDK ' + version, flush=True)
        return
    work.mkdir(parents=True, exist_ok=True)
    for attempt in range(1, attempts + 1):
        print(f'NDK {version}: attempt {attempt}/{attempts}; {problem}', flush=True)
        print(f'Free SDK disk space: {shutil.disk_usage(sdk).free / (1024 ** 3):.1f} GiB', flush=True)
        # This runs before Gradle on an isolated GitHub runner. Remove only the
        # incomplete target and SDK manager's download staging, not other NDKs.
        remove_incomplete(target)
        remove_incomplete(sdk / '.temp')
        # Each retry gets a fresh SDK manager download cache; never change HOME.
        cache = work / f'android-user-{attempt}'
        remove_incomplete(cache)
        cache.mkdir(parents=True)
        environment = dict(os.environ)
        environment['ANDROID_USER_HOME'] = str(cache)
        # Older command-line tools use ANDROID_PREFS_ROOT instead.
        environment['ANDROID_PREFS_ROOT'] = str(cache)
        try:
            subprocess.run([str(sdkmanager), '--sdk_root=' + str(sdk),
                            '--install', 'ndk;' + version],
                           env=environment, check=True, timeout=900)
        except (OSError, subprocess.SubprocessError) as error:
            problem = 'sdkmanager failed: ' + str(error)
        else:
            problem = ndk_problem(target, version)
            if problem is None:
                print('NDK ' + version + ' installed and toolchain verified.', flush=True)
                return
        print('NDK verification failed: ' + str(problem), flush=True)
    remove_incomplete(target)
    raise RuntimeError(f'NDK {version} was not installed completely after {attempts} attempts: {problem}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', required=True)
    parser.add_argument('--version', default='28.2.13676358')
    parser.add_argument('--work', required=True)
    args = parser.parse_args()
    try:
        prepare(args.sdk, args.version, args.work)
    except (OSError, ValueError, RuntimeError) as error:
        print('::error::' + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
