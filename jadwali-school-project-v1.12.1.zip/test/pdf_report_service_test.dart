import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

import 'reference_timetable_report_test.dart' show schoolLayout;

import 'package:iraqi_school_timetable/services/reference_office_service.dart';
import 'package:iraqi_school_timetable/services/pdf_report_service.dart';
import 'package:iraqi_school_timetable/services/reference_timetable_layout.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('six actual classes export colored day blocks on one A3 page', () async {
    final source = schoolLayout();
    final layout = ReferenceTimetableLayout(
      entries: source.entries,
      sections: source.sections,
      days: source.days,
      slots: source.slots,
      templateColumns: false,
    );
    final bytes = await PdfReportService().buildReferenceTimetablePdf(
      layout: layout,
      schoolName: 'مدرسة الاختبار',
      reportNumber: '1',
      effectiveDate: '25/10/2026',
    );
    expect(
      RegExp(r'/Type\s*/Page\b').allMatches(latin1.decode(bytes)),
      hasLength(1),
    );
    final directory = Platform.environment['JADWALI_REPORT_ARTIFACT_DIR'];
    if (directory != null) {
      Directory(directory).createSync(recursive: true);
      File('$directory/jadwali-colored-six-classes.pdf')
          .writeAsBytesSync(bytes);
      for (final word in [true, false]) {
        final office = const ReferenceOfficeService().timetable(
          layout: layout,
          schoolName: 'مدرسة الاختبار',
          word: word,
          date: '25/10/2026',
        );
        File('$directory/jadwali-colored-six-classes.${word ? 'docx' : 'xlsx'}')
            .writeAsBytesSync(office);
      }
    }
  });

  test(
    'the supplied 181-lesson form exports to one A3 page with punctuation',
    () async {
      final input = jsonDecode(
        File('test/fixtures/backup_school_181.json').readAsStringSync(),
      ) as Map;
      List<Map<String, Object?>> rows(String key) => (input[key] as List)
          .map((r) => Map<String, Object?>.from(r as Map))
          .toList();
      final layout = ReferenceTimetableLayout(
        entries: rows('initialPlacements')
            .map(
              (e) => {
                ...e,
                'subject_name': 'المادة ${e['subject_id']}',
                'teacher_name': 'المعلم ${e['teacher_id']}',
              },
            )
            .toList(),
        sections: rows('sections')
            .map((s) => {...s, 'max_daily_lessons': 6})
            .toList(),
        days: rows('days'),
        slots: rows('slots'),
      );
      final bytes = await PdfReportService().buildReferenceTimetablePdf(
        layout: layout,
        schoolName: 'مدرسة - الأمل (فرع 1)',
        reportNumber: '٢',
        effectiveDate: '24/10/2026',
      );
      expect(
        RegExp(r'/Type\s*/Page\b').allMatches(latin1.decode(bytes)).length,
        1,
      );
      expect(bytes.length, greaterThan(1000));
      final artifactDirectory =
          Platform.environment['JADWALI_REPORT_ARTIFACT_DIR'];
      if (artifactDirectory != null) {
        final folder = Directory(artifactDirectory)
          ..createSync(recursive: true);
        File('${folder.path}/jadwali-native-reference.pdf')
            .writeAsBytesSync(bytes);
      }
    },
  );

  test('PDF export handles punctuation missing from the bundled Arabic font and stays one page', () async {
    final bytes = await PdfReportService().buildTimetablePdf(
      schoolName: 'مدرسة - الأمل (فرع 1)',
      academicYear: '2026-2027',
      versionName: 'الجدول | الأول',
      status: 'قيد التعديل',
      sections: <Map<String, Object?>>[
        {'id': 1, 'grade_name': 'الأول الابتدائي', 'section_name': 'أ'},
        {'id': 2, 'grade_name': 'السادس الابتدائي', 'section_name': 'ب'},
      ],
      days: <Map<String, Object?>>[
        {'id': 1, 'name': 'الأحد', 'position': 1, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 2, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 3, 'is_active': 1},
        {'id': 4, 'name': 'الأربعاء', 'position': 4, 'is_active': 1},
        {'id': 5, 'name': 'الخميس', 'position': 5, 'is_active': 1},
      ],
      slots: <Map<String, Object?>>[
        {
          'id': 1,
          'name': 'الحصة الأولى',
          'start_time': '08:00',
          'end_time': '08:45',
          'position': 1,
          'kind': 'lesson',
          'is_available': 1,
        },
      ],
      entries: <Map<String, Object?>>[
        {
          'section_id': 1,
          'day_id': 1,
          'slot_id': 1,
          'grade_name': 'الأول الابتدائي',
          'section_name': 'أ',
          'subject_name': 'الرياضيات - (مراجعة)',
          'teacher_name': 'أحمد / علي',
        },
      ],
    );
    expect(bytes.length, greaterThan(100));
    final pdfText = latin1.decode(bytes);
    expect(RegExp(r'/Type\s*/Page\b').allMatches(pdfText).length, 1);
  });

  test(
    'teacher PDF contains an individual timetable with subject and section',
    () async {
      final bytes = await PdfReportService().buildTeacherTimetablePdf(
        schoolName: 'مدرسة الاختبار',
        academicYear: '2026-2027',
        versionName: 'نسخة اختبار',
        status: 'مسودة',
        teacher: {'id': 7, 'name': 'طالب'},
        targetLoad: 4,
        entries: <Map<String, Object?>>[
          {
            'teacher_id': 7,
            'day_id': 1,
            'slot_id': 1,
            'grade_name': 'الأول الابتدائي',
            'section_name': 'أ',
            'subject_name': 'اللغة العربية',
          },
        ],
        days: <Map<String, Object?>>[
          {'id': 1, 'name': 'الأحد', 'position': 1, 'is_active': 1},
          {'id': 2, 'name': 'الاثنين', 'position': 2, 'is_active': 1},
        ],
        slots: <Map<String, Object?>>[
          {
            'id': 1,
            'name': 'الحصة الأولى',
            'start_time': '08:00',
            'end_time': '08:45',
            'position': 1,
            'kind': 'lesson',
            'is_available': 1,
          },
        ],
      );
      expect(bytes.length, greaterThan(100));
      expect(latin1.decode(bytes), contains('%PDF'));
    },
  );
}
