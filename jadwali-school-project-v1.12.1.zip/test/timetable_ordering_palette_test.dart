import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/core/timetable_palette.dart';
import 'package:iraqi_school_timetable/core/timetable_ordering.dart';

void main() {
  test('الحصتان السادسة والسابعة لا تنعكسان عند تساوي position', () {
    final slots = <Map<String, Object?>>[
      {'id': 7, 'position': 99, 'start_time': '12:20'},
      {'id': 6, 'position': 99, 'start_time': '11:45'},
      {'id': 5, 'position': 4, 'start_time': '11:00'},
    ];
    slots.sort(TimetableOrdering.compare);
    expect(slots.map((slot) => slot['id']).toList(), [5, 6, 7]);
  });
  test('لون المادة ثابت بغض النظر عن ترتيب السجلات', () {
    expect(TimetablePalette.accent(4), TimetablePalette.accent(4));
    expect(TimetablePalette.accent(4), isNot(TimetablePalette.accent(5)));
    expect(TimetablePalette.tint(4), isNot(TimetablePalette.tint(5)));
  });
}
