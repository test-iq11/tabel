import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:iraqi_school_timetable/services/conflict_detection_service.dart';

void main() {
  test('يظل الحل صالحاً عند تغيير المعرّفات وترتيب بيانات المدرسة', () {
    final original = jsonDecode(File('test/fixtures/whole_week_repair.json').readAsStringSync()) as Map<String, dynamic>;
    final random = Random(2194);
    for (var variant = 1; variant <= 12; variant++) {
      final offset = variant * 100;
      final idOffsets = {'sections': offset, 'teachers': offset * 2, 'days': offset * 4, 'slots': offset * 5};
      final fieldOffsets = {'section_id': offset, 'teacher_id': offset * 2, 'subject_id': offset * 3, 'day_id': offset * 4, 'slot_id': offset * 5};
      List<Map<String, Object?>> rows(String key) {
        final output = (original[key] as List).map((value) {
          final row = Map<String, Object?>.from(value as Map);
          if (idOffsets.containsKey(key)) row['id'] = (row['id'] as int) + idOffsets[key]!;
          for (final field in fieldOffsets.keys) {
            if (row.containsKey(field)) row[field] = (row[field] as int) + fieldOffsets[field]!;
          }
          return row;
        }).toList()..shuffle(random);
        return output;
      }
      final sections = rows('sections'), requirements = rows('requirements');
      final teachers = rows('teachers'), qualifications = rows('qualifications');
      final days = rows('days'), slots = rows('slots'), availability = rows('teacherAvailability');
      final result = const AutoSchedulerService(nodeLimit: 10000).generate(
        sections: sections, requirements: requirements, teachers: teachers,
        qualifications: qualifications, days: days, slots: slots, teacherAvailability: availability,
      );
      expect(result.complete, isTrue, reason: 'variant $variant');
      final issues = const ConflictDetectionService().scan(
        entries: result.placements, sections: sections, requirements: requirements,
        teachers: teachers, qualifications: qualifications, days: days, slots: slots,
        teacherAvailability: availability,
      );
      expect(issues.where((i) => i.type != 'تكرار توقيت المادة في أيام متتالية'), isEmpty);
    }
  });

  test('يعيد ترتيب الأسبوع كاملاً لحالة تركت النسخة السابقة فيها حصة ناقصة', () {
    final input = jsonDecode(File('test/fixtures/whole_week_repair.json').readAsStringSync()) as Map<String, dynamic>;
    List<Map<String, Object?>> rows(String key) =>
        (input[key] as List).map((r) => Map<String, Object?>.from(r as Map)).toList();
    final result = const AutoSchedulerService(nodeLimit: 1000).generate(
      sections: rows('sections'), requirements: rows('requirements'),
      teachers: rows('teachers'), qualifications: rows('qualifications'),
      days: rows('days'), slots: rows('slots'),
      teacherAvailability: rows('teacherAvailability'),
    );
    expect(result.complete, isTrue);
    expect(result.placements, hasLength(18));
    final issues = const ConflictDetectionService().scan(
      entries: result.placements, sections: rows('sections'),
      requirements: rows('requirements'), teachers: rows('teachers'),
      qualifications: rows('qualifications'), days: rows('days'),
      slots: rows('slots'), teacherAvailability: rows('teacherAvailability'),
    );
    expect(issues.where((i) => i.type != 'تكرار توقيت المادة في أيام متتالية'), isEmpty);
  });

  test('يشخّص عجز السعة المشتركة ويحفظ أكبر عدد ممكن دون تعارض', () {
    final result = const AutoSchedulerService(nodeLimit: 5000).generate(
      sections: [
        for (var id = 1; id <= 3; id++)
          {'id': id, 'grade_id': 1, 'max_daily_lessons': 2},
      ],
      requirements: [
        for (var id = 1; id <= 3; id++)
          {'section_id': id, 'subject_id': 1, 'weekly_lessons': 2, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 1, 'weekly_load': 2, 'max_daily_lessons': 2},
        {'id': 2, 'weekly_load': 2, 'max_daily_lessons': 2},
        {'id': 3, 'weekly_load': 20, 'max_daily_lessons': 2},
      ],
      qualifications: [
        {'teacher_id': 1, 'subject_id': 1},
        {'teacher_id': 1, 'subject_id': 1},
        {'teacher_id': 2, 'subject_id': 1},
        {'teacher_id': 3, 'subject_id': 2},
      ],
      days: [
        for (var id = 1; id <= 3; id++) {'id': id, 'position': id, 'is_active': 1},
      ],
      slots: [
        for (var id = 1; id <= 2; id++)
          {'id': id, 'position': id, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(result.placements, hasLength(4));
    expect(result.complete, isFalse);
    expect(result.unscheduled.join(' '), contains('سعة المعلمين المؤهلين المشتركة'));
  });

  test('فاحص التعارضات يعتمد صف الشعبة الحالي للحصص غير المحفوظة', () {
    final issues = const ConflictDetectionService().scan(
      entries: [
        {'section_id': 1, 'subject_id': 1, 'teacher_id': 1, 'day_id': 1, 'slot_id': 1, 'grade_id': 2},
      ],
      sections: [{'id': 1, 'grade_id': 1}],
      qualifications: [{'teacher_id': 1, 'subject_id': 1}],
      teacherSubjectGrades: [{'teacher_id': 1, 'subject_id': 1, 'grade_id': 1}],
    );
    expect(issues.where((i) => i.type == 'تعذر تحديد صف الشعبة' || i.type == 'الصف غير مسموح للمعلم'), isEmpty);
  });

  test('80 مدرسة عشوائية: لا تزامن ولا مخالفة إتاحة أو نصاب', () {
    final random = Random(193);
    for (var sample = 0; sample < 80; sample++) {
      final days = <Map<String, Object?>>[
        for (var d = 1; d <= 3; d++)
          {'id': d, 'position': d, 'name': 'يوم $d', 'is_active': 1},
      ];
      final slots = <Map<String, Object?>>[
        for (var s = 1; s <= 3; s++)
          {'id': s, 'position': s, 'kind': 'lesson', 'is_available': 1},
      ];
      final sections = <Map<String, Object?>>[
        for (var s = 1; s <= 3; s++)
          {'id': s, 'grade_id': 1, 'max_daily_lessons': 3},
      ];
      final teachers = <Map<String, Object?>>[
        for (var t = 1; t <= 3; t++)
          {
            'id': t,
            'weekly_load': 2 + random.nextInt(6),
            'max_daily_lessons': 1 + random.nextInt(3),
            'max_consecutive_lessons': 1 + random.nextInt(3),
          },
      ];
      final qualifications = <Map<String, Object?>>[
        for (var t = 1; t <= 3; t++)
          for (var subject = 1; subject <= 2; subject++)
            if (random.nextBool()) {'teacher_id': t, 'subject_id': subject},
      ];
      final requirements = <Map<String, Object?>>[
        for (var section = 1; section <= 3; section++)
          for (var subject = 1; subject <= 2; subject++)
            {
              'section_id': section,
              'subject_id': subject,
              'weekly_lessons': 1 + random.nextInt(3),
              'allow_same_day': 0,
              'max_daily_lessons': 1,
            },
      ];
      final availability = <Map<String, Object?>>[
        for (var t = 1; t <= 3; t++)
          for (var d = 1; d <= 3; d++)
            for (var s = 1; s <= 3; s++)
              if (random.nextInt(5) == 0)
                {'teacher_id': t, 'day_id': d, 'slot_id': s, 'is_available': 0},
      ];
      final blocked = <Map<String, Object?>>[
        if (random.nextBool()) {'subject_id': 1, 'slot_id': 3},
      ];
      final result = const AutoSchedulerService(nodeLimit: 300).generate(
        sections: sections,
        requirements: requirements,
        teachers: teachers,
        qualifications: qualifications,
        days: days,
        slots: slots,
        teacherAvailability: availability,
        subjectBlockedSlots: blocked,
      );
      final teacherCells = <String>{};
      final sectionCells = <String>{};
      for (final entry in result.placements) {
        expect(
          teacherCells.add(
            '${entry['teacher_id']}:${entry['day_id']}:${entry['slot_id']}',
          ),
          isTrue,
        );
        expect(
          sectionCells.add(
            '${entry['section_id']}:${entry['day_id']}:${entry['slot_id']}',
          ),
          isTrue,
        );
      }
      final issues = const ConflictDetectionService().scan(
        entries: result.placements,
        requirements: requirements,
        sections: sections,
        slots: slots,
        days: days,
        teachers: teachers,
        qualifications: qualifications,
        teacherAvailability: availability,
        subjectBlockedSlots: blocked,
      );
      // Missing lessons are expected on deliberately infeasible instances.
      final violations = issues
          .where(
            (issue) => ![
              'نقص الحصص',
              'تكرار توقيت المادة في أيام متتالية',
            ].contains(issue.type),
          )
          .toList();
      expect(
        violations,
        isEmpty,
        reason:
            'sample $sample: ${violations.map((i) => '${i.type}: ${i.message}').join('; ')}',
      );
    }
  });
}
