import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/file_save_service.dart';

void main() {
  late Directory directory;
  setUp(() async {
    directory = await Directory.systemTemp.createTemp('jadwali-save-');
  });
  tearDown(() async {
    await directory.delete(recursive: true);
  });

  test('desktop save writes the actual binary data and replaces the selected file', () async {
    final file = File('${directory.path}/الجدول.pdf');
    await file.writeAsString('old longer contents that must be replaced');
    final payload = Uint8List.fromList([0, 255, 13, 10, 216, 172]);
    final saver = FileSaveService(
      writeSelectedPath: true,
      dialog: ({required dialogTitle, required fileName, required allowedExtensions, required bytes}) async {
        expect(fileName, 'الجدول.pdf');
        expect(allowedExtensions, ['pdf']);
        expect(bytes, payload);
        return file.path;
      },
    );
    expect(await saver.saveBytes(
      dialogTitle: 'حفظ', fileName: 'الجدول.pdf',
      allowedExtensions: ['pdf'], bytes: payload,
    ), file.path);
    expect(await file.readAsBytes(), payload);
  });

  test('cancelled save leaves the destination directory unchanged', () async {
    final saver = FileSaveService(
      writeSelectedPath: true,
      dialog: ({required dialogTitle, required fileName, required allowedExtensions, required bytes}) async => null,
    );
    expect(await saver.saveBytes(
      dialogTitle: 'حفظ', fileName: 'نسخة.json',
      allowedExtensions: ['json'], bytes: Uint8List.fromList([1, 2, 3]),
    ), isNull);
    expect(await directory.list().toList(), isEmpty);
  });

  test('mobile keeps picker-owned content URIs without filesystem writes', () async {
    const uri = 'content://school-backups/نسخة.json';
    final payload = Uint8List.fromList([1, 2, 3]);
    final saver = FileSaveService(
      writeSelectedPath: false,
      dialog: ({required dialogTitle, required fileName, required allowedExtensions, required bytes}) async {
        expect(bytes, payload);
        return uri;
      },
    );
    expect(await saver.saveBytes(
      dialogTitle: 'حفظ', fileName: 'نسخة.json',
      allowedExtensions: ['json'], bytes: payload,
    ), uri);
    expect(await directory.list().toList(), isEmpty);
  });

  test('desktop write errors propagate instead of reporting a successful export', () async {
    final saver = FileSaveService(
      writeSelectedPath: true,
      dialog: ({required dialogTitle, required fileName, required allowedExtensions, required bytes}) async =>
          '${directory.path}/missing/نسخة.json',
    );
    await expectLater(saver.saveBytes(
      dialogTitle: 'حفظ', fileName: 'نسخة.json',
      allowedExtensions: ['json'], bytes: Uint8List.fromList([1, 2, 3]),
    ), throwsA(isA<FileSystemException>()));
  });
}
