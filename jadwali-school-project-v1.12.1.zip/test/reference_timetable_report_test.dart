import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/reference_office_service.dart';
import 'package:iraqi_school_timetable/services/reference_timetable_layout.dart';

Map<String, Object?> fixture() => Map<String, Object?>.from(
  jsonDecode(File('test/fixtures/backup_school_181.json').readAsStringSync())
      as Map,
);
List<Map<String, Object?>> rows(Map<String, Object?> input, String key) =>
    (input[key] as List)
        .map((r) => Map<String, Object?>.from(r as Map))
        .toList();
ReferenceTimetableLayout schoolLayout() {
  final input = fixture();
  return ReferenceTimetableLayout(
    entries: rows(input, 'initialPlacements')
        .map(
          (e) => {
            ...e,
            'subject_name': 'مادة ${e['subject_id']}',
            'teacher_name': 'معلم ${e['teacher_id']}',
          },
        )
        .toList(),
    sections: rows(
      input,
      'sections',
    ).map((s) => {...s, 'max_daily_lessons': 6}).toList(),
    days: rows(input, 'days'),
    slots: rows(input, 'slots'),
  );
}

String file(Archive archive, String path) =>
    utf8.decode(archive.findFile(path)!.readBytes()!);
void saveExample(List<int> bytes, String fileName) {
  final directory = Platform.environment['JADWALI_REPORT_ARTIFACT_DIR'];
  if (directory == null) return;
  final folder = Directory(directory)..createSync(recursive: true);
  File('${folder.path}/$fileName').writeAsBytesSync(bytes);
}

void main() {
  test('reference form retains all 181 lessons and Sunday seventh only', () {
    final layout = schoolLayout(), group = schoolLayout().classGroups.single;
    expect(group, hasLength(12));
    expect(group.whereType<Map<String, Object?>>(), hasLength(6));
    expect(layout.days.map((d) => layout.periodsForDay(d, group).length), [
      7,
      6,
      6,
      6,
      6,
    ]);
    final table = layout.rows(group);
    expect(table, hasLength(33));
    expect(table.every((r) => r.length == 26), isTrue);
    expect(table[0].take(2), ['اليوم', 'الدرس']);
    expect(table[1].skip(2).take(2), ['المادة', 'المعلم']);
    final subjects = table
        .skip(2)
        .expand((r) => [for (var c = 2; c < r.length; c += 2) r[c]])
        .where((s) => s.isNotEmpty);
    expect(subjects, hasLength(181));
    // Sunday period seven: sixth class's subject and teacher, other pairs blank.
    expect(table[8][1], '٧');
    expect(table[8][12], startsWith('مادة '));
    expect(
      [
        for (var c = 2; c < 26; c += 2)
          if (c != 12) table[8][c],
      ].every((s) => s.isEmpty),
      isTrue,
    );
  });
  test(
    'thirteen classes get a second group and every entry is preserved once',
    () {
      final layout = ReferenceTimetableLayout(
        entries: [
          for (var i = 1; i <= 13; i++)
            {'section_id': i, 'day_id': 1, 'slot_id': 1, 'subject_name': 'م$i'},
        ],
        sections: [
          for (var i = 1; i <= 13; i++) {'id': i, 'section_name': '$i'},
        ],
        days: [
          {'id': 1, 'name': 'الأحد', 'is_active': 1},
        ],
        slots: [
          {'id': 1, 'kind': 'lesson', 'is_available': 1},
        ],
        templateColumns: false,
      );
      expect(layout.classGroups.map((g) => g.length), [12, 1]);
      expect(
        layout.classGroups
            .expand((g) => layout.rows(g).skip(2))
            .expand((r) => r.skip(2))
            .where((s) => s.startsWith('م')),
        hasLength(13),
      );
      final bytes = const ReferenceOfficeService().timetable(
        layout: layout,
        schoolName: 'مدرسة',
        word: false,
      );
      final archive = ZipDecoder().decodeBytes(bytes);
      expect(archive.findFile('xl/worksheets/sheet2.xml'), isNotNull);
      expect(file(archive, 'xl/worksheets/sheet2.xml'), contains('م13'));
    },
  );
  test(
    'inactive saved days and late periods are never lost from the report',
    () {
      final layout = ReferenceTimetableLayout(
        entries: [
          {
            'section_id': 1,
            'day_id': 9,
            'slot_id': 8,
            'subject_name': 'حصة محفوظة',
          },
        ],
        sections: [
          {'id': 1, 'max_daily_lessons': 6},
        ],
        days: [
          {'id': 9, 'name': 'يوم معطل', 'is_active': 0},
        ],
        slots: [
          for (var i = 1; i <= 8; i++)
            {
              'id': i,
              'position': i,
              'kind': 'lesson',
              'is_available': i == 8 ? 0 : 1,
            },
        ],
      );
      expect(layout.rows(layout.classGroups.single).last[2], 'حصة محفوظة');
      expect(
        layout.periodsForDay(layout.days.single, layout.classGroups.single),
        hasLength(8),
      );
    },
  );
  test('colliding saved entries are shown together instead of silently overwritten', () {
    final layout = ReferenceTimetableLayout(
      entries: [
        for (final name in ['الأولى', 'الثانية'])
          {'section_id': 1, 'day_id': 1, 'slot_id': 1, 'subject_name': name},
      ],
      sections: [
        {'id': 1},
      ],
      days: [
        {'id': 1},
      ],
      slots: [
        {'id': 1, 'kind': 'lesson'},
      ],
    );
    expect(layout.rows(layout.classGroups.single).last[2], 'الأولى\nالثانية');
  });
  for (final paper in ['A3', 'A4']) {
    test(
      'Excel $paper has two headers, merged days, RTL and literal metadata',
      () {
        final bytes = const ReferenceOfficeService().timetable(
          layout: schoolLayout(),
          schoolName: 'مدرسة الاختبار',
          word: false,
          paper: paper,
          number: '2',
          date: '24/10/2026',
          manager: 'المدير',
        );
        final sheet = file(
          ZipDecoder().decodeBytes(bytes),
          'xl/worksheets/sheet1.xml',
        );
        saveExample(bytes, 'jadwali-native-reference-$paper.xlsx');
      expect(sheet, contains('rightToLeft="1"'));
        expect(sheet, contains('topLeftCell="C5"'));
        expect(sheet, contains('A5:A11'));
        expect(sheet, contains('C3:D3'));
        expect(sheet, contains('paperSize="${paper == 'A4' ? 9 : 8}"'));
        expect(sheet, contains('24/10/2026'));
        expect(sheet, contains('مدير المدرسة: المدير'));
        expect(RegExp('>مادة ').allMatches(sheet), hasLength(181));
      },
    );
    test(
      'Word $paper merges class headers and days while preserving Arabic names',
      () {
        final bytes = const ReferenceOfficeService().timetable(
          layout: schoolLayout(),
          schoolName: 'مدرسة الاختبار',
          word: true,
          paper: paper,
        );
        final doc = file(ZipDecoder().decodeBytes(bytes), 'word/document.xml');
        saveExample(bytes, 'jadwali-native-reference-$paper.docx');
      expect(doc, contains('<w:bidiVisual/>'));
        expect(doc, contains('<w:gridSpan w:val="2"/>'));
        expect(doc, contains('<w:vMerge w:val="restart"/>'));
        expect(doc, contains('w:orient="landscape"'));
        expect(doc, contains('w:w="${paper == 'A4' ? 16838 : 23811}"'));
        expect(RegExp('>مادة ').allMatches(doc), hasLength(181));
      },
    );
  }
  test('empty school still exports a valid form', () {
    final layout = ReferenceTimetableLayout(
      entries: [],
      sections: [],
      days: [],
      slots: [],
    );
    for (final word in [true, false]) {
      final bytes = const ReferenceOfficeService().timetable(
        layout: layout,
        schoolName: '',
        word: word,
      );
      expect(ZipDecoder().decodeBytes(bytes).files.length, greaterThan(2));
    }
  });
}
