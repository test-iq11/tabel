import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/teacher_absence_service.dart';

Map<String, Object?> school({bool secondDay = true, bool substitute = true}) => {
  'sections': <Map<String, Object?>>[{'id': 1, 'grade_id': 1, 'max_daily_lessons': 1}],
  'requirements': <Map<String, Object?>>[{'section_id': 1, 'subject_id': 1, 'weekly_lessons': 1, 'allow_same_day': 0}],
  'teachers': <Map<String, Object?>>[
    {'id': 1, 'name': 'T1', 'weekly_load': 2, 'max_daily_lessons': 1},
    {'id': 2, 'name': 'T2', 'weekly_load': 2, 'max_daily_lessons': 1},
  ],
  'qualifications': <Map<String, Object?>>[
    {'teacher_id': 1, 'subject_id': 1},
    if (substitute) {'teacher_id': 2, 'subject_id': 1},
  ],
  'teacherGrades': <Map<String, Object?>>[],
  'teacherSubjectGrades': <Map<String, Object?>>[],
  'teacherAvailability': <Map<String, Object?>>[],
  'subjectBlockedSlots': <Map<String, Object?>>[],
  'days': <Map<String, Object?>>[
    {'id': 1, 'position': 0, 'name': 'الأحد', 'is_active': 1},
    if (secondDay) {'id': 2, 'position': 1, 'name': 'الاثنين', 'is_active': 1},
  ],
  'slots': <Map<String, Object?>>[{'id': 1, 'position': 0, 'kind': 'lesson', 'is_available': 1}],
  'entries': <Map<String, Object?>>[
    {'id': 1, 'section_id': 1, 'subject_id': 1, 'teacher_id': 1, 'day_id': 1, 'slot_id': 1},
  ],
};

void main() {
  test('uses a qualified substitute without changing the source availability or source rows', () {
    final input = school();
    final result = const TeacherAbsenceService().plan(input, teacherId: 1, dayId: 1, nodeLimit: 1000);
    expect(result.complete, isTrue);
    expect(result.affectedCount, 1);
    expect(result.substitutionCount, 1);
    expect(result.entries.single['teacher_id'], 2);
    expect((input['teacherAvailability'] as List), isEmpty);
    expect((input['entries'] as List).single['teacher_id'], 1);
    expect(result.availability.single['is_available'], 0);
    expect(TeacherAbsencePlan.fromMap(result.toMap()).complete, isTrue);
  });

  test('can rearrange another weekday when no qualified substitute exists', () {
    final result = const TeacherAbsenceService().plan(
      school(substitute: false), teacherId: 1, dayId: 1, nodeLimit: 1000,
    );
    expect(result.complete, isTrue);
    expect(result.substitutionCount, 0);
    expect(result.entries.single['teacher_id'], 1);
    expect(result.entries.single['day_id'], 2);
  });

  test('an impossible absence is not reported as complete and never fabricates a replacement', () {
    final result = const TeacherAbsenceService().plan(
      school(secondDay: false, substitute: false), teacherId: 1, dayId: 1, nodeLimit: 1000,
    );
    expect(result.complete, isFalse);
    expect(result.entries, isEmpty);
    expect(result.messages, isNotEmpty);
  });

  test('a lesson pinned to the absent teacher requires explicit unpinning', () {
    final input = school();
    (input['entries'] as List).single['is_locked'] = 1;
    final result = const TeacherAbsenceService().plan(input, teacherId: 1, dayId: 1);
    expect(result.complete, isFalse);
    expect(result.entries.single['teacher_id'], 1);
    expect(result.messages.join(' '), contains('مثبتة'));
  });

  test('subject qualification does not bypass grade eligibility', () {
    final input = school();
    input['teacherSubjectGrades'] = <Map<String, Object?>>[
      {'teacher_id': 1, 'subject_id': 1, 'grade_id': 1},
      {'teacher_id': 2, 'subject_id': 1, 'grade_id': 2},
    ];
    final result = const TeacherAbsenceService().plan(input, teacherId: 1, dayId: 1, nodeLimit: 1000);
    expect(result.complete, isTrue);
    expect(result.substitutionCount, 0);
    expect(result.entries.single['teacher_id'], 1);
    expect(result.entries.single['day_id'], 2);
  });

  test('absence of an unscheduled teacher leaves the valid schedule intact', () {
    final result = const TeacherAbsenceService().plan(school(), teacherId: 2, dayId: 1);
    expect(result.complete, isTrue);
    expect(result.affectedCount, 0);
    expect(result.entries.single['teacher_id'], 1);
  });

  test('rejects invalid or disabled absence periods', () {
    final result = const TeacherAbsenceService().plan(school(), teacherId: 1, dayId: 1, slotIds: [99]);
    expect(result.complete, isFalse);
    expect(result.entries, isEmpty);
  });
}
