import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:iraqi_school_timetable/services/conflict_detection_service.dart';

/// The school data is anonymized; its teacher IDs, qualifications, workloads,
/// requirement counts, and valid 181-lesson starting schedule are unchanged.
void main() {
  final input = jsonDecode(
    File('test/fixtures/backup_school_181.json').readAsStringSync(),
  ) as Map<String, dynamic>;
  List<Map<String, Object?>> rows(String key) => (input[key] as List)
      .map((row) => Map<String, Object?>.from(row as Map))
      .toList();

  final subjectIds = rows('requirements')
      .map((row) => row['subject_id'] as int)
      .toSet()
      .toList()
    ..sort();
  final slotIds = rows('slots').map((row) => row['id'] as int).toList()
    ..sort();

  void verify(List<Map<String, Object?>> extraBlocks, {bool completeExpected = true}) {
    final blocks = [...rows('subjectBlockedSlots'), ...extraBlocks];
    final result = const AutoSchedulerService(nodeLimit: 5000).generate(
      sections: rows('sections'),
      requirements: rows('requirements'),
      teachers: rows('teachers'),
      qualifications: rows('qualifications'),
      teacherGrades: rows('teacherGrades'),
      teacherSubjectGrades: rows('teacherSubjectGrades'),
      subjectBlockedSlots: blocks,
      days: rows('days'),
      slots: rows('slots'),
      teacherAvailability: rows('teacherAvailability'),
      initialPlacements: rows('initialPlacements'),
    );
    expect(result.complete, completeExpected,
        reason: 'blocks=$extraBlocks; missing=${result.unscheduled}; '
            'dailySpread=${result.dailySpreadIssues}');
    expect(result.requestedCount, 181);
    expect(result.placements, hasLength(completeExpected ? 181 : 180));
    if (!completeExpected) {
      expect(result.unscheduled, isNotEmpty);
      expect(result.dailySpreadIssues, isEmpty);
      expect(result.searchLimitReached, isFalse,
          reason: 'The known 180-lesson capacity bound was reached.');
    }

    final expected = <String, int>{};
    for (final requirement in rows('requirements')) {
      final key = '${requirement['section_id']}:${requirement['subject_id']}';
      expected[key] = (expected[key] ?? 0) +
          (requirement['weekly_lessons'] as int);
    }
    // With Arabic blocked in both late periods, sixth grade cannot receive
    // the sixth weekly lesson without violating its same-day-repeat setting.
    // This is the only known impossible pair; all other requirements still fit.
    if (!completeExpected) expected['11:2'] = 5;
    final actual = <String, int>{};
    for (final entry in result.placements) {
      final key = '${entry['section_id']}:${entry['subject_id']}';
      actual[key] = (actual[key] ?? 0) + 1;
      expect(
        blocks.any((block) => block['subject_id'] == entry['subject_id'] &&
            block['slot_id'] == entry['slot_id']),
        isFalse,
        reason: 'A blocked lesson was retained: $entry',
      );
    }
    expect(actual, expected);

    final issues = const ConflictDetectionService().scan(
      entries: result.placements,
      requirements: rows('requirements'),
      sections: rows('sections'),
      slots: rows('slots'),
      teachers: rows('teachers'),
      qualifications: rows('qualifications'),
      days: rows('days'),
      teacherGrades: rows('teacherGrades'),
      teacherSubjectGrades: rows('teacherSubjectGrades'),
      subjectBlockedSlots: blocks,
      teacherAvailability: rows('teacherAvailability'),
    );
    // Adjacent-day timing is a soft preference; every assignment, workload,
    // consecutive-lesson, availability, and daily-coverage rule must still pass.
    final violations = issues.where(
      (issue) => issue.type != 'تكرار توقيت المادة في أيام متتالية' &&
          !(!completeExpected && issue.type == 'نقص الحصص' &&
              issue.sectionId == 11 && issue.subjectId == 2),
    );
    expect(violations, isEmpty,
        reason: violations.map((issue) => '${issue.type}: ${issue.message}').join('\n'));
  }

  test('backup school: retains the valid 181-lesson baseline', () {
    verify([]);
  });

  for (final subjectId in subjectIds) {
    for (final slotId in slotIds) {
      test('backup school: blocks subject $subjectId in period $slotId', () {
        verify([{'subject_id': subjectId, 'slot_id': slotId}]);
      });
    }
  }
  for (final subjectId in subjectIds) {
    for (var first = 0; first < slotIds.length; first++) {
      for (var second = first + 1; second < slotIds.length; second++) {
        final a = slotIds[first], b = slotIds[second];
        final impossible = subjectId == 2 && a == 6 && b == 7;
        test('backup school: blocks subject $subjectId in periods $a and $b', () {
          verify([
            {'subject_id': subjectId, 'slot_id': a},
            {'subject_id': subjectId, 'slot_id': b},
          ], completeExpected: !impossible);
        });
      }
    }
  }

  final mixedCases = jsonDecode(
    File('test/fixtures/backup_school_mixed_blocks.json').readAsStringSync(),
  ) as List;
  for (final value in mixedCases) {
    final scenario = value as Map;
    final blocks = (scenario['blocked'] as List)
        .map((row) => Map<String, Object?>.from(row as Map)).toList();
    test('backup school: mixed restrictions case ${scenario['case']}', () {
      verify(blocks);
    });
  }

}
