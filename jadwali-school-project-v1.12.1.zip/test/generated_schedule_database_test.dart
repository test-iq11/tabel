import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  late Directory folder;
  late DatabaseService storage;
  late Map<String, Object?> input;
  late int year, original;
  List<Map<String, Object?>> rows(String key) => (input[key] as List)
      .map((r) => Map<String, Object?>.from(r as Map)).toList();
  setUp(() async {
    sqfliteFfiInit();
    folder = await Directory.systemTemp.createTemp('jadwali-181-save-');
    storage = DatabaseService.withStorage(factory: databaseFactoryFfi, directory: folder.path);
    input = Map<String, Object?>.from(jsonDecode(File('test/fixtures/backup_school_181.json').readAsStringSync()) as Map);
    final db = await storage.database;
    await db.transaction((txn) async {
      await txn.delete('time_slots');
      for (final row in rows('slots')) { await txn.insert('time_slots', row); }
      final existingSubjects = (await txn.query('subjects')).map((s) => s['id']).toSet();
      for (final id in rows('requirements').map((r) => r['subject_id']).toSet()) {
        if (!existingSubjects.contains(id)) await txn.insert('subjects', {'id': id, 'name': 'المادة $id'});
      }
      for (final row in rows('sections')) {
        await txn.insert('sections', {'id': row['id'], 'grade_id': row['grade_id'], 'name': row['section_name'], 'max_daily_lessons': 6});
      }
      for (final row in rows('teachers')) { await txn.insert('teachers', row); }
      for (final row in rows('qualifications')) { await txn.insert('teacher_subjects', row); }
      for (final row in rows('teacherSubjectGrades')) { await txn.insert('teacher_subject_grades', row); }
      for (final row in rows('requirements')) {
        await txn.insert('section_subject_requirements', {for (final key in
          ['section_id', 'subject_id', 'weekly_lessons', 'max_daily_lessons', 'allow_same_day']) key: row[key]});
      }
    });
    year = (await storage.activeYearId())!;
    original = await storage.saveAsNewVersion(yearId: year, name: 'الجدول السابق',
      entries: rows('initialPlacements'), requireComplete: true);
  });
  tearDown(() async { await storage.close(); await folder.delete(recursive: true); });

  Future<List<Map<String, Object?>>> solveNew() async {
    final db = await storage.database;
    await db.insert('subject_blocked_slots', {'subject_id': 3, 'slot_id': 1});
    await db.insert('subject_blocked_slots', {'subject_id': 3, 'slot_id': 2});
    final result = const AutoSchedulerService(nodeLimit: 60000).generate(
      sections: rows('sections'), requirements: rows('requirements'), teachers: rows('teachers'),
      qualifications: rows('qualifications'), teacherSubjectGrades: rows('teacherSubjectGrades'),
      days: rows('days'), slots: rows('slots'), subjectBlockedSlots: await db.query('subject_blocked_slots'),
      feasibilityOnly: true,
    );
    expect(result.complete, isTrue);
    return result.placements;
  }
  test('181 lessons replace the active timetable while preserving its archived predecessor', () async {
    final entries = await solveNew();
    final next = await storage.saveAsNewVersion(yearId: year, name: 'الجدول الجديد', entries: entries,
      requireComplete: true, expectedActiveVersionId: original);
    expect(await storage.activeVersionId(year), next);
    expect(await storage.entriesDetailed(versionId: next), hasLength(181));
    expect(await storage.entriesDetailed(versionId: original), hasLength(181));
    expect((await storage.summary())['الحصص الموزعة'], 181);
    expect((await storage.rows('timetable_versions')).where((v) => v['is_active'] == 1), hasLength(1));
  });
  test('a missing lesson cannot replace the active full schedule', () async {
    final entries = await solveNew();
    entries.removeLast();
    final before = (await storage.rows('timetable_versions')).length;
    await expectLater(storage.saveAsNewVersion(yearId: year, name: 'ناقص', entries: entries,
      requireComplete: true, expectedActiveVersionId: original), throwsStateError);
    expect(await storage.activeVersionId(year), original);
    expect(await storage.rows('timetable_versions'), hasLength(before));
  });
  test('new constraints are rechecked inside the save transaction', () async {
    final entries = await solveNew();
    final db = await storage.database;
    final chosen = entries.firstWhere((e) => e['subject_id'] != 3);
    await db.insert('subject_blocked_slots', {'subject_id': chosen['subject_id'], 'slot_id': chosen['slot_id']});
    await expectLater(storage.saveAsNewVersion(yearId: year, name: 'قديم القيود', entries: entries,
      requireComplete: true, expectedActiveVersionId: original), throwsStateError);
    expect(await storage.activeVersionId(year), original);
  });
  test('a stale active version cannot be replaced by an obsolete search result', () async {
    final entries = await solveNew();
    await expectLater(storage.saveAsNewVersion(yearId: year, name: 'قديم', entries: entries,
      requireComplete: true, expectedActiveVersionId: original + 999), throwsStateError);
    expect(await storage.activeVersionId(year), original);
  });
  test('a late pin change prevents replacing the schedule with a conflicting result', () async {
    final entries = await solveNew();
    final pin = rows('initialPlacements').firstWhere((old) => !entries.any((e) =>
      ['section_id', 'subject_id', 'teacher_id', 'day_id', 'slot_id'].every((k) => old[k] == e[k])));
    await storage.setEntryLock(yearId: year, sectionId: pin['section_id'] as int,
      dayId: pin['day_id'] as int, slotId: pin['slot_id'] as int, locked: true);
    await expectLater(storage.saveAsNewVersion(yearId: year, name: 'تثبيت قديم', entries: entries,
      requireComplete: true, expectedActiveVersionId: original), throwsStateError);
    expect(await storage.activeVersionId(year), original);
  });
  test('a database failure rolls back both entries and active-version changes', () async {
    final entries = await solveNew();
    final db = await storage.database;
    final before = (await storage.rows('timetable_versions')).length;
    await db.execute('''CREATE TRIGGER reject_new_schedule BEFORE INSERT ON timetable_entries
      WHEN NEW.version_id != $original BEGIN SELECT RAISE(ABORT, 'save failure'); END''');
    await expectLater(storage.saveAsNewVersion(yearId: year, name: 'فشل حفظ', entries: entries,
      requireComplete: true, expectedActiveVersionId: original), throwsA(isA<DatabaseException>()));
    expect(await storage.activeVersionId(year), original);
    expect(await storage.rows('timetable_versions'), hasLength(before));
    expect(await storage.entriesDetailed(versionId: original), hasLength(181));
  });
}
