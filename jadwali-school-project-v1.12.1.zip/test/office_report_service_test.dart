import 'dart:convert';

import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/office_report_service.dart';
import 'package:iraqi_school_timetable/services/timetable_report_layout.dart';

void main() {
  const schoolName = 'مدرسة الاختبار';
  const academicYear = '2026-2027';
  const versionName = 'الجدول التجريبي';
  const status = 'مسودة';
  final sections = <Map<String, Object?>>[
    {'id': 1, 'grade_name': 'الأول الابتدائي', 'section_name': 'أ'},
    {'id': 2, 'grade_name': 'السادس الابتدائي', 'section_name': 'ب'},
  ];
  final days = <Map<String, Object?>>[
    {'id': 1, 'name': 'الأحد', 'position': 1, 'is_active': 1},
    {'id': 2, 'name': 'الاثنين', 'position': 2, 'is_active': 1},
    {'id': 3, 'name': 'الثلاثاء', 'position': 3, 'is_active': 1},
    {'id': 4, 'name': 'الأربعاء', 'position': 4, 'is_active': 1},
    {'id': 5, 'name': 'الخميس', 'position': 5, 'is_active': 1},
  ];
  final slots = <Map<String, Object?>>[
    {'id': 1, 'name': 'الحصة الأولى', 'start_time': '08:00', 'end_time': '08:45', 'position': 1, 'kind': 'lesson', 'is_available': 1},
  ];
  final entries = <Map<String, Object?>>[
    {'section_id': 1, 'day_id': 1, 'slot_id': 1, 'day_position': 1, 'slot_position': 1, 'subject_name': 'اللغة العربية', 'teacher_name': 'أحمد'},
  ];

  test('Word export is a ZIP-based OOXML document with A3 landscape and Arabic text', () async {
    final bytes = await OfficeReportService().buildDocx(
      schoolName: schoolName,
      academicYear: academicYear,
      versionName: versionName,
      status: status,
      entries: entries,
      sections: sections,
      days: days,
      slots: slots,
    );
    expect(bytes.length, greaterThan(100));
    final archive = ZipDecoder().decodeBytes(bytes);
    final document = archive.findFile('word/document.xml');
    expect(document, isNotNull);
    final xml = utf8.decode(document!.readBytes()!);
    expect(xml, contains('w:w="23811"'));
    expect(xml, contains('w:orient="landscape"'));
    expect(xml, contains('اللغة العربية'));
    expect(xml, contains('أحمد'));
    expect(xml, contains('السادس'));
    expect(xml, contains('الصف السادس'));
    expect(xml, contains('الأيام عمودية والصفوف والشعب أفقية'));
    expect(xml.indexOf('الأحد'), lessThan(xml.indexOf('الخميس')));
    expect(xml, contains('08:00'));
    expect(xml, contains('08:45'));
    // Time labels belong to the matching lesson cell in the class-by-day matrix.
    expect(RegExp('08:00').allMatches(xml).length, 1);
    expect(RegExp('08:45').allMatches(xml).length, 1);
  });

  test('Excel export sets the paper to A3 landscape and preserves Arabic text', () async {
    final bytes = await OfficeReportService().buildXlsx(
      schoolName: schoolName,
      academicYear: academicYear,
      versionName: versionName,
      status: status,
      entries: entries,
      sections: sections,
      days: days,
      slots: slots,
    );
    expect(bytes.length, greaterThan(100));
    final archive = ZipDecoder().decodeBytes(bytes);
    final worksheet = archive.findFile('xl/worksheets/sheet1.xml');
    expect(worksheet, isNotNull);
    final xml = utf8.decode(worksheet!.readBytes()!);
    expect(xml, contains('paperSize="8"'));
    expect(xml, contains('orientation="landscape"'));
    expect(xml, contains('اللغة العربية'));
    expect(xml, contains('الأحد'));
    expect(xml, contains('السادس'));
    expect(xml, contains('الأيام عمودية والصفوف والشعب أفقية'));
    expect(xml.indexOf('الأحد'), lessThan(xml.indexOf('الخميس')));
    expect(xml, contains('08:00'));
    expect(xml, contains('08:45'));
    expect(RegExp('08:00').allMatches(xml).length, 1);
    expect(RegExp('08:45').allMatches(xml).length, 1);
    expect(archive.findFile('xl/worksheets/sheet2.xml'), isNull);
  });

  test('all export formats use weekdays as rows and grades/sections as columns', () {
    final layout = TimetableReportLayout(
      entries: [
        {'section_id': 1, 'day_id': 1, 'slot_id': 1, 'subject_name': 'اللغة العربية', 'teacher_name': 'أحمد'},
      ],
      sections: [
        {'id': 1, 'grade_name': 'الأول الابتدائي', 'section_name': 'أ', 'grade_position': 0},
        {'id': 2, 'grade_name': 'السادس الابتدائي', 'section_name': 'ب', 'grade_position': 5},
      ],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 2, 'is_active': 1},
        {'id': 4, 'name': 'الأربعاء', 'position': 3, 'is_active': 1},
        {'id': 5, 'name': 'الخميس', 'position': 4, 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الحصة الأولى', 'start_time': '8:00', 'end_time': '8:45', 'position': 0, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    final rows = layout.rowsForAllSections();
    expect(rows, hasLength(6)); // Header plus one row for each school day.
    expect(rows[0][0], 'اليوم');
    expect(rows[0][1], 'الصف الأول\nالشعبة أ');
    expect(rows[0][2], 'الصف السادس\nالشعبة ب');
    expect(rows[1][0], 'الأحد');
    expect(rows[1][1], contains('08:00-08:45'));
    expect(rows[1][1], contains('اللغة العربية'));
    expect(rows[1][1], contains('أحمد'));
    expect(rows[1][2], isEmpty);
    expect(rows[5][0], 'الخميس');
    expect(rows.every((row) => row.length == 3), isTrue);
  });
}
