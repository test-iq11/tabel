import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/constraint_explanation_service.dart';

void main() {
  const service = ConstraintExplanationService();
  Map<String, Object?> school() => Map<String, Object?>.from(
    jsonDecode(File('test/fixtures/backup_school_181.json').readAsStringSync()) as Map,
  );
  Map<String, Object?> simple() => {
    'sections': [
      {'id': 1, 'grade_id': 1, 'max_daily_lessons': 2},
      {'id': 2, 'grade_id': 1, 'max_daily_lessons': 2},
    ],
    'requirements': [
      {'section_id': 1, 'subject_id': 1, 'weekly_lessons': 1, 'allow_same_day': 0},
      {'section_id': 2, 'subject_id': 1, 'weekly_lessons': 1, 'allow_same_day': 0},
    ],
    'teachers': [{'id': 1, 'name': 'المعلم أ', 'weekly_load': 4, 'max_daily_lessons': 2}],
    'qualifications': [{'teacher_id': 1, 'subject_id': 1}],
    'days': [for (var id = 1; id <= 3; id++) {'id': id, 'position': id, 'name': 'يوم $id', 'is_active': 1}],
    'slots': [for (var id = 1; id <= 2; id++) {'id': id, 'position': id, 'kind': 'lesson', 'is_available': 1}],
  };

  test('does not invent contradictions for the valid 181 lesson school', () {
    expect(service.explain(school()), isEmpty);
  });

  test('explains the actual sixth grade Arabic contradiction without relaxing it', () {
    final input = school();
    input['subjectBlockedSlots'] = [
      {'subject_id': 2, 'slot_id': 6}, {'subject_id': 2, 'slot_id': 7},
    ];
    final explanation = service.explain(input).singleWhere(
      (item) => item.code == 'subject_period_capacity:11:2',
    );
    expect(explanation.proven, isTrue);
    expect(explanation.reason, contains('6 حصص'));
    expect(explanation.reason, contains('5 فقط'));
    expect(explanation.affectedSectionIds, [11]);
    expect(explanation.suggestions.join(' '), contains('السادسة'));
    expect(input['subjectBlockedSlots'], [
      {'subject_id': 2, 'slot_id': 6}, {'subject_id': 2, 'slot_id': 7},
    ]);
  });

  test('subject expertise alone does not grant a teacher another grade', () {
    final input = simple();
    input['teacherSubjectGrades'] = [{'teacher_id': 1, 'subject_id': 1, 'grade_id': 2}];
    final explanations = service.explain(input);
    final item = explanations.firstWhere((e) => e.code.startsWith('no_qualified_teacher:'));
    expect(item.proven, isTrue);
    expect(item.affectedTeacherIds, [1]);
    expect(item.suggestions.join(' '), contains('صفوف'));
  });

  test('shared teacher bottleneck is detected despite sufficient aggregate load', () {
    final input = simple();
    input['sections'] = [for (var id = 1; id <= 3; id++) {'id': id, 'grade_id': 1, 'max_daily_lessons': 2}];
    input['requirements'] = [
      {'section_id': 1, 'subject_id': 1, 'weekly_lessons': 3},
      {'section_id': 2, 'subject_id': 2, 'weekly_lessons': 3},
      {'section_id': 3, 'subject_id': 3, 'weekly_lessons': 1},
    ];
    input['teachers'] = [
      {'id': 1, 'weekly_load': 2, 'max_daily_lessons': 2},
      {'id': 2, 'weekly_load': 2, 'max_daily_lessons': 2},
      {'id': 3, 'weekly_load': 20, 'max_daily_lessons': 2},
    ];
    input['qualifications'] = [
      for (final teacher in [1, 2])
        for (final subject in [1, 2]) {'teacher_id': teacher, 'subject_id': subject},
      {'teacher_id': 3, 'subject_id': 3},
    ];
    final explanations = service.explain(input);
    expect(explanations.where((e) => e.code.startsWith('mandatory_teacher_capacity:')), isEmpty);
    final shared = explanations.singleWhere((e) => e.code == 'shared_teacher_capacity');
    expect(shared.reason, contains('5 من أصل 7'));
    expect(shared.proven, isTrue);
  });

  test('two locked simultaneous lessons expose their teacher conflict', () {
    final input = simple();
    input['lockedPlacements'] = [
      for (var section = 1; section <= 2; section++)
        {'section_id': section, 'subject_id': 1, 'teacher_id': 1, 'day_id': 1, 'slot_id': 1},
    ];
    final locks = service.explain(input).where((e) => e.code.startsWith('locked:')).toList();
    expect(locks.any((e) => e.title.contains('تعارض المعلم') && e.affectedTeacherIds.contains(1)), isTrue);
    expect(locks.every((e) => e.proven), isTrue);
    expect(locks.every((e) => e.suggestions.any((s) => s.contains('تثبيت'))), isTrue);
  });

  test('a locked lesson cannot bypass blocked periods or teacher availability', () {
    final input = simple();
    input['subjectBlockedSlots'] = [{'subject_id': 1, 'slot_id': 1}];
    input['teacherAvailability'] = [{'teacher_id': 1, 'day_id': 1, 'slot_id': 1, 'is_available': 0}];
    input['lockedPlacements'] = [
      {'section_id': 1, 'subject_id': 1, 'teacher_id': 1, 'day_id': 1, 'slot_id': 1},
    ];
    final explanations = service.explain(input);
    expect(explanations.any((e) => e.code.startsWith('locked:المادة في فترة ممنوعة:')), isTrue);
    expect(explanations.any((e) => e.code.startsWith('locked:المعلم غير متاح في الفترة:')), isTrue);
  });

  test('a daily subject cannot remain locked twice on a day at the cost of another day', () {
    final input = simple();
    input['days'] = [for (var id = 1; id <= 5; id++) {'id': id, 'position': id, 'is_active': 1}];
    input['requirements'] = [
      {'section_id': 1, 'subject_id': 1, 'weekly_lessons': 5, 'allow_same_day': 1, 'max_daily_lessons': 2},
    ];
    input['teachers'] = [{'id': 1, 'weekly_load': 10, 'max_daily_lessons': 2}];
    input['lockedPlacements'] = [
      for (var slot = 1; slot <= 2; slot++)
        {'section_id': 1, 'subject_id': 1, 'teacher_id': 1, 'day_id': 1, 'slot_id': slot},
    ];
    expect(service.explain(input).any((e) => e.code == 'locked_daily_coverage:1:1'), isTrue);
  });

  test('search exhaustion is only an advisory and explanations round-trip immutably', () {
    final input = simple()..['searchLimitReached'] = true;
    final item = service.explain(input).single;
    expect(item.code, 'search_limit');
    expect(item.proven, isFalse);
    final decoded = ConstraintExplanation.fromMap(Map<String, Object?>.from(jsonDecode(jsonEncode(item.toMap())) as Map));
    expect(decoded.code, item.code);
    expect(decoded.proven, isFalse);
    expect(() => decoded.suggestions.add('change'), throwsUnsupportedError);
    expect(() => decoded.affectedSectionIds.add(1), throwsUnsupportedError);
  });
}
