import 'dart:isolate';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/schedule_search_controller.dart';

Map<String, Object?> _school() => {
  'sections': [{'id': 1, 'grade_id': 1, 'max_daily_lessons': 1}],
  'requirements': [{'section_id': 1, 'subject_id': 1, 'weekly_lessons': 2, 'allow_same_day': 0}],
  'teachers': [{'id': 1, 'weekly_load': 2, 'max_daily_lessons': 1}],
  'qualifications': [{'teacher_id': 1, 'subject_id': 1}],
  'days': [{'id': 1, 'position': 1, 'is_active': 1}, {'id': 2, 'position': 2, 'is_active': 1}],
  'slots': [{'id': 1, 'position': 1, 'kind': 'lesson', 'is_available': 1}],
  'nodeLimit': 1000,
};

void _blockingWorker(List<Object?> arguments) {
  final port = arguments[0] as SendPort;
  final options = Map<String, Object?>.from(arguments[1] as Map);
  final input = Map<String, Object?>.from(options['input'] as Map);
  port.send({
    'type': 'progress', 'profile': 'minimal_changes', 'preference': 'minimal_changes',
    'bestCount': 1, 'requestedCount': 2, 'exploredNodes': 10,
    'testNodeLimit': options['nodeLimit'], 'testSeed': input['initialPlacements'],
    'placements': [{'section_id': 1, 'subject_id': 1, 'teacher_id': 1, 'day_id': 1, 'slot_id': 1}],
  });
  // A deliberately synchronous CPU loop proves cancellation kills the worker;
  // a queued command or cooperative await could never stop this loop.
  while (true) {}
}

void _crashingWorker(List<Object?> arguments) => throw StateError('worker lifecycle test');
void _emptyWorker(List<Object?> arguments) {}

void main() {
  test('real engine publishes a complete solution and can start again', () async {
    final controller = ScheduleSearchController();
    addTearDown(controller.dispose);
    final events = <Map<String, Object?>>[];
    final subscription = controller.events.listen(events.add);
    addTearDown(subscription.cancel);
    final solutions = await controller.start(_school());
    expect(solutions, hasLength(1));
    expect(solutions.single['complete'], isTrue);
    expect(solutions.single['placements'] as List, hasLength(2));
    expect(controller.isRunning, isFalse);
    expect(events.any((event) => event['type'] == 'profile'), isTrue);
    expect((await controller.start(_school())).single['complete'], isTrue);
  });

  test('stop kills a synchronous isolate and retains the latest best snapshot', () async {
    final controller = ScheduleSearchController(worker: _blockingWorker);
    addTearDown(controller.dispose);
    final published = controller.events.firstWhere((event) => event['type'] == 'progress');
    final result = controller.start(_school());
    await published.timeout(const Duration(seconds: 5));
    final stopped = await controller.stop().timeout(const Duration(seconds: 2));
    expect(controller.isRunning, isFalse);
    expect(stopped, hasLength(1));
    expect(stopped.single['placements'] as List, hasLength(1));
    expect(stopped.single['complete'], isFalse);
    expect(await result, stopped);
  });

  test('continue uses the best seed and a larger search budget', () async {
    final controller = ScheduleSearchController(worker: _blockingWorker);
    addTearDown(controller.dispose);
    var progress = controller.events.firstWhere((event) => event['type'] == 'progress');
    final first = controller.start(_school());
    expect((await progress)['testNodeLimit'], 1000);
    await controller.stop();
    await first;
    progress = controller.events.firstWhere((event) => event['type'] == 'progress');
    final next = controller.continueSearch(timeLimit: const Duration(seconds: 10));
    final event = await progress.timeout(const Duration(seconds: 5));
    expect(event['testNodeLimit'], 2000);
    expect(event['testSeed'] as List, hasLength(1));
    await controller.stop();
    await next;
  });

  test('continuing then stopping before a new snapshot retains the prior safe result', () async {
    final controller = ScheduleSearchController(worker: _blockingWorker);
    addTearDown(controller.dispose);
    final published = controller.events.firstWhere((event) => event['type'] == 'progress');
    final first = controller.start(_school());
    await published.timeout(const Duration(seconds: 5));
    await controller.stop();
    await first;
    final retry = controller.continueSearch();
    final kept = await controller.stop();
    expect(kept.single['placements'] as List, hasLength(1));
    expect(await retry, kept);
  });

  test('dispose during spawn resolves the attempt and rejects future starts', () async {
    final controller = ScheduleSearchController(worker: _blockingWorker);
    final attempt = controller.start(_school());
    await controller.dispose();
    expect(await attempt, isEmpty);
    expect(controller.isRunning, isFalse);
    expect(() => controller.start(_school()), throwsStateError);
  });

  test('worker errors and unexpected exits resolve as failures, not stuck searches', () async {
    for (final worker in [_crashingWorker, _emptyWorker]) {
      final controller = ScheduleSearchController(worker: worker);
      await expectLater(controller.start(_school()).timeout(const Duration(seconds: 5)), throwsStateError);
      expect(controller.isRunning, isFalse);
      await controller.dispose();
    }
  });
}
