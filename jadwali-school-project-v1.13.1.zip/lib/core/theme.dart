import 'package:flutter/material.dart';

ThemeData buildAppTheme({String style = 'calm'}) {
  final dark = style == 'dark';
  final navy = dark ? const Color(0xFFE7EEF3) : style == 'blue'
      ? const Color(0xFF183B66)
      : style == 'paper'
      ? const Color(0xFF4B4A3C)
      : const Color(0xFF18334A);
  final blue = dark ? const Color(0xFF71C7B9) : style == 'blue'
      ? const Color(0xFF2878C8)
      : style == 'paper'
      ? const Color(0xFF807650)
      : const Color(0xFF147D76);
  const green = Color(0xFF16845B);
  final scheme =
      ColorScheme.fromSeed(
        seedColor: blue,
        brightness: dark ? Brightness.dark : Brightness.light,
      ).copyWith(
        primary: blue,
        secondary: navy,
        tertiary: green,
        surface: dark ? const Color(0xFF1A2937) : Colors.white,
      );
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'JadwaliArabic',
    colorScheme: scheme,
    scaffoldBackgroundColor: dark
        ? const Color(0xFF111D29)
        : style == 'paper'
            ? const Color(0xFFF3F1EC)
            : const Color(0xFFF5F7F8),
    appBarTheme: AppBarTheme(
      backgroundColor: dark ? const Color(0xFF1A2937) : const Color(0xFFF5F7F8),
      foregroundColor: navy,
      iconTheme: IconThemeData(color: blue),
      actionsIconTheme: IconThemeData(color: blue),
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
      titleTextStyle: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w800,
        color: navy,
      ),
    ),
    iconTheme: IconThemeData(color: blue),
    listTileTheme: ListTileThemeData(
      iconColor: blue,
      contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 3),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(14)),
      ),
    ),
    dividerTheme: DividerThemeData(
      color: dark ? const Color(0xFF30424F) : const Color(0xFFE6EBEE),
      thickness: 1,
      space: 1,
    ),
    cardTheme: CardThemeData(
      color: dark ? const Color(0xFF1A2937) : Colors.white,
      elevation: 0,
      shadowColor: const Color(0x0B163045),
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: dark ? const Color(0xFF30424F) : const Color(0xFFE6EBEE)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: dark ? const Color(0xFF20313F) : Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(13),
        borderSide: const BorderSide(color: Color(0xFFDCE4EE)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(13),
        borderSide: const BorderSide(color: Color(0xFFDCE4EE)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(13),
        borderSide: BorderSide(color: blue, width: 1.7),
      ),
      prefixIconColor: blue,
      suffixIconColor: const Color(0xFF71839A),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: blue,
        foregroundColor: dark ? const Color(0xFF112E2B) : Colors.white,
        minimumSize: const Size(44, 46),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: blue,
        minimumSize: const Size(44, 44),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: const Color(0xFFEAF1F8),
      labelStyle: const TextStyle(fontWeight: FontWeight.w600),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: dark ? const Color(0xFF1A2937) : Colors.white,
      surfaceTintColor: Colors.transparent,
      indicatorColor: dark ? const Color(0xFF243F42) : const Color(0xFFE8F4F0),
      indicatorShape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      iconTheme: WidgetStateProperty.resolveWith<IconThemeData?>(
        (states) => IconThemeData(
          color: states.contains(WidgetState.selected)
              ? navy
              : const Color(0xFF71839A),
          size: 23,
        ),
      ),
      labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>(
        (states) => TextStyle(
          fontSize: 11,
          fontWeight: states.contains(WidgetState.selected)
              ? FontWeight.w800
              : FontWeight.w500,
          color: states.contains(WidgetState.selected)
              ? navy
              : const Color(0xFF71839A),
        ),
      ),
    ),
    textTheme: TextTheme(
      headlineSmall: TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.w800,
        color: navy,
      ),
      titleLarge: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w800,
        color: navy,
      ),
      titleMedium: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: navy,
      ),
      bodyMedium: TextStyle(fontSize: 14, height: 1.45),
    ),
  );
}
