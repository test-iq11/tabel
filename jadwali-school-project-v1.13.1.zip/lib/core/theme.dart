import 'package:flutter/material.dart';

ThemeData buildAppTheme({String style = 'calm'}) {
  final navy = style == 'blue'
      ? const Color(0xFF182C52)
      : style == 'paper'
      ? const Color(0xFF62594D)
      : const Color(0xFF6655BE);
  final blue = style == 'blue'
      ? const Color(0xFF3563CF)
      : style == 'paper'
      ? const Color(0xFF62594D)
      : const Color(0xFF6655BE);
  const green = Color(0xFF16845B);
  final scheme =
      ColorScheme.fromSeed(
        seedColor: blue,
        brightness: Brightness.light,
      ).copyWith(
        primary: navy,
        secondary: blue,
        tertiary: green,
        surface: Colors.white,
      );
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'JadwaliUI',
    fontFamilyFallback: const ['JadwaliLatin'],
    colorScheme: scheme,
    scaffoldBackgroundColor: style == 'paper'
        ? const Color(0xFFF3F1EC)
        : const Color(0xFFF7F8FC),
    appBarTheme: AppBarTheme(
      backgroundColor: Color(0xFFF7F8FC),
      foregroundColor: navy,
      iconTheme: IconThemeData(color: blue),
      actionsIconTheme: IconThemeData(color: blue),
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
      titleTextStyle: TextStyle(
        fontFamily: 'JadwaliUI',
        fontFamilyFallback: const ['JadwaliLatin'],
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: const Color(0xFF28314F),
      ),
    ),
    iconTheme: IconThemeData(color: blue),
    listTileTheme: ListTileThemeData(
      iconColor: blue,
      contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 3),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(14)),
      ),
    ),
    dividerTheme: const DividerThemeData(
      color: Color(0xFFE6E6F0),
      thickness: 1,
      space: 1,
    ),
    cardTheme: CardThemeData(
      color: Colors.white,
      elevation: 0,
      shadowColor: const Color(0x140D2340),
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: Color(0xFFE6E6F0)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFE4E2ED)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFE4E2ED)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: blue, width: 1.7),
      ),
      prefixIconColor: blue,
      suffixIconColor: const Color(0xFF6F758B),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: navy,
        foregroundColor: Colors.white,
        minimumSize: const Size(44, 46),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: navy,
        minimumSize: const Size(44, 44),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: Colors.white,
      selectedColor: const Color(0xFFEEEAFB),
      secondarySelectedColor: const Color(0xFFEEEAFB),
      secondaryLabelStyle: const TextStyle(
        fontFamily: 'JadwaliUI',
        color: Color(0xFF6652B1),
      ),
      labelStyle: const TextStyle(
        fontFamily: 'JadwaliUI',
        fontFamilyFallback: ['JadwaliLatin'],
        color: Color(0xFF28314F),
        fontWeight: FontWeight.w600,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white,
      surfaceTintColor: Colors.transparent,
      indicatorColor: const Color(0xFFEEEAFB),
      indicatorShape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      iconTheme: WidgetStateProperty.resolveWith<IconThemeData?>(
        (states) => IconThemeData(
          color: states.contains(WidgetState.selected)
              ? navy
              : const Color(0xFF6F758B),
          size: 23,
        ),
      ),
      labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>(
        (states) => TextStyle(
          fontSize: 11,
          fontWeight: states.contains(WidgetState.selected)
              ? FontWeight.w800
              : FontWeight.w500,
          color: states.contains(WidgetState.selected)
              ? navy
              : const Color(0xFF6F758B),
        ),
      ),
    ),
    textTheme: TextTheme(
      headlineSmall: TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.w800,
        color: navy,
      ),
      titleLarge: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: const Color(0xFF28314F),
      ),
      titleMedium: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: navy,
      ),
      bodyMedium: TextStyle(
        fontSize: 13,
        height: 1.7,
        color: Color(0xFF28314F),
      ),
    ),
  );
}
