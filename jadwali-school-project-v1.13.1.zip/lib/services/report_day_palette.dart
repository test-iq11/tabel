/// A single, print-safe palette shared by PDF, Office and Flutter preview.
/// Sunday through Thursday keep one consistent tint across every section,
/// subject, teacher and lesson in the day's report block.
class ReportDayPalette {
  const ReportDayPalette._();

  static const colors = <int>[
    0xFFEAF3FB, // Sunday: pale blue
    0xFFEAF5EF, // Monday: pale green
    0xFFFFF5DF, // Tuesday: pale amber
    0xFFF0ECFA, // Wednesday: pale violet
    0xFFFBEFF1, // Thursday: pale rose
  ];

  static int argb(int dayIndex) => colors[dayIndex % colors.length];
  static String rgb(int dayIndex) =>
      argb(dayIndex).toRadixString(16).substring(2).toUpperCase();

  /// Two blank table fields between adjacent class columns.
  static const gradeGapFields = 2;
  /// Two blank table rows between adjacent day blocks.
  static const dayGapFields = 2;
}
