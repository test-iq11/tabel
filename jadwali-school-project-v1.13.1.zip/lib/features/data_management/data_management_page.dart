import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/ui_helpers.dart';
import '../../core/preview_widgets.dart';
import 'requirements_matrix.dart';
import '../../core/editor_navigation_guard.dart';
import '../../data/database_service.dart';

/// Normalizes Arabic text so searches work across common spelling variants.
String _normalizeArabicSearch(String value) {
  return value
      .toLowerCase()
      .replaceAll(RegExp(r'[\u064B-\u065F\u0670\u0640]'), '')
      .replaceAll(RegExp(r'[أإآٱ]'), 'ا')
      .replaceAll('ى', 'ي')
      .replaceAll('ة', 'ه')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}

const List<Color> _subjectPalette = <Color>[
  Color(0xFF6655BE),
  Color(0xFF16845B),
  Color(0xFF8A63C7),
  Color(0xFFE09B32),
  Color(0xFF168A9B),
  Color(0xFFD65B70),
  Color(0xFF5D7C2F),
  Color(0xFFB45F06),
  Color(0xFF4C64A8),
];

Color _displaySubjectColor(Map<String, Object?> subject, int index) {
  final raw = subject['color'];
  final stored = raw is int
      ? raw
      : (raw is num ? raw.toInt() : int.tryParse('$raw') ?? 0);
  // Older databases gave every subject the same default blue; vary those
  // defaults by list position while preserving any custom user-selected color.
  if (stored > 0 && stored != 0xFF2196F3) return Color(stored);
  return _subjectPalette[index % _subjectPalette.length];
}

enum DataArea { teachers, requirements, subjects, settings }

class DataManagementPage extends StatelessWidget {
  const DataManagementPage({
    required this.onChanged,
    this.area = DataArea.settings,
    this.onOpenTeacher,
    this.navigationGuard,
    super.key,
  });
  final VoidCallback onChanged;
  final DataArea area;
  final EditorNavigationGuard? navigationGuard;
  final ValueChanged<int>? onOpenTeacher;

  @override
  Widget build(BuildContext context) {
    if (area == DataArea.settings) {
      return DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('إعدادات المدرسة'),
            bottom: const TabBar(
              tabs: [
                Tab(text: 'المدرسة والأوقات'),
                Tab(text: 'الصفوف والشعب'),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              _SettingsTab(onChanged: onChanged),
              _GradesSectionsTab(onChanged: onChanged),
            ],
          ),
        ),
      );
    }
    final title = switch (area) {
      DataArea.teachers => 'المعلمون',
      DataArea.requirements => 'الحصص المطلوبة',
      DataArea.subjects => 'المواد والقيود',
      DataArea.settings => 'المدرسة',
    };
    return Scaffold(
      appBar:
          area == DataArea.teachers ||
              area == DataArea.requirements ||
              area == DataArea.subjects
          ? null
          : AppBar(title: Text(title)),
      body: switch (area) {
        DataArea.teachers => _TeachersTab(
          onChanged: onChanged,
          onOpenTeacher: onOpenTeacher,
        ),
        DataArea.requirements => _RequirementsTab(
          onChanged: onChanged,
          navigationGuard: navigationGuard,
        ),
        DataArea.subjects => _SubjectsTab(onChanged: onChanged),
        DataArea.settings => _SettingsTab(onChanged: onChanged),
      },
    );
  }
}

class _GradesSectionsTab extends StatefulWidget {
  const _GradesSectionsTab({required this.onChanged});
  final VoidCallback onChanged;
  @override
  State<_GradesSectionsTab> createState() => _GradesSectionsTabState();
}

class _GradesSectionsTabState extends State<_GradesSectionsTab> {
  Future<List<dynamic>> _load() async => Future.wait([
    DatabaseService.instance.gradesDetailed(),
    DatabaseService.instance.sectionsDetailed(),
    DatabaseService.instance.rows('stages', orderBy: 'position'),
  ]);
  void _refresh() => setState(() {});

  Future<void> _addGrade(List<Map<String, Object?>> stages) async {
    final name = TextEditingController();
    int? stageId = stages.isEmpty ? null : stages.first['id'] as int;
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, update) => AlertDialog(
          title: const Text('إضافة صف'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: name,
                autofocus: true,
                decoration: const InputDecoration(labelText: 'اسم الصف'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<int>(
                initialValue: stageId,
                decoration: const InputDecoration(labelText: 'المرحلة'),
                items: stages
                    .map(
                      (s) => DropdownMenuItem(
                        value: s['id'] as int,
                        child: Text('${s['name']}'),
                      ),
                    )
                    .toList(),
                onChanged: (v) => update(() => stageId = v),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    if (name.text.trim().isEmpty || stageId == null) {
      if (mounted)
        showMessage(context, 'أدخل اسم الصف واختر المرحلة.', error: true);
      return;
    }
    try {
      await DatabaseService.instance.add('grades', {
        'stage_id': stageId,
        'name': name.text.trim(),
        'max_daily_lessons': 6,
        'position': 99,
      });
      _refresh();
      widget.onChanged();
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر إضافة الصف: $e', error: true);
    }
  }

  Future<void> _addSection(List<Map<String, Object?>> grades) async {
    final name = TextEditingController();
    int? gradeId = grades.isEmpty ? null : grades.first['id'] as int;
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, update) => AlertDialog(
          title: const Text('إضافة شعبة'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<int>(
                initialValue: gradeId,
                decoration: const InputDecoration(labelText: 'الصف'),
                items: grades
                    .map(
                      (g) => DropdownMenuItem(
                        value: g['id'] as int,
                        child: Text(displayGradeName(g['name'])),
                      ),
                    )
                    .toList(),
                onChanged: (v) => update(() => gradeId = v),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: name,
                autofocus: true,
                decoration: const InputDecoration(
                  labelText: 'اسم الشعبة (أ، ب، ج...)',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    if (name.text.trim().isEmpty || gradeId == null) {
      if (mounted)
        showMessage(context, 'اختر الصف واكتب اسم الشعبة.', error: true);
      return;
    }
    try {
      await DatabaseService.instance.add('sections', {
        'grade_id': gradeId,
        'name': name.text.trim(),
        'max_daily_lessons': 6,
      });
      _refresh();
      widget.onChanged();
    } catch (e) {
      if (mounted)
        showMessage(
          context,
          'تعذر إضافة الشعبة. تحقق من عدم تكرار اسمها ضمن الصف نفسه. ($e)',
          error: true,
        );
    }
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
    future: _load(),
    builder: (context, snapshot) {
      if (snapshot.hasError)
        return emptyState(
          icon: Icons.error_outline,
          title: 'تعذر تحميل البيانات',
          message: '${snapshot.error}',
        );
      if (snapshot.connectionState != ConnectionState.done)
        return const Center(child: CircularProgressIndicator());
      if (!snapshot.hasData)
        return emptyState(
          icon: Icons.info_outline,
          title: 'لا توجد بيانات',
          message: 'لم تُرجع قاعدة البيانات بيانات لهذا القسم.',
        );
      final grades = (snapshot.data![0] as List).cast<Map<String, Object?>>();
      final sections = (snapshot.data![1] as List).cast<Map<String, Object?>>();
      final stages = (snapshot.data![2] as List).cast<Map<String, Object?>>();
      return ListView(
        padding: const EdgeInsets.all(16),
        children: [
          pageHeading(
            'الصفوف والشعب',
            'أضف الصفوف والشعب حسب الهيكل الفعلي للمدرسة.',
            trailing: PopupMenuButton<String>(
              onSelected: (value) =>
                  value == 'grade' ? _addGrade(stages) : _addSection(grades),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'grade', child: Text('إضافة صف')),
                PopupMenuItem(value: 'section', child: Text('إضافة شعبة')),
              ],
              child: const Icon(
                Icons.add_circle,
                size: 32,
                color: Color(0xFF6655BE),
              ),
            ),
          ),
          if (grades.isEmpty)
            emptyState(
              icon: Icons.school_outlined,
              title: 'لا توجد صفوف',
              message: 'أضف مرحلة دراسية ثم أنشئ الصف الأول.',
            ),
          ...grades.map((grade) {
            final gradeSections = sections
                .where((s) => s['grade_id'] == grade['id'])
                .toList();
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              displayGradeName(grade['name']),
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF28314F),
                              ),
                            ),
                          ),
                          Chip(
                            backgroundColor: const Color(0xFFEEEAFB),
                            label: Text(
                              '${gradeSections.length} شعبة',
                              style: const TextStyle(
                                color: Color(0xFF28314F),
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          IconButton(
                            tooltip: 'حذف الصف',
                            onPressed: () async {
                              if (await confirmAction(
                                context,
                                'حذف الصف',
                                'سيُرفض الحذف إذا كان الصف مرتبطاً بشعب أو بيانات أخرى. هل تريد المتابعة؟',
                              )) {
                                try {
                                  await DatabaseService.instance.remove(
                                    'grades',
                                    grade['id'] as int,
                                  );
                                  _refresh();
                                  widget.onChanged();
                                } catch (e) {
                                  if (context.mounted)
                                    showMessage(
                                      context,
                                      'تعذر حذف الصف لوجود ارتباطات: $e',
                                      error: true,
                                    );
                                }
                              }
                            },
                            icon: const Icon(
                              Icons.delete_outline,
                              color: Colors.redAccent,
                            ),
                          ),
                        ],
                      ),
                      if (gradeSections.isEmpty)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 6),
                          child: Text(
                            'لا توجد شعب مضافة لهذا الصف.',
                            style: TextStyle(color: Colors.black54),
                          ),
                        ),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: gradeSections
                            .map(
                              (s) => InputChip(
                                label: Text(
                                  '${s['section_name']}',
                                  style: const TextStyle(
                                    color: Color(0xFF28314F),
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                onDeleted: () async {
                                  if (await confirmAction(
                                    context,
                                    'حذف الشعبة',
                                    'سيتم حذف الشعبة إذا لم تمنع ارتباطات الجدول ذلك.',
                                  )) {
                                    try {
                                      await DatabaseService.instance.remove(
                                        'sections',
                                        s['id'] as int,
                                      );
                                      _refresh();
                                      widget.onChanged();
                                    } catch (e) {
                                      if (context.mounted)
                                        showMessage(
                                          context,
                                          'تعذر حذف الشعبة: $e',
                                          error: true,
                                        );
                                    }
                                  }
                                },
                              ),
                            )
                            .toList(),
                      ),
                      const SizedBox(height: 5),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: TextButton.icon(
                          onPressed: () => _addSection(grades),
                          icon: const Icon(Icons.add),
                          label: const Text('إضافة شعبة'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => _addGrade(stages),
            icon: const Icon(Icons.add),
            label: const Text('إضافة صف جديد'),
          ),
        ],
      );
    },
  );
}

class _SubjectsTab extends StatefulWidget {
  const _SubjectsTab({required this.onChanged});
  final VoidCallback onChanged;
  @override
  State<_SubjectsTab> createState() => _SubjectsTabState();
}

class _SubjectsTabState extends State<_SubjectsTab> {
  static const _subjectOrderKey = 'jadwali_subject_display_order_v1';
  late Future<List<dynamic>> _dataFuture;
  final _pendingBlocks = <String>{};

  @override
  void initState() {
    super.initState();
    _dataFuture = _load();
  }

  Future<List<dynamic>> _load() async {
    final values = await Future.wait([
      DatabaseService.instance.rows('subjects', orderBy: 'name'),
      DatabaseService.instance.rows('time_slots', orderBy: 'position'),
      DatabaseService.instance.rows('subject_blocked_slots'),
    ]);
    // sqflite/plugin adapters may expose query results as a read-only list.
    // A cast() alone is only a view; calling sort() on that view can throw
    // Unsupported operation: read-only. Copy to a growable list before sorting.
    // Copy every query result into growable, owned collections. SQLite/plugin
    // adapters can return fixed/read-only lists; a cast() is only a view and
    // sorting or reordering it can throw Unsupported operation: read-only.
    final subjects = (values[0] as List)
        .map((row) => Map<String, Object?>.from(row as Map))
        .toList(growable: true);
    final slots = (values[1] as List)
        .map((row) => Map<String, Object?>.from(row as Map))
        .toList(growable: true);
    final blockedRows = (values[2] as List)
        .map((row) => Map<String, Object?>.from(row as Map))
        .toList(growable: true);
    final prefs = await SharedPreferences.getInstance();
    final savedOrder = (prefs.getStringList(_subjectOrderKey) ?? <String>[])
        .map((value) => int.tryParse(value))
        .whereType<int>()
        .toList();
    final positionById = <int, int>{
      for (var i = 0; i < savedOrder.length; i++) savedOrder[i]: i,
    };
    subjects.sort((a, b) {
      final aId = a['id'] as int;
      final bId = b['id'] as int;
      final aPosition = positionById[aId] ?? 1 << 30;
      final bPosition = positionById[bId] ?? 1 << 30;
      final rank = aPosition.compareTo(bPosition);
      return rank != 0 ? rank : '${a['name']}'.compareTo('${b['name']}');
    });
    return <dynamic>[subjects, slots, blockedRows];
  }

  void _reload() => setState(() => _dataFuture = _load());

  Future<void> _reorderSubjects(
    List<Map<String, Object?>> subjects,
    int draggedId,
    int targetId,
  ) async {
    final from = subjects.indexWhere((subject) => subject['id'] == draggedId);
    final to = subjects.indexWhere((subject) => subject['id'] == targetId);
    if (from < 0 || to < 0 || from == to) return;
    final reordered = List<Map<String, Object?>>.from(subjects);
    final moved = reordered.removeAt(from);
    // When removing an item located before the target, the target shifts left.
    final insertionIndex = from < to ? to - 1 : to;
    reordered.insert(insertionIndex, moved);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _subjectOrderKey,
      reordered.map((subject) => '${subject['id']}').toList(),
    );
    if (mounted) setState(() => _dataFuture = _load());
    if (mounted)
      showMessage(
        context,
        'تم تغيير ترتيب المواد. سيُحفظ هذا الترتيب على الجهاز.',
      );
  }

  Future<void> _editSubject([Map<String, Object?>? item]) async {
    final name = TextEditingController(text: item?['name']?.toString() ?? '');
    final code = TextEditingController(text: item?['code']?.toString() ?? '');
    final daily = TextEditingController(
      text: '${item?['max_daily_lessons'] ?? 2}',
    );
    var morningPriority = (item?['morning_priority'] as num?)?.toInt() ?? 1;
    final dbService = DatabaseService.instance;
    final slots = (await dbService.rows(
      'time_slots',
      orderBy: 'position',
    )).where((slot) => slot['kind'] == 'lesson').toList();
    final blockedRows = item == null
        ? <Map<String, Object?>>[]
        : await dbService.rows('subject_blocked_slots');
    final selectedBlockedSlots = <int>{
      for (final row in blockedRows)
        if (item != null && row['subject_id'] == item['id'])
          row['slot_id'] as int,
    };
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, update) => AlertDialog(
          title: Text(item == null ? 'إضافة مادة' : 'تعديل مادة'),
          content: SizedBox(
            width: 450,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: name,
                    autofocus: true,
                    decoration: const InputDecoration(labelText: 'اسم المادة'),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: code,
                    decoration: const InputDecoration(
                      labelText: 'الرمز (اختياري)',
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: daily,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'الحد اليومي للشعبة',
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      'الفترات الممنوعة لهذه المادة',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                  const SizedBox(height: 4),
                  DropdownButtonFormField<int>(
                    initialValue: morningPriority,
                    decoration: const InputDecoration(
                      labelText: 'أولوية الفترات المبكرة عند موازنة المواد',
                    ),
                    items: const [
                      DropdownMenuItem(value: 1, child: Text('مرنة')),
                      DropdownMenuItem(value: 2, child: Text('متوسطة')),
                      DropdownMenuItem(
                        value: 3,
                        child: Text('مرتفعة — مادة تحتاج تركيزاً'),
                      ),
                    ],
                    onChanged: (value) {
                      if (value != null) update(() => morningPriority = value);
                    },
                  ),
                  const SizedBox(height: 12),
                  const Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      'اختر الحصص التي لا تريد أن تظهر فيها هذه المادة. سيستبعدها التوزيع التلقائي، ويمنع إدخالها يدوياً في هذه الفترات.',
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ),
                  const SizedBox(height: 6),
                  if (slots.isEmpty)
                    const Text(
                      'لا توجد فترات تدريس. أضف الحصص من تبويب المدرسة والأوقات.',
                    ),
                  ...slots.map(
                    (slot) => CheckboxListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      value: selectedBlockedSlots.contains(slot['id']),
                      title: Text('${slot['name']}'),
                      subtitle: Text(
                        '${slot['start_time']} - ${slot['end_time']}',
                      ),
                      onChanged: (value) => update(() {
                        final id = slot['id'] as int;
                        if (value == true)
                          selectedBlockedSlots.add(id);
                        else
                          selectedBlockedSlots.remove(id);
                      }),
                    ),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    if (name.text.trim().isEmpty) {
      if (mounted) showMessage(context, 'اسم المادة مطلوب.', error: true);
      return;
    }
    final values = {
      'name': name.text.trim(),
      'code': code.text.trim(),
      'max_daily_lessons': int.tryParse(daily.text) ?? 2,
      'morning_priority': morningPriority,
    };
    try {
      final db = await dbService.database;
      late int subjectId;
      await db.transaction((txn) async {
        if (item == null) {
          subjectId = await txn.insert('subjects', {
            ...values,
            'color': 4280391411,
            'allow_same_day': 0,
          });
        } else {
          subjectId = item['id'] as int;
          await txn.update(
            'subjects',
            values,
            where: 'id=?',
            whereArgs: [subjectId],
          );
        }
        await txn.delete(
          'subject_blocked_slots',
          where: 'subject_id=?',
          whereArgs: [subjectId],
        );
        for (final slotId in selectedBlockedSlots) {
          await txn.insert('subject_blocked_slots', {
            'subject_id': subjectId,
            'slot_id': slotId,
          });
        }
      });
      await dbService.log(
        item == null ? 'إضافة' : 'تعديل',
        'subjects',
        subjectId,
        'تحديث بيانات المادة والفترات الممنوعة: ${selectedBlockedSlots.length}',
      );
      _reload();
      widget.onChanged();
    } catch (e) {
      if (mounted)
        showMessage(
          context,
          'تعذر حفظ المادة؛ ربما يوجد اسم مكرر. $e',
          error: true,
        );
    }
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
    future: _dataFuture,
    builder: (context, snapshot) {
      if (snapshot.hasError)
        return emptyState(
          icon: Icons.error_outline,
          title: 'تعذر تحميل البيانات',
          message: '${snapshot.error}',
        );
      if (!snapshot.hasData && snapshot.connectionState != ConnectionState.done)
        return const Center(child: CircularProgressIndicator());
      if (!snapshot.hasData)
        return emptyState(
          icon: Icons.info_outline,
          title: 'لا توجد بيانات',
          message: 'لم تُرجع قاعدة البيانات بيانات لهذا القسم.',
        );
      final subjects = (snapshot.data![0] as List).cast<Map<String, Object?>>();
      final slots = (snapshot.data![1] as List).cast<Map<String, Object?>>();
      final blockedRows = (snapshot.data![2] as List)
          .cast<Map<String, Object?>>();
      return ListView(
        key: const PageStorageKey('subjects-list'),
        padding: const EdgeInsets.all(16),
        children: [
          pageHeading(
            'المواد الدراسية',
            'حدّد الفترات الممنوعة لكل مادة. اضغط مطولاً لإعادة ترتيب البطاقات.',
            trailing: IconButton(
              onPressed: () => _editSubject(),
              icon: const Icon(
                Icons.add_circle,
                size: 32,
                color: Color(0xFF6655BE),
              ),
            ),
          ),
          if (subjects.isEmpty)
            emptyState(
              icon: Icons.menu_book_outlined,
              title: 'لا توجد مواد',
              message: 'أضف المواد التي تدرسها المدرسة.',
            ),
          PreviewGrid(
            children: subjects.asMap().entries.map((subjectItem) {
              final index = subjectItem.key;
              final s = subjectItem.value;
              final subjectId = s['id'] as int;
              final subjectColor = _displaySubjectColor(s, index);
              final blockedIds = blockedRows
                  .where((r) => r['subject_id'] == subjectId)
                  .map((r) => r['slot_id'])
                  .toSet();
              final card = PreviewPanel(
                title: '${s['name']}',
                trailing: IconButton(
                  tooltip: 'تعديل المادة',
                  onPressed: () => _editSubject(s),
                  icon: const Icon(Icons.edit_outlined, size: 18),
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${blockedIds.length} فترات ممنوعة',
                        style: const TextStyle(
                          fontSize: 11,
                          color: previewMuted,
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'الفترات الممنوعة',
                        style: TextStyle(fontSize: 12),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          for (final slot in slots)
                            FilterChip(
                              key: ValueKey('block-$subjectId-${slot['id']}'),
                              label: Text(
                                '${slot['name']}',
                                style: const TextStyle(fontSize: 11),
                              ),
                              showCheckmark: false,
                              avatar: Icon(
                                blockedIds.contains(slot['id'])
                                    ? Icons.block
                                    : Icons.radio_button_unchecked,
                                size: 16,
                              ),
                              selected: blockedIds.contains(slot['id']),
                              selectedColor: const Color(0xFFFFE7E7),
                              onSelected:
                                  _pendingBlocks.contains(
                                    '$subjectId:${slot['id']}',
                                  )
                                  ? null
                                  : (blocked) async {
                                      final key = '$subjectId:${slot['id']}';
                                      setState(() => _pendingBlocks.add(key));
                                      try {
                                        final db = await DatabaseService
                                            .instance
                                            .database;
                                        await db.transaction((txn) async {
                                          await txn.delete(
                                            'subject_blocked_slots',
                                            where: 'subject_id=? AND slot_id=?',
                                            whereArgs: [subjectId, slot['id']],
                                          );
                                          if (blocked)
                                            await txn.insert(
                                              'subject_blocked_slots',
                                              {
                                                'subject_id': subjectId,
                                                'slot_id': slot['id'],
                                              },
                                            );
                                        });
                                        if (!mounted) return;
                                        setState(() {
                                          blockedRows.removeWhere(
                                            (r) =>
                                                r['subject_id'] == subjectId &&
                                                r['slot_id'] == slot['id'],
                                          );
                                          if (blocked)
                                            blockedRows.add({
                                              'subject_id': subjectId,
                                              'slot_id': slot['id'],
                                            });
                                        });
                                        widget.onChanged();
                                      } catch (e) {
                                        if (context.mounted)
                                          showMessage(
                                            context,
                                            'تعذر حفظ المنع: $e',
                                            error: true,
                                          );
                                      } finally {
                                        if (mounted)
                                          setState(
                                            () => _pendingBlocks.remove(key),
                                          );
                                      }
                                    },
                            ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Text(
                        'الحد اليومي: ${s['max_daily_lessons']} · الحظر يستبعد الفترة من التوزيع لجميع الصفوف.',
                        style: const TextStyle(
                          fontSize: 11,
                          color: previewMuted,
                        ),
                      ),
                      Align(
                        alignment: AlignmentDirectional.centerEnd,
                        child: TextButton(
                          onPressed: () async {
                            if (!await confirmAction(
                              context,
                              'حذف المادة',
                              'قد يمنع وجود حصص أو متطلبات مرتبطة حذف هذه المادة.',
                            ))
                              return;
                            try {
                              await DatabaseService.instance.remove(
                                'subjects',
                                subjectId,
                              );
                              if (!mounted) return;
                              _reload();
                              widget.onChanged();
                            } catch (e) {
                              if (context.mounted)
                                showMessage(
                                  context,
                                  'تعذر حذف المادة: $e',
                                  error: true,
                                );
                            }
                          },
                          child: const Text(
                            'حذف المادة',
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.redAccent,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
              return Padding(
                key: ValueKey('subject-order-wrap-$subjectId'),
                padding: const EdgeInsets.only(bottom: 9),
                child: DragTarget<int>(
                  onWillAcceptWithDetails: (details) =>
                      details.data != subjectId,
                  onAcceptWithDetails: (details) =>
                      _reorderSubjects(subjects, details.data, subjectId),
                  builder: (context, candidates, rejected) =>
                      LongPressDraggable<int>(
                        data: subjectId,
                        maxSimultaneousDrags: 1,
                        feedback: Material(
                          color: Colors.transparent,
                          child: SizedBox(
                            width: MediaQuery.sizeOf(context).width - 48,
                            child: Opacity(
                              opacity: .96,
                              child: Card(
                                color: subjectColor.withValues(alpha: .96),
                                child: ListTile(
                                  leading: const Icon(
                                    Icons.menu_book_rounded,
                                    color: Colors.white,
                                  ),
                                  title: Text(
                                    '${s['name']}',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                  trailing: const Icon(
                                    Icons.drag_indicator_rounded,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        childWhenDragging: Opacity(opacity: .25, child: card),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 140),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(18),
                            border: candidates.isNotEmpty
                                ? Border.all(color: subjectColor, width: 2)
                                : null,
                          ),
                          child: card,
                        ),
                      ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () => _editSubject(),
            icon: const Icon(Icons.add),
            label: const Text('إضافة مادة'),
          ),
        ],
      );
    },
  );
}

class _TeachersTab extends StatefulWidget {
  const _TeachersTab({required this.onChanged, this.onOpenTeacher});
  final ValueChanged<int>? onOpenTeacher;
  final VoidCallback onChanged;
  @override
  State<_TeachersTab> createState() => _TeachersTabState();
}

class _TeachersTabState extends State<_TeachersTab> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  late Future<List<dynamic>> _dataFuture;

  @override
  void didUpdateWidget(covariant _TeachersTab oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Refresh after changes to another school-data screen.
    _dataFuture = _load();
  }

  @override
  void initState() {
    super.initState();
    _dataFuture = _load();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _reload() {
    setState(() => _dataFuture = _load());
  }

  bool _matchesTeacher({
    required Map<String, Object?> teacher,
    required List<String> searchableValues,
  }) {
    final query = _normalizeArabicSearch(_searchQuery);
    if (query.isEmpty) return true;
    final searchable = _normalizeArabicSearch(
      [
        teacher['name']?.toString() ?? '',
        teacher['code']?.toString() ?? '',
        ...searchableValues,
      ].join(' '),
    );
    return searchable.contains(query);
  }

  Future<List<dynamic>> _load() async => Future.wait([
    DatabaseService.instance.rows('teachers', orderBy: 'name'),
    DatabaseService.instance.rows('subjects', orderBy: 'name'),
    DatabaseService.instance.rows('teacher_subjects'),
    DatabaseService.instance.rows('grades', orderBy: 'position'),
    DatabaseService.instance.rows('teacher_grades'),
    DatabaseService.instance.rows('teacher_subject_grades'),
    DatabaseService.instance.entriesDetailed(),
  ]);

  Future<void> _editTeacher(
    List<Map<String, Object?>> subjects, [
    Map<String, Object?>? teacher,
  ]) async {
    final name = TextEditingController(
      text: teacher?['name']?.toString() ?? '',
    );
    final code = TextEditingController(
      text: teacher?['code']?.toString() ?? '',
    );
    final weekly = TextEditingController(
      text: '${teacher?['weekly_load'] ?? 24}',
    );
    final daily = TextEditingController(
      text: '${teacher?['max_daily_lessons'] ?? 6}',
    );
    final consecutive = TextEditingController(
      text: '${teacher?['max_consecutive_lessons'] ?? 4}',
    );
    final dbService = DatabaseService.instance;
    final qualificationRows = await dbService.rows('teacher_subjects');
    final grades = await dbService.rows('grades', orderBy: 'position');
    final teacherGradeRows = await dbService.rows('teacher_grades');
    final subjectGradeRows = await dbService.rows('teacher_subject_grades');
    final selected = <int>{
      for (final q in qualificationRows)
        if (teacher != null && q['teacher_id'] == teacher['id'])
          q['subject_id'] as int,
    };
    final selectedGradeIds = <int>{
      for (final row in teacherGradeRows)
        if (teacher != null && row['teacher_id'] == teacher['id'])
          row['grade_id'] as int,
    };
    final gradesBySubject = <int, Set<int>>{};
    final allGradesBySubject = <int>{};
    for (final subjectId in selected) {
      final rows = subjectGradeRows
          .where(
            (r) =>
                r['teacher_id'] == teacher?['id'] &&
                r['subject_id'] == subjectId,
          )
          .toList();
      if (rows.any((r) => r['grade_id'] == 0)) {
        // لا نعرض «جميع الصفوف» إلا إذا كانت الصلاحية العامة محفوظة صراحة.
        allGradesBySubject.add(subjectId);
      } else if (rows.isNotEmpty) {
        gradesBySubject[subjectId] = rows
            .map((r) => r['grade_id'] as int)
            .toSet();
      } else if (selectedGradeIds.isNotEmpty) {
        // توافق: استخدم صلاحيات الصفوف القديمة كاختيار مبدئي لهذه المادة.
        gradesBySubject[subjectId] = Set<int>.from(selectedGradeIds);
      } else if (subjectGradeRows.isEmpty) {
        // في قاعدة قديمة لا تحتوي أي قواعد حديثة، نحافظ على السلوك السابق.
        allGradesBySubject.add(subjectId);
      } else {
        // توجد قواعد حديثة في قاعدة البيانات لكن هذه المادة بلا قاعدة لهذا المعلم؛
        // لا نحول غياب البيانات إلى إذن شامل، بل نطلب تحديد الصفوف صراحة.
        gradesBySubject[subjectId] = <int>{};
      }
    }
    // توافق مع النسخ السابقة: تستخدم قيود الصفوف العامة القديمة كاختيار مبدئي؛
    // إذا لم توجد قيود قديمة أو حديثة، يظل السلوك القديم متاحاً لهذه القاعدة فقط.
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, update) => AlertDialog(
          title: Text(teacher == null ? 'إضافة معلم' : 'تعديل بيانات المعلم'),
          content: SizedBox(
            width: 420,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: name,
                    autofocus: true,
                    decoration: const InputDecoration(
                      labelText: 'اسم المعلم الكامل',
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: code,
                    decoration: const InputDecoration(
                      labelText: 'الرمز (اختياري)',
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: weekly,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'النصاب الأسبوعي',
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: TextField(
                          controller: daily,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'الحد اليومي',
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: consecutive,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'أقصى حصص متتالية',
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      'المواد والصفوف المسموح بها لكل مادة',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  const Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      'حدد كل مادة على حدة ثم اختر الصفوف التي يدرّسها المعلم فيها. مثال: الإنكليزية للصفوف الأول والثاني والخامس والسادس، والأخلاقية للأول فقط.',
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ),
                  ...subjects.map((s) {
                    final subjectId = s['id'] as int;
                    final isSelected = selected.contains(subjectId);
                    final allForSubject = allGradesBySubject.contains(
                      subjectId,
                    );
                    final chosen = gradesBySubject[subjectId] ?? <int>{};
                    return Card(
                      margin: const EdgeInsets.only(top: 7),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          vertical: 4,
                          horizontal: 8,
                        ),
                        child: Column(
                          children: [
                            CheckboxListTile(
                              dense: true,
                              contentPadding: EdgeInsets.zero,
                              value: isSelected,
                              title: Text(
                                '${s['name']}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              onChanged: (value) => update(() {
                                if (value == true) {
                                  selected.add(subjectId);
                                  // اختيار مادة جديدة لا يمنح جميع الصفوف تلقائياً.
                                  allGradesBySubject.remove(subjectId);
                                  gradesBySubject[subjectId] = Set<int>.from(
                                    selectedGradeIds,
                                  );
                                } else {
                                  selected.remove(subjectId);
                                  allGradesBySubject.remove(subjectId);
                                  gradesBySubject.remove(subjectId);
                                }
                              }),
                            ),
                            if (isSelected) ...[
                              SwitchListTile(
                                dense: true,
                                contentPadding: const EdgeInsets.only(
                                  right: 24,
                                ),
                                title: const Text('جميع الصفوف لهذه المادة'),
                                value: allForSubject,
                                onChanged: (value) => update(() {
                                  if (value) {
                                    allGradesBySubject.add(subjectId);
                                    gradesBySubject.remove(subjectId);
                                  } else {
                                    allGradesBySubject.remove(subjectId);
                                    gradesBySubject[subjectId] = <int>{};
                                  }
                                }),
                              ),
                              if (!allForSubject)
                                Wrap(
                                  spacing: 4,
                                  runSpacing: 0,
                                  children: grades
                                      .map(
                                        (g) => FilterChip(
                                          label: Text(
                                            displayGradeName(g['name']),
                                            style: const TextStyle(
                                              color: Color(0xFF28314F),
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                          selected: chosen.contains(g['id']),
                                          selectedColor: const Color(
                                            0xFFDCEBFA,
                                          ),
                                          backgroundColor: const Color(
                                            0xFFF4F7FB,
                                          ),
                                          checkmarkColor: const Color(
                                            0xFF28314F,
                                          ),
                                          onSelected: (value) => update(() {
                                            final gradeId = g['id'] as int;
                                            final set = gradesBySubject
                                                .putIfAbsent(
                                                  subjectId,
                                                  () => <int>{},
                                                );
                                            if (value)
                                              set.add(gradeId);
                                            else
                                              set.remove(gradeId);
                                          }),
                                        ),
                                      )
                                      .toList(),
                                ),
                              if (!allForSubject && chosen.isEmpty)
                                const Padding(
                                  padding: EdgeInsets.only(bottom: 8),
                                  child: Text(
                                    'اختر صفاً واحداً على الأقل لهذه المادة.',
                                    style: TextStyle(
                                      color: Colors.redAccent,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                            ],
                          ],
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
    if (result != true) return;
    if (name.text.trim().isEmpty) {
      if (mounted) showMessage(context, 'اسم المعلم مطلوب.', error: true);
      return;
    }
    if (selected.any(
      (id) =>
          !allGradesBySubject.contains(id) &&
          (gradesBySubject[id]?.isEmpty ?? true),
    )) {
      if (mounted)
        showMessage(
          context,
          'لكل مادة اختر جميع الصفوف أو صفاً واحداً على الأقل.',
          error: true,
        );
      return;
    }
    final values = {
      'name': name.text.trim(),
      'code': code.text.trim(),
      'weekly_load': int.tryParse(weekly.text) ?? 24,
      'max_daily_lessons': int.tryParse(daily.text) ?? 6,
      'max_consecutive_lessons': int.tryParse(consecutive.text) ?? 4,
      'notes': teacher?['notes'] ?? '',
    };
    try {
      final db = await dbService.database;
      await db.transaction((txn) async {
        int id;
        if (teacher == null) {
          id = await txn.insert('teachers', values);
        } else {
          id = teacher['id'] as int;
          await txn.update('teachers', values, where: 'id=?', whereArgs: [id]);
        }
        await txn.delete(
          'teacher_subjects',
          where: 'teacher_id=?',
          whereArgs: [id],
        );
        for (final subjectId in selected) {
          await txn.insert('teacher_subjects', {
            'teacher_id': id,
            'subject_id': subjectId,
          });
        }
        await txn.delete(
          'teacher_grades',
          where: 'teacher_id=?',
          whereArgs: [id],
        );
        await txn.delete(
          'teacher_subject_grades',
          where: 'teacher_id=?',
          whereArgs: [id],
        );
        for (final subjectId in selected) {
          if (allGradesBySubject.contains(subjectId)) {
            await txn.insert('teacher_subject_grades', {
              'teacher_id': id,
              'subject_id': subjectId,
              'grade_id': 0,
            });
          } else {
            for (final gradeId in gradesBySubject[subjectId] ?? <int>{}) {
              await txn.insert('teacher_subject_grades', {
                'teacher_id': id,
                'subject_id': subjectId,
                'grade_id': gradeId,
              });
            }
          }
        }
      });
      if (mounted) _reload();
      widget.onChanged();
    } catch (e) {
      if (mounted)
        showMessage(context, 'تعذر حفظ بيانات المعلم: $e', error: true);
    }
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
    future: _dataFuture,
    builder: (context, snapshot) {
      if (snapshot.hasError)
        return emptyState(
          icon: Icons.error_outline,
          title: 'تعذر تحميل البيانات',
          message: '${snapshot.error}',
        );
      if (snapshot.connectionState != ConnectionState.done)
        return const Center(child: CircularProgressIndicator());
      if (!snapshot.hasData)
        return emptyState(
          icon: Icons.info_outline,
          title: 'لا توجد بيانات',
          message: 'لم تُرجع قاعدة البيانات بيانات لهذا القسم.',
        );
      final teachers = (snapshot.data![0] as List).cast<Map<String, Object?>>();
      final subjects = (snapshot.data![1] as List).cast<Map<String, Object?>>();
      final quals = (snapshot.data![2] as List).cast<Map<String, Object?>>();
      final grades = (snapshot.data![3] as List).cast<Map<String, Object?>>();
      final teacherGradeRows = (snapshot.data![4] as List)
          .cast<Map<String, Object?>>();
      final teacherSubjectGradeRows = (snapshot.data![5] as List)
          .cast<Map<String, Object?>>();
      final teacherCards = <Widget>[];
      for (final t in teachers) {
        final ids = quals
            .where((q) => q['teacher_id'] == t['id'])
            .map((q) => q['subject_id'])
            .toSet();
        final names = subjects
            .where((s) => ids.contains(s['id']))
            .map((s) => '${s['name']}')
            .join('، ');
        final gradeIds = teacherGradeRows
            .where((r) => r['teacher_id'] == t['id'])
            .map((r) => r['grade_id'])
            .toSet();
        final gradeNames = gradeIds.isEmpty
            ? (teacherSubjectGradeRows.isEmpty
                  ? 'جميع الصفوف (افتراضي)'
                  : 'لم تحدد الصفوف')
            : grades
                  .where((g) => gradeIds.contains(g['id']))
                  .map((g) => displayGradeName(g['name']))
                  .join('، ');
        final subjectGradeSummary = <String>[];
        for (final subjectId in ids) {
          final rows = teacherSubjectGradeRows
              .where(
                (r) =>
                    r['teacher_id'] == t['id'] && r['subject_id'] == subjectId,
              )
              .toList();
          final currentSubjectName = subjects.firstWhere(
            (s) => s['id'] == subjectId,
            orElse: () => {'name': 'مادة'},
          )['name'];
          if (rows.any((r) => r['grade_id'] == 0) ||
              (rows.isEmpty &&
                  teacherSubjectGradeRows.isEmpty &&
                  gradeIds.isEmpty)) {
            subjectGradeSummary.add('$currentSubjectName: جميع الصفوف');
          } else if (rows.isNotEmpty) {
            final allowed = rows.map((r) => r['grade_id']).toSet();
            final namesForSubject = grades
                .where((g) => allowed.contains(g['id']))
                .map((g) => displayGradeName(g['name']))
                .join('، ');
            subjectGradeSummary.add(
              '$currentSubjectName: ${namesForSubject.isEmpty ? 'لا توجد صفوف صالحة' : namesForSubject}',
            );
          } else if (gradeIds.isNotEmpty) {
            final namesForSubject = grades
                .where((g) => gradeIds.contains(g['id']))
                .map((g) => displayGradeName(g['name']))
                .join('، ');
            subjectGradeSummary.add(
              '$currentSubjectName: $namesForSubject (إعداد قديم)',
            );
          } else {
            subjectGradeSummary.add('$currentSubjectName: لم تحدد الصفوف');
          }
        }
        if (!_matchesTeacher(
          teacher: t,
          searchableValues: [
            names,
            gradeNames,
            ...subjectGradeSummary,
            'النصاب ${t['weekly_load']}',
            'يومي ${t['max_daily_lessons']}',
          ],
        ))
          continue;
        final assigned = (snapshot.data![6] as List)
            .cast<Map<String, Object?>>()
            .where((e) => e['teacher_id'] == t['id'])
            .length;
        final weekly = (t['weekly_load'] as num?)?.toInt() ?? 0;
        teacherCards.add(
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 43,
                        height: 43,
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primary
                              .withValues(alpha: .09),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          '${t['name']}'
                              .split(' ')
                              .where((w) => w.isNotEmpty)
                              .take(2)
                              .map((w) => w[0])
                              .join(),
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        tooltip: 'تعديل ${t['name']}',
                        icon: const Icon(Icons.edit_outlined, size: 19),
                        onPressed: () => _editTeacher(subjects, t),
                      ),
                      PopupMenuButton<String>(
                        onSelected: (_) async {
                          if (!await confirmAction(
                            context,
                            'حذف المعلم',
                            'قد تصبح حصصه بلا معلم. هل تريد الحذف؟',
                          ))
                            return;
                          try {
                            await DatabaseService.instance.remove(
                              'teachers',
                              t['id'] as int,
                            );
                            _reload();
                            widget.onChanged();
                          } catch (e) {
                            if (context.mounted)
                              showMessage(
                                context,
                                'تعذر حذف المعلم: $e',
                                error: true,
                              );
                          }
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(
                            value: 'delete',
                            child: Text('حذف المعلم'),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '${t['name']}',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    names.isEmpty ? 'لم تحدد المواد' : names,
                    style: const TextStyle(fontSize: 11, color: previewMuted),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'النصاب الأسبوعي',
                          style: TextStyle(fontSize: 11, color: previewMuted),
                        ),
                      ),
                      Text(
                        '$assigned / $weekly',
                        textDirection: TextDirection.ltr,
                        style: const TextStyle(fontSize: 12),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: weekly == 0
                        ? 0
                        : (assigned / weekly).clamp(0.0, 1.0),
                    minHeight: 5,
                    borderRadius: BorderRadius.circular(10),
                    backgroundColor: previewLine,
                    color: assigned > weekly ? Colors.red.shade400 : null,
                  ),
                  const SizedBox(height: 9),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          assigned > weekly
                              ? 'النصاب أقل من الحصص الموزعة'
                              : 'حصة موزعة من النصاب',
                          style: const TextStyle(
                            fontSize: 10,
                            color: previewMuted,
                          ),
                        ),
                      ),
                      Text(
                        'يومي: ${t['max_daily_lessons']}',
                        style: const TextStyle(
                          fontSize: 10,
                          color: previewMuted,
                        ),
                      ),
                    ],
                  ),
                  ExpansionTile(
                    tilePadding: EdgeInsets.zero,
                    title: const Text(
                      'الاختصاص والصفوف والإتاحة',
                      style: TextStyle(fontSize: 11),
                    ),
                    children: [
                      Text(
                        subjectGradeSummary.isEmpty
                            ? gradeNames
                            : subjectGradeSummary.join('\n'),
                        style: const TextStyle(fontSize: 11),
                      ),
                      TextButton(
                        onPressed: () => _editTeacher(subjects, t),
                        child: const Text('تعديل الاختصاص والإتاحة'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () =>
                          widget.onOpenTeacher?.call(t['id'] as int),
                      icon: const Icon(Icons.calendar_month_outlined, size: 16),
                      label: const Text('عرض الجدول'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      }
      final normalizedQuery = _normalizeArabicSearch(_searchQuery);
      return ListView(
        padding: const EdgeInsets.all(16),
        children: [
          pageHeading(
            'المعلمون',
            'ابحث بالاسم أو الرمز أو المادة أو الصف والشعبة التي يدرّسها المعلم.',
            trailing: IconButton(
              onPressed: () => _editTeacher(subjects),
              tooltip: 'إضافة معلم',
              icon: const Icon(
                Icons.person_add_alt_1,
                size: 30,
                color: Color(0xFF6655BE),
              ),
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _searchController,
            textInputAction: TextInputAction.search,
            onChanged: (value) => setState(() => _searchQuery = value),
            decoration: InputDecoration(
              hintText: 'ابحث عن معلم أو مادة أو صف…',
              hintStyle: const TextStyle(color: Color(0xFF66788D)),
              prefixIcon: const Icon(Icons.search, color: Color(0xFF6655BE)),
              suffixIcon: _searchQuery.isEmpty
                  ? null
                  : IconButton(
                      tooltip: 'مسح البحث',
                      icon: const Icon(Icons.close),
                      onPressed: () {
                        _searchController.clear();
                        setState(() => _searchQuery = '');
                      },
                    ),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(color: Color(0xFFE4E2ED)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(color: Color(0xFFE4E2ED)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(
                  color: Color(0xFF6655BE),
                  width: 1.6,
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: Text(
                  normalizedQuery.isEmpty
                      ? 'عدد المعلمين: ${teachers.length}'
                      : 'نتائج البحث: ${teacherCards.length} من ${teachers.length}',
                  style: const TextStyle(
                    color: Color(0xFF34465C),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              if (_searchQuery.isNotEmpty)
                TextButton(
                  onPressed: () {
                    _searchController.clear();
                    setState(() => _searchQuery = '');
                  },
                  child: const Text('عرض الكل'),
                ),
            ],
          ),
          if (teachers.isEmpty)
            emptyState(
              icon: Icons.co_present_outlined,
              title: 'لا يوجد معلمون بعد',
              message: 'أضف المعلمين وحدد المواد المؤهلين لتدريسها قبل الجدولة التلقائية.',
            ),
          if (teachers.isNotEmpty && teacherCards.isEmpty)
            emptyState(
              icon: Icons.search_off,
              title: 'لا توجد نتائج مطابقة',
              message: 'جرّب كتابة اسم المعلم أو جزء منه، أو رمز المعلم، أو اسم المادة أو الصف.',
            ),
          PreviewGrid(children: teacherCards),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () => _editTeacher(subjects),
            icon: const Icon(Icons.add),
            label: const Text('إضافة معلم'),
          ),
        ],
      );
    },
  );
}

class _RequirementsTab extends StatefulWidget {
  const _RequirementsTab({required this.onChanged, this.navigationGuard});
  final EditorNavigationGuard? navigationGuard;
  final VoidCallback onChanged;
  @override
  State<_RequirementsTab> createState() => _RequirementsTabState();
}

class _RequirementsTabState extends State<_RequirementsTab>
    with AutomaticKeepAliveClientMixin<_RequirementsTab> {
  @override
  bool get wantKeepAlive => true;

  int? _selectedSectionId;
  late Future<List<dynamic>> _dataFuture;
  @override
  void initState() {
    super.initState();
    _dataFuture = _load();
  }

  void _reloadRequirements() => setState(() => _dataFuture = _load());

  Future<List<dynamic>> _load() async => Future.wait([
    DatabaseService.instance.sectionsDetailed(),
    DatabaseService.instance.rows('subjects', orderBy: 'name'),
    DatabaseService.instance.requirementsDetailed(),
  ]);
  Future<void> _editRequirement(
    List<Map<String, Object?>> sections,
    List<Map<String, Object?>> subjects, [
    Map<String, Object?>? existing,
  ]) async {
    final int? sectionId =
        existing?['section_id'] as int? ??
        _selectedSectionId ??
        (sections.isEmpty ? null : sections.first['id'] as int);
    int? subjectId =
        existing?['subject_id'] as int? ??
        (subjects.isEmpty ? null : subjects.first['id'] as int);
    final targetSection = sections.where((s) => s['id'] == sectionId).toList();
    final targetSectionLabel = targetSection.isEmpty
        ? 'لا توجد شعبة محددة'
        : '${displayGradeName(targetSection.first['grade_name'])} - ${targetSection.first['section_name']}';
    final count = TextEditingController(
      text: '${existing?['weekly_lessons'] ?? 5}',
    );
    final maxDaily = TextEditingController(
      text: '${existing?['max_daily_lessons'] ?? 2}',
    );
    bool allowSameDay = (existing?['allow_same_day'] as int? ?? 0) == 1;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, update) => AlertDialog(
          title: Text(
            existing == null ? 'تحديد حصص مادة لشعبة' : 'تعديل الحصص المطلوبة',
          ),
          content: SizedBox(
            width: 410,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  InputDecorator(
                    decoration: const InputDecoration(
                      labelText: 'الشعبة المحددة للعمل عليها',
                      border: OutlineInputBorder(),
                    ),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        targetSectionLabel,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<int>(
                    initialValue: subjectId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'المادة',
                      prefixIcon: Icon(
                        Icons.menu_book_rounded,
                        color: Color(0xFF8A63C7),
                      ),
                    ),
                    items: subjects.asMap().entries.map((item) {
                      final subject = item.value;
                      final color = _displaySubjectColor(subject, item.key);
                      return DropdownMenuItem<int>(
                        value: subject['id'] as int,
                        child: Row(
                          children: [
                            Container(
                              width: 9,
                              height: 28,
                              decoration: BoxDecoration(
                                color: color,
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                            const SizedBox(width: 9),
                            Expanded(
                              child: Text(
                                '${subject['name']}',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                    onChanged: existing == null
                        ? (v) => update(() => subjectId = v)
                        : null,
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: count,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'عدد الحصص الأسبوعية المطلوبة',
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: maxDaily,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'أقصى عدد يومي للمادة',
                    ),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('السماح بتكرار المادة في اليوم'),
                    value: allowSameDay,
                    onChanged: (v) => update(() => allowSameDay = v),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    if (sectionId == null || subjectId == null) {
      if (mounted) showMessage(context, 'اختر الشعبة والمادة.', error: true);
      return;
    }
    final values = {
      'section_id': sectionId,
      'subject_id': subjectId,
      'weekly_lessons': (int.tryParse(count.text) ?? 0).clamp(0, 60),
      'max_daily_lessons': (int.tryParse(maxDaily.text) ?? 2).clamp(1, 10),
      'allow_same_day': allowSameDay ? 1 : 0,
    };
    try {
      if (existing == null) {
        final db = await DatabaseService.instance.database;
        final old = await db.query(
          'section_subject_requirements',
          where: 'section_id=? AND subject_id=?',
          whereArgs: [sectionId, subjectId],
          limit: 1,
        );
        if (old.isEmpty)
          await DatabaseService.instance.add(
            'section_subject_requirements',
            values,
          );
        else
          await DatabaseService.instance.edit(
            'section_subject_requirements',
            old.first['id'] as int,
            values,
          );
      } else {
        await DatabaseService.instance.edit(
          'section_subject_requirements',
          existing['id'] as int,
          values,
        );
      }
      _reloadRequirements();
      widget.onChanged();
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر حفظ المتطلبات: $e', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return FutureBuilder<List<dynamic>>(
      future: _dataFuture,
      builder: (context, snapshot) {
        if (snapshot.hasError)
          return emptyState(
            icon: Icons.error_outline,
            title: 'تعذر تحميل البيانات',
            message: '${snapshot.error}',
          );
        if (snapshot.connectionState != ConnectionState.done)
          return const Center(child: CircularProgressIndicator());
        if (!snapshot.hasData)
          return emptyState(
            icon: Icons.info_outline,
            title: 'لا توجد بيانات',
            message: 'لم تُرجع قاعدة البيانات بيانات لهذا القسم.',
          );
        final sections = (snapshot.data![0] as List)
            .cast<Map<String, Object?>>();
        final subjects = (snapshot.data![1] as List)
            .cast<Map<String, Object?>>();
        final requirements = (snapshot.data![2] as List)
            .cast<Map<String, Object?>>();
        return RequirementsMatrix(
          navigationGuard: widget.navigationGuard,
          sections: sections,
          subjects: subjects,
          requirements: requirements,
          onChanged: () {
            _reloadRequirements();
            widget.onChanged();
          },
          onRules: (section, subject, existing) async {
            _selectedSectionId = section['id'] as int;
            await _editRequirement(sections, [subject], existing);
            if (mounted) {
              _reloadRequirements();
              widget.onChanged();
            }
          },
        );
      },
    );
  }
}

class _SettingsTab extends StatefulWidget {
  const _SettingsTab({required this.onChanged});
  final VoidCallback onChanged;
  @override
  State<_SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<_SettingsTab> {
  final _school = TextEditingController();
  final _directorate = TextEditingController();
  final _stage = TextEditingController();
  bool _settingsLoaded = false;
  Future<List<dynamic>> _load() async => Future.wait([
    DatabaseService.instance.getSettings(),
    DatabaseService.instance.rows('academic_years', orderBy: 'created_at DESC'),
    DatabaseService.instance.rows('school_days', orderBy: 'position'),
    DatabaseService.instance.rows('time_slots', orderBy: 'position'),
  ]);

  Future<void> _saveSettings() async {
    await DatabaseService.instance.saveSettings({
      'school_name': _school.text.trim().isEmpty
          ? 'مدرستي'
          : _school.text.trim(),
      'directorate': _directorate.text.trim(),
      'stage': _stage.text.trim(),
    });
    if (mounted) showMessage(context, 'تم حفظ إعدادات المدرسة.');
    widget.onChanged();
    setState(() {});
  }

  Future<void> _addYear() async {
    final name = TextEditingController(
      text: '${DateTime.now().year}-${DateTime.now().year + 1}',
    );
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('عام دراسي جديد'),
        content: TextField(
          controller: name,
          decoration: const InputDecoration(labelText: 'اسم العام الدراسي'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('إنشاء'),
          ),
        ],
      ),
    );
    if (ok != true || name.text.trim().isEmpty) return;
    try {
      final id = await DatabaseService.instance.add('academic_years', {
        'name': name.text.trim(),
        'is_active': 0,
        'created_at': DateTime.now().toIso8601String(),
      });
      await DatabaseService.instance.setActiveYear(id);
      if (mounted)
        showMessage(
          context,
          'تم إنشاء العام وتفعيله مع الاحتفاظ بالأعوام السابقة.',
        );
      setState(() {});
      widget.onChanged();
    } catch (e) {
      if (mounted)
        showMessage(
          context,
          'تعذر إنشاء العام؛ تحقق من عدم تكرار الاسم. $e',
          error: true,
        );
    }
  }

  Future<void> _editSlot([Map<String, Object?>? slot]) async {
    final name = TextEditingController(
      text: slot?['name']?.toString() ?? 'الحصة الجديدة',
    );
    final start = TextEditingController(
      text: slot?['start_time']?.toString() ?? '12:00',
    );
    final end = TextEditingController(
      text: slot?['end_time']?.toString() ?? '12:45',
    );
    String kind = slot?['kind']?.toString() ?? 'lesson';
    final available = (slot?['is_available'] as int? ?? 1) == 1;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, update) => AlertDialog(
          title: Text(slot == null ? 'إضافة فترة' : 'تعديل الفترة'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: name,
                  decoration: const InputDecoration(labelText: 'اسم الفترة'),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: start,
                        decoration: const InputDecoration(
                          labelText: 'البداية HH:MM',
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: end,
                        decoration: const InputDecoration(
                          labelText: 'النهاية HH:MM',
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  initialValue: kind,
                  decoration: const InputDecoration(labelText: 'نوع الفترة'),
                  items: const [
                    DropdownMenuItem(
                      value: 'lesson',
                      child: Text('حصة دراسية'),
                    ),
                    DropdownMenuItem(value: 'break', child: Text('استراحة')),
                    DropdownMenuItem(value: 'activity', child: Text('نشاط')),
                    DropdownMenuItem(
                      value: 'unavailable',
                      child: Text('غير متاحة'),
                    ),
                  ],
                  onChanged: (v) => update(() => kind = v ?? 'lesson'),
                ),
                const SizedBox(height: 6),
                Text(
                  'لن تُدرج الاستراحات والأنشطة ضمن حصص الجدولة.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final timePattern = RegExp(r'^([01]\d|2[0-3]):[0-5]\d$');
    if (!timePattern.hasMatch(start.text) ||
        !timePattern.hasMatch(end.text) ||
        start.text.compareTo(end.text) >= 0 ||
        name.text.trim().isEmpty) {
      if (mounted)
        showMessage(
          context,
          'تحقق من اسم الفترة والوقت بصيغة HH:MM وأن النهاية بعد البداية.',
          error: true,
        );
      return;
    }
    try {
      final values = {
        'name': name.text.trim(),
        'start_time': start.text,
        'end_time': end.text,
        'kind': kind,
        'is_available': kind == 'lesson' ? (available ? 1 : 0) : 0,
        'position': slot?['position'] ?? 99,
      };
      if (slot == null)
        await DatabaseService.instance.add('time_slots', values);
      else
        await DatabaseService.instance.edit(
          'time_slots',
          slot['id'] as int,
          values,
        );
      setState(() {});
      widget.onChanged();
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر حفظ الفترة: $e', error: true);
    }
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
    future: _load(),
    builder: (context, snapshot) {
      if (snapshot.hasError)
        return emptyState(
          icon: Icons.error_outline,
          title: 'تعذر تحميل البيانات',
          message: '${snapshot.error}',
        );
      if (snapshot.connectionState != ConnectionState.done)
        return const Center(child: CircularProgressIndicator());
      if (!snapshot.hasData)
        return emptyState(
          icon: Icons.info_outline,
          title: 'لا توجد بيانات',
          message: 'لم تُرجع قاعدة البيانات بيانات لهذا القسم.',
        );
      final settings = (snapshot.data![0] as Map).cast<String, Object?>();
      final years = (snapshot.data![1] as List).cast<Map<String, Object?>>();
      final days = (snapshot.data![2] as List).cast<Map<String, Object?>>();
      final slots = (snapshot.data![3] as List).cast<Map<String, Object?>>();
      if (!_settingsLoaded) {
        _school.text = settings['school_name']?.toString() ?? 'مدرستي';
        _directorate.text = settings['directorate']?.toString() ?? '';
        _stage.text = settings['stage']?.toString() ?? 'الابتدائية';
        _settingsLoaded = true;
      }
      return ListView(
        padding: const EdgeInsets.all(16),
        children: [
          pageHeading(
            'إعدادات المدرسة',
            'تُحفظ الإعدادات والفترات محلياً على الجهاز.',
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  TextField(
                    controller: _school,
                    decoration: const InputDecoration(labelText: 'اسم المدرسة'),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _directorate,
                    decoration: const InputDecoration(
                      labelText: 'المديرية أو الإدارة (اختياري)',
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _stage,
                    decoration: const InputDecoration(
                      labelText: 'المرحلة الدراسية',
                    ),
                  ),
                  const SizedBox(height: 12),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: FilledButton.icon(
                      onPressed: _saveSettings,
                      icon: const Icon(Icons.save_outlined),
                      label: const Text('حفظ الإعدادات'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              const Expanded(
                child: Text(
                  'الأعوام الدراسية',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
              ),
              IconButton(
                onPressed: _addYear,
                icon: const Icon(Icons.add_circle, color: Color(0xFF6655BE)),
              ),
            ],
          ),
          RadioGroup<int>(
            groupValue: years.where((year) => year['is_active'] == 1).isEmpty
                ? null
                : years.firstWhere((year) => year['is_active'] == 1)['id']
                      as int,
            onChanged: (id) async {
              if (id != null) {
                await DatabaseService.instance.setActiveYear(id);
                if (!mounted) return;
                setState(() {});
                widget.onChanged();
              }
            },
            child: Column(
              children: years
                  .map(
                    (year) => Card(
                      child: RadioListTile<int>(
                        value: year['id'] as int,
                        title: Text('${year['name']}'),
                        subtitle: Text(
                          year['is_active'] == 1
                              ? 'العام النشط'
                              : 'أرشيف عام سابق',
                        ),
                        secondary: year['is_active'] == 1
                            ? const Icon(
                                Icons.check_circle,
                                color: Color(0xFF16845B),
                              )
                            : null,
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'أيام الدوام',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Card(
            child: Column(
              children: days
                  .map(
                    (day) => SwitchListTile(
                      value: day['is_active'] == 1,
                      title: Text('${day['name']}'),
                      onChanged: (v) async {
                        if (!v) {
                          final version = await DatabaseService.instance
                              .activeVersionId(
                                await DatabaseService.instance.activeYearId(),
                              );
                          final entries = await DatabaseService.instance
                              .entriesDetailed(versionId: version);
                          final related = entries
                              .where((e) => e['day_id'] == day['id'])
                              .length;
                          if (related > 0 &&
                              !await confirmAction(
                                context,
                                'تعطيل يوم يحتوي حصصاً',
                                'يوجد $related حصة في هذا اليوم. سيظل الجدول محفوظاً لكنه سيظهر كتعارض يحتاج مراجعة. متابعة؟',
                              ))
                            return;
                        }
                        await DatabaseService.instance.edit(
                          'school_days',
                          day['id'] as int,
                          {'is_active': v ? 1 : 0},
                        );
                        setState(() {});
                        widget.onChanged();
                      },
                    ),
                  )
                  .toList(),
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              const Expanded(
                child: Text(
                  'أوقات الحصص والاستراحات',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
              ),
              IconButton(
                onPressed: () => _editSlot(),
                icon: const Icon(Icons.add_circle, color: Color(0xFF6655BE)),
              ),
            ],
          ),
          ...slots.map(
            (slot) => Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: Card(
                child: ListTile(
                  leading: Icon(
                    slot['kind'] == 'lesson'
                        ? Icons.access_time
                        : Icons.coffee_outlined,
                    color: slot['kind'] == 'lesson'
                        ? const Color(0xFF6655BE)
                        : Colors.orange,
                  ),
                  title: Text('${slot['name']}'),
                  subtitle: Text(
                    '${slot['start_time']} – ${slot['end_time']} • ${_kindLabel('${slot['kind']}')}',
                  ),
                  trailing: PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'edit') _editSlot(slot);
                      if (v == 'delete' &&
                          await confirmAction(
                            context,
                            'حذف الفترة',
                            'إذا كانت الفترة مستخدمة في الجدول فلن يتم حذفها.',
                          )) {
                        try {
                          await DatabaseService.instance.remove(
                            'time_slots',
                            slot['id'] as int,
                          );
                          setState(() {});
                        } catch (e) {
                          if (context.mounted)
                            showMessage(
                              context,
                              'تعذر حذف الفترة المرتبطة بجدول: $e',
                              error: true,
                            );
                        }
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'edit', child: Text('تعديل')),
                      PopupMenuItem(value: 'delete', child: Text('حذف')),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'ملاحظة: عند تعطيل يوم يحتوي حصصاً، لا تُحذف الحصص تلقائياً حفاظاً على بيانات الجدول.',
            style: TextStyle(color: Colors.black54),
          ),
        ],
      );
    },
  );

  String _kindLabel(String kind) => switch (kind) {
    'lesson' => 'حصة دراسية',
    'break' => 'استراحة',
    'activity' => 'نشاط',
    _ => 'غير متاحة',
  };
}
