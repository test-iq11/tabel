import 'package:flutter/material.dart';

import '../../core/timetable_ordering.dart';
import '../../core/ui_helpers.dart';
import '../../data/database_service.dart';

class AvailabilityPage extends StatefulWidget {
  const AvailabilityPage({
    required this.onChanged,
    required this.onEditTeachers,
    super.key,
  });
  final VoidCallback onChanged, onEditTeachers;
  @override
  State<AvailabilityPage> createState() => _AvailabilityPageState();
}

class _AvailabilityPageState extends State<AvailabilityPage> {
  late Future<List<dynamic>> _future;
  int? _teacherId;
  bool _saving = false;
  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<dynamic>> _load() => Future.wait([
    DatabaseService.instance.rows('teachers', orderBy: 'name'),
    DatabaseService.instance.rows('school_days', orderBy: 'position'),
    DatabaseService.instance.rows('time_slots', orderBy: 'position'),
    DatabaseService.instance.rows('teacher_availability'),
  ]);
  Future<void> _setAvailability(
    List<Map<String, Object?>> cells,
    bool available,
  ) async {
    if (_saving || _teacherId == null) return;
    final teacher = _teacherId!;
    setState(() => _saving = true);
    try {
      final db = await DatabaseService.instance.database;
      await db.transaction((txn) async {
        for (final cell in cells) {
          await txn.delete(
            'teacher_availability',
            where: 'teacher_id=? AND day_id=? AND slot_id=?',
            whereArgs: [teacher, cell['day_id'], cell['slot_id']],
          );
          if (!available)
            await txn.insert('teacher_availability', {
              'teacher_id': teacher,
              'day_id': cell['day_id'],
              'slot_id': cell['slot_id'],
              'is_available': 0,
            });
        }
      });
      if (!mounted) return;
      setState(() => _future = _load());
      widget.onChanged();
      showMessage(
        context,
        available
            ? 'تم السماح بالتدريس في الفترات المحددة.'
            : 'حُفظ المنع. أعد توزيع الجدول لتطبيقه على الحصص الحالية.',
      );
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر حفظ الإتاحة: $e', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إتاحة المعلمين')),
    body: FutureBuilder<List<dynamic>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.hasError)
          return emptyState(
            icon: Icons.error_outline,
            title: 'تعذر تحميل الإتاحة',
            message: '${snapshot.error}',
          );
        if (!snapshot.hasData)
          return const Center(child: CircularProgressIndicator());
        final teachers = (snapshot.data![0] as List)
            .cast<Map<String, Object?>>();
        final days = (snapshot.data![1] as List)
            .cast<Map<String, Object?>>()
            .where((d) => d['is_active'] == 1)
            .toList();
        final slots =
            (snapshot.data![2] as List)
                .cast<Map<String, Object?>>()
                .where((s) => s['kind'] == 'lesson' && s['is_available'] == 1)
                .toList()
              ..sort(TimetableOrdering.compare);
        final availability = (snapshot.data![3] as List)
            .cast<Map<String, Object?>>();
        if (!teachers.any((t) => t['id'] == _teacherId))
          _teacherId = teachers.isEmpty ? null : teachers.first['id'] as int;
        if (teachers.isEmpty)
          return emptyState(
            icon: Icons.person_add_alt,
            title: 'أضف المعلمين أولاً',
            message: 'بعد إضافة المعلم يمكنك تحديد أيامه وحصصه المتاحة هنا.',
          );
        final blocked = availability
            .where(
              (a) => a['teacher_id'] == _teacherId && a['is_available'] == 0,
            )
            .map((a) => '${a['day_id']}:${a['slot_id']}')
            .toSet();
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            pageHeading(
              'وقت التدريس المتاح',
              'اضغط الخانة للتبديل بين متاح وممنوع. تُحفظ اختياراتك فوراً.',
            ),
            DropdownButtonFormField<int>(
              key: ValueKey(_teacherId),
              initialValue: _teacherId,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'المعلم',
                prefixIcon: Icon(Icons.person_outline),
              ),
              items: teachers
                  .map(
                    (t) => DropdownMenuItem(
                      value: t['id'] as int,
                      child: Text('${t['name']}'),
                    ),
                  )
                  .toList(),
              onChanged: _saving ? null : (v) => setState(() => _teacherId = v),
            ),
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${blocked.length} فترة ممنوعة',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 8),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: DataTable(
                        columns: [
                          const DataColumn(label: Text('اليوم')),
                          for (final slot in slots)
                            DataColumn(label: Text('${slot['name']}')),
                        ],
                        rows: [
                          for (final day in days)
                            DataRow(
                              cells: [
                                DataCell(
                                  PopupMenuButton<bool>(
                                    enabled: !_saving,
                                    tooltip: 'إتاحة اليوم كاملاً',
                                    onSelected: (v) => _setAvailability([
                                      for (final slot in slots)
                                        {
                                          'day_id': day['id'],
                                          'slot_id': slot['id'],
                                        },
                                    ], v),
                                    itemBuilder: (_) => const [
                                      PopupMenuItem(
                                        value: true,
                                        child: Text('السماح طوال اليوم'),
                                      ),
                                      PopupMenuItem(
                                        value: false,
                                        child: Text('منع اليوم كاملاً'),
                                      ),
                                    ],
                                    child: Padding(
                                      padding: const EdgeInsets.all(8),
                                      child: Text('${day['name']}'),
                                    ),
                                  ),
                                ),
                                for (final slot in slots)
                                  DataCell(
                                    Semantics(
                                      button: true,
                                      label:
                                          '${day['name']} ${slot['name']}: ${blocked.contains('${day['id']}:${slot['id']}') ? 'ممنوع' : 'متاح'}',
                                      child: ActionChip(
                                        avatar: Icon(
                                          blocked.contains(
                                                '${day['id']}:${slot['id']}',
                                              )
                                              ? Icons.block
                                              : Icons.check,
                                          size: 16,
                                        ),
                                        label: Text(
                                          blocked.contains(
                                                '${day['id']}:${slot['id']}',
                                              )
                                              ? 'ممنوع'
                                              : 'متاح',
                                        ),
                                        backgroundColor:
                                            blocked.contains(
                                              '${day['id']}:${slot['id']}',
                                            )
                                            ? const Color(0xFFFFE7E7)
                                            : const Color(0xFFE5F3ED),
                                        onPressed: _saving
                                            ? null
                                            : () => _setAvailability(
                                                [
                                                  {
                                                    'day_id': day['id'],
                                                    'slot_id': slot['id'],
                                                  },
                                                ],
                                                blocked.contains(
                                                  '${day['id']}:${slot['id']}',
                                                ),
                                              ),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                        ],
                      ),
                    ),
                    if (_saving) const LinearProgressIndicator(),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: widget.onEditTeachers,
              icon: const Icon(Icons.school_outlined),
              label: const Text('تعديل المواد والصفوف المسموحة للمعلمين'),
            ),
          ],
        );
      },
    ),
  );
}
