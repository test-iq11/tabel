import 'package:flutter/material.dart';

import '../../core/design_widgets.dart';
import '../../core/ui_helpers.dart';
import '../../data/database_service.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({
    required this.onNavigate,
    this.onOpenSection,
    super.key,
  });
  final ValueChanged<int> onNavigate;
  final ValueChanged<int>? onOpenSection;
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  late Future<Map<String, Object?>> _future;
  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() => _future = _load();
  Future<Map<String, Object?>> _load() async {
    final db = DatabaseService.instance;
    return {
      ...await db.summary(),
      'days': await db.rows('school_days', orderBy: 'position'),
    };
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: FutureBuilder<Map<String, Object?>>(
      future: _future,
      builder: (context, snap) {
        if (snap.hasError)
          return emptyState(
            icon: Icons.error_outline,
            title: 'تعذر تحميل الملخص',
            message: '${snap.error}',
          );
        if (!snap.hasData)
          return const Center(child: CircularProgressIndicator());
        int value(String key) => (snap.data![key] as num?)?.toInt() ?? 0;
        return RefreshIndicator(
          onRefresh: () async {
            setState(_reload);
            await _future;
          },
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 26),
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'مساحة مدرستك',
                          style: TextStyle(fontSize: 10, color: designAccent),
                        ),
                        SizedBox(height: 5),
                        Text(
                          'كل أسبوع، بداية مرتّبة.',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: designInk,
                          ),
                        ),
                        SizedBox(height: 5),
                        Text(
                          'خطوة واضحة لكل مهمة في يومك.',
                          style: TextStyle(fontSize: 11, color: designMuted),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: const BoxDecoration(
                      color: Color(0xFFFFF4DF),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.auto_awesome_outlined,
                      color: Color(0xFFBC8B42),
                      size: 23,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF7968BD), Color(0xFF4B477D)],
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x245F4C9C),
                      blurRadius: 24,
                      offset: Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: .1),
                            border: Border.all(color: Colors.white24),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Text(
                            'جدول المدرسة',
                            style: TextStyle(color: Colors.white, fontSize: 10),
                          ),
                        ),
                        const Spacer(),
                        const Icon(
                          Icons.calendar_month_outlined,
                          color: Color(0xFFE4DDFA),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    const Text(
                      'أسبوعك في مكان واحد',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'حصص الصفوف والمعلمين، بتفاصيل واضحة.',
                      style: TextStyle(color: Color(0xFFE0DAEF), fontSize: 11),
                    ),
                    const SizedBox(height: 18),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          for (final d
                              in (snap.data!['days'] as List)
                                  .cast<Map<String, Object?>>()
                                  .where((d) => d['is_active'] != 0))
                            Padding(
                              padding: const EdgeInsetsDirectional.only(end: 6),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 8,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: .08),
                                  border: Border.all(color: Colors.white12),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Column(
                                  children: [
                                    Text(
                                      '${d['name']}',
                                      style: const TextStyle(
                                        color: Color(0xFFE6E0F4),
                                        fontSize: 10,
                                      ),
                                    ),
                                    const SizedBox(height: 5),
                                    const Icon(
                                      Icons.circle,
                                      size: 4,
                                      color: Color(0xFFE6E0F4),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    // Live counts, never label a timetable valid based on count alone.
                    Text(
                      '${value('الحصص الموزعة')} حصة موزعة من ${value('الحصص المطلوبة')} مطلوبة',
                      style: const TextStyle(
                        color: Color(0xFFE0DAEF),
                        fontSize: 11,
                      ),
                    ),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: () => widget.onNavigate(1),
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Color(0xFF5A498D),
                      ),
                      label: const Text('استعرض الجدول'),
                      icon: const Icon(Icons.west, size: 18),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'الجدول الحالي لمدرستك',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Color(0xFFE0D9EF), fontSize: 10),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  for (final metric in [
                    (value('الحصص الموزعة'), 'حصة موزعة'),
                    (value('عدد الشعب'), 'صفوف دراسية'),
                    (value('عدد المعلمين'), 'معلمين'),
                  ])
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 3),
                        child: Card(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                              vertical: 10,
                              horizontal: 3,
                            ),
                            child: Column(
                              children: [
                                Text(
                                  '${metric.$1}',
                                  style: const TextStyle(
                                    fontSize: 22,
                                    color: Color(0xFF5A4B8D),
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                Text(
                                  metric.$2,
                                  style: const TextStyle(
                                    fontSize: 10,
                                    color: designMuted,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 22),
              const Row(
                children: [
                  Expanded(
                    child: Text(
                      'ماذا تريد أن تنجز؟',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  Text(
                    'وصول سريع',
                    style: TextStyle(fontSize: 10, color: designMuted),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ActionGrid(
                children: [
                  ActionTile(
                    title: 'توزيع جديد',
                    subtitle: 'راجع الشروط وابدأ البحث',
                    icon: Icons.auto_awesome_outlined,
                    tone: 0,
                    onTap: () => widget.onNavigate(7),
                  ),
                  ActionTile(
                    title: 'تقارير المدرسة',
                    subtitle: 'معاينة، حفظ وطباعة',
                    icon: Icons.description_outlined,
                    tone: 1,
                    onTap: () => widget.onNavigate(10),
                  ),
                  ActionTile(
                    title: 'الحصص المطلوبة',
                    subtitle: 'اضبط حصص كل صف',
                    icon: Icons.menu_book_outlined,
                    tone: 2,
                    onTap: () => widget.onNavigate(3),
                  ),
                  ActionTile(
                    title: 'فحص التعارضات',
                    subtitle: 'راجع أثر الشروط',
                    icon: Icons.check_outlined,
                    tone: 3,
                    onTap: () => widget.onNavigate(6),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextButton.icon(
                onPressed: () => widget.onNavigate(13),
                icon: const Icon(Icons.school_outlined, size: 18),
                label: const Text('إدارة بيانات المدرسة'),
              ),
            ],
          ),
        );
      },
    ),
  );
}
