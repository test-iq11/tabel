import 'package:flutter/material.dart';

import '../../core/ui_helpers.dart';
import '../../data/database_service.dart';
import '../../services/backup_service.dart';
import '../../services/conflict_detection_service.dart';
import '../timetable/schedule_comparison_dialog.dart';

enum ToolsSection { backups, versions }

class ToolsPage extends StatefulWidget {
  const ToolsPage({required this.onChanged, required this.section, super.key});
  final ToolsSection section;
  final VoidCallback onChanged;
  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> {
  Future<Map<String, Object?>>? _future;
  bool _busy = false;
  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() => _future = _load();

  Future<Map<String, Object?>> _load() async {
    final db = DatabaseService.instance;
    final yearId = await db.activeYearId();
    final versionId = await db.activeVersionId(yearId);
    final versions =
        (await db.rows('timetable_versions'))
            .where((v) => v['academic_year_id'] == yearId)
            .toList()
          ..sort(
            (a, b) => '${b['created_at']}'.compareTo('${a['created_at']}'),
          );
    return {
      'settings': await db.getSettings(),
      'year': await db.activeYear() ?? <String, Object?>{},
      'yearId': yearId,
      'versionId': versionId,
      'version': versionId == null
          ? <String, Object?>{}
          : versions.firstWhere(
              (v) => v['id'] == versionId,
              orElse: () => <String, Object?>{},
            ),
      'versions': versions,
      'entries': await db.entriesDetailed(versionId: versionId),
      'requirements': await db.requirementsDetailed(),
      'slots': await db.rows('time_slots', orderBy: 'position'),
      'sections': await db.sectionsDetailed(),
      'teachers': await db.rows('teachers'),
      'qualifications': await db.rows('teacher_subjects'),
      'teacherGrades': await db.rows('teacher_grades'),
      'teacherSubjectGrades': await db.rows('teacher_subject_grades'),
      'subjectBlockedSlots': await db.rows('subject_blocked_slots'),
      'availability': await db.rows('teacher_availability'),
      'days': await db.rows('school_days', orderBy: 'position'),
    };
  }

  Future<void> _exportBackup() async {
    setState(() => _busy = true);
    try {
      final path = await BackupService(DatabaseService.instance).exportBackup();
      if (path != null && mounted)
        showMessage(context, 'تم إنشاء النسخة الاحتياطية: $path');
    } catch (e) {
      if (mounted)
        showMessage(context, 'فشل إنشاء النسخة الاحتياطية: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _importBackup() async {
    final proceed = await confirmAction(
      context,
      'استعادة نسخة احتياطية',
      'ستُستبدل بيانات المدرسة الحالية بمحتويات النسخة المختارة. ينشئ التطبيق نسخة طوارئ محلية قبل الاستعادة. هل تريد المتابعة؟',
    );
    if (!proceed) return;
    setState(() => _busy = true);
    try {
      final result = await BackupService(DatabaseService.instance)
          .importBackup();
      if (result != null && mounted) {
        await showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('تمت الاستعادة'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('المدرسة: ${result['school_name']}'),
                Text(
                  'الشعب: ${result['sections']} • المعلمون: ${result['teachers']} • المواد: ${result['subjects']}',
                ),
                Text('الحصص المحفوظة ضمن الأرشيف: ${result['entries']}'),
                const SizedBox(height: 8),
                Text(
                  'نسخة الطوارئ: ${result['emergency_backup']}',
                  style: const TextStyle(fontSize: 11, color: Colors.black54),
                ),
              ],
            ),
            actions: [
              FilledButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('حسناً'),
              ),
            ],
          ),
        );
        setState(_reload);
        widget.onChanged();
      }
    } catch (e) {
      if (mounted)
        showMessage(
          context,
          'فشلت الاستعادة ولم يُفترض تطبيق استعادة جزئية: $e',
          error: true,
        );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _approve(Map<String, Object?> data) async {
    final blockers = const ConflictDetectionService()
        .scan(
          entries: (data['entries'] as List).cast<Map<String, Object?>>(),
          requirements: (data['requirements'] as List)
              .cast<Map<String, Object?>>(),
          sections: (data['sections'] as List).cast<Map<String, Object?>>(),
          slots: (data['slots'] as List).cast<Map<String, Object?>>(),
          teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
          qualifications: (data['qualifications'] as List)
              .cast<Map<String, Object?>>(),
          days: (data['days'] as List).cast<Map<String, Object?>>(),
          teacherGrades: (data['teacherGrades'] as List)
              .cast<Map<String, Object?>>(),
          teacherSubjectGrades: (data['teacherSubjectGrades'] as List)
              .cast<Map<String, Object?>>(),
          subjectBlockedSlots: (data['subjectBlockedSlots'] as List)
              .cast<Map<String, Object?>>(),
          teacherAvailability: (data['availability'] as List)
              .cast<Map<String, Object?>>(),
        )
        .where((i) => i.severity == 'خطأ مانع')
        .toList();
    if (blockers.isNotEmpty) {
      if (mounted)
        await showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('لا يمكن اعتماد الجدول'),
            content: Text(
              'تم اكتشاف ${blockers.length} خطأ مانع. عالجها من صفحة فحص التعارضات ثم أعد المحاولة.\n\n${blockers.take(5).map((e) => '• ${e.type}: ${e.message}').join('\n')}',
            ),
            actions: [
              FilledButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('حسناً'),
              ),
            ],
          ),
        );
      return;
    }
    final warnings = const ConflictDetectionService()
        .scan(
          entries: (data['entries'] as List).cast<Map<String, Object?>>(),
          requirements: (data['requirements'] as List)
              .cast<Map<String, Object?>>(),
          sections: (data['sections'] as List).cast<Map<String, Object?>>(),
          slots: (data['slots'] as List).cast<Map<String, Object?>>(),
          teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
          qualifications: (data['qualifications'] as List)
              .cast<Map<String, Object?>>(),
          days: (data['days'] as List).cast<Map<String, Object?>>(),
          teacherGrades: (data['teacherGrades'] as List)
              .cast<Map<String, Object?>>(),
          teacherSubjectGrades: (data['teacherSubjectGrades'] as List)
              .cast<Map<String, Object?>>(),
          subjectBlockedSlots: (data['subjectBlockedSlots'] as List)
              .cast<Map<String, Object?>>(),
          teacherAvailability: (data['availability'] as List)
              .cast<Map<String, Object?>>(),
        )
        .where((i) => i.severity == 'تحذير')
        .length;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تأكيد اعتماد الجدول'),
        content: Text(
          warnings == 0
              ? 'لم تُكتشف أخطاء مانعة أو تحذيرات. هل تريد اعتماد النسخة الحالية؟'
              : 'لا توجد أخطاء مانعة، لكن توجد $warnings تحذيراً. تأكد من مراجعتها. هل تريد الاعتماد وفق سياسة المدرسة؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('مراجعة لاحقاً'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('اعتماد'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final versionId = data['versionId'] as int?;
    if (versionId == null) return;
    final now = DateTime.now().toIso8601String();
    await DatabaseService.instance.edit('timetable_versions', versionId, {
      'status': 'معتمد',
      'approved_at': now,
      'updated_at': now,
    });
    await DatabaseService.instance.log(
      'اعتماد',
      'timetable_versions',
      versionId,
      'اعتماد الجدول بعد فحص التحقق',
    );
    if (mounted) {
      showMessage(context, 'تم اعتماد الجدول وحفظ تاريخ الاعتماد.');
      setState(_reload);
      widget.onChanged();
    }
  }

  Future<void> _restoreVersion(
    Map<String, Object?> data,
    Map<String, Object?> version,
  ) async {
    if (version['is_active'] == 1) {
      showMessage(context, 'هذه هي النسخة النشطة بالفعل.');
      return;
    }
    final ok = await confirmAction(
      context,
      'استعادة نسخة جدول',
      'سيتم إنشاء نسخة عمل جديدة من «${version['name']}». ستبقى النسخة الحالية والنسخة المختارة محفوظتين في الأرشيف.',
    );
    if (!ok) return;
    setState(() => _busy = true);
    try {
      final db = await DatabaseService.instance.database;
      final oldEntries = await db.query(
        'timetable_entries',
        where: 'version_id=?',
        whereArgs: [version['id']],
      );
      final stripped = oldEntries.map((e) {
        final row = Map<String, Object?>.from(e);
        row.remove('id');
        row.remove('version_id');
        row.remove('created_at');
        return row;
      }).toList();
      final id = await DatabaseService.instance.saveAsNewVersion(
        yearId: data['yearId'] as int,
        name: 'استعادة: ${version['name']}',
        entries: stripped,
        notes: 'نسخة مستعادة من النسخة رقم ${version['id']}.',
      );
      if (mounted)
        showMessage(context, 'تم إنشاء نسخة مستعادة جديدة برقم $id.');
      setState(_reload);
      widget.onChanged();
    } catch (e) {
      if (mounted)
        showMessage(context, 'تعذرت استعادة النسخة: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _compareWithActive(
    Map<String, Object?> data,
    Map<String, Object?> other,
  ) async {
    setState(() => _busy = true);
    try {
      final previous = await DatabaseService.instance.entriesDetailed(
        versionId: other['id'] as int,
      );
      final subjects = await DatabaseService.instance.rows('subjects');
      if (!mounted) return;
      await showScheduleComparisonDialog(
        context,
        before: previous,
        after: (data['entries'] as List).cast<Map<String, Object?>>(),
        sections: (data['sections'] as List).cast<Map<String, Object?>>(),
        teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
        subjects: subjects,
        days: (data['days'] as List).cast<Map<String, Object?>>(),
        slots: (data['slots'] as List).cast<Map<String, Object?>>(),
        title: 'مقارنة «${other['name']}» بالنسخة النشطة',
        readOnly: true,
      );
    } catch (e) {
      if (mounted) showMessage(context, 'تعذرت المقارنة: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _deleteArchivedVersion(Map<String, Object?> version) async {
    if (version['is_active'] == 1) {
      showMessage(context, 'لا يمكن حذف النسخة النشطة.');
      return;
    }
    final versionId = version['id'] as int;
    final db = await DatabaseService.instance.database;
    final entryCount = await db.rawQuery(
      'SELECT COUNT(*) AS count FROM timetable_entries WHERE version_id=?',
      [versionId],
    );
    final count = (entryCount.first['count'] as num?)?.toInt() ?? 0;
    final ok = await confirmAction(
      context,
      'حذف نسخة مؤرشفة نهائياً',
      'ستُحذف النسخة «${version['name']}» و$count حصة محفوظة داخلها فقط. لن تتأثر بيانات المعلمين أو المواد أو الشعب، ولن تُحذف النسخة النشطة. لا يمكن التراجع عن هذا الحذف. هل تريد المتابعة؟',
    );
    if (!ok || !mounted) return;
    setState(() => _busy = true);
    try {
      await DatabaseService.instance.deleteArchivedVersion(versionId);
      if (!mounted) return;
      showMessage(context, 'تم حذف النسخة المؤرشفة «${version['name']}».');
      setState(_reload);
      widget.onChanged();
    } catch (e) {
      if (mounted)
        showMessage(context, 'تعذر حذف النسخة المؤرشفة: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _prettyDate(Object? value) =>
      value.toString().replaceFirst('T', ' ').split('.').first;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(
        widget.section == ToolsSection.backups
            ? 'النسخ الاحتياطية'
            : 'النسخ والاعتماد',
      ),
      actions: [
        IconButton(
          tooltip: 'تحديث',
          onPressed: _busy ? null : () => setState(_reload),
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: FutureBuilder<Map<String, Object?>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.hasError)
          return emptyState(
            icon: Icons.error_outline,
            title: 'تعذر تحميل البيانات',
            message: '${snapshot.error}',
          );
        if (!snapshot.hasData)
          return const Center(child: CircularProgressIndicator());
        final data = snapshot.data!;
        final version = (data['version'] as Map).cast<String, Object?>();
        final versions = (data['versions'] as List)
            .cast<Map<String, Object?>>();
        return Stack(
          children: [
            ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (widget.section == ToolsSection.backups) ...[
                  const Text(
                    'النسخ الاحتياطي والاستعادة',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        children: [
                          ListTile(
                            leading: const Icon(
                              Icons.backup_outlined,
                              color: Color(0xFF2878C8),
                              size: 30,
                            ),
                            title: const Text('إنشاء نسخة احتياطية'),
                            subtitle: const Text(
                              'JSON يشمل قاعدة البيانات والنسخ المؤرشفة والإعدادات.',
                            ),
                            trailing: const Icon(Icons.chevron_left),
                            onTap: _busy ? null : _exportBackup,
                          ),
                          const Divider(height: 1),
                          ListTile(
                            leading: const Icon(
                              Icons.restore_outlined,
                              color: Color(0xFFB87419),
                              size: 30,
                            ),
                            title: const Text('استعادة نسخة احتياطية'),
                            subtitle: const Text(
                              'يتحقق من إصدار المخطط وينشئ نسخة طوارئ قبل الاستعادة.',
                            ),
                            trailing: const Icon(Icons.chevron_left),
                            onTap: _busy ? null : _importBackup,
                          ),
                        ],
                      ),
                    ),
                  ),
                ] else ...[
                  const SizedBox(height: 18),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'دورة اعتماد الجدول',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'الحالة الحالية: ${version['status'] ?? 'مسودة'}',
                          ),
                          const SizedBox(height: 10),
                          FilledButton.icon(
                            onPressed: _busy || data['versionId'] == null
                                ? null
                                : () => _approve(data),
                            icon: const Icon(Icons.verified_outlined),
                            label: const Text('فحص ثم اعتماد الجدول'),
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFF16845B),
                              minimumSize: const Size.fromHeight(46),
                            ),
                          ),
                          const SizedBox(height: 5),
                          const Text(
                            'لن يسمح التطبيق بالاعتماد عند اكتشاف أخطاء مانعة. التحذيرات تُعرض قبل الاعتماد.',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    'أرشيف نسخ الجداول',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  if (versions.isEmpty)
                    emptyState(
                      icon: Icons.history,
                      title: 'لا توجد نسخ',
                      message: 'أنشئ جدولاً أو نتيجة جدولة تلقائية لتبدأ إدارة النسخ.',
                    ),
                  ...versions.map(
                    (v) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Card(
                        child: ListTile(
                          leading: Icon(
                            v['is_active'] == 1
                                ? Icons.radio_button_checked
                                : Icons.history,
                            color: v['is_active'] == 1
                                ? const Color(0xFF16845B)
                                : const Color(0xFF8CA3BA),
                          ),
                          title: Text(
                            '${v['name']}',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          subtitle: Text(
                            '${v['status']} • ${_prettyDate(v['created_at'])}',
                          ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'compare')
                                _compareWithActive(data, v);
                              if (value == 'restore') _restoreVersion(data, v);
                              if (value == 'delete') _deleteArchivedVersion(v);
                            },
                            itemBuilder: (_) => [
                              const PopupMenuItem(
                                value: 'compare',
                                child: Text('مقارنة مع النشطة'),
                              ),
                              if (v['is_active'] != 1)
                                const PopupMenuItem(
                                  value: 'restore',
                                  child: Text('استعادة كنسخة جديدة'),
                                ),
                              if (v['is_active'] != 1)
                                const PopupMenuItem(
                                  value: 'delete',
                                  child: Text(
                                    'حذف النسخة المؤرشفة',
                                    style: TextStyle(color: Colors.red),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 20),
              ],
            ),
            if (_busy)
              const Positioned.fill(
                child: AbsorbPointer(
                  child: ColoredBox(color: Color(0x22000000)),
                ),
              ),
            if (_busy)
              const Positioned(
                top: 0,
                right: 0,
                left: 0,
                child: LinearProgressIndicator(),
              ),
          ],
        );
      },
    ),
  );
}
