import 'dart:convert';
import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/reference_timetable_layout.dart';
import 'package:iraqi_school_timetable/services/reference_office_service.dart';
import 'package:iraqi_school_timetable/services/report_day_palette.dart';

void main() {
  final sections = <Map<String, Object?>>[
    {'id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 2},
    {'id': 2, 'grade_name': 'الثاني', 'section_name': 'أ', 'max_daily_lessons': 2},
  ];
  final days = <Map<String, Object?>>[
    {'id': 1, 'name': 'الأحد', 'position': 1, 'is_active': 1},
    {'id': 2, 'name': 'الاثنين', 'position': 2, 'is_active': 1},
  ];
  final slots = <Map<String, Object?>>[
    {'id': 1, 'name': 'الأولى', 'position': 1, 'kind': 'lesson', 'is_available': 1},
    {'id': 2, 'name': 'الثانية', 'position': 2, 'kind': 'lesson', 'is_available': 1},
  ];
  final layout = ReferenceTimetableLayout(
    entries: [
      for (var d = 1; d <= 2; d++)
        for (var s = 1; s <= 2; s++)
          for (var t = 1; t <= 2; t++)
            {'section_id': s, 'day_id': d, 'slot_id': t,
              'subject_name': 'م$d-$s-$t', 'teacher_name': 'معلم $s'},
    ],
    sections: sections,
    days: days,
    slots: slots,
    templateColumns: false,
  );

  test('a day shares one tint and there are exactly two grade and day gaps', () {
    final grid = layout.spacedGrid(layout.classGroups.single);
    expect(grid.rows.first.length, 8); // day + period + 4 class cells + 2 gaps
    expect(grid.gapColumns, {4, 5});
    expect(grid.gapRows, {4, 5});
    expect(grid.rows[2][0], 'الأحد');
    expect(grid.rows[3][0], '');
    expect(grid.rows[6][0], 'الاثنين');
    expect(grid.rows[7][0], '');
    expect(grid.dayRows[2], 0);
    expect(grid.dayRows[3], 0);
    expect(grid.dayRows[6], 1);
    expect(grid.dayRows[7], 1);
    expect(grid.rows[2][4], '');
    expect(grid.rows[2][5], '');
    expect(grid.rows[2][6], 'م1-2-1');
    expect(grid.daySpans.singleWhere((s) => s.start == 2).end, 3);
    expect(ReportDayPalette.argb(0), isNot(ReportDayPalette.argb(1)));
  });

  test('Excel and Word export keep the shared day palette and blank gaps', () {
    const office = ReferenceOfficeService();
    final xlsx = ZipDecoder().decodeBytes(office.timetable(
      layout: layout, schoolName: 'مدرسة', word: false,
    ));
    String xml(Archive archive, String path) =>
        utf8.decode(archive.findFile(path)!.readBytes()!);
    final styles = xml(xlsx, 'xl/styles.xml');
    final sheet = xml(xlsx, 'xl/worksheets/sheet1.xml');
    expect(styles, contains('FF${ReportDayPalette.rgb(0)}'));
    expect(styles, contains('FF${ReportDayPalette.rgb(1)}'));
    expect(sheet, contains('width="2.6"'));
    expect(sheet, contains('ht="7"'));
    expect(sheet, contains('A5:A6')); // first day merged once
    final docx = ZipDecoder().decodeBytes(office.timetable(
      layout: layout, schoolName: 'مدرسة', word: true,
    ));
    final document = xml(docx, 'word/document.xml');
    expect(document, contains('w:fill="${ReportDayPalette.rgb(0)}"'));
    expect(document, contains('w:fill="${ReportDayPalette.rgb(1)}"'));
    expect(document, contains('<w:vMerge'));
  });
}
