import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iraqi_school_timetable/app/app.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';

class _TestPaths extends PathProviderPlatform {
  _TestPaths(this.directory);
  final String directory;
  @override
  Future<String> getApplicationSupportPath() async => directory;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory directory;
  late PathProviderPlatform previousPaths;
  setUpAll(() async {
    directory = await Directory.systemTemp.createTemp('jadwali-ui-');
    previousPaths = PathProviderPlatform.instance;
    PathProviderPlatform.instance = _TestPaths(directory.path);
    SharedPreferences.setMockInitialValues({});
    final input = jsonDecode(
      File('test/fixtures/backup_school_181.json').readAsStringSync(),
    ) as Map;
    List<Map<String, Object?>> rows(String key) => (input[key] as List)
        .map((r) => Map<String, Object?>.from(r as Map))
        .toList();
    final storage = DatabaseService.instance;
    final db = await storage.database;
    await db.transaction((txn) async {
      await txn.delete('time_slots');
      for (final slot in rows('slots')) {
        await txn.insert('time_slots', slot);
      }
      final known = (await txn.query('subjects')).map((s) => s['id']).toSet();
      for (final req in rows('requirements')) {
        if (known.add(req['subject_id']))
          await txn.insert('subjects', {
            'id': req['subject_id'],
            'name': 'مادة ${req['subject_id']}',
          });
      }
      for (final section in rows('sections')) {
        await txn.insert('sections', {
          'id': section['id'],
          'grade_id': section['grade_id'],
          'name': section['section_name'],
          'max_daily_lessons': 6,
        });
      }
      for (final t in rows('teachers')) {
        await txn.insert('teachers', t);
      }
      for (final q in rows('qualifications')) {
        await txn.insert('teacher_subjects', q);
      }
      for (final q in rows('teacherSubjectGrades')) {
        await txn.insert('teacher_subject_grades', q);
      }
      for (final r in rows('requirements')) {
        await txn.insert('section_subject_requirements', {
          for (final k in [
            'section_id',
            'subject_id',
            'weekly_lessons',
            'max_daily_lessons',
            'allow_same_day',
          ])
            k: r[k],
        });
      }
    });
    await storage.saveAsNewVersion(
      yearId: (await storage.activeYearId())!,
      name: 'الجدول النشط',
      entries: rows('initialPlacements'),
      requireComplete: true,
    );
  });
  tearDownAll(() async {
    await DatabaseService.instance.close();
    PathProviderPlatform.instance = previousPaths;
    await directory.delete(recursive: true);
  });
  Future<void> settle(WidgetTester tester) async {
    for (var i = 0; i < 60; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)),
      );
      await tester.pump(const Duration(milliseconds: 100));
      if (find.byType(CircularProgressIndicator).evaluate().isEmpty) break;
    }
    await tester.pumpAndSettle();
    expect(find.byType(CircularProgressIndicator), findsNothing);
  }

  testWidgets(
    'all thirteen real screens open on a phone and Excel import is absent',
    (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(const TimetableApp());
      await settle(tester);
      expect(tester.takeException(), isNull, reason: 'dashboard');
      for (final label in [
        'الجدول',
        'المعلمون',
        'الحصص المطلوبة',
        'المواد والقيود',
        'إتاحة المعلمين',
        'التعارضات',
        'التوزيع والحلول',
        'الغياب والبدلاء',
        'النسخ والاعتماد',
        'التقارير',
        'النسخ الاحتياطية',
        'إعدادات المدرسة',
      ]) {
        await tester.tap(find.text('كل الشاشات'));
        await tester.pumpAndSettle();
        final item = find.widgetWithText(ListTile, label);
        final scrollable = find
            .descendant(
              of: find.byType(DraggableScrollableSheet),
              matching: find.byType(Scrollable),
            )
            .first;
        await tester.scrollUntilVisible(item, 250, scrollable: scrollable);
        await Scrollable.ensureVisible(tester.element(item), alignment: .5);
        await tester.pumpAndSettle();
        await tester.tap(item);
        await settle(tester);
        expect(tester.takeException(), isNull, reason: label);
        expect(find.textContaining('تعذر تحميل'), findsNothing, reason: label);
        expect(find.textContaining('استيراد Excel'), findsNothing);
      }
    },
  );
}
