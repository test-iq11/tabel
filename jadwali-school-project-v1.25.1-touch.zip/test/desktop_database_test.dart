import 'dart:io';
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  test('desktop SQLite creates the school schema and preserves data after reopening', () async {
    sqfliteFfiInit();
    final directory = await Directory.systemTemp.createTemp(
      'jadwali-desktop-db-',
    );
    final service = DatabaseService.withStorage(
      factory: databaseFactoryFfi,
      directory: directory.path,
    );
    addTearDown(() async {
      await service.close();
      await directory.delete(recursive: true);
    });
    var db = await service.database;
    expect((await db.rawQuery('PRAGMA foreign_keys')).single.values.single, 1);
    expect((await db.query('school_settings')).single['school_name'], 'مدرستي');
    expect(await db.query('grades'), hasLength(6));
    await db.update('school_settings', {'school_name': 'مدرسة الكمبيوتر'});
    final teacherId = await db.insert('teachers', {'name': 'معلم الحاسوب'});
    await expectLater(
      db.insert('teacher_subjects', {
        'teacher_id': teacherId,
        'subject_id': 999999,
      }),
      throwsA(isA<DatabaseException>()),
    );
    final grade = (await db.query('grades')).first;
    final sectionId = await db.insert('sections', {
      'grade_id': grade['id'],
      'name': 'تثبيت',
    });
    final subjectId = await db.insert('subjects', {'name': 'مادة التثبيت'});
    await db.insert('teacher_subjects', {
      'teacher_id': teacherId,
      'subject_id': subjectId,
    });
    final yearId = (await service.activeYearId())!;
    final versionId = (await service.activeVersionId(yearId))!;
    final entryId = await db.insert('timetable_entries', {
      'version_id': versionId,
      'section_id': sectionId,
      'subject_id': subjectId,
      'teacher_id': teacherId,
      'day_id': 1,
      'slot_id': 1,
      'created_at': DateTime.now().toIso8601String(),
    });
    expect(
      (await db.query(
        'timetable_entries',
        where: 'id=?',
        whereArgs: [entryId],
      )).single['is_locked'],
      0,
    );
    await service.setEntryLock(
      yearId: yearId,
      sectionId: sectionId,
      dayId: 1,
      slotId: 1,
      locked: true,
    );
    expect(
      (await service.entriesDetailed(versionId: versionId)).single['is_locked'],
      1,
    );
    await expectLater(
      service.saveEntry({'slot_id': 2}, entryId: entryId),
      throwsStateError,
    );
    await service.close();
    db = await service.database;
    expect(
      (await db.query('school_settings')).single['school_name'],
      'مدرسة الكمبيوتر',
    );
    expect(
      (await db.query(
        'teachers',
        where: 'id = ?',
        whereArgs: [teacherId],
      )).single['name'],
      'معلم الحاسوب',
    );
    expect(
      (await db.query(
        'timetable_entries',
        where: 'id=?',
        whereArgs: [entryId],
      )).single['is_locked'],
      1,
    );
    expect(
      (await service.exportAll())['schema_version'],
      DatabaseService.schemaVersion,
    );
    expect(
      (await service.exportAll())['format'],
      'iraqi_school_timetable_backup',
    );
    final legacy = jsonDecode(
      jsonEncode(await service.exportAll()),
    ) as Map<String, dynamic>;
    legacy['schema_version'] = 7;
    final tables = legacy['tables'] as Map<String, dynamic>;
    for (final row in tables['timetable_entries'] as List) {
      (row as Map).remove('is_locked');
    }
    for (final row in tables['subjects'] as List) {
      (row as Map).remove('morning_priority');
    }
    await service.importAll(legacy.cast<String, Object?>());
    expect((await db.query('timetable_entries')).single['is_locked'], 0);
    expect(
      (await db.query(
        'subjects',
        where: 'id=?',
        whereArgs: [subjectId],
      )).single['morning_priority'],
      1,
    );
  });
}
