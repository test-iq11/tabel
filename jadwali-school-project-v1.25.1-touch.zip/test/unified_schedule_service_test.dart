import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/unified_schedule_service.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';

Map<String, Object?> school() => Map<String, Object?>.from(
  jsonDecode(
    File('test/fixtures/school_oct27_period_capacity.json').readAsStringSync(),
  ) as Map,
);

void main() {
  test(
    'cold impossible school is proven without spending the search budget',
    () {
      final input = school()..['initialPlacements'] = <Map<String, Object?>>[];
      final phases = <String>[];
      final result = const UnifiedScheduleService().generate(
        input: input,
        timeLimit: const Duration(seconds: 1),
        onProgress: (event) => phases.add('${event['phase']}'),
      );
      expect(result.provenInfeasible, isTrue);
      expect(result.complete, isFalse);
      expect(result.searchLimitReached, isFalse);
      expect(result.exploredNodes, 0);
      expect(phases, ['infeasible']);
    },
  );
  test('valid full school remains complete and pins are preserved', () {
    final input = school();
    input['subjectBlockedSlots'] = (input['subjectBlockedSlots'] as List)
        .where((r) => !(r['subject_id'] == 1 && r['slot_id'] == 5))
        .toList();
    input['lockedPlacements'] = (input['initialPlacements'] as List)
        .take(8)
        .toList();
    final result = const UnifiedScheduleService().generate(
      input: input,
      timeLimit: const Duration(seconds: 2),
    );
    expect(result.complete, isTrue);
    expect(result.placements, hasLength(181));
    expect(ScheduleImprovementService.valid(input, result.placements), isTrue);
    expect(
      ScheduleImprovementService.validPartial(input, result.placements),
      isTrue,
    );
  });
  test('tiny time budget never creates an infeasibility claim for a feasible school', () {
    final input = school();
    input['subjectBlockedSlots'] = (input['subjectBlockedSlots'] as List)
        .where((r) => !(r['subject_id'] == 1 && r['slot_id'] == 5))
        .toList();
    input['initialPlacements'] = <Map<String, Object?>>[];
    final result = const UnifiedScheduleService().generate(
      input: input,
      timeLimit: const Duration(microseconds: 1),
      nodeLimit: 1,
    );
    expect(result.provenInfeasible, isFalse);
    expect(result.searchLimitReached, isTrue);
    expect(
      ScheduleImprovementService.validPartial(input, result.placements),
      isTrue,
    );
  });
}
