import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/ejection_chain_repair.dart';

Lesson row(int subject, int section, int teacher, int slot, [int day = 1]) => {
  'subject_id': subject,
  'section_id': section,
  'teacher_id': teacher,
  'slot_id': slot,
  'day_id': day,
};
void main() {
  final slots = [
    for (var i = 1; i <= 4; i++)
      <String, Object?>{'id': i, 'kind': 'lesson', 'is_available': 1},
  ];
  final days = [
    for (var i = 1; i <= 2; i++) <String, Object?>{'id': i, 'is_active': 1},
  ];
  bool clashes(List<Lesson> rows) {
    for (var i = 0; i < rows.length; i++)
      for (var j = i + 1; j < rows.length; j++) {
        final a = rows[i], b = rows[j];
        if (a['day_id'] == b['day_id'] &&
            a['slot_id'] == b['slot_id'] &&
            (a['section_id'] == b['section_id'] ||
                a['teacher_id'] == b['teacher_id']))
          return false;
      }
    return true;
  }

  test(
    'three-period cycle repairs a full section without dropping lessons',
    () {
      final seed = [row(1, 1, 1, 1), row(2, 1, 2, 2), row(3, 1, 3, 3)];
      final allowed = {
        1: {2},
        2: {2, 3},
        3: {1, 3},
      };
      bool valid(List<Lesson> rs) =>
          clashes(rs) &&
          rs.every((r) => allowed[r['subject_id']]!.contains(r['slot_id']));
      final result = const EjectionChainRepair().repair(
        initial: seed,
        days: [days.first],
        slots: slots.take(3).toList(),
        partialValid: valid,
        completeValid: (rs) => rs.length == 3 && valid(rs),
      );
      expect(result, isNotNull);
      expect(result!.map((r) => r['slot_id']), [2, 3, 1]);
      expect(seed.map((r) => r['slot_id']), [1, 2, 3]);
    },
  );
  test('chain releases teacher through other sections on the same day', () {
    final seed = [
      row(1, 1, 1, 1),
      row(2, 1, 2, 2),
      row(3, 2, 1, 2),
      row(4, 2, 3, 3),
    ];
    final allowed = {
      1: {2},
      2: {1, 2},
      3: {2, 3},
      4: {3, 4},
    };
    bool valid(List<Lesson> rs) =>
        clashes(rs) &&
        rs.every((r) => allowed[r['subject_id']]!.contains(r['slot_id']));
    final result = const EjectionChainRepair().repair(
      initial: seed,
      days: days,
      slots: slots,
      partialValid: valid,
      completeValid: (rs) => rs.length == 4 && valid(rs),
    );
    expect(result, isNotNull);
    expect(result!.map((r) => r['slot_id']), [2, 1, 3, 4]);
    expect(result.every((r) => r['day_id'] == 1), isTrue);
  });
  test(
    'whole-week scope resolves teacher unavailability and keeps pinned lesson',
    () {
      final seed = [row(1, 1, 1, 1), row(2, 1, 2, 1, 2), row(3, 2, 3, 2)];
      bool valid(List<Lesson> rs) =>
          clashes(rs) &&
          rs.every(
            (r) =>
                r['slot_id'] == (r['subject_id'] == 3 ? 2 : 1) &&
                (r['subject_id'] != 1 || r['day_id'] == 2),
          );
      final result = const EjectionChainRepair().repair(
        initial: seed,
        days: days,
        slots: slots,
        locks: [seed.last],
        partialValid: valid,
        completeValid: (rs) => rs.length == 3 && valid(rs),
      );
      expect(result, isNotNull);
      expect(result![0]['day_id'], 2);
      expect(result[1]['day_id'], 1);
      expect(result.last, seed.last);
    },
  );
  test(
    'impossible locked conflict, cancellation and budget do not change input',
    () {
      final seed = [row(1, 1, 1, 1)];
      bool valid(List<Lesson> rs) => rs.every((r) => r['slot_id'] == 2);
      for (final mode in [0, 1, 2]) {
        final result = const EjectionChainRepair().repair(
          initial: seed,
          days: days,
          slots: slots,
          locks: mode == 0 ? seed : [],
          maxNodes: mode == 1 ? 0 : 50,
          shouldStop: () => mode == 2,
          partialValid: valid,
          completeValid: valid,
        );
        expect(result, isNull);
      }
      expect(seed.single['slot_id'], 1);
    },
  );
  test(
    'complete validator can reject an otherwise collision-free candidate',
    () {
      final seed = [row(1, 1, 1, 1)];
      final result = const EjectionChainRepair().repair(
        initial: seed,
        days: days,
        slots: slots,
        partialValid: (rs) => rs.every((r) => r['slot_id'] == 2),
        completeValid: (_) => false,
        maxNodes: 30,
      );
      expect(result, isNull);
    },
  );
}
