import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/mandatory_period_capacity.dart';
import 'package:iraqi_school_timetable/services/constraint_explanation_service.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';
import 'package:iraqi_school_timetable/services/unified_schedule_service.dart';

void main() {
  Map<String, Object?> school({int lessons = 1, int teachers = 1}) => {
    'sections': [
      for (var s = 1; s <= 2; s++)
        {'id': s, 'grade_id': 1, 'max_daily_lessons': 1},
    ],
    'requirements': [
      for (var s = 1; s <= 2; s++)
        {
          'section_id': s,
          'subject_id': 1,
          'weekly_lessons': lessons,
          'allow_same_day': 0,
        },
    ],
    'days': [
      {'id': 1, 'is_active': 1},
    ],
    'slots': [
      {'id': 1, 'kind': 'lesson', 'is_available': 1},
    ],
    'teachers': [
      for (var t = 1; t <= teachers; t++) {'id': t},
    ],
    'qualifications': [
      for (var t = 1; t <= teachers; t++) {'teacher_id': t, 'subject_id': 1},
    ],
  };
  test('simultaneous shortage is proven and appears in explanations', () {
    final input = school();
    final r = const MandatoryPeriodCapacity().inspect(input);
    expect(r.single['required'], 2);
    expect(r.single['capacity'], 1);
    expect(
      const ConstraintExplanationService()
          .explain(input)
          .any((r) => r.proven && r.code.startsWith('mandatory_period_')),
      isTrue,
    );
  });
  test('spare cells do not force occupancy; enough teachers remove proof', () {
    expect(
      const MandatoryPeriodCapacity().inspect(school(teachers: 2)),
      isEmpty,
    );
    final input = school();
    input['days'] = [
      {'id': 1, 'is_active': 1},
      {'id': 2, 'is_active': 1},
    ];
    expect(const MandatoryPeriodCapacity().inspect(input), isEmpty);
  });
  test('daily quota does not force occupancy in the first period', () {
    final input = school(teachers: 2);
    input['slots'] = [
      {'id': 1, 'position': 0, 'kind': 'lesson', 'is_available': 1},
      {'id': 2, 'position': 1, 'kind': 'lesson', 'is_available': 1},
    ];
    input['subjectBlockedSlots'] = [
      {'subject_id': 1, 'slot_id': 1},
    ];
    expect(const MandatoryPeriodCapacity().inspect(input), isEmpty);
    final result = const UnifiedScheduleService().generate(
      input: input,
      timeLimit: const Duration(seconds: 2),
    );
    expect(result.provenInfeasible, isFalse);
    expect(result.complete, isTrue);
    expect(result.placements.every((r) => r['slot_id'] == 2), isTrue);
    expect(ScheduleImprovementService.valid(input, result.placements), isTrue);
  });
  test('matching detects subset bottleneck even if teacher union is large', () {
    final input = school(teachers: 3);
    input['sections'] = [
      {'id': 1, 'grade_id': 1, 'max_daily_lessons': 1},
      {'id': 2, 'grade_id': 1, 'max_daily_lessons': 1},
      {'id': 3, 'grade_id': 2, 'max_daily_lessons': 1},
    ];
    input['requirements'] = [
      for (var s = 1; s <= 3; s++)
        {'section_id': s, 'subject_id': 1, 'weekly_lessons': 1},
    ];
    input['teacherSubjectGrades'] = [
      {'teacher_id': 1, 'subject_id': 1, 'grade_id': 1},
      {'teacher_id': 2, 'subject_id': 1, 'grade_id': 2},
      {'teacher_id': 3, 'subject_id': 1, 'grade_id': 2},
    ];
    final r = const MandatoryPeriodCapacity().inspect(input).single;
    expect(r['required'], 3);
    expect(r['capacity'], 2);
  });
  test(
    'seed retention removes forbidden placements and never claims completeness',
    () {
      final input = school(teachers: 2);
      input['initialPlacements'] = [
        {
          'section_id': 1,
          'subject_id': 1,
          'teacher_id': 1,
          'day_id': 1,
          'slot_id': 1,
        },
        {
          'section_id': 2,
          'subject_id': 1,
          'teacher_id': 2,
          'day_id': 1,
          'slot_id': 1,
        },
      ];
      input['teacherAvailability'] = [
        {'teacher_id': 2, 'day_id': 1, 'slot_id': 1, 'is_available': 0},
      ];
      final kept = ScheduleImprovementService.retainValidSeed(input);
      expect(kept, hasLength(1));
      expect(ScheduleImprovementService.validPartial(input, kept), isTrue);
      expect(ScheduleImprovementService.valid(input, kept), isFalse);
    },
  );
}
