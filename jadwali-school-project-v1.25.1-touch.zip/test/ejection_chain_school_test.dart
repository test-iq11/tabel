import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';
import 'package:iraqi_school_timetable/services/ejection_chain_repair.dart';
import 'package:iraqi_school_timetable/services/conflict_detection_service.dart';

void main() {
  test(
    '181 lesson repairs and direct chain independently satisfy all rules',
    () {
      final source = jsonDecode(
        File('test/fixtures/backup_school_181.json').readAsStringSync(),
      ) as Map;
      List<Map<String, Object?>> rows(Map input, String key) =>
          (input[key] as List? ?? [])
              .map((r) => Map<String, Object?>.from(r as Map))
              .toList();

      for (var mode = 0; mode < 4; mode++) {
        final input = Map<String, Object?>.from(source);
        if (mode < 3)
          input['subjectBlockedSlots'] = [
            ...rows(source, 'subjectBlockedSlots'),
            for (final slot
                in (mode == 0
                    ? [1]
                    : mode == 1
                    ? [2]
                    : [1, 2]))
              {'subject_id': 2, 'slot_id': slot},
          ];
        else {
          final lesson = rows(source, 'initialPlacements').first;
          input['teacherAvailability'] = [
            ...rows(source, 'teacherAvailability'),
            {
              'teacher_id': lesson['teacher_id'],
              'day_id': lesson['day_id'],
              'slot_id': lesson['slot_id'],
              'is_available': 0,
            },
          ];
        }
        final watch = Stopwatch()..start();
        final result = const AutoSchedulerService(nodeLimit: 5000).generate(
          sections: rows(input, 'sections'),
          requirements: rows(input, 'requirements'),
          teachers: rows(input, 'teachers'),
          qualifications: rows(input, 'qualifications'),
          teacherGrades: rows(input, 'teacherGrades'),
          teacherSubjectGrades: rows(input, 'teacherSubjectGrades'),
          subjectBlockedSlots: rows(input, 'subjectBlockedSlots'),
          teacherAvailability: rows(input, 'teacherAvailability'),
          days: rows(input, 'days'),
          slots: rows(input, 'slots'),
          initialPlacements: rows(input, 'initialPlacements'),
          timeLimit: const Duration(seconds: 5),
        );
        expect(result.complete, isTrue, reason: 'case $mode');
        expect(
          ScheduleImprovementService.valid(input, result.placements),
          isTrue,
        );
        if (mode == 0) {
          bool partial(List<Lesson> rs) => const ConflictDetectionService()
              .scan(
                entries: rs,
                requirements: rows(input, 'requirements'),
                sections: rows(input, 'sections'),
                slots: rows(input, 'slots'),
                teachers: rows(input, 'teachers'),
                qualifications: rows(input, 'qualifications'),
                days: rows(input, 'days'),
                teacherGrades: rows(input, 'teacherGrades'),
                teacherSubjectGrades: rows(input, 'teacherSubjectGrades'),
                subjectBlockedSlots: rows(input, 'subjectBlockedSlots'),
                teacherAvailability: rows(input, 'teacherAvailability'),
              )
              .every(
                (e) => const {
                  'نقص الحصص',
                  'توزيع المادة على كل أيام الأسبوع',
                  'تكرار توقيت المادة في أيام متتالية',
                }.contains(e.type),
              );
          watch.reset();
          final chain = const EjectionChainRepair().repair(
            initial: rows(input, 'initialPlacements'),
            days: rows(input, 'days'),
            slots: rows(input, 'slots'),
            partialValid: partial,
            completeValid: (rs) => ScheduleImprovementService.valid(input, rs),
            maxNodes: 3000,
            shouldStop: () => watch.elapsedMilliseconds > 5000,
          );
          expect(chain, isNotNull, reason: 'direct chains on real 181 school');
          expect(ScheduleImprovementService.valid(input, chain!), isTrue);
        }
      }
    },
  );
}
