import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:iraqi_school_timetable/services/lesson_swap_service.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  late Directory folder;
  late DatabaseService storage;
  late Map<String, Object?> input;
  late int year, original;
  List<Map<String, Object?>> rows(String key) => (input[key] as List)
      .map((r) => Map<String, Object?>.from(r as Map))
      .toList();
  setUp(() async {
    sqfliteFfiInit();
    folder = await Directory.systemTemp.createTemp('jadwali-181-save-');
    storage = DatabaseService.withStorage(
      factory: databaseFactoryFfi,
      directory: folder.path,
    );
    input = Map<String, Object?>.from(
      jsonDecode(
        File('test/fixtures/backup_school_181.json').readAsStringSync(),
      ) as Map,
    );
    final db = await storage.database;
    await db.transaction((txn) async {
      await txn.delete('time_slots');
      for (final row in rows('slots')) {
        await txn.insert('time_slots', row);
      }
      final existingSubjects = (await txn.query('subjects'))
          .map((s) => s['id'])
          .toSet();
      for (final id in rows(
        'requirements',
      ).map((r) => r['subject_id']).toSet()) {
        if (!existingSubjects.contains(id))
          await txn.insert('subjects', {'id': id, 'name': 'المادة $id'});
      }
      for (final row in rows('sections')) {
        await txn.insert('sections', {
          'id': row['id'],
          'grade_id': row['grade_id'],
          'name': row['section_name'],
          'max_daily_lessons': 6,
        });
      }
      for (final row in rows('teachers')) {
        await txn.insert('teachers', row);
      }
      for (final row in rows('qualifications')) {
        await txn.insert('teacher_subjects', row);
      }
      for (final row in rows('teacherSubjectGrades')) {
        await txn.insert('teacher_subject_grades', row);
      }
      for (final row in rows('requirements')) {
        await txn.insert('section_subject_requirements', {
          for (final key in [
            'section_id',
            'subject_id',
            'weekly_lessons',
            'max_daily_lessons',
            'allow_same_day',
          ])
            key: row[key],
        });
      }
    });
    year = (await storage.activeYearId())!;
    original = await storage.saveAsNewVersion(
      yearId: year,
      name: 'الجدول السابق',
      entries: rows('initialPlacements'),
      requireComplete: true,
    );
  });
  tearDown(() async {
    await storage.close();
    await folder.delete(recursive: true);
  });

  Future<Map<String, Object?>> data() async => {
    ...input,
    'entries': await storage.entriesDetailed(),
    'availability': await storage.rows('teacher_availability'),
    'subjectBlockedSlots': await storage.rows('subject_blocked_slots'),
  };
  Future<(Map<String, Object?>, Map<String, Object?>)> pair({
    bool crossDay = false,
  }) async {
    final d = await data();
    final entries = (d['entries'] as List).cast<Map<String, Object?>>();
    for (final a in entries) {
      for (final b in entries) {
        if (a['id'] == b['id'] ||
            a['section_id'] != b['section_id'] ||
            a['subject_id'] == b['subject_id'])
          continue;
        if ((a['day_id'] != b['day_id']) != crossDay) continue;
        if (const LessonSwapService().validate(d, a, b) == null) return (a, b);
      }
    }
    throw StateError('No valid pair in regression fixture');
  }

  Future<List<Map<String, Object?>>> board() async =>
      (await storage.database).query('timetable_entries', orderBy: 'id');

  for (final crossDay in [false, true]) {
    test('181 lessons: atomic swap and undo, crossDay=$crossDay', () async {
      final p = await pair(crossDay: crossDay);
      final before = await board();
      await storage.swapLessons(yearId: year, first: p.$1, second: p.$2);
      final after = await board();
      expect(after.length, 181);
      expect(
        after
            .where(
              (r) => before.any(
                (b) => b['id'] == r['id'] && b['subject_id'] != r['subject_id'],
              ),
            )
            .length,
        2,
      );
      expect(
        after.singleWhere((r) => r['id'] == p.$1['id'])['teacher_id'],
        p.$2['teacher_id'],
      );
      await storage.undoLastManualEdit();
      expect(await board(), before);
      expect(storage.canUndoManualEdit, isFalse);
    });
  }
  test(
    'late pin and changed lesson reject stale requests without writes',
    () async {
      final p = await pair();
      final db = await storage.database;
      await db.update(
        'timetable_entries',
        {'is_locked': 1},
        where: 'id=?',
        whereArgs: [p.$2['id']],
      );
      final before = await board();
      await expectLater(
        storage.swapLessons(yearId: year, first: p.$1, second: p.$2),
        throwsStateError,
      );
      expect(await board(), before);
    },
  );
  test('subject restriction added after selection prevents swap', () async {
    final p = await pair();
    final before = await board();
    await (await storage.database).insert('subject_blocked_slots', {
      'subject_id': p.$1['subject_id'],
      'slot_id': p.$2['slot_id'],
    });
    await expectLater(
      storage.swapLessons(yearId: year, first: p.$1, second: p.$2),
      throwsStateError,
    );
    expect(await board(), before);
  });
  test(
    'scoped teacher unavailability is checked inside the transaction',
    () async {
      final p = await pair();
      final before = await board();
      final section = rows('sections')
          .singleWhere((s) => s['id'] == p.$1['section_id']);
      await (await storage.database).insert('teacher_availability', {
        'teacher_id': p.$1['teacher_id'],
        'day_id': p.$2['day_id'],
        'slot_id': p.$2['slot_id'],
        'is_available': 0,
        'grade_id': section['grade_id'],
        'subject_id': p.$1['subject_id'],
      });
      await expectLater(
        storage.swapLessons(yearId: year, first: p.$1, second: p.$2),
        throwsStateError,
      );
      expect(await board(), before);
    },
  );
  test('second update failure rolls back first and approved-version clone', () async {
    final p = await pair();
    final db = await storage.database;
    await db.update(
      'timetable_versions',
      {'status': 'معتمد'},
      where: 'id=?',
      whereArgs: [original],
    );
    final before = await board();
    final versions = await storage.rows('timetable_versions');
    await db.execute(
      "CREATE TRIGGER reject_second_swap BEFORE UPDATE OF subject_id ON timetable_entries WHEN NEW.section_id=${p.$2['section_id']} AND NEW.day_id=${p.$2['day_id']} AND NEW.slot_id=${p.$2['slot_id']} BEGIN SELECT RAISE(ABORT, 'injected swap failure'); END",
    );
    await expectLater(
      storage.swapLessons(yearId: year, first: p.$1, second: p.$2),
      throwsA(isA<DatabaseException>()),
    );
    expect(await board(), before);
    expect(await storage.rows('timetable_versions'), versions);
    expect(storage.canUndoManualEdit, isFalse);
  });
  test(
    'approved predecessor is preserved and undo restores both draft cells',
    () async {
      final p = await pair();
      final db = await storage.database;
      await db.update(
        'timetable_versions',
        {'status': 'معتمد'},
        where: 'id=?',
        whereArgs: [original],
      );
      final before = await board();
      await storage.swapLessons(yearId: year, first: p.$1, second: p.$2);
      final active = (await storage.activeVersionId(year))!;
      expect(active, isNot(original));
      expect(
        await db.query(
          'timetable_entries',
          where: 'version_id=?',
          whereArgs: [original],
          orderBy: 'id',
        ),
        before,
      );
      await storage.undoLastManualEdit();
      final draft = await db.query(
        'timetable_entries',
        where: 'version_id=?',
        whereArgs: [active],
      );
      for (final row in draft) {
        final old = before.singleWhere(
          (b) =>
              b['section_id'] == row['section_id'] &&
              b['day_id'] == row['day_id'] &&
              b['slot_id'] == row['slot_id'],
        );
        for (final key in LessonSwapService.payload) {
          expect(row[key], old[key]);
        }
      }
    },
  );
  test(
    'undo rejects newly forbidden original positions and keeps swapped board',
    () async {
      final p = await pair();
      await storage.swapLessons(yearId: year, first: p.$1, second: p.$2);
      final before = await board();
      await (await storage.database).insert('subject_blocked_slots', {
        'subject_id': p.$1['subject_id'],
        'slot_id': p.$1['slot_id'],
      });
      await expectLater(storage.undoLastManualEdit(), throwsStateError);
      expect(await board(), before);
    },
  );
  test('another class or version cannot be swapped', () async {
    final p = await pair();
    final before = await board();
    await expectLater(
      storage.swapLessons(
        yearId: year,
        first: p.$1,
        second: {...p.$2, 'section_id': -1},
      ),
      throwsStateError,
    );
    await expectLater(
      storage.swapLessons(
        yearId: year,
        first: p.$1,
        second: {...p.$2, 'version_id': -1},
      ),
      throwsStateError,
    );
    expect(await board(), before);
  });
}
