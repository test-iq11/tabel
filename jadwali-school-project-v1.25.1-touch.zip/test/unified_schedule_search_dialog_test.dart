import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/features/timetable/schedule_search_dialog.dart';

Map<String, Object?> _school() => {
  'sections': [
    {'id': 1, 'grade_id': 1, 'max_daily_lessons': 1},
  ],
  'requirements': [
    {
      'section_id': 1,
      'subject_id': 1,
      'weekly_lessons': 2,
      'allow_same_day': 0,
    },
  ],
  'teachers': [
    {'id': 1, 'weekly_load': 2, 'max_daily_lessons': 1},
  ],
  'qualifications': [
    {'teacher_id': 1, 'subject_id': 1},
  ],
  'days': [
    {'id': 1, 'position': 1, 'is_active': 1},
    {'id': 2, 'position': 2, 'is_active': 1},
  ],
  'slots': [
    {'id': 1, 'position': 1, 'kind': 'lesson', 'is_available': 1},
  ],
  // UI lifecycle test: leave enough CPU budget for cold isolate/JIT startup.
  // Tiny-budget behavior is tested separately in unified_schedule_service_test.
  'timeLimitMs': 5000,
  'improvementTimeMs': 5,
  'nodeLimit': 1000,
};

void main() {
  for (final width in [320.0, 1280.0]) {
    testWidgets('single local search and review at width $width', (
      tester,
    ) async {
      tester.view.physicalSize = Size(width, 800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      List<Map<String, Object?>>? result;
      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) => Scaffold(
              body: TextButton(
                onPressed: () async {
                  result = await showScheduleSearchDialog(
                    context,
                    input: _school(),
                    profiles: ['minimal_changes'],
                  );
                },
                child: const Text('ابدأ'),
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.text('ابدأ'));
      await tester.pump();
      expect(find.byKey(const ValueKey('open-cp-sat')), findsNothing);
      expect(find.textContaining('OR-Tools'), findsNothing);
      expect(find.textContaining('البحث العميق'), findsNothing);
      expect(find.textContaining('التوزيع العميق'), findsNothing);
      // The real worker is an isolate, so allow bounded real time to return.
      // Pump the widget only outside runAsync to keep fake timers consistent.
      for (var i = 0; i < 400; i++) {
        await tester.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 25)),
        );
        await tester.pump(const Duration(milliseconds: 50));
        if (find.text('الجدول جاهز للمراجعة').evaluate().isNotEmpty) break;
      }
      expect(find.text('الجدول جاهز للمراجعة'), findsOneWidget);
      expect(find.text('الموزع: 2 من 2 حصة'), findsOneWidget);
      expect(
        find.text('وجدنا جدولاً كاملاً صالحاً. راجعه قبل الحفظ.'),
        findsOneWidget,
      );
      expect(
        result,
        isNull,
        reason: 'A completed search must still await review.',
      );
      expect(tester.takeException(), isNull);
      await tester.tap(find.text('مراجعة أفضل نتيجة'));
      await tester.pumpAndSettle();
      expect(result, hasLength(1));
      expect(result!.single['complete'], isTrue);
      expect(result!.single['placements'], hasLength(2));
      expect(find.byType(AlertDialog), findsNothing);
      expect(tester.takeException(), isNull);
    });
  }
  testWidgets(
    'proven contradictory constraints do not offer another blind retry',
    (tester) async {
      final input = _school();
      input['sections'] = [
        {'id': 1, 'grade_id': 1, 'max_daily_lessons': 1},
        {'id': 2, 'grade_id': 1, 'max_daily_lessons': 1},
      ];
      input['requirements'] = [
        {'section_id': 1, 'subject_id': 1, 'weekly_lessons': 1},
        {'section_id': 2, 'subject_id': 1, 'weekly_lessons': 1},
      ];
      input['days'] = [
        {'id': 1, 'position': 1, 'is_active': 1},
      ];
      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) => Scaffold(
              body: TextButton(
                onPressed: () => showScheduleSearchDialog(
                  context,
                  input: input,
                  profiles: ['minimal_changes'],
                ),
                child: const Text('ابدأ'),
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.text('ابدأ'));
      await tester.pump();
      for (var i = 0; i < 400; i++) {
        await tester.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 25)),
        );
        await tester.pump(const Duration(milliseconds: 50));
        if (find
            .text('القيود الحالية لا تسمح بجدول كامل')
            .evaluate()
            .isNotEmpty)
          break;
      }
      expect(find.text('القيود الحالية لا تسمح بجدول كامل'), findsOneWidget);
      expect(find.text('متابعة ببحث أوسع'), findsNothing);
      expect(find.text('مراجعة أفضل نتيجة'), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.tap(find.text('إلغاء'));
      await tester.pumpAndSettle();
      expect(find.byType(AlertDialog), findsNothing);
    },
  );
}
