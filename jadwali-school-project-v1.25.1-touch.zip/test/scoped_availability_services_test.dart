import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/preflight_inspection_service.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:iraqi_school_timetable/services/whole_week_local_search.dart';
import 'package:iraqi_school_timetable/services/teacher_timetable_capacity.dart';
import 'package:iraqi_school_timetable/services/timetable_repair_service.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';
import 'package:iraqi_school_timetable/services/constraint_explanation_service.dart';

List<Map<String, Object?>> rows(Map<String, Object?> data, String key) =>
    (data[key] as List? ?? [])
        .map((r) => Map<String, Object?>.from(r as Map))
        .toList();
Map<String, Object?> school() => {
  'sections': [
    for (var s = 1; s <= 2; s++)
      {'id': s, 'grade_id': s, 'max_daily_lessons': 1},
  ],
  'requirements': [
    for (var s = 1; s <= 2; s++)
      {
        'section_id': s,
        'subject_id': 1,
        'weekly_lessons': 1,
        'allow_same_day': 0,
      },
  ],
  'teachers': [
    for (var t = 1; t <= 2; t++)
      {'id': t, 'weekly_load': 2, 'max_daily_lessons': 2},
  ],
  'qualifications': [
    for (var t = 1; t <= 2; t++) {'teacher_id': t, 'subject_id': 1},
  ],
  'days': [
    {'id': 1, 'position': 0, 'is_active': 1},
  ],
  'slots': [
    {'id': 1, 'position': 0, 'kind': 'lesson', 'is_available': 1},
  ],
  'teacherAvailability': [
    {
      'teacher_id': 1,
      'day_id': 1,
      'slot_id': 1,
      'is_available': 0,
      'grade_id': 1,
      'subject_id': 1,
    },
  ],
};
SchedulerResult generate(Map<String, Object?> i) =>
    const AutoSchedulerService(nodeLimit: 10000).generate(
      sections: rows(i, 'sections'),
      requirements: rows(i, 'requirements'),
      teachers: rows(i, 'teachers'),
      qualifications: rows(i, 'qualifications'),
      days: rows(i, 'days'),
      slots: rows(i, 'slots'),
      teacherAvailability: rows(i, 'teacherAvailability'),
      feasibilityOnly: true,
    );
void main() {
  test('scoped ban changes only matching grade and subject across primary and whole-week search', () {
    final input = school();
    final result = generate(input);
    expect(result.complete, isTrue);
    expect(
      result.placements.singleWhere((e) => e['section_id'] == 1)['teacher_id'],
      2,
    );
    expect(
      result.placements.singleWhere((e) => e['section_id'] == 2)['teacher_id'],
      1,
    );
    expect(ScheduleImprovementService.valid(input, result.placements), isTrue);
    final whole = const WholeWeekLocalSearch().solve(
      sections: rows(input, 'sections'),
      requirements: rows(input, 'requirements'),
      teachers: rows(input, 'teachers'),
      qualifications: rows(input, 'qualifications'),
      teacherGrades: [],
      teacherSubjectGrades: [],
      days: rows(input, 'days'),
      slots: rows(input, 'slots'),
      subjectBlockedSlots: [],
      teacherAvailability: rows(input, 'teacherAvailability'),
      lockedPlacements: [],
    );
    expect(whole, isNotNull);
    expect(ScheduleImprovementService.valid(input, whole!), isTrue);
    expect(whole.singleWhere((e) => e['section_id'] == 1)['teacher_id'], 2);
  });
  test('capacity and explanations retain unrelated grade capacity', () {
    final input = school();
    final capacity = const TeacherTimetableCapacity().calculate(
      teachers: rows(input, 'teachers'),
      sections: rows(input, 'sections'),
      requirements: rows(input, 'requirements'),
      qualifications: rows(input, 'qualifications'),
      teacherGrades: [],
      teacherSubjectGrades: [],
      days: rows(input, 'days'),
      slots: rows(input, 'slots'),
      subjectBlockedSlots: [],
      teacherAvailability: rows(input, 'teacherAvailability'),
    );
    expect(capacity[1], 1);
    expect(
      const ConstraintExplanationService()
          .explain(input)
          .where((e) => e.proven),
      isEmpty,
    );
  });
  test(
    'global restriction remains effective with a specific available row',
    () {
      final input = school();
      input['teacherAvailability'] = [
        {'teacher_id': 1, 'day_id': 1, 'slot_id': 1, 'is_available': 0},
        {
          'teacher_id': 1,
          'day_id': 1,
          'slot_id': 1,
          'grade_id': 1,
          'subject_id': 1,
          'is_available': 1,
        },
      ];
      final result = generate(input);
      expect(result.complete, isFalse);
      expect(result.placements.every((r) => r['teacher_id'] != 1), isTrue);
    },
  );
  test('Kempe repair may use a scoped blocked time for another grade', () {
    final input = school();
    final original = <Map<String, Object?>>[
      {
        'section_id': 1,
        'subject_id': 1,
        'teacher_id': 1,
        'day_id': 1,
        'slot_id': 1,
      },
      {
        'section_id': 2,
        'subject_id': 1,
        'teacher_id': 1,
        'day_id': 1,
        'slot_id': 2,
      },
    ];
    final fixed = const TimetableRepairService().repair(
      initialPlacements: original,
      blockedSlots: [],
      slots: [
        ...rows(input, 'slots'),
        {'id': 2, 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
      sections: rows(input, 'sections'),
      teacherAvailability: rows(input, 'teacherAvailability'),
      isOtherwiseValid: (_) => true,
    );
    expect(fixed, isNotNull);
    expect(fixed!.singleWhere((r) => r['section_id'] == 1)['slot_id'], 2);
    expect(fixed.singleWhere((r) => r['section_id'] == 2)['slot_id'], 1);
    expect(original.first['slot_id'], 1);
  });
  test(
    'a daily quota of one permits a later period without false capacity proof',
    () {
      final input = school();
      input['slots'] = [
        ...rows(input, 'slots'),
        {'id': 2, 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ];
      input['subjectBlockedSlots'] = [
        {'subject_id': 1, 'slot_id': 1},
      ];
      expect(
        const ConstraintExplanationService()
            .explain(input)
            .where((e) => e.proven),
        isEmpty,
      );
      final checked = const PreflightInspectionService().inspect(
        sections: rows(input, 'sections'),
        requirements: rows(input, 'requirements'),
        teachers: rows(input, 'teachers'),
        subjects: [
          {'id': 1, 'name': 'مادة'},
        ],
        qualifications: rows(input, 'qualifications'),
        teacherGrades: [],
        teacherSubjectGrades: [],
        days: rows(input, 'days'),
        slots: rows(input, 'slots'),
        currentEntries: [],
        availability: rows(input, 'teacherAvailability'),
        subjectBlockedSlots: rows(input, 'subjectBlockedSlots'),
      );
      expect(checked.canStart, isTrue);
      expect(
        checked.findings.where(
          (f) =>
              f.code == 'subject_availability_capacity' ||
              f.code == 'no_teacher_slot',
        ),
        isEmpty,
      );
    },
  );
}
