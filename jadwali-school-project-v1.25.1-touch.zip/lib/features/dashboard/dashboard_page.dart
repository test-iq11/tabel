import 'package:flutter/material.dart';

import '../../core/design_widgets.dart';
import '../../core/interface_settings.dart';
import '../../core/smart_widgets.dart';
import '../../core/school_hero.dart';
import '../settings/design_studio.dart';
import '../../core/ui_helpers.dart';
import '../../data/database_service.dart';
import '../smart/smart_access_dialog.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({
    required this.onNavigate,
    this.onOpenSection,
    this.onOpenTeacher,
    super.key,
  });
  final ValueChanged<int> onNavigate;
  final ValueChanged<int>? onOpenSection, onOpenTeacher;
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  late Future<Map<String, Object?>> _future;
  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    _future = _load();
  }

  Future<Map<String, Object?>> _load() async {
    final db = DatabaseService.instance;
    final year = await db.activeYearId();
    final version = await db.activeVersionId(year);
    return {
      ...await db.summary(),
      'days': await db.rows('school_days', orderBy: 'position'),
      'school': (await db.getSettings())['school_name'],
      'entries': version == null
          ? <Map<String, Object?>>[]
          : await db.entriesDetailed(versionId: version),
    };
  }

  Future<void> _search() => showSmartAccess(
    context,
    onNavigate: widget.onNavigate,
    onTeacher: widget.onOpenTeacher,
    onSection: widget.onOpenSection,
  );
  Future<void> _customize(String name) async {
    await showDesignStudio(context, schoolName: name);
    if (mounted) setState(_reload);
  }

  Widget _hero(Map<String, Object?> data, int count, int requested, int days) =>
      SchoolHero(
        key: const ValueKey('smart-school-hero'),
        design: InterfaceSettings.instance.design,
        name: '${data['school'] ?? 'المدرسة'}',
        count: count,
        requested: requested,
        days: days,
        sections: (data['عدد الشعب'] as num?)?.toInt() ?? 0,
        teachers: (data['عدد المعلمين'] as num?)?.toInt() ?? 0,
        onCustomize: () => _customize('${data['school'] ?? 'المدرسة'}'),
        onTimetable: () => widget.onNavigate(1),
        onScenario: () => widget.onNavigate(16),
      );
  Widget _metric(String value, String label, IconData icon) => SmartPanel(
    child: Row(
      children: [
        Container(
          padding: const EdgeInsets.all(9),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withValues(alpha: .08),
            borderRadius: BorderRadius.circular(13),
          ),
          child: Icon(icon, size: 21),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
  @override
  Widget build(BuildContext context) => Scaffold(
    body: FutureBuilder<Map<String, Object?>>(
      future: _future,
      builder: (context, snap) {
        if (snap.hasError)
          return emptyState(
            icon: Icons.error_outline,
            title: 'تعذر تحميل الملخص',
            message: '${snap.error}',
          );
        if (!snap.hasData)
          return const Center(child: CircularProgressIndicator());
        final data = snap.data!;
        int value(String key) => (data[key] as num?)?.toInt() ?? 0;
        final entries = (data['entries'] as List).cast<Map<String, Object?>>();
        final days = (data['days'] as List)
            .cast<Map<String, Object?>>()
            .where((d) => d['is_active'] != 0)
            .toList();
        final pins = entries.where((e) => e['is_locked'] == 1).length;
        final day = days.isEmpty ? null : days.first;
        final firstDay = entries
            .where((e) => e['day_id'] == day?['id'])
            .take(4)
            .toList();
        return RefreshIndicator(
          onRefresh: () async {
            setState(_reload);
            await _future;
          },
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1280),
              child: ListView(
                key: const ValueKey('smart-dashboard-scroll'),
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
                children: [
                  _hero(
                    data,
                    entries.length,
                    value('الحصص المطلوبة'),
                    days.length,
                  ),
                  const SizedBox(height: 18),
                  LayoutBuilder(
                    builder: (context, c) {
                      final columns = c.maxWidth > 750
                          ? 4
                          : c.maxWidth < 290 ||
                                MediaQuery.textScalerOf(context).scale(1) > 1.35
                          ? 1
                          : 2;
                      final metrics = [
                        (
                          '${entries.length}',
                          'حصة موزعة',
                          Icons.calendar_month_outlined,
                        ),
                        (
                          '${value('عدد الشعب')}',
                          'صفوف دراسية',
                          Icons.school_outlined,
                        ),
                        (
                          '${value('عدد المعلمين')}',
                          'معلمين',
                          Icons.people_outline,
                        ),
                        ('$pins', 'حصص مقفلة', Icons.lock_outline),
                      ];
                      return Wrap(
                        spacing: 12,
                        runSpacing: 12,
                        children: [
                          for (final m in metrics)
                            SizedBox(
                              width:
                                  (c.maxWidth - 12 * (columns - 1)) / columns,
                              child: _metric(m.$1, m.$2, m.$3),
                            ),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 22),
                  const SmartHeading('أدوات تتجاوز عرض الجدول'),
                  ActionGrid(
                    children: [
                      ActionTile(
                        key: const ValueKey('smart-lab-entry'),
                        title: 'ماذا لو؟',
                        subtitle: 'جرّب شرطاً دون تغيير بياناتك',
                        icon: Icons.auto_awesome_outlined,
                        onTap: () => widget.onNavigate(16),
                      ),
                      ActionTile(
                        title: 'طوارئ اليوم',
                        subtitle: 'خطط لغياب معلم وراجع البدلاء',
                        icon: Icons.bolt_outlined,
                        tone: 1,
                        onTap: () => widget.onNavigate(8),
                      ),
                      ActionTile(
                        key: const ValueKey('smart-search-entry'),
                        title: 'وصول ذكي',
                        subtitle: 'ابحث عن معلم أو صف أو أداة',
                        icon: Icons.search,
                        tone: 2,
                        onTap: _search,
                      ),
                    ],
                  ),
                  SmartHeading(
                    'اختصاراتك',
                    action: TextButton.icon(
                      onPressed: () => customizeHome(context),
                      icon: const Icon(Icons.tune, size: 17),
                      label: const Text('تخصيص الرئيسية'),
                    ),
                  ),
                  ActionGrid(
                    children: [
                      for (final id in InterfaceSettings.instance.shortcuts)
                        ActionTile(
                          title: shortcutInfo[id]!.$1,
                          subtitle: shortcutInfo[id]!.$2,
                          icon: shortcutInfo[id]!.$3,
                          tone: shortcutInfo[id]!.$4,
                          onTap: () => widget.onNavigate(id),
                        ),
                    ],
                  ),
                  if (firstDay.isNotEmpty) ...[
                    SmartHeading('نظرة إلى ${day!['name']}'),
                    SmartPanel(
                      child: Column(
                        children: [
                          for (final e in firstDay)
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(Icons.schedule),
                              title: Text('${e['subject_name']}'),
                              subtitle: Text(
                                '${e['grade_name'] ?? ''} ${e['section_name'] ?? ''} · ${e['teacher_name'] ?? 'دون معلم'}\n${e['slot_name']} · ${e['start_time']}',
                              ),
                              trailing: const Icon(Icons.chevron_left),
                              onTap: () => widget.onOpenSection?.call(
                                e['section_id'] as int,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                  if (!InterfaceSettings.instance.design.focus) ...[
                    const SizedBox(height: 22),
                    SmartPanel(
                      child: Wrap(
                        spacing: 15,
                        runSpacing: 10,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          const Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'مساحتك، على ذوقك',
                                style: TextStyle(fontWeight: FontWeight.w700),
                              ),
                              Text(
                                'ألوان هادئة وتفاصيل يمكنك تغييرها.',
                                style: TextStyle(fontSize: 11),
                              ),
                            ],
                          ),
                          OutlinedButton.icon(
                            onPressed: () =>
                                _customize('${data['school'] ?? 'المدرسة'}'),
                            icon: const Icon(Icons.tune, size: 18),
                            label: const Text('تخصيص المظهر'),
                          ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                  TextButton.icon(
                    onPressed: () => widget.onNavigate(13),
                    icon: const Icon(Icons.school_outlined),
                    label: const Text('إدارة بيانات المدرسة'),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    ),
  );
}
