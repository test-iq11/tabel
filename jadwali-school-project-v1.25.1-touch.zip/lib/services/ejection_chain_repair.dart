typedef Lesson = Map<String, Object?>;

/// Bounded conflict-directed ejection chains. Intermediate boards remain private;
/// only a complete, independently validated board can leave this service.
class EjectionChainRepair {
  const EjectionChainRepair();

  List<Lesson>? repair({
    required List<Lesson> initial,
    required List<Lesson> days,
    required List<Lesson> slots,
    required bool Function(List<Lesson>) partialValid,
    required bool Function(List<Lesson>) completeValid,
    List<Lesson> locks = const [],
    int maxNodes = 3000,
    int maxMoved = 24,
    bool Function()? shouldStop,
    void Function(int)? onNode,
  }) {
    if (initial.isEmpty || maxNodes <= 0 || shouldStop?.call() == true)
      return null;
    String identity(Lesson r) => [
      'section_id',
      'subject_id',
      'teacher_id',
      'day_id',
      'slot_id',
      'room_id',
    ].map((k) => r[k]).join(':');
    final lockedKeys = locks.map(identity).toSet();
    if (!lockedKeys.every(initial.map(identity).toSet().contains)) return null;
    final pinned = <int>{
      for (var i = 0; i < initial.length; i++)
        if (lockedKeys.contains(identity(initial[i]))) i,
    };
    final cells = [
      for (final day in days)
        if (day['is_active'] != 0)
          for (final slot in slots)
            if (slot['kind'] == 'lesson' && slot['is_available'] != 0)
              (day['id'], slot['id']),
    ];
    final domains = <int, List<Lesson>>{};
    List<Lesson> domain(int id) => domains.putIfAbsent(id, () {
      final result = <Lesson>[];
      for (final cell in cells) {
        if (shouldStop?.call() == true) break;
        final row = {...initial[id], 'day_id': cell.$1, 'slot_id': cell.$2};
        if (partialValid([row])) result.add(row);
      }
      return result;
    });
    final pending = <int>{};
    for (var i = 0; i < initial.length; i++) {
      if (shouldStop?.call() == true) return null;
      if (!partialValid([initial[i]])) pending.add(i);
    }
    if (pending.any(pinned.contains) || pending.length > maxMoved) return null;
    if (pending.isEmpty)
      return completeValid(initial)
          ? initial.map((r) => Lesson.from(r)).toList()
          : null;
    final start = <int, Lesson>{
      for (var i = 0; i < initial.length; i++)
        if (!pending.contains(i)) i: Lesson.from(initial[i]),
    };
    if (!partialValid(start.values.toList())) return null;
    var nodes = 0;
    final rootSections = pending.map((i) => initial[i]['section_id']).toSet();
    bool collide(Lesson a, Lesson b) =>
        a['day_id'] == b['day_id'] &&
        a['slot_id'] == b['slot_id'] &&
        (a['section_id'] == b['section_id'] ||
            (a['teacher_id'] != null && a['teacher_id'] == b['teacher_id']) ||
            (a['room_id'] != null && a['room_id'] == b['room_id']));
    // Restart with broader neighborhoods; reserve a separate share for each.
    for (var scope = 0; scope < 3; scope++) {
      final limit = maxNodes * (scope + 1) ~/ 3;
      final seen = <String>{};
      List<Lesson>? search(
        Map<int, Lesson> board,
        Set<int> todo,
        Set<int> committed,
      ) {
        if (nodes >= limit || shouldStop?.call() == true) return null;
        nodes++;
        onNode?.call(nodes);
        if (todo.isEmpty) {
          final result = [for (var i = 0; i < initial.length; i++) board[i]!];
          return completeValid(result) ? result : null;
        }
        if (committed.length + todo.length > maxMoved) return null;
        final fingerprint = [
          for (var i = 0; i < initial.length; i++)
            '$i:${board[i]?['day_id']}:${board[i]?['slot_id']}',
        ].join('|');
        if (!seen.add('$fingerprint/${(committed.toList()..sort()).join(',')}'))
          return null;
        final ordered = todo.toList()
          ..sort((a, b) => domain(a).length.compareTo(domain(b).length));
        final id = ordered.first;
        final options = domain(id)
            .where((r) => scope == 2 || r['day_id'] == initial[id]['day_id'])
            .toList();
        int cost(Lesson r) =>
            board.values.where((other) => collide(r, other)).length * 10 +
            (r['day_id'] == initial[id]['day_id'] ? 0 : 100);
        options.sort((a, b) => cost(a).compareTo(cost(b)));
        for (final row in options) {
          if (nodes >= limit || shouldStop?.call() == true) return null;
          final displaced = board.keys
              .where((other) => collide(row, board[other]!))
              .toSet();
          bool movable(int other) =>
              !pinned.contains(other) &&
              !committed.contains(other) &&
              (scope != 0 ||
                  rootSections.contains(initial[other]['section_id']));
          if (!displaced.every(movable)) continue;
          final candidate = {...board}
            ..removeWhere((k, v) => displaced.contains(k));
          candidate[id] = row;
          final variants = <Set<int>>[];
          if (partialValid(candidate.values.toList())) {
            variants.add(displaced);
          } else {
            // A daily subject/teacher limit may require releasing another lesson
            // even though it occupies a different period. Try related blockers.
            for (final other in candidate.keys) {
              if (other == id || !movable(other)) continue;
              final existing = candidate[other]!;
              if (existing['day_id'] != row['day_id']) continue;
              if (existing['section_id'] != row['section_id'] &&
                  existing['teacher_id'] != row['teacher_id'])
                continue;
              final reduced = {...candidate}..remove(other);
              if (partialValid(reduced.values.toList()))
                variants.add({...displaced, other});
              if (shouldStop?.call() == true) return null;
            }
          }
          for (final removed in variants) {
            final next = {...board}..removeWhere((k, v) => removed.contains(k));
            next[id] = row;
            final result = search(next, {...todo, ...removed}..remove(id), {
              ...committed,
              id,
            });
            if (result != null) return result;
          }
        }
        return null;
      }

      final result = search(start, pending, {});
      if (result != null) return result;
    }
    return null;
  }
}
