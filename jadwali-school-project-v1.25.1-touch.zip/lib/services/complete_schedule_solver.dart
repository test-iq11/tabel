import '../core/timetable_ordering.dart';
import 'teacher_availability_policy.dart';
import 'required_repeat_policy.dart';
import 'schedule_improvement_service.dart';
import 'school_timetable_policy.dart';
import 'teacher_assignment_policy.dart';
import 'teacher_capacity_flow.dart';

/// Only exhaustive tree exhaustion produces [infeasible]. A resource limit,
/// cancellation, or malformed model never becomes a claim of impossibility.
enum CompleteScheduleStatus {
  solved,
  infeasible,
  limit,
  cancelled,
  invalidInput,
}

class CompleteScheduleResult {
  const CompleteScheduleResult({
    required this.status,
    required this.placements,
    required this.exploredNodes,
    required this.elapsed,
    required this.reason,
  });
  final CompleteScheduleStatus status;
  final List<Map<String, Object?>> placements;
  final int exploredNodes;
  final Duration elapsed;
  final String reason;
  bool get complete => status == CompleteScheduleStatus.solved;
  bool get provenInfeasible => status == CompleteScheduleStatus.infeasible;
}

/// Finite-domain search over section/day/period cells. Unlike bounded exchange
/// chains, this search can move every unpinned lesson and change its teacher.
/// Every branch is retained unless a necessary constraint excludes it. MRV,
/// forward checking, daily-coverage propagation and relaxed maximum matching
/// reduce the tree; they never silently relax a school rule.
///
/// With finite valid school data and no resource interruption, the tree is
/// exhaustive. This is a completeness property, not a runtime guarantee. The
/// public default is deliberately bounded for an interactive phone application.
class CompleteScheduleSolver {
  const CompleteScheduleSolver();

  CompleteScheduleResult solve({
    required Map<String, Object?> input,
    Duration timeLimit = const Duration(seconds: 20),
    int nodeLimit = 1000000,
    bool Function()? shouldCancel,
    bool preserveLessonPositions = false,
    void Function(List<Map<String, Object?>> placements, int exploredNodes)?
    onProgress,
  }) => _Search(
    input,
    timeLimit,
    nodeLimit,
    shouldCancel,
    onProgress,
    preserveLessonPositions,
  ).run();
}

class _Requirement {
  _Requirement(
    this.row,
    this.section,
    this.subject,
    this.remaining,
    this.dailyLimit,
    this.lateRepeat,
    this.coverage,
    this.teachers,
    int days,
  ) : daily = List.filled(days, 0),
      lateDaily = List.filled(days, 0);
  final Map<String, Object?> row;
  final int section, subject, dailyLimit;
  int remaining;
  final bool lateRepeat, coverage;
  final List<int> teachers;
  final List<int> daily, lateDaily;
}

class _Cell {
  _Cell(this.section, this.day, this.slot, this.time);
  final int section, day, slot, time;
  int requirement = -2; // -2 unassigned, -1 deliberately empty.
  int teacher = -1;
  Map<String, Object?>? lock;
}

class _Option {
  const _Option(this.requirement, this.teacher);
  final int requirement, teacher;
}

class _Search {
  _Search(
    this.input,
    this.timeLimit,
    this.nodeLimit,
    this.shouldCancel,
    this.onProgress,
    this.preserveLessonPositions,
  );
  final bool preserveLessonPositions;
  final Map<String, Object?> input;
  final Duration timeLimit;
  final int nodeLimit;
  final bool Function()? shouldCancel;
  final void Function(List<Map<String, Object?>>, int)? onProgress;
  final clock = Stopwatch();
  late List<Map<String, Object?>> sections, teachers, days, slots;
  final requirements = <_Requirement>[];
  final cells = <_Cell>[];
  final sectionRequirements = <List<int>>[];
  final sectionCells = <List<int>>[];
  final timeCells = <List<int>>[];
  final staticOptions = <List<_Option>>[];
  final blocked = <String>{};
  late TeacherAvailabilityPolicy availability;
  final seed = <String, Map<String, Object?>>{};
  late List<int> sectionRemaining, sectionFree, teacherWeekly;
  late List<List<int>> sectionDaily, sectionDailyLimit, teacherDaily;
  late List<List<bool>> teacherBusy;
  late List<int> weeklyLimits, dailyLimits, consecutiveLimits;
  int nodes = 0, requested = 0, placed = 0, lastProgress = 0;
  CompleteScheduleStatus? interrupted;
  List<Map<String, Object?>> best = [];
  List<Map<String, Object?>>? solution;
  String? invalid;

  bool stop() {
    if (interrupted != null) return true;
    if (shouldCancel?.call() ?? false) {
      interrupted = CompleteScheduleStatus.cancelled;
    } else if (nodes >= nodeLimit || clock.elapsed >= timeLimit) {
      interrupted = CompleteScheduleStatus.limit;
    }
    return interrupted != null;
  }

  CompleteScheduleResult run() {
    clock.start();
    if (stop()) return result(interrupted!);
    initialize();
    if (invalid != null) return result(CompleteScheduleStatus.invalidInput);
    if (stop()) return result(interrupted!);
    // Initial rows are preferences only. A complete valid seed can be returned
    // immediately; invalid or partial seeds cannot restrict the complete tree.
    final original = _rows(input['initialPlacements']);
    if (ScheduleImprovementService.valid(input, original) &&
        ScheduleImprovementService.validPartial(input, original)) {
      solution = original;
      return result(CompleteScheduleStatus.solved);
    }
    best = ScheduleImprovementService.retainValidSeed(input);
    publish(force: true);
    if (stop()) return result(interrupted!);
    final found = search();
    if (found) return result(CompleteScheduleStatus.solved);
    return result(
      interrupted ??
          (preserveLessonPositions
              ? CompleteScheduleStatus.limit
              : CompleteScheduleStatus.infeasible),
    );
  }

  CompleteScheduleResult result(CompleteScheduleStatus status) {
    clock.stop();
    return CompleteScheduleResult(
      status: status,
      placements: (solution ?? best)
          .map((e) => Map<String, Object?>.from(e))
          .toList(),
      exploredNodes: nodes,
      elapsed: clock.elapsed,
      reason: switch (status) {
        CompleteScheduleStatus.solved => 'اكتمل الجدول واجتاز الفحص المستقل.',
        CompleteScheduleStatus.infeasible =>
          'استُنفدت احتمالات البحث بالقيود الحالية دون جدول كامل صالح.',
        CompleteScheduleStatus.limit =>
          'انتهت ميزانية البحث؛ لم تثبت استحالة التوزيع.',
        CompleteScheduleStatus.cancelled =>
          'أُوقف البحث مع الاحتفاظ بأفضل مسودة آمنة.',
        CompleteScheduleStatus.invalidInput =>
          invalid ?? 'تعذر إنشاء نموذج موثوق من البيانات المدخلة.',
      },
    );
  }

  void initialize() {
    sections = _rows(input['sections']);
    teachers = _rows(input['teachers']);
    days =
        _rows(input['days']).where((r) => _n(r['is_active'], 1) == 1).toList()
          ..sort(TimetableOrdering.compare);
    slots =
        _rows(input['slots'])
            .where(
              (r) => r['kind'] == 'lesson' && _n(r['is_available'], 1) == 1,
            )
            .toList()
          ..sort(TimetableOrdering.compare);
    final demand = _rows(input['requirements']);
    final sectionIndex = {
      for (var i = 0; i < sections.length; i++) _n(sections[i]['id']): i,
    };
    final teacherIndex = {
      for (var i = 0; i < teachers.length; i++) _n(teachers[i]['id']): i,
    };
    if (sectionIndex.length != sections.length ||
        teacherIndex.length != teachers.length ||
        days.map((r) => _n(r['id'])).toSet().length != days.length ||
        slots.map((r) => _n(r['id'])).toSet().length != slots.length) {
      invalid = 'معرّفات مكررة في إعدادات المدرسة.';
      return;
    }
    final requirementKeys = <String>{};
    final sectionDemand = List<int>.filled(sections.length, 0);
    for (final r in demand) {
      final s = sectionIndex[_n(r['section_id'])];
      final weekly = _n(r['weekly_lessons']);
      if (s == null ||
          weekly < 0 ||
          weekly > 1000 ||
          !requirementKeys.add('${r['section_id']}:${r['subject_id']}')) {
        invalid = 'صحّح المتطلبات المكررة أو غير الصالحة قبل التوزيع.';
        return;
      }
      sectionDemand[s] += weekly;
      requested += weekly;
    }
    // Resource protection is not a mathematical infeasibility claim.
    if (sections.length * days.length * slots.length > 10000 ||
        requested > 3000) {
      invalid = 'هذا النموذج يتجاوز سعة البحث المحلي الحالية.';
      return;
    }
    sectionRemaining = [...sectionDemand];
    sectionFree = List.filled(sections.length, 0);
    sectionDaily = List.generate(
      sections.length,
      (_) => List.filled(days.length, 0),
    );
    sectionDailyLimit = List.generate(
      sections.length,
      (s) => List.generate(
        days.length,
        (d) =>
            SchoolTimetablePolicy.canUseSeventhPeriod(
              section: sections[s],
              day: days[d],
              activeDays: days,
              lessonSlots: slots,
              weeklyDemand: sectionDemand[s],
            )
            ? 7
            : SchoolTimetablePolicy.normalDailyLimit(
                section: sections[s],
                lessonSlotCount: slots.length,
              ),
      ),
    );
    teacherWeekly = List.filled(teachers.length, 0);
    teacherDaily = List.generate(
      teachers.length,
      (_) => List.filled(days.length, 0),
    );
    teacherBusy = List.generate(
      teachers.length,
      (_) => List.filled(days.length * slots.length, false),
    );
    weeklyLimits = [for (final t in teachers) _n(t['weekly_load'])];
    dailyLimits = [for (final t in teachers) _n(t['max_daily_lessons'])];
    consecutiveLimits = [
      for (final t in teachers) _n(t['max_consecutive_lessons']),
    ];
    blocked.addAll(
      _rows(input['subjectBlockedSlots'])
          .map((r) => '${_n(r['subject_id'])}:${_n(r['slot_id'])}'),
    );
    availability = TeacherAvailabilityPolicy(
      _rows(input['teacherAvailability'] ?? input['availability']),
    );
    for (final row in _rows(input['initialPlacements'])) {
      seed['${row['section_id']}:${row['day_id']}:${row['slot_id']}'] = row;
    }
    final policy = TeacherAssignmentPolicy(
      qualifications: _rows(input['qualifications']),
      teacherGrades: _rows(input['teacherGrades']),
      teacherSubjectGrades: _rows(input['teacherSubjectGrades']),
    );
    sectionRequirements.addAll(List.generate(sections.length, (_) => <int>[]));
    sectionCells.addAll(List.generate(sections.length, (_) => <int>[]));
    timeCells.addAll(List.generate(days.length * slots.length, (_) => <int>[]));
    final requirementIndex = <String, int>{};
    for (final row in demand) {
      final s = sectionIndex[_n(row['section_id'])]!;
      final subject = _n(row['subject_id']);
      final weekly = _n(row['weekly_lessons']);
      if (weekly == 0) continue;
      final grade = _n(sections[s]['grade_id']);
      final lateRepeat = RequiredRepeatPolicy.allowsLatePeriodRepeat(
        requirement: row,
        section: sections[s],
        activeDays: days,
        sectionWeeklyDemand: sectionDemand[s],
        lessonSlots: slots,
        subjectBlockedSlots: _rows(input['subjectBlockedSlots']),
      );
      final daily = _n(row['allow_same_day']) == 1
          ? (_n(row['max_daily_lessons'], 2) <= 0
                ? 1
                : _n(row['max_daily_lessons'], 2))
          : (lateRepeat ? 2 : 1);
      final eligible = <int>[
        for (var t = 0; t < teachers.length; t++)
          if (policy.isSubjectQualified(_n(teachers[t]['id']), subject) &&
              policy.isGradeAllowed(_n(teachers[t]['id']), subject, grade))
            t,
      ];
      requirementIndex['${row['section_id']}:$subject'] = requirements.length;
      sectionRequirements[s].add(requirements.length);
      requirements.add(
        _Requirement(
          row,
          s,
          subject,
          weekly,
          daily,
          lateRepeat,
          weekly >= 5,
          eligible,
          days.length,
        ),
      );
    }
    final cellIndex = <String, int>{};
    for (var s = 0; s < sections.length; s++) {
      if (sectionDemand[s] == 0) continue;
      for (var d = 0; d < days.length; d++) {
        for (var p = 0; p < slots.length; p++) {
          if (p >= 6 && !(p == 6 && sectionDailyLimit[s][d] == 7)) continue;
          final c = _Cell(s, d, p, d * slots.length + p);
          final index = cells.length;
          cells.add(c);
          sectionFree[s]++;
          sectionCells[s].add(index);
          timeCells[c.time].add(index);
          cellIndex['${sections[s]['id']}:${days[d]['id']}:${slots[p]['id']}'] =
              index;
        }
      }
    }
    // Freeze immutable eligibility once. Candidate generation then avoids
    // repeatedly allocating string keys for identical subject/teacher rules.
    for (final cell in cells) {
      staticOptions.add([
        for (final r in sectionRequirements[cell.section])
          if ((!preserveLessonPositions ||
                  seed['${sections[cell.section]['id']}:${days[cell.day]['id']}:${slots[cell.slot]['id']}']?['subject_id'] ==
                      requirements[r].subject) &&
              !blocked.contains(
                '${requirements[r].subject}:${slots[cell.slot]['id']}',
              ))
            for (final t in requirements[r].teachers)
              if (availability.isAvailable(
                teacherId: _n(teachers[t]['id']),
                dayId: _n(days[cell.day]['id']),
                slotId: _n(slots[cell.slot]['id']),
                gradeId: _n(sections[cell.section]['grade_id']),
                subjectId: requirements[r].subject,
              ))
                _Option(r, t),
      ]);
    }
    for (final lock in _rows(input['lockedPlacements'])) {
      final ci =
          cellIndex['${lock['section_id']}:${lock['day_id']}:${lock['slot_id']}'];
      final ri =
          requirementIndex['${lock['section_id']}:${lock['subject_id']}'];
      final ti = teacherIndex[_n(lock['teacher_id'])];
      if (ci == null ||
          ri == null ||
          ti == null ||
          cells[ci].requirement != -2 ||
          !canPlace(cells[ci], ri, ti)) {
        invalid = 'توجد حصة مقفلة تخالف القيود الحالية؛ راجعها أولاً.';
        return;
      }
      cells[ci].lock = Map<String, Object?>.from(lock);
      assign(cells[ci], _Option(ri, ti));
    }
    if (!ScheduleImprovementService.validPartial(input, board())) {
      invalid = 'بيانات الفترات أو الحصص المقفلة غير صالحة للبحث.';
    }
  }

  bool canPlace(_Cell c, int r, int t, {bool staticChecked = false}) {
    final req = requirements[r];
    if (req.remaining <= 0 ||
        req.section != c.section ||
        sectionDaily[c.section][c.day] >= sectionDailyLimit[c.section][c.day] ||
        req.daily[c.day] >= req.dailyLimit ||
        (!staticChecked &&
            (blocked.contains('${req.subject}:${slots[c.slot]['id']}') ||
                !req.teachers.contains(t))))
      return false;
    if (req.lateRepeat &&
        req.daily[c.day] > 0 &&
        c.slot < 5 &&
        req.lateDaily[c.day] == 0)
      return false;
    if (req.coverage &&
        req.daily[c.day] > 0 &&
        req.daily.where((v) => v == 0).length >= req.remaining)
      return false;
    if (teacherBusy[t][c.time] ||
        (weeklyLimits[t] > 0 && teacherWeekly[t] >= weeklyLimits[t]) ||
        (dailyLimits[t] > 0 && teacherDaily[t][c.day] >= dailyLimits[t]) ||
        (!staticChecked &&
            !availability.isAvailable(
              teacherId: _n(teachers[t]['id']),
              dayId: _n(days[c.day]['id']),
              slotId: _n(slots[c.slot]['id']),
              gradeId: _n(sections[c.section]['grade_id']),
              subjectId: req.subject,
            )))
      return false;
    final consecutive = consecutiveLimits[t];
    if (consecutive > 0) {
      var run = 1;
      for (
        var p = c.slot - 1;
        p >= 0 && teacherBusy[t][c.day * slots.length + p];
        p--
      ) {
        run++;
      }
      for (
        var p = c.slot + 1;
        p < slots.length && teacherBusy[t][c.day * slots.length + p];
        p++
      ) {
        run++;
      }
      if (run > consecutive) return false;
    }
    return true;
  }

  void assign(_Cell c, _Option option) {
    c.requirement = option.requirement;
    c.teacher = option.teacher;
    sectionFree[c.section]--;
    if (option.requirement < 0) return;
    final r = requirements[option.requirement];
    r.remaining--;
    r.daily[c.day]++;
    if (c.slot >= 5) r.lateDaily[c.day]++;
    sectionRemaining[c.section]--;
    sectionDaily[c.section][c.day]++;
    teacherWeekly[c.teacher]++;
    teacherDaily[c.teacher][c.day]++;
    teacherBusy[c.teacher][c.time] = true;
    placed++;
  }

  void undo(_Cell c) {
    sectionFree[c.section]++;
    if (c.requirement >= 0) {
      final r = requirements[c.requirement];
      r.remaining++;
      r.daily[c.day]--;
      if (c.slot >= 5) r.lateDaily[c.day]--;
      sectionRemaining[c.section]++;
      sectionDaily[c.section][c.day]--;
      teacherWeekly[c.teacher]--;
      teacherDaily[c.teacher][c.day]--;
      teacherBusy[c.teacher][c.time] = false;
      placed--;
    }
    c.requirement = -2;
    c.teacher = -1;
  }

  List<Map<String, Object?>> board() => [
    for (final c in cells)
      if (c.requirement >= 0)
        c.lock != null
            ? Map<String, Object?>.from(c.lock!)
            : <String, Object?>{
                'section_id': _n(sections[c.section]['id']),
                'subject_id': requirements[c.requirement].subject,
                'teacher_id': _n(teachers[c.teacher]['id']),
                'day_id': _n(days[c.day]['id']),
                'slot_id': _n(slots[c.slot]['id']),
                'room_id': null,
              },
  ];

  void publish({bool force = false}) {
    if (placed > best.length) {
      final candidate = board();
      if (ScheduleImprovementService.validPartial(input, candidate))
        best = candidate;
    }
    if (force || clock.elapsedMilliseconds - lastProgress >= 250) {
      lastProgress = clock.elapsedMilliseconds;
      onProgress?.call(
        best.map((r) => Map<String, Object?>.from(r)).toList(),
        nodes,
      );
    }
  }

  bool search() {
    if (stop()) return false;
    nodes++;
    if (placed == requested) {
      final candidate = board();
      if (ScheduleImprovementService.valid(input, candidate) &&
          ScheduleImprovementService.validPartial(input, candidate)) {
        solution = candidate;
        best = candidate;
        publish(force: true);
        return true;
      }
      return false;
    }
    if (placed > best.length || nodes % 128 == 0) publish();
    for (var s = 0; s < sections.length; s++) {
      if (sectionRemaining[s] > sectionFree[s]) return false;
      var remainingCapacity = 0;
      for (var d = 0; d < days.length; d++) {
        final free = sectionCells[s]
            .where((i) => cells[i].day == d && cells[i].requirement == -2)
            .length;
        final cap = sectionDailyLimit[s][d] - sectionDaily[s][d];
        remainingCapacity += free < cap ? free : cap;
      }
      if (remainingCapacity < sectionRemaining[s]) return false;
    }
    final domains = <int, List<_Option>>{};
    final reqCells = List.generate(requirements.length, (_) => <int>[]);
    final reqDayCells = List.generate(
      requirements.length,
      (_) => List<int>.filled(days.length, 0),
    );
    final reqTeachers = List.generate(requirements.length, (_) => <int>{});
    int chosen = -1;
    var smallest = 1 << 30;
    for (var i = 0; i < cells.length; i++) {
      final c = cells[i];
      if (c.requirement != -2) continue;
      final options = <_Option>[];
      final possibleReqs = <int>{};
      for (final option in staticOptions[i]) {
        if (canPlace(
          c,
          option.requirement,
          option.teacher,
          staticChecked: true,
        )) {
          options.add(option);
          reqTeachers[option.requirement].add(option.teacher);
          possibleReqs.add(option.requirement);
        }
      }
      for (final r in possibleReqs) {
        reqCells[r].add(i);
        reqDayCells[r][c.day]++;
      }
      if (sectionFree[c.section] > sectionRemaining[c.section]) {
        options.add(const _Option(-1, -1));
      }
      if (options.isEmpty) return false;
      domains[i] = options;
      if (options.length < smallest) {
        smallest = options.length;
        chosen = i;
      }
    }
    if (chosen < 0) return false;
    for (var r = 0; r < requirements.length; r++) {
      final req = requirements[r];
      if (reqCells[r].length < req.remaining) return false;
      var dailyCapacity = 0;
      var missingDays = 0;
      for (var d = 0; d < days.length; d++) {
        final cap = req.dailyLimit - req.daily[d];
        final available = reqDayCells[r][d];
        dailyCapacity += available < cap ? available : cap;
        if (req.coverage && req.daily[d] == 0) {
          missingDays++;
          if (available == 0) return false;
        }
      }
      if (dailyCapacity < req.remaining || missingDays > req.remaining)
        return false;
    }
    // Matching is a relaxed upper bound, so failure is a sound prune. Run it
    // periodically; omitting it at other nodes affects speed, not completeness.
    if (nodes == 1 || nodes % 8 == 0) {
      for (var s = 0; s < sections.length; s++) {
        final reqs = sectionRequirements[s]
            .where((r) => requirements[r].remaining > 0)
            .toList();
        if (reqs.isEmpty) continue;
        if (TeacherCapacityFlow.maximum(
              demand: [for (final r in reqs) requirements[r].remaining],
              eligibleTeachers: [for (final r in reqs) reqCells[r]],
              capacity: {
                for (final i in sectionCells[s])
                  if (cells[i].requirement == -2) i: 1,
              },
            ) <
            sectionRemaining[s])
          return false;
      }
      final teacherPossible = List.generate(
        teachers.length,
        (_) => List<bool>.filled(days.length * slots.length, false),
      );
      for (final entry in domains.entries) {
        for (final o in entry.value) {
          if (o.teacher >= 0)
            teacherPossible[o.teacher][cells[entry.key].time] = true;
        }
      }
      final teacherCapacity = <int, int>{};
      for (var t = 0; t < teachers.length; t++) {
        var capacity = 0;
        for (var d = 0; d < days.length; d++) {
          // DP counts the maximum extra lessons in this teacher's day,
          // retaining existing busy periods and respecting consecutive limits.
          // Subject/section coupling is omitted, hence this is an upper bound.
          final maxRun = consecutiveLimits[t] > 0
              ? consecutiveLimits[t]
              : slots.length;
          var states = List<int>.filled(maxRun + 1, -1000000)..[0] = 0;
          for (var p = 0; p < slots.length; p++) {
            final next = List<int>.filled(maxRun + 1, -1000000);
            final index = d * slots.length + p;
            for (var run = 0; run <= maxRun; run++) {
              if (states[run] < 0) continue;
              if (!teacherBusy[t][index] && states[run] > next[0])
                next[0] = states[run];
              if (run < maxRun &&
                  (teacherBusy[t][index] || teacherPossible[t][index])) {
                final value = states[run] + (teacherBusy[t][index] ? 0 : 1);
                if (value > next[run + 1]) next[run + 1] = value;
              }
            }
            states = next;
          }
          var dayCapacity = states.reduce((a, b) => a > b ? a : b);
          if (dayCapacity < 0) return false;
          if (dailyLimits[t] > 0 &&
              dayCapacity > dailyLimits[t] - teacherDaily[t][d]) {
            dayCapacity = dailyLimits[t] - teacherDaily[t][d];
          }
          capacity += dayCapacity;
        }
        if (weeklyLimits[t] > 0 &&
            capacity > weeklyLimits[t] - teacherWeekly[t]) {
          capacity = weeklyLimits[t] - teacherWeekly[t];
        }
        teacherCapacity[t] = capacity;
      }
      final remaining = requirements.where((r) => r.remaining > 0).length;
      if (remaining > 0 &&
          TeacherCapacityFlow.maximum(
                demand: [for (final r in requirements) r.remaining],
                eligibleTeachers: [for (final ts in reqTeachers) ts.toList()],
                capacity: teacherCapacity,
              ) <
              requested - placed)
        return false;
      for (final group in timeCells) {
        final mandatory = group
            .where(
              (i) =>
                  cells[i].requirement == -2 &&
                  sectionFree[cells[i].section] ==
                      sectionRemaining[cells[i].section],
            )
            .toList();
        if (mandatory.length < 2) continue;
        if (TeacherCapacityFlow.maximum(
              demand: List.filled(mandatory.length, 1),
              eligibleTeachers: [
                for (final i in mandatory)
                  domains[i]!
                      .map((o) => o.teacher)
                      .where((t) => t >= 0)
                      .toSet()
                      .toList(),
              ],
              capacity: {for (var t = 0; t < teachers.length; t++) t: 1},
            ) <
            mandatory.length)
          return false;
      }
    }
    final cell = cells[chosen];
    final preferred =
        seed['${sections[cell.section]['id']}:${days[cell.day]['id']}:${slots[cell.slot]['id']}'];
    double priority(_Option option) {
      if (option.requirement < 0) return -1000000;
      final req = requirements[option.requirement];
      var score = 1000 * req.remaining / reqCells[option.requirement].length;
      if (req.coverage && req.daily[cell.day] == 0) score += 100;
      if (preferred?['subject_id'] == req.subject) {
        score += 10000;
        if (preferred?['teacher_id'] == teachers[option.teacher]['id'])
          score += 10000;
      }
      // Prefer spare teacher capacity. This is ordering only; all alternatives
      // remain in the tree, including teachers not used in the seed.
      score -= teacherWeekly[option.teacher] * 0.1;
      if (req.daily[cell.day] > 0) {
        if (cell.slot >= 5 || (cell.slot < 3 && req.lateDaily[cell.day] > 0))
          score += 5;
      }
      return score;
    }

    final options = domains[chosen]!
      ..sort((a, b) => priority(b).compareTo(priority(a)));
    for (final option in options) {
      if (stop()) return false;
      assign(cell, option);
      if (search()) return true;
      undo(cell);
    }
    return false;
  }
}

int _n(Object? value, [int fallback = 0]) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
List<Map<String, Object?>> _rows(Object? value) => value is List
    ? value.whereType<Map>().map((r) => Map<String, Object?>.from(r)).toList()
    : [];
