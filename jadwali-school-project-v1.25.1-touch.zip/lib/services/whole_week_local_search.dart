import 'teacher_availability_policy.dart';

import 'dart:math';

import '../core/timetable_ordering.dart';
import 'required_repeat_policy.dart';
import 'school_timetable_policy.dart';
import 'teacher_assignment_policy.dart';

/// A complete-board tabu search. Every move exchanges lessons across the whole
/// week, including other weekdays, and may change both teachers. Section cells,
/// lesson counts, blocked periods, qualifications and pins are always preserved.
/// Other constraints guide the search; only a zero-conflict board is returned.
class WholeWeekLocalSearch {
  const WholeWeekLocalSearch();

  List<Map<String, Object?>>? solve({
    required List<Map<String, Object?>> sections,
    required List<Map<String, Object?>> requirements,
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> qualifications,
    required List<Map<String, Object?>> teacherGrades,
    required List<Map<String, Object?>> teacherSubjectGrades,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    required List<Map<String, Object?>> subjectBlockedSlots,
    required List<Map<String, Object?>> teacherAvailability,
    required List<Map<String, Object?>> lockedPlacements,
    int maxIterations = 20000,
    bool Function()? shouldStop,
    void Function(int iterations)? onIteration,
  }) {
    final activeDays = days.where((r) => _int(r['is_active'], 1) == 1).toList()
      ..sort(TimetableOrdering.compare);
    final periods =
        slots
            .where(
              (r) => r['kind'] == 'lesson' && _int(r['is_available'], 1) == 1,
            )
            .toList()
          ..sort(TimetableOrdering.compare);
    if (activeDays.isEmpty || periods.isEmpty || teachers.isEmpty) return null;
    final sectionIndex = {
      for (var i = 0; i < sections.length; i++) _int(sections[i]['id']): i,
    };
    final teacherIndex = {
      for (var i = 0; i < teachers.length; i++) _int(teachers[i]['id']): i,
    };
    final dayIndex = {
      for (var i = 0; i < activeDays.length; i++) _int(activeDays[i]['id']): i,
    };
    final slotIndex = {
      for (var i = 0; i < periods.length; i++) _int(periods[i]['id']): i,
    };
    final dayCount = activeDays.length, slotCount = periods.length;
    final cellCount = dayCount * slotCount;
    final blocked = {
      for (final r in subjectBlockedSlots)
        '${_int(r['subject_id'])}:${_int(r['slot_id'])}',
    };
    final availabilityPolicy = TeacherAvailabilityPolicy(teacherAvailability);
    final policy = TeacherAssignmentPolicy(
      qualifications: qualifications,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
    );
    final demand = <int, int>{};
    for (final req in requirements) {
      final id = _int(req['section_id']);
      demand[id] =
          (demand[id] ?? 0) + _int(req['weekly_lessons']).clamp(0, 1000);
    }
    final groups = <_LocalGroup>[];
    final tokenGroup = <int>[];
    final groupByKey = <String, int>{};
    final sectionCells = <List<int>>[];
    for (final section in sections) {
      final normal = SchoolTimetablePolicy.normalDailyLimit(
        section: section,
        lessonSlotCount: slotCount,
      );
      final cells = <int>[];
      for (var d = 0; d < dayCount; d++) {
        final seventh = SchoolTimetablePolicy.canUseSeventhPeriod(
          section: section,
          day: activeDays[d],
          activeDays: activeDays,
          lessonSlots: periods,
          weeklyDemand: demand[_int(section['id'])] ?? 0,
        );
        for (var s = 0; s < slotCount; s++) {
          if (s < normal || (s == 6 && seventh)) cells.add(d * slotCount + s);
        }
      }
      if ((demand[_int(section['id'])] ?? 0) > cells.length) return null;
      sectionCells.add(cells);
    }
    for (final req in requirements) {
      final weekly = _int(req['weekly_lessons']);
      if (weekly <= 0) continue;
      final section = sectionIndex[_int(req['section_id'])];
      if (section == null || weekly > 1000) return null;
      final subject = _int(req['subject_id']);
      final key = '${_int(req['section_id'])}:$subject';
      if (groupByKey.containsKey(key)) return null;
      final eligible = [
        for (var t = 0; t < teachers.length; t++)
          if (policy.isSubjectQualified(_int(teachers[t]['id']), subject) &&
              policy.isGradeAllowed(
                _int(teachers[t]['id']),
                subject,
                _int(sections[section]['grade_id']),
              ))
            t,
      ];
      final domains = List.generate(cellCount, (_) => <int>[]);
      for (final cell in sectionCells[section]) {
        final d = cell ~/ slotCount, s = cell % slotCount;
        if (blocked.contains('$subject:${_int(periods[s]['id'])}')) continue;
        domains[cell] = eligible
            .where(
              (t) => availabilityPolicy.isAvailable(
                teacherId: _int(teachers[t]['id']),
                dayId: _int(activeDays[d]['id']),
                slotId: _int(periods[s]['id']),
                gradeId: _int(sections[section]['grade_id']),
                subjectId: subject,
              ),
            )
            .toList();
      }
      if (domains.every((values) => values.isEmpty)) return null;
      final implicitRepeat = RequiredRepeatPolicy.allowsLatePeriodRepeat(
        requirement: req,
        section: sections[section],
        activeDays: activeDays,
        sectionWeeklyDemand: demand[_int(req['section_id'])] ?? 0,
        lessonSlots: periods,
        subjectBlockedSlots: subjectBlockedSlots,
      );
      final repeat = _int(req['allow_same_day']) == 1;
      final configured = _int(req['max_daily_lessons'], 2);
      final g = groups.length;
      groupByKey[key] = g;
      groups.add(
        _LocalGroup(
          section,
          subject,
          weekly,
          repeat
              ? max(1, configured)
              : implicitRepeat
              ? 2
              : 1,
          weekly >= 5,
          !repeat && implicitRepeat,
          domains,
        ),
      );
      for (var n = 0; n < weekly; n++) {
        tokenGroup.add(g);
      }
    }
    final n = tokenGroup.length;
    if (n == 0 || n > 2000 || shouldStop?.call() == true) return null;
    final fixed = List<bool>.filled(n, false);
    final rooms = List<Object?>.filled(n, null);
    final fixedCells = List<int>.filled(n, -1),
        fixedTeachers = List<int>.filled(n, -1);
    for (final row in lockedPlacements) {
      final g =
          groupByKey['${_int(row['section_id'])}:${_int(row['subject_id'])}'];
      final d = dayIndex[_int(row['day_id'])],
          s = slotIndex[_int(row['slot_id'])];
      final t = teacherIndex[_int(row['teacher_id'])];
      if (g == null || d == null || s == null || t == null) return null;
      final i = List.generate(
        n,
        (i) => i,
      ).where((i) => tokenGroup[i] == g && !fixed[i]).firstOrNull;
      final cell = d * slotCount + s;
      if (i == null || !groups[g].domains[cell].contains(t)) return null;
      fixed[i] = true;
      fixedCells[i] = cell;
      fixedTeachers[i] = t;
      rooms[i] = row['room_id'];
    }
    final cell = List<int>.filled(n, -1), teacher = List<int>.filled(n, -1);
    final at = List.generate(
      sections.length,
      (_) => List<int>.filled(cellCount, -1),
    );
    final groupDay = List.generate(
      groups.length,
      (_) => List<int>.filled(dayCount, 0),
    );
    final groupEarly = List.generate(
      groups.length,
      (_) => List<int>.filled(dayCount, 0),
    );
    final teacherCell = List.generate(
      teachers.length,
      (_) => List<int>.filled(cellCount, 0),
    );
    final teacherDay = List.generate(
      teachers.length,
      (_) => List<int>.filled(dayCount, 0),
    );
    final teacherWeek = List<int>.filled(teachers.length, 0);
    final tabu = List.generate(n, (_) => List<int>.filled(cellCount, 0));
    final random = Random(37021);
    int excess(int value, int limit) =>
        limit > 0 && value > limit ? (value - limit) * (value - limit) : 0;
    int groupCost(int g, int d) {
      final rule = groups[g], count = groupDay[g][d], early = groupEarly[g][d];
      var cost = excess(count, rule.dailyLimit) * 8;
      if (rule.dailyCoverage && count == 0) cost += 8;
      if (rule.implicitRepeat) {
        cost += excess(early, 1) * 8 + excess(count - early, 1) * 8;
        if (count > early && early == 0) cost += 8;
      }
      return cost;
    }

    int weekCost(int t) =>
        excess(teacherWeek[t], _int(teachers[t]['weekly_load'], 24)) * 10;
    int dayCost(int t, int d) {
      var cost =
          excess(teacherDay[t][d], _int(teachers[t]['max_daily_lessons'], 6)) *
          8;
      final limit = _int(teachers[t]['max_consecutive_lessons']);
      var run = 0;
      for (var s = 0; s < slotCount; s++) {
        final count = teacherCell[t][d * slotCount + s];
        cost += count * (count - 1) * 6;
        run = count > 0 ? run + 1 : 0;
        if (limit > 0 && run > limit) cost += 8;
      }
      return cost;
    }

    void adjust(int i, int c, int t, int direction) {
      final g = tokenGroup[i], d = c ~/ slotCount;
      groupDay[g][d] += direction;
      if (c % slotCount < 5) groupEarly[g][d] += direction;
      teacherCell[t][c] += direction;
      teacherDay[t][d] += direction;
      teacherWeek[t] += direction;
    }

    int totalCost() {
      var cost = 0;
      for (var g = 0; g < groups.length; g++) {
        for (var d = 0; d < dayCount; d++) {
          cost += groupCost(g, d);
        }
      }
      for (var t = 0; t < teachers.length; t++) {
        cost += weekCost(t);
        for (var d = 0; d < dayCount; d++) {
          cost += dayCost(t, d);
        }
      }
      return cost;
    }

    List<Map<String, Object?>> result() => [
      for (var i = 0; i < n; i++)
        {
          'section_id': sections[groups[tokenGroup[i]].section]['id'],
          'subject_id': groups[tokenGroup[i]].subject,
          'teacher_id': teachers[teacher[i]]['id'],
          'day_id': activeDays[cell[i] ~/ slotCount]['id'],
          'slot_id': periods[cell[i] % slotCount]['id'],
          'room_id': rooms[i],
        },
    ];
    var iteration = 0;
    for (
      var restart = 0;
      iteration < maxIterations && shouldStop?.call() != true;
      restart++
    ) {
      for (final row in at) {
        row.fillRange(0, row.length, -1);
      }
      cell.fillRange(0, n, -1);
      teacher.fillRange(0, n, -1);
      for (var i = 0; i < n; i++) {
        tabu[i].fillRange(0, cellCount, 0);
        if (!fixed[i]) continue;
        final section = groups[tokenGroup[i]].section;
        if (at[section][fixedCells[i]] >= 0) return null;
        cell[i] = fixedCells[i];
        teacher[i] = fixedTeachers[i];
        at[section][cell[i]] = i;
      }
      final tokens = [
        for (var i = 0; i < n; i++)
          if (!fixed[i]) i,
      ]..shuffle(random);
      tokens.sort(
        (a, b) => groups[tokenGroup[a]].domains
            .where((v) => v.isNotEmpty)
            .length
            .compareTo(
              groups[tokenGroup[b]].domains.where((v) => v.isNotEmpty).length,
            ),
      );
      final cellOrders = List.generate(
        groups.length,
        (g) => [
          for (final c in sectionCells[groups[g].section])
            if (groups[g].domains[c].isNotEmpty) c,
        ]..shuffle(random),
      );
      bool match(int i, Set<int> visited) {
        final g = tokenGroup[i], section = groups[g].section;
        for (final c in cellOrders[g]) {
          if (!visited.add(c)) continue;
          final other = at[section][c];
          if (other >= 0 && fixed[other]) continue;
          if (other < 0 || match(other, visited)) {
            at[section][c] = i;
            cell[i] = c;
            return true;
          }
        }
        return false;
      }

      for (final i in tokens) {
        if (!match(i, <int>{})) return null;
      }
      for (final row in groupDay) {
        row.fillRange(0, dayCount, 0);
      }
      for (final row in groupEarly) {
        row.fillRange(0, dayCount, 0);
      }
      for (final row in teacherCell) {
        row.fillRange(0, cellCount, 0);
      }
      for (final row in teacherDay) {
        row.fillRange(0, dayCount, 0);
      }
      teacherWeek.fillRange(0, teacherWeek.length, 0);
      // Prefer legal teachers with spare capacity; never freeze an old teacher
      // assignment merely because it came from a previous timetable.
      for (final i in [
        for (var i = 0; i < n; i++)
          if (fixed[i]) i,
        ...tokens,
      ]) {
        if (!fixed[i]) {
          final candidates = [...groups[tokenGroup[i]].domains[cell[i]]]
            ..shuffle(random);
          candidates.sort(
            (a, b) => (teacherCell[a][cell[i]] * 100 + teacherWeek[a])
                .compareTo(teacherCell[b][cell[i]] * 100 + teacherWeek[b]),
          );
          teacher[i] = candidates.first;
        }
        adjust(i, cell[i], teacher[i], 1);
      }
      var cost = totalCost(), best = cost, lastImprovement = iteration;
      while (iteration < maxIterations &&
          iteration - lastImprovement < 1300 &&
          shouldStop?.call() != true) {
        if (cost == 0) {
          onIteration?.call(iteration);
          return result();
        }
        iteration++;
        if (iteration % 32 == 0) onIteration?.call(iteration);
        final bad = <int>[];
        for (var i = 0; i < n; i++) {
          if (fixed[i]) continue;
          final g = tokenGroup[i], t = teacher[i], d = cell[i] ~/ slotCount;
          if (groupCost(g, d) > 0 ||
              dayCost(t, d) > 0 ||
              weekCost(t) > 0 ||
              (groups[g].dailyCoverage && groupDay[g].any((v) => v == 0)))
            bad.add(i);
        }
        if (bad.isEmpty) break;
        final i = bad[random.nextInt(bad.length)];
        final g = tokenGroup[i],
            section = groups[g].section,
            oldCell = cell[i],
            oldTeacher = teacher[i];
        var bestCost = 1 << 50,
            bestCell = -1,
            bestTeacher = -1,
            bestOtherTeacher = -1,
            ties = 0;
        for (final target in cellOrders[g]) {
          if (shouldStop?.call() == true) return null;
          final j = at[section][target];
          if (j >= 0 && fixed[j]) continue;
          final otherGroup = j >= 0 ? tokenGroup[j] : -1;
          if (j >= 0 && j != i && groups[otherGroup].domains[oldCell].isEmpty)
            continue;
          final firstTeachers = groups[g].domains[target];
          final secondTeachers = j >= 0 && j != i
              ? groups[otherGroup].domains[oldCell]
              : const [-1];
          for (final newTeacher in firstTeachers) {
            for (final otherTeacher in secondTeachers) {
              if (target == oldCell && newTeacher == oldTeacher) continue;
              final oldOtherTeacher = j >= 0 ? teacher[j] : -1;
              final gs = {g, if (j >= 0 && j != i) otherGroup};
              final ds = {oldCell ~/ slotCount, target ~/ slotCount};
              final ts = {
                oldTeacher,
                newTeacher,
                if (j >= 0 && j != i) oldOtherTeacher,
                if (j >= 0 && j != i) otherTeacher,
              };
              int affectedCost() {
                var sum = 0;
                for (final group in gs) {
                  for (final d in ds) {
                    sum += groupCost(group, d);
                  }
                }
                for (final t in ts) {
                  sum += weekCost(t);
                  for (final d in ds) {
                    sum += dayCost(t, d);
                  }
                }
                return sum;
              }

              final before = affectedCost();
              adjust(i, oldCell, oldTeacher, -1);
              if (j >= 0 && j != i) adjust(j, target, oldOtherTeacher, -1);
              adjust(i, target, newTeacher, 1);
              if (j >= 0 && j != i) adjust(j, oldCell, otherTeacher, 1);
              final candidate = cost + affectedCost() - before;
              adjust(i, target, newTeacher, -1);
              if (j >= 0 && j != i) adjust(j, oldCell, otherTeacher, -1);
              adjust(i, oldCell, oldTeacher, 1);
              if (j >= 0 && j != i) adjust(j, target, oldOtherTeacher, 1);
              if (candidate >= best &&
                  (tabu[i][target] > iteration ||
                      (j >= 0 && j != i && tabu[j][oldCell] > iteration)))
                continue;
              if (candidate < bestCost ||
                  (candidate == bestCost && random.nextInt(++ties) == 0)) {
                if (candidate < bestCost) ties = 1;
                bestCost = candidate;
                bestCell = target;
                bestTeacher = newTeacher;
                bestOtherTeacher = otherTeacher;
              }
            }
          }
        }
        if (bestCell < 0) continue;
        final j = at[section][bestCell];
        adjust(i, oldCell, oldTeacher, -1);
        if (j >= 0 && j != i) adjust(j, bestCell, teacher[j], -1);
        adjust(i, bestCell, bestTeacher, 1);
        at[section][oldCell] = -1;
        if (j >= 0 && j != i) {
          adjust(j, oldCell, bestOtherTeacher, 1);
          cell[j] = oldCell;
          teacher[j] = bestOtherTeacher;
          at[section][oldCell] = j;
          tabu[j][bestCell] = iteration + 5 + random.nextInt(8);
        }
        cell[i] = bestCell;
        teacher[i] = bestTeacher;
        at[section][bestCell] = i;
        tabu[i][oldCell] = iteration + 5 + random.nextInt(8);
        cost = bestCost;
        if (cost < best) {
          best = cost;
          lastImprovement = iteration;
        }
      }
      if (cost == 0) {
        onIteration?.call(iteration);
        return result();
      }
    }
    return null;
  }
}

class _LocalGroup {
  _LocalGroup(
    this.section,
    this.subject,
    this.weekly,
    this.dailyLimit,
    this.dailyCoverage,
    this.implicitRepeat,
    this.domains,
  );
  final int section, subject, weekly, dailyLimit;
  final bool dailyCoverage, implicitRepeat;
  final List<List<int>> domains;
}

int _int(Object? value, [int fallback = 0]) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
