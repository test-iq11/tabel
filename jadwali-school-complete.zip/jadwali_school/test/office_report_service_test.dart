import 'dart:convert';

import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/office_report_service.dart';

void main() {
  const schoolName = 'مدرسة الاختبار';
  const academicYear = '2026-2027';
  const versionName = 'الجدول التجريبي';
  const status = 'مسودة';
  final sections = <Map<String, Object?>>[
    {'id': 1, 'grade_name': 'الأول الابتدائي', 'section_name': 'أ'},
  ];
  final days = <Map<String, Object?>>[
    {'id': 1, 'name': 'الأحد', 'position': 1, 'is_active': 1},
    {'id': 2, 'name': 'الاثنين', 'position': 2, 'is_active': 1},
    {'id': 3, 'name': 'الثلاثاء', 'position': 3, 'is_active': 1},
    {'id': 4, 'name': 'الأربعاء', 'position': 4, 'is_active': 1},
    {'id': 5, 'name': 'الخميس', 'position': 5, 'is_active': 1},
  ];
  final slots = <Map<String, Object?>>[
    {'id': 1, 'name': 'الحصة الأولى', 'start_time': '08:00', 'end_time': '08:45', 'position': 1, 'kind': 'lesson', 'is_available': 1},
  ];
  final entries = <Map<String, Object?>>[
    {'section_id': 1, 'day_id': 1, 'slot_id': 1, 'day_position': 1, 'slot_position': 1, 'subject_name': 'اللغة العربية', 'teacher_name': 'أحمد'},
  ];

  test('Word export is a ZIP-based OOXML document with A3 landscape and Arabic text', () async {
    final bytes = await OfficeReportService().buildDocx(
      schoolName: schoolName,
      academicYear: academicYear,
      versionName: versionName,
      status: status,
      entries: entries,
      sections: sections,
      days: days,
      slots: slots,
    );
    expect(bytes.length, greaterThan(100));
    final archive = ZipDecoder().decodeBytes(bytes);
    final document = archive.findFile('word/document.xml');
    expect(document, isNotNull);
    final xml = utf8.decode(document!.readBytes()!);
    expect(xml, contains('w:w="23811"'));
    expect(xml, contains('w:orient="landscape"'));
    expect(xml, contains('اللغة العربية'));
    expect(xml, contains('أحمد'));
  });

  test('Excel export sets the paper to A3 landscape and preserves Arabic text', () async {
    final bytes = await OfficeReportService().buildXlsx(
      schoolName: schoolName,
      academicYear: academicYear,
      versionName: versionName,
      status: status,
      entries: entries,
      sections: sections,
      days: days,
      slots: slots,
    );
    expect(bytes.length, greaterThan(100));
    final archive = ZipDecoder().decodeBytes(bytes);
    final worksheet = archive.findFile('xl/worksheets/sheet1.xml');
    expect(worksheet, isNotNull);
    final xml = utf8.decode(worksheet!.readBytes()!);
    expect(xml, contains('paperSize="8"'));
    expect(xml, contains('orientation="landscape"'));
    expect(xml, contains('اللغة العربية'));
    expect(xml, contains('الأحد'));
  });
}
