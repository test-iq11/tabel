# ملاحظات الإصدار 1.8.4

هذا الإصدار يصلح أخطاء التحليل التي أبلغ عنها CI في `theme.dart` و`timetable_page.dart` ويزيل استعمالات `withOpacity` المعلّمة deprecated في الملفين المحددين. لا يمثل هذا وحده تأكيداً على خلو كامل المشروع من أخطاء أخرى؛ اعتمد نتيجة `flutter analyze --no-fatal-infos` و`flutter test` وبناء APK من CI.
