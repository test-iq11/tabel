# تحديث الإصدار 1.8.9+23

## إصلاح فشل GitHub Actions

- إزالة المتغير المحلي `weeklyRequired` غير المستخدم من `lib/features/timetable/timetable_page.dart`.
- لا يغيّر هذا الإصلاح منطق سياسة الحصة السابعة؛ فالتحقق يستمر عبر `_isCellAllowedBySeventhPeriodPolicy` التي تحسب الطلب الأسبوعي وتستدعي `SchoolTimetablePolicy.canUseSeventhPeriod`.
- تحديث رقم الإصدار إلى `1.8.9+23`.

## التحقق

تم التحقق نصياً من إزالة المتغير ومن تحديث رقم الإصدار واسم الحزمة. لم يتم تشغيل `flutter analyze` أو `flutter test` في بيئة إعداد الحزمة؛ يجب تأكيد نجاحهما عبر GitHub Actions.
