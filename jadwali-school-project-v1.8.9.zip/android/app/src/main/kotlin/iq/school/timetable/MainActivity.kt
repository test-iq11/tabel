package iq.school.timetable

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
