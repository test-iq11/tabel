أيقونة تطبيق «جدولي المدرسي»
- ملف المصدر: jadwali-school-icon.png
- نسخ أيقونة Android بأحجام مختلفة موجودة في android/app/src/main/res/mipmap-*.
- عند تغيير الأيقونة مستقبلاً، حدّث هذه الأحجام الخمسة مع إبقاء الاسم ic_launcher.png.
