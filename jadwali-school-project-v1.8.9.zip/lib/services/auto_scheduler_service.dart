import 'teacher_assignment_policy.dart';
import 'required_repeat_policy.dart';
import 'school_timetable_policy.dart';

/// محرك جدولة أسبوعية آلي يستخدم CSP مع اختيار المتطلب الأقل خيارات (MRV)
/// والتراجع المنظم. يراعي تأهيل المعلم للمادة وصلاحية المادة في صف الشعبة.
class SchedulerResult {
  const SchedulerResult({
    required this.placements,
    required this.unscheduled,
    required this.requestedCount,
    required this.exploredNodes,
    required this.searchLimitReached,
  });

  final List<Map<String, Object?>> placements;
  final List<String> unscheduled;
  final int requestedCount;
  final int exploredNodes;
  final bool searchLimitReached;
  bool get complete => placements.length == requestedCount && unscheduled.isEmpty;
}

class _RequirementGroup {
  _RequirementGroup({
    required this.section,
    required this.requirement,
    required this.teachers,
    required this.total,
    required this.requiredLatePeriodRepeat,
  }) : remaining = total;

  final Map<String, Object?> section;
  final Map<String, Object?> requirement;
  final List<Map<String, Object?>> teachers;
  final int total;
  /// True only for a necessary exception: weekly demand exceeds active days,
  /// the saved same-day-repeat switch is off, and a valid late-period slot exists.
  final bool requiredLatePeriodRepeat;
  int remaining;
  int lastGridRank = -1;

  int get sectionId => _integer(section['id'] ?? requirement['section_id']);
  int get subjectId => _integer(requirement['subject_id']);
  bool get allowSameDay => _integer(requirement['allow_same_day']) == 1;
  int get maxSubjectDaily => _integer(requirement['max_daily_lessons'], fallback: 2);
}

class _Candidate {
  const _Candidate({
    required this.group,
    required this.teacher,
    required this.day,
    required this.slot,
    required this.gridRank,
    required this.score,
  });

  final _RequirementGroup group;
  final Map<String, Object?> teacher;
  final Map<String, Object?> day;
  final Map<String, Object?> slot;
  final int gridRank;
  final int score;

  int get teacherId => _integer(teacher['id']);
  int get dayId => _integer(day['id']);
  int get slotId => _integer(slot['id']);
  int get teacherIdSort => teacherId;
}

class AutoSchedulerService {
  const AutoSchedulerService({this.nodeLimit = 120000});
  final int nodeLimit;

  SchedulerResult generate({
    required List<Map<String, Object?>> sections,
    required List<Map<String, Object?>> requirements,
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> qualifications,
    List<Map<String, Object?>> teacherGrades = const [],
    List<Map<String, Object?>> teacherSubjectGrades = const [],
    List<Map<String, Object?>> subjectBlockedSlots = const [],
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    List<Map<String, Object?>> teacherAvailability = const [],
  }) {
    final enabledDays = days
        .where((d) => _integer(d['is_active'], fallback: 1) == 1)
        .toList()
      ..sort((a, b) => _integer(a['position']).compareTo(_integer(b['position'])));
    final lessonSlots = slots
        .where((s) => s['kind'] == 'lesson' && _integer(s['is_available'], fallback: 1) == 1)
        .toList()
      ..sort((a, b) => _integer(a['position']).compareTo(_integer(b['position'])));

    final requestedCount = requirements.fold<int>(
      0,
      (sum, r) => sum + _integer(r['weekly_lessons']).clamp(0, 1000).toInt(),
    );
    final sectionById = {for (final s in sections) _integer(s['id']): s};
    final teacherById = {for (final t in teachers) _integer(t['id']): t};
    final qualifiedIds = <int, List<int>>{};
    for (final qualification in qualifications) {
      final subjectId = _integer(qualification['subject_id']);
      final teacherId = _integer(qualification['teacher_id']);
      if (teacherById.containsKey(teacherId)) {
        (qualifiedIds[subjectId] ??= <int>[]).add(teacherId);
      }
    }
    final assignmentPolicy = TeacherAssignmentPolicy(
      qualifications: qualifications,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
    );
    bool teacherCanTeachSubjectGrade(int teacherId, int subjectId, Map<String, Object?>? section) =>
        section != null && assignmentPolicy.isGradeAllowed(
          teacherId, subjectId, _integer(section['grade_id']),
        );
    List<int> eligibleTeacherIdsFor(int subjectId, Map<String, Object?>? section) =>
        (qualifiedIds[subjectId] ?? const <int>[]).where((id) => teacherCanTeachSubjectGrade(id, subjectId, section)).toList();
    final blockedSubjectSlotPairs = <String>{
      for (final item in subjectBlockedSlots)
        '${_integer(item['subject_id'])}:${_integer(item['slot_id'])}',
    };
    int weeklyDemandForSection(int sectionId) => requirements
        .where((row) => _integer(row['section_id']) == sectionId)
        .fold<int>(0, (sum, row) =>
            sum + _integer(row['weekly_lessons']).clamp(0, 1000).toInt());

    bool hasNecessaryLatePeriodRepeat(Map<String, Object?> requirement) {
      final section = sectionById[_integer(requirement['section_id'])];
      if (section == null) return false;
      return RequiredRepeatPolicy.allowsLatePeriodRepeat(
        requirement: requirement,
        section: section,
        activeDays: enabledDays,
        sectionWeeklyDemand: weeklyDemandForSection(_integer(requirement['section_id'])),
        lessonSlots: lessonSlots,
        subjectBlockedSlots: subjectBlockedSlots,
      );
    }

    // Preserve every requested lesson. If the subject is required more often
    // than there are active weekdays, allow the necessary extra occurrence
    // only when it can be put in period 6 (or an already-authorized period 7).
    int maxSchedulableForRequirement(Map<String, Object?> requirement) {
      if (enabledDays.isEmpty || lessonSlots.isEmpty) return 0;
      final subjectId = _integer(requirement['subject_id']);
      final allowSameDay = _integer(requirement['allow_same_day']) == 1;
      final configuredMax = _integer(requirement['max_daily_lessons'], fallback: 2);
      final necessaryRepeat = hasNecessaryLatePeriodRepeat(requirement);
      final subjectDailyLimit = allowSameDay
          ? (configuredMax > 0 ? configuredMax : 1)
          : (necessaryRepeat ? 2 : 1);
      final subjectAvailableSlots = lessonSlots.where((slot) =>
          !blockedSubjectSlotPairs.contains('$subjectId:${_integer(slot['id'])}')).length;
      final effectiveDailyLimit = subjectDailyLimit < subjectAvailableSlots
          ? subjectDailyLimit
          : subjectAvailableSlots;
      return enabledDays.length * effectiveDailyLimit;
    }
    final unavailable = <String>{
      for (final item in teacherAvailability)
        if (_integer(item['is_available'], fallback: 1) == 0)
          '${_integer(item['teacher_id'])}:${_integer(item['day_id'])}:${_integer(item['slot_id'])}',
    };
    // حد أدنى مضمون لنصاب المعلم: المتطلبات التي لا يوجد لها سوى معلم مؤهل واحد.
    final mandatoryDemandByTeacher = <int, int>{};
    for (final requirement in requirements) {
      final requested = _integer(requirement['weekly_lessons']).clamp(0, 1000).toInt();
      if (requested <= 0) continue;
      final count = requested < maxSchedulableForRequirement(requirement)
          ? requested
          : maxSchedulableForRequirement(requirement);
      if (count <= 0) continue;
      final section = sectionById[_integer(requirement['section_id'])];
      final eligible = eligibleTeacherIdsFor(_integer(requirement['subject_id']), section);
      if (eligible.length == 1) {
        mandatoryDemandByTeacher[eligible.single] = (mandatoryDemandByTeacher[eligible.single] ?? 0) + count;
      }
    }
    final mandatoryTeacherCapacityIssue = <int, String>{};
    for (final teacherEntry in mandatoryDemandByTeacher.entries) {
      final teacher = teacherById[teacherEntry.key];
      final weeklyLimit = teacher == null ? 0 : _integer(teacher['weekly_load'], fallback: 24);
      if (teacher != null && weeklyLimit > 0 && teacherEntry.value > weeklyLimit) {
        mandatoryTeacherCapacityIssue[teacherEntry.key] = 'المعلم ${teacher['name']} هو الوحيد المؤهل لمتطلبات مجموعها ${teacherEntry.value} حصة أسبوعياً، بينما النصاب المسجل له $weeklyLimit فقط. أضف معلماً مؤهلاً بديلاً لبعض الشعب أو صحّح النصاب إذا كان مسجلاً خطأً.';
      }
    }
    final dayRank = {for (var i = 0; i < enabledDays.length; i++) _integer(enabledDays[i]['id']): i};
    final slotRank = {for (var i = 0; i < lessonSlots.length; i++) _integer(lessonSlots[i]['id']): i};
    // Rotate the preferred period for each subject through the school week.
    // Using a stable subject order (instead of raw database IDs) keeps the
    // result consistent even if IDs are not consecutive.
    final orderedSubjectIds = requirements
        .map((row) => _integer(row['subject_id']))
        .toSet()
        .toList()
      ..sort();
    final subjectRotationOffset = <int, int>{
      for (var i = 0; i < orderedSubjectIds.length; i++) orderedSubjectIds[i]: i,
    };

    // تقدير سعة كل شعبة قبل البحث. يمنع استنزاف البحث عندما تكون الحصص المطلوبة
    // أكثر من الخانات المتاحة أصلاً، ويتيح توزيع بقية المواد بدلاً من التوقف بلا تفسير.
    final sectionCapacity = <int, int>{};
    final sectionDemand = <int, int>{};
    final sectionDailyLimitById = <int, int>{};
    final sectionAllowsSeventhById = <int, bool>{};
    final sectionCapacityMessage = <int, String>{};
    final requirementRowsBySection = <int, List<Map<String, Object?>>>{};
    for (final requirement in requirements) {
      final sectionId = _integer(requirement['section_id']);
      (requirementRowsBySection[sectionId] ??= <Map<String, Object?>>[]).add(requirement);
      sectionDemand[sectionId] = (sectionDemand[sectionId] ?? 0) +
          _integer(requirement['weekly_lessons']).clamp(0, 1000).toInt();
    }
    final slotsPerDay = lessonSlots.length;
    for (final section in sections) {
      final sectionId = _integer(section['id']);
      final configuredDailyLimit = _integer(section['max_daily_lessons'], fallback: 6);
      final configuredCapacity = configuredDailyLimit > 0
          ? (configuredDailyLimit < slotsPerDay ? configuredDailyLimit : slotsPerDay)
          : slotsPerDay;
      // Keep the normal daily limit at six. The seventh period contributes at
      // most one extra cell for sixth grade on Sunday, and only if required.
      final standardDailyLimit = configuredCapacity < 6 ? configuredCapacity : 6;
      final demand = sectionDemand[sectionId] ?? 0;
      final needsSeventh = SchoolTimetablePolicy.isSixthGrade(section) &&
          enabledDays.any(SchoolTimetablePolicy.isSunday) &&
          slotsPerDay >= 7 && configuredCapacity >= 7 &&
          configuredDailyLimit >= 7 &&
          demand > enabledDays.length * 6;
      final effectiveDailyLimit = standardDailyLimit;
      sectionAllowsSeventhById[sectionId] = needsSeventh;
      sectionDailyLimitById[sectionId] = effectiveDailyLimit;
      final capacity = enabledDays.length * effectiveDailyLimit + (needsSeventh ? 1 : 0);
      sectionCapacity[sectionId] = capacity;
      if (demand > capacity) {
        final stage = (section['stage_name'] ?? '').toString().trim();
        final grade = (section['grade_name'] ?? 'صف غير محدد').toString().trim();
        final sectionName = (section['section_name'] ?? section['name'] ?? 'غير محددة').toString().trim();
        final location = [if (stage.isNotEmpty) 'المرحلة $stage', 'الصف $grade', 'الشعبة $sectionName'].join('، ');
        final capacityExplanation = needsSeventh
            ? '${enabledDays.length} أيام × $effectiveDailyLimit حصص، مع حصة سابعة إضافية يوم الأحد للصف السادس فقط'
            : '${enabledDays.length} أيام × $effectiveDailyLimit حصص يومياً';
        sectionCapacityMessage[sectionId] = '$location: مجموع المطلوب $demand حصة أسبوعياً، لكن المتاح $capacity خانة فقط '
            '($capacityExplanation). زد عدد الفترات المتاحة أو خفّض المتطلبات حتى يصبح المجموع ضمن السعة.';
      }
    }

    // إذا تجاوزت متطلبات الشعبة سعتها، نخصّص الخانات أولاً للمواد ذات المعلمين
    // الأقل عدداً. تبقى الحصص التي لم تحصل على خانة ضمن تقرير غير الموزع.
    final targetCountByRequirement = <String, int>{};
    for (final sectionEntry in requirementRowsBySection.entries) {
      final sectionId = sectionEntry.key;
      final rows = sectionEntry.value;
      final capacity = sectionCapacity[sectionId] ?? 0;
      final demand = sectionDemand[sectionId] ?? 0;
      if (demand <= capacity) {
        for (final row in rows) {
          final key = '$sectionId:${_integer(row['subject_id'])}';
          final requested = _integer(row['weekly_lessons']).clamp(0, 1000).toInt();
          final ruleMaximum = maxSchedulableForRequirement(row);
          targetCountByRequirement[key] = requested < ruleMaximum ? requested : ruleMaximum;
        }
        continue;
      }
      for (final row in rows) {
        final key = '$sectionId:${_integer(row['subject_id'])}';
        targetCountByRequirement[key] = 0;
      }
      final section = sectionById[sectionId];
      final eligibleRows = rows.where((row) =>
          _integer(row['weekly_lessons']) > 0 &&
          maxSchedulableForRequirement(row) > 0 &&
          eligibleTeacherIdsFor(_integer(row['subject_id']), section).isNotEmpty).toList();
      eligibleRows.sort((a, b) {
        final aTeacherCount = eligibleTeacherIdsFor(_integer(a['subject_id']), section).length;
        final bTeacherCount = eligibleTeacherIdsFor(_integer(b['subject_id']), section).length;
        final scarcity = aTeacherCount.compareTo(bTeacherCount);
        if (scarcity != 0) return scarcity;
        final demandOrder = _integer(b['weekly_lessons']).compareTo(_integer(a['weekly_lessons']));
        if (demandOrder != 0) return demandOrder;
        return _integer(a['subject_id']).compareTo(_integer(b['subject_id']));
      });
      var budget = capacity;
      for (final row in eligibleRows) {
        final key = '$sectionId:${_integer(row['subject_id'])}';
        final requestedCountForSubject = _integer(row['weekly_lessons']).clamp(0, 1000).toInt();
        final ruleMaximum = maxSchedulableForRequirement(row);
        final requested = requestedCountForSubject < ruleMaximum ? requestedCountForSubject : ruleMaximum;
        final target = requested < budget ? requested : budget;
        targetCountByRequirement[key] = target;
        budget -= target;
      }
    }

    final groups = <_RequirementGroup>[];
    for (final requirement in requirements) {
      final requested = _integer(requirement['weekly_lessons']).clamp(0, 1000).toInt();
      if (requested <= 0) continue;
      final sectionId = _integer(requirement['section_id']);
      final section = sectionById[sectionId];
      if (section == null) continue;
      final target = targetCountByRequirement['$sectionId:${_integer(requirement['subject_id'])}'] ?? requested;
      if (target <= 0) continue;
      final candidates = eligibleTeacherIdsFor(_integer(requirement['subject_id']), section)
          .map((id) => teacherById[id])
          .whereType<Map<String, Object?>>()
          .toList();
      if (candidates.isEmpty) continue;
      groups.add(_RequirementGroup(
        section: section,
        requirement: requirement,
        teachers: candidates,
        total: target,
        requiredLatePeriodRepeat: target > enabledDays.length &&
            _integer(requirement['allow_same_day']) != 1 &&
            hasNecessaryLatePeriodRepeat(requirement),
      ));
    }

    // A subject with more than five weekly lessons must cover every active
    // day. If capacity allocation left fewer lessons than active days, leave
    // that requirement wholly unscheduled instead of emitting a knowingly
    // invalid partial spread.
    final schedulableGroups = groups.where((g) =>
      enabledDays.isNotEmpty && lessonSlots.isNotEmpty &&
      !(_integer(g.requirement['weekly_lessons']) > 5 && g.total < enabledDays.length)
    ).toList();
    final schedulableCount = schedulableGroups.fold<int>(0, (sum, g) => sum + g.total);

    final sectionCells = <String>{};
    final teacherCells = <String>{};
    final teacherWeekly = <int, int>{};
    final teacherDaily = <String, int>{};
    final sectionDaily = <String, int>{};
    final subjectDaily = <String, int>{};
    // Fairness counters: avoid assigning a subject to the same period on
    // adjacent school days, and spread each subject across periods over a week.
    final subjectPositionUsage = <String, int>{};
    final subjectPositionByDay = <String, int>{};
    final teacherDaySlotRanks = <String, List<int>>{};
    final placed = <Map<String, Object?>>[];
    var best = <Map<String, Object?>>[];
    var bestPartialScore = 1 << 62;
    var nodes = 0;
    var limitReached = false;
    var runningScore = 0;
    var bestCompleteScore = 1 << 62;
    var bestComplete = <Map<String, Object?>>[];

    String teacherDayKey(int teacherId, int dayId) => '$teacherId:$dayId';
    String sectionDayKey(int sectionId, int dayId) => '$sectionId:$dayId';
    String subjectDayKey(int sectionId, int subjectId, int dayId) => '$sectionId:$subjectId:$dayId';

    bool teacherConsecutiveAllowed(int teacherId, int dayId, int newSlotRank, int maxConsecutive) {
      if (maxConsecutive <= 0) return true;
      final values = [...(teacherDaySlotRanks[teacherDayKey(teacherId, dayId)] ?? const <int>[]), newSlotRank]..sort();
      var run = 1;
      var longest = 1;
      for (var i = 1; i < values.length; i++) {
        run = values[i] == values[i - 1] + 1 ? run + 1 : 1;
        if (run > longest) longest = run;
      }
      return longest <= maxConsecutive;
    }

    List<_Candidate> candidatesFor(_RequirementGroup group) {
      if (group.teachers.isEmpty || enabledDays.isEmpty || lessonSlots.isEmpty) return <_Candidate>[];
      final output = <_Candidate>[];
      for (final teacher in group.teachers) {
        final teacherId = _integer(teacher['id']);
        // دفاع إضافي عند توليد كل خيار: لا يكفي أن يكون المعلم مؤهلاً للمادة؛
        // يجب أن تسمح قاعدة (المعلم + المادة) بالصف المرتبط بهذه الشعبة تحديداً.
        // هذا الحارس يمنع أي مسار بحث من تجاوز قيد الصف/المادة.
        if (!(qualifiedIds[group.subjectId] ?? const <int>[]).contains(teacherId) ||
            !teacherCanTeachSubjectGrade(teacherId, group.subjectId, group.section)) {
          continue;
        }
        final weeklyLimit = _integer(teacher['weekly_load'], fallback: 24);
        if (weeklyLimit > 0 && (teacherWeekly[teacherId] ?? 0) >= weeklyLimit) continue;
        for (final day in enabledDays) {
          final dayId = _integer(day['id']);
          final dRank = dayRank[dayId] ?? 0;
          final tDayKey = teacherDayKey(teacherId, dayId);
          final sDayKey = sectionDayKey(group.sectionId, dayId);
          final subjectDayKeyValue = subjectDayKey(group.sectionId, group.subjectId, dayId);
          final currentTeacherDay = teacherDaily[tDayKey] ?? 0;
          final teacherDayLimit = _integer(teacher['max_daily_lessons'], fallback: 6);
          if (teacherDayLimit > 0 && currentTeacherDay >= teacherDayLimit) continue;
          final currentSectionDay = sectionDaily[sDayKey] ?? 0;
          final sectionLimit = sectionDailyLimitById[group.sectionId] ?? (slotsPerDay < 6 ? slotsPerDay : 6);
          final dayAllowsSeventh = (sectionAllowsSeventhById[group.sectionId] ?? false) &&
              SchoolTimetablePolicy.isSunday(day);
          final dailySectionLimit = dayAllowsSeventh ? 7 : sectionLimit;
          if (dailySectionLimit > 0 && currentSectionDay >= dailySectionLimit) continue;
          final currentSubjectDay = subjectDaily[subjectDayKeyValue] ?? 0;
          final requiresEveryDay = _integer(group.requirement['weekly_lessons']) > 5;
          final missingSubjectDays = requiresEveryDay
              ? enabledDays.where((candidateDay) =>
                  (subjectDaily[subjectDayKey(group.sectionId, group.subjectId, _integer(candidateDay['id']))] ?? 0) == 0).length
              : 0;
          // Do not repeat a subject on an already-covered day until each other
          // active day has one lesson, unless the remaining count makes that
          // impossible (in that case the branch itself is rejected).
          if (requiresEveryDay && currentSubjectDay > 0 &&
              group.remaining <= missingSubjectDays) {
            continue;
          }
          final subjectLimit = group.allowSameDay
              ? group.maxSubjectDaily
              : (group.requiredLatePeriodRepeat ? 2 : 1);
          if (currentSubjectDay >= (subjectLimit <= 0 ? 1 : subjectLimit)) continue;

          for (var sRank = 0; sRank < lessonSlots.length; sRank++) {
            // A necessary second lesson goes in period 6/7. Reserve early
            // periods for the normal daily occurrence; never silently place an
            // implicit duplicate in periods 1-5.
            if (group.requiredLatePeriodRepeat) {
              if (currentSubjectDay == 0 && sRank >= 5) continue;
              if (currentSubjectDay > 0 && sRank < 5) continue;
            }
            // Never use period seven merely because it exists in settings.
            // It is considered only for sections whose weekly demand mathematically
            // exceeds six periods per active school day.
            if (sRank >= 6 && !(dayAllowsSeventh && sRank == 6)) continue;
            if (sRank >= dailySectionLimit) continue;
            final slot = lessonSlots[sRank];
            final slotId = _integer(slot['id']);
            final gridRank = dRank * lessonSlots.length + sRank;
            // الحصص المتكررة للمادة نفسها تُرتّب زمنياً لمنع بحث مكرر في تبديل نسخ متطابقة.
            // The exceptional seventh period is on Sunday, so its grid rank
            // can be earlier than already-placed lessons later in the week.
            // Permit this single intentional back-step for a required repeat.
            final seventhOnSundayForRepeatedSubject = sRank == 6 && dayAllowsSeventh &&
                currentSubjectDay > 0 && group.requiredLatePeriodRepeat;
            if (gridRank <= group.lastGridRank && !seventhOnSundayForRepeatedSubject) continue;
            if (sectionCells.contains('${group.sectionId}:$dayId:$slotId')) continue;
            if (blockedSubjectSlotPairs.contains('${group.subjectId}:$slotId')) continue;
            if (teacherCells.contains('$teacherId:$dayId:$slotId')) continue;
            if (unavailable.contains('$teacherId:$dayId:$slotId')) continue;
            if (!teacherConsecutiveAllowed(teacherId, dayId, sRank, _integer(teacher['max_consecutive_lessons'], fallback: 0))) continue;

            // Soft fairness objective. The desired period rotates by one slot
            // each school day and each subject gets a stable starting offset.
            // This is a preference only: if constraints make it impossible, the
            // scheduler may reuse a period rather than leave a lesson unplaced.
            final sectionSubjectPrefix = '${group.sectionId}:${group.subjectId}';
            final periodCount = (sectionDailyLimitById[group.sectionId] ?? 6)
                .clamp(1, lessonSlots.length < 6 ? lessonSlots.length : 6)
                .toInt();
            final rotationOffset = subjectRotationOffset[group.subjectId] ?? 0;
            final preferredRank = (rotationOffset + dRank) % periodCount;
            final forwardDistance = (sRank - preferredRank + periodCount) % periodCount;
            final rotationDistance = forwardDistance < periodCount - forwardDistance
                ? forwardDistance
                : periodCount - forwardDistance;
            final slotUseKey = '$sectionSubjectPrefix:$sRank';
            final repeatedPeriodCount = subjectPositionUsage[slotUseKey] ?? 0;
            final previousDayUse = dRank > 0
                ? (subjectPositionByDay['$sectionSubjectPrefix:${dRank - 1}:$sRank'] ?? 0)
                : 0;
            final nextDayUse = dRank + 1 < enabledDays.length
                ? (subjectPositionByDay['$sectionSubjectPrefix:${dRank + 1}:$sRank'] ?? 0)
                : 0;

            // Balance normalized teacher load rather than raw counts: 4/6
            // hours is heavier than 4/24, so the optimizer should prefer the
            // teacher with more remaining capacity when both are eligible.
            final currentTeacherWeekly = teacherWeekly[teacherId] ?? 0;
            final normalizedWeeklyLimit = weeklyLimit > 0
                ? weeklyLimit
                : (enabledDays.length * lessonSlots.length).clamp(1, 10000).toInt();
            final normalizedTeacherDayLimit = teacherDayLimit > 0
                ? teacherDayLimit
                : (lessonSlots.length > 0 ? lessonSlots.length : 1);
            var score = (currentTeacherWeekly * 2400) ~/ normalizedWeeklyLimit;
            score += (currentTeacherDay * 360) ~/ normalizedTeacherDayLimit;
            // Spread each section's load across days. This replaces the old
            // chronological gridRank cost, which unintentionally biased the
            // optimizer toward earlier weekdays instead of balanced days.
            score += currentSectionDay * 80;
            score += currentSubjectDay * 1000;
            score += rotationDistance * 24;
            // Reusing the same period throughout the week is undesirable even
            // when days are not adjacent; consecutive-day repetition is much
            // worse and receives its own dominant penalty.
            score += repeatedPeriodCount * 1200;
            // Adjacent-day repetition is the user's most visible fairness issue
            // (for example, Arabic first period on Sunday and Monday). Treat it
            // as a dominant soft objective, without ever overriding hard rules.
            score += (previousDayUse + nextDayUse) * 100000;
            final positions = teacherDaySlotRanks[tDayKey] ?? const <int>[];
            if (positions.isNotEmpty) {
              final adjacent = positions.any((p) => (p - sRank).abs() == 1);
              score += adjacent ? -20 : 8;
            }
            output.add(_Candidate(group: group, teacher: teacher, day: day, slot: slot, gridRank: gridRank, score: score));
          }
        }
      }
      output.sort((a, b) {
        final score = a.score.compareTo(b.score);
        if (score != 0) return score;
        final rank = a.gridRank.compareTo(b.gridRank);
        if (rank != 0) return rank;
        return a.teacherIdSort.compareTo(b.teacherIdSort);
      });
      return output;
    }

    void apply(_Candidate c) {
      final g = c.group;
      final t = c.teacherId;
      final d = c.dayId;
      final s = c.slotId;
      final sRank = slotRank[s] ?? 0;
      sectionCells.add('${g.sectionId}:$d:$s');
      teacherCells.add('$t:$d:$s');
      teacherWeekly[t] = (teacherWeekly[t] ?? 0) + 1;
      teacherDaily[teacherDayKey(t, d)] = (teacherDaily[teacherDayKey(t, d)] ?? 0) + 1;
      sectionDaily[sectionDayKey(g.sectionId, d)] = (sectionDaily[sectionDayKey(g.sectionId, d)] ?? 0) + 1;
      subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] = (subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] ?? 0) + 1;
      final subjectPrefix = '${g.sectionId}:${g.subjectId}';
      final positionKey = '$subjectPrefix:$sRank';
      final dayPositionKey = '$subjectPrefix:${dayRank[d] ?? 0}:$sRank';
      subjectPositionUsage[positionKey] = (subjectPositionUsage[positionKey] ?? 0) + 1;
      subjectPositionByDay[dayPositionKey] = (subjectPositionByDay[dayPositionKey] ?? 0) + 1;
      (teacherDaySlotRanks[teacherDayKey(t, d)] ??= <int>[]).add(sRank);
      g.remaining--;
      g.lastGridRank = c.gridRank;
      runningScore += c.score;
      placed.add({
        'section_id': g.sectionId,
        'subject_id': g.subjectId,
        'teacher_id': t,
        'day_id': d,
        'slot_id': s,
        'room_id': null,
      });
    }

    void undo(_Candidate c, int oldLastGridRank) {
      final g = c.group;
      final t = c.teacherId;
      final d = c.dayId;
      final s = c.slotId;
      final sRank = slotRank[s] ?? 0;
      sectionCells.remove('${g.sectionId}:$d:$s');
      teacherCells.remove('$t:$d:$s');
      teacherWeekly[t] = (teacherWeekly[t] ?? 1) - 1;
      teacherDaily[teacherDayKey(t, d)] = (teacherDaily[teacherDayKey(t, d)] ?? 1) - 1;
      sectionDaily[sectionDayKey(g.sectionId, d)] = (sectionDaily[sectionDayKey(g.sectionId, d)] ?? 1) - 1;
      subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] = (subjectDaily[subjectDayKey(g.sectionId, g.subjectId, d)] ?? 1) - 1;
      final subjectPrefix = '${g.sectionId}:${g.subjectId}';
      final positionKey = '$subjectPrefix:$sRank';
      final dayPositionKey = '$subjectPrefix:${dayRank[d] ?? 0}:$sRank';
      final remainingPositionUse = (subjectPositionUsage[positionKey] ?? 1) - 1;
      if (remainingPositionUse <= 0) {
        subjectPositionUsage.remove(positionKey);
      } else {
        subjectPositionUsage[positionKey] = remainingPositionUse;
      }
      final remainingDayUse = (subjectPositionByDay[dayPositionKey] ?? 1) - 1;
      if (remainingDayUse <= 0) {
        subjectPositionByDay.remove(dayPositionKey);
      } else {
        subjectPositionByDay[dayPositionKey] = remainingDayUse;
      }
      teacherDaySlotRanks[teacherDayKey(t, d)]?.remove(sRank);
      g.remaining++;
      g.lastGridRank = oldLastGridRank;
      // Candidate scores are accumulated during apply; remove this placement's
      // contribution before exploring a sibling branch.
      // The matching score is stored on the last placement's candidate stack.
      runningScore -= _integer(c.score);
      placed.removeLast();
    }

    void search() {
      if (limitReached) return;
      nodes++;
      // If a fully feasible timetable is impossible, keep the best partial
      // arrangement by both lesson count and fairness score. This avoids
      // returning an arbitrary, unnecessarily repetitive partial result.
      if (placed.length > best.length ||
          (placed.length == best.length && runningScore < bestPartialScore)) {
        best = placed.map((e) => Map<String, Object?>.from(e)).toList();
        bestPartialScore = runningScore;
      }
      if (placed.length == schedulableCount && schedulableGroups.every((g) => g.remaining == 0)) {
        // Do not stop at the first valid timetable. Keep searching within the
        // node budget and retain the lowest-cost complete arrangement so soft
        // fairness preferences are optimized globally, not only greedily.
        if (runningScore < bestCompleteScore) {
          bestCompleteScore = runningScore;
          bestComplete = placed.map((e) => Map<String, Object?>.from(e)).toList();
        }
        return;
      }
      // Branch-and-bound: candidate cost components are non-negative except
      // the small -20 preference for adjacent teacher lessons. Therefore no
      // remaining lesson can lower the total by more than 20 points. Pruning
      // branches that cannot beat the best complete timetable preserves hard
      // constraints while spending the node budget on genuinely better options.
      if (bestComplete.isNotEmpty) {
        final remainingPlacements = schedulableCount - placed.length;
        final optimisticLowerBound = runningScore - (remainingPlacements * 20);
        if (optimisticLowerBound >= bestCompleteScore) return;
      }
      if (nodes >= nodeLimit) {
        limitReached = true;
        return;
      }

      _RequirementGroup? selected;
      List<_Candidate> selectedCandidates = <_Candidate>[];
      var smallestRatio = double.infinity;
      for (final group in schedulableGroups) {
        if (group.remaining <= 0) continue;
        final options = candidatesFor(group);
        if (options.isEmpty) return; // قيد مسدود في هذه الحالة؛ ارجع للفرع السابق.
        // الأولوية للمادة التي لديها خيارات قليلة مقارنة بعدد حصصها المتبقية؛
        // هذا يقلل حالات استهلاك الفترات المتاحة للمواد الأكثر مرونة.
        final ratio = options.length / group.remaining;
        if (ratio < smallestRatio) {
          selected = group;
          selectedCandidates = options;
          smallestRatio = ratio;
          if (options.length == 1) break;
        }
      }
      if (selected == null) return;
      for (final candidate in selectedCandidates) {
        final oldLast = selected.lastGridRank;
        apply(candidate);
        search();
        undo(candidate, oldLast);
        if (limitReached) return;
      }
    }

    search();
    if (bestComplete.isNotEmpty) best = bestComplete;

    // A partial search result must not retain a >5-lesson subject that missed
    // any active day. Remove that subject's placements as a unit; the final
    // report will explain why its complete distribution could not be satisfied.
    final invalidDailySpreadKeys = <String>{};
    for (final requirement in requirements) {
      if (_integer(requirement['weekly_lessons']) <= 5) continue;
      final sectionId = _integer(requirement['section_id']);
      final subjectId = _integer(requirement['subject_id']);
      final hasEveryDay = enabledDays.every((day) => best.any((placement) =>
        _integer(placement['section_id']) == sectionId &&
        _integer(placement['subject_id']) == subjectId &&
        _integer(placement['day_id']) == _integer(day['id'])));
      if (!hasEveryDay) invalidDailySpreadKeys.add('$sectionId:$subjectId');
    }
    if (invalidDailySpreadKeys.isNotEmpty) {
      best = best.where((placement) => !invalidDailySpreadKeys.contains(
        '${_integer(placement['section_id'])}:${_integer(placement['subject_id'])}')).toList();
    }

    // تحقق نهائي قبل إعادة النتيجة (والحفظ في قاعدة البيانات): أي موضع لا يطابق
    // تأهيل المعلم للمادة وصلاحية المادة في صف الشعبة يُستبعد احتياطياً.
    // هذا دفاع مستقل عن مرشحي البحث، حتى لا تُحفظ حصة مخالفة عند حدوث انحدار لاحق.
    best = best.where((placement) {
      final teacherId = _integer(placement['teacher_id']);
      final subjectId = _integer(placement['subject_id']);
      final section = sectionById[_integer(placement['section_id'])];
      return section != null &&
          assignmentPolicy.isSubjectQualified(teacherId, subjectId) &&
          teacherCanTeachSubjectGrade(teacherId, subjectId, section);
    }).toList();

    final placedCounts = <String, int>{};
    for (final placement in best) {
      final key = '${placement['section_id']}:${placement['subject_id']}';
      placedCounts[key] = (placedCounts[key] ?? 0) + 1;
    }
    final unscheduled = <String>[];
    for (final requirement in requirements) {
      final sectionId = _integer(requirement['section_id']);
      final subjectId = _integer(requirement['subject_id']);
      final required = _integer(requirement['weekly_lessons']).clamp(0, 1000).toInt();
      if (required <= 0) continue;
      final completed = placedCounts['$sectionId:$subjectId'] ?? 0;
      if (completed >= required) continue;
      final section = sectionById[sectionId];
      final stage = (section?['stage_name'] ?? requirement['stage_name'] ?? '').toString().trim();
      final grade = (section?['grade_name'] ?? requirement['grade_name'] ?? '').toString().trim();
      final sectionName = (section?['section_name'] ?? requirement['section_name'] ?? 'الشعبة $sectionId').toString().trim();
      final location = [if (stage.isNotEmpty) 'المرحلة $stage', if (grade.isNotEmpty) 'الصف $grade', 'الشعبة $sectionName'].join('، ');
      final subjectName = (requirement['subject_name'] ?? 'المادة $subjectId').toString();
      final possibleTeachers = qualifiedIds[subjectId] ?? const <int>[];
      final sectionTeachers = eligibleTeacherIdsFor(subjectId, section);
      final blockedForSubject = lessonSlots.where((slot) =>
          blockedSubjectSlotPairs.contains('$subjectId:${_integer(slot['id'])}')).length;
      final capacityMessage = sectionCapacityMessage[sectionId];
      final teacherCapacityMessage = sectionTeachers.length == 1
          ? mandatoryTeacherCapacityIssue[sectionTeachers.single]
          : null;
      final reason = section == null
          ? 'الشعبة غير موجودة؛ راجع ربط المتطلب بالصف والشعبة.'
          : invalidDailySpreadKeys.contains('$sectionId:$subjectId')
              ? 'لأن المادة مطلوبة أكثر من 5 حصص أسبوعياً، يشترط المحرك وضع حصة واحدة منها على الأقل في كل يوم دوام. لم يعتمد التوزيع الجزئي لهذه المادة لأن القيود الحالية لم تسمح بتغطية جميع الأيام؛ راجع توفر المعلم والفترات الممنوعة وعدد الفترات المتاحة.'
          : possibleTeachers.isEmpty
              ? 'لا يوجد معلم مسجل ضمن اختصاص مادة $subjectName. افتح «البيانات > المعلمون»، وعدّل معلماً وحدد المادة ضمن مواده المؤهل لتدريسها.'
              : sectionTeachers.isEmpty
                  ? 'يوجد معلمون لمادة $subjectName، لكن لا يوجد معلم مسموح له بتدريسها في ${location} ضمن إعدادات الصفوف الحالية. افتح «البيانات > المعلمون» وحدد هذا الصف ضمن صفوف المعلم، أو اختر «جميع الصفوف».'
                  : blockedForSubject >= lessonSlots.length && lessonSlots.isNotEmpty
                      ? 'المادة $subjectName ممنوعة من جميع فترات التدريس المتاحة. افتح «البيانات > المواد» وعدّل الفترات الممنوعة لهذه المادة.'
              : enabledDays.isEmpty
                  ? 'لا توجد أيام دوام مفعّلة؛ فعّل أيام المدرسة من إعدادات الدوام.'
                  : lessonSlots.isEmpty
                      ? 'لا توجد فترات متاحة من نوع «حصة دراسية»؛ أضف الفترات أو فعّلها في إعدادات الدوام.'
                      : required > maxSchedulableForRequirement(requirement)
                          ? 'إعداد هذه المادة يسمح بحد أقصى ${maxSchedulableForRequirement(requirement)} حصة أسبوعياً ضمن عدد أيام الدوام والفترات المسموحة، بينما المتطلب المسجل $required. لتمكين الحصة المتبقية عند تجاوز المطلوب عدد أيام الدوام، فعّل الفترة السادسة للشعبة (أو السابعة إذا كانت مسموحة)، واجعل الفترة غير ممنوعة للمادة ومتاحة لمعلمها؛ لم تتغير بياناتك تلقائياً.'
                      : [if (capacityMessage != null) capacityMessage,
                         if (teacherCapacityMessage != null) teacherCapacityMessage,
                         if (blockedForSubject > 0 && blockedForSubject < lessonSlots.length) 'هذه المادة ممنوعة في $blockedForSubject من أصل ${lessonSlots.length} فترات؛ تم استبعادها من تلك الفترات تلقائياً.',
                         if (capacityMessage == null && teacherCapacityMessage == null)
                           (limitReached
                             ? 'توقف البحث بعد فحص $nodes حالة دون العثور على حل كامل ضمن القيود. جرّب زيادة الفترات أو تخفيف القيود اليومية/النصاب.'
                             : 'لم تتوفر خانة ومعلم يحققان القيود الحالية. راجع النصاب الأسبوعي واليومي، أوقات عدم إتاحة المعلم، وحد الحصص المتتالية.')].join(' ');
      unscheduled.add('$location، مادة $subjectName: المطلوب $required حصة أسبوعياً، الموزع $completed، المتبقي ${required - completed}. $reason');
    }
    return SchedulerResult(
      placements: best,
      unscheduled: unscheduled,
      requestedCount: requestedCount,
      exploredNodes: nodes,
      searchLimitReached: limitReached,
    );
  }
}

int _integer(Object? value, {int fallback = 0}) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse('$value') ?? fallback;
}
