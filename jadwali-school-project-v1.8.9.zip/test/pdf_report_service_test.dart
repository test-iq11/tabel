import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/pdf_report_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('PDF export handles punctuation missing from the bundled Arabic font and stays one page', () async {
    final bytes = await PdfReportService().buildTimetablePdf(
      schoolName: 'مدرسة - الأمل (فرع 1)',
      academicYear: '2026-2027',
      versionName: 'الجدول | الأول',
      status: 'قيد التعديل',
      sections: <Map<String, Object?>>[
        {'id': 1, 'grade_name': 'الأول الابتدائي', 'section_name': 'أ'},
        {'id': 2, 'grade_name': 'السادس الابتدائي', 'section_name': 'ب'},
      ],
      days: <Map<String, Object?>>[
        {'id': 1, 'name': 'الأحد', 'position': 1, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 2, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 3, 'is_active': 1},
        {'id': 4, 'name': 'الأربعاء', 'position': 4, 'is_active': 1},
        {'id': 5, 'name': 'الخميس', 'position': 5, 'is_active': 1},
      ],
      slots: <Map<String, Object?>>[
        {'id': 1, 'name': 'الحصة الأولى', 'start_time': '08:00', 'end_time': '08:45', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
      entries: <Map<String, Object?>>[
        {'section_id': 1, 'day_id': 1, 'slot_id': 1, 'grade_name': 'الأول الابتدائي', 'section_name': 'أ', 'subject_name': 'الرياضيات - (مراجعة)', 'teacher_name': 'أحمد / علي'},
      ],
    );
    expect(bytes.length, greaterThan(100));
    final pdfText = latin1.decode(bytes);
    expect(RegExp(r'/Type\s*/Page\b').allMatches(pdfText).length, 1);
  });

  test('teacher PDF contains an individual timetable with subject and section', () async {
    final bytes = await PdfReportService().buildTeacherTimetablePdf(
      schoolName: 'مدرسة الاختبار',
      academicYear: '2026-2027',
      versionName: 'نسخة اختبار',
      status: 'مسودة',
      teacher: {'id': 7, 'name': 'طالب'},
      targetLoad: 4,
      entries: <Map<String, Object?>>[
        {'teacher_id': 7, 'day_id': 1, 'slot_id': 1, 'grade_name': 'الأول الابتدائي', 'section_name': 'أ', 'subject_name': 'اللغة العربية'},
      ],
      days: <Map<String, Object?>>[
        {'id': 1, 'name': 'الأحد', 'position': 1, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 2, 'is_active': 1},
      ],
      slots: <Map<String, Object?>>[
        {'id': 1, 'name': 'الحصة الأولى', 'start_time': '08:00', 'end_time': '08:45', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(bytes.length, greaterThan(100));
    expect(latin1.decode(bytes), contains('%PDF'));
  });

}
