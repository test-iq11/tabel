from pathlib import Path
import json,zipfile,re
ROOT=Path(__file__).resolve().parents[1]
read=lambda name:(ROOT/name).read_text(encoding='utf8')
checks={
 'Flutter original main and database preserved': (ROOT/'lib/app/app.dart').exists() and (ROOT/'lib/data/database_service.dart').exists(),
 'settings instead of mobile drawer': 'top-settings' in read('lib/app/app.dart') and "drawer:" not in read('lib/app/app.dart'),
 'five navigation tabs in correct order': "['الرئيسية', 'إعداد الجدول', 'الجدول', 'الإصلاح', 'التقارير']" in read('lib/app/app.dart'),
 'start with hero and no short dashboard': 'html-dashboard-hero' in read('lib/core/html_dashboard_hero.dart') and 'جدول مختصر' not in read('lib/features/dashboard/dashboard_page.dart'),
 'live classroom data action card': 'live-schedule-decisions' in read('lib/features/dashboard/dashboard_page.dart'),
 'A4 UI only': "_paper = 'A4'" in read('lib/features/reports/reports_page.dart') and "['A3', 'A4']" not in read('lib/features/reports/reports_page.dart'),
 'A4 docx and excel portrait support': 'w:orient="${orientation' in read('lib/services/reference_office_service.dart') and 'orientation="${orientation' in read('lib/services/reference_office_service.dart'),
 'teacher workload colors retained': 'WorkloadReportPalette.colors' in read('lib/features/reports/reports_page.dart'),
 'atomic swap database validation retained': 'final reason = const LessonSwapService().validate(data, first, second)' in read('lib/data/database_service.dart'),
 'same-section safe swap alternatives': 'safeAlternatives' in read('lib/services/lesson_swap_service.dart') and 'safe-swap-alternatives' in read('lib/features/timetable/timetable_page.dart'),
 'report lesson swap preserved': '_tapReportLesson' in read('lib/features/reports/reports_page.dart') and 'safeAlternatives' in read('lib/features/reports/reports_page.dart'),
 'search partitions budget and exact fallback': 'heuristicBudget' in read('lib/services/unified_schedule_service.dart') and 'CompleteScheduleSolver().solve' in read('lib/services/unified_schedule_service.dart'),
 'math proof of section domain': 'SectionTimeDomainFlow().inspect' in read('lib/services/unified_schedule_service.dart'),
 'grade 6 special Sunday slot': 'SchoolTimetablePolicy' in read('lib/services/complete_schedule_solver.dart'),
 'standalone regression tests': (ROOT/'test/v1310_user_requirements_test.dart').exists(),
 'eager settings cards accessible for widget tests': 'SingleChildScrollView' in read('lib/features/settings/app_settings_page.dart') and 'settings-scroll' in read('lib/features/settings/app_settings_page.dart') and 'tester.ensureVisible(item)' in read('test/app_navigation_test.dart'),
 'dark mode settings and tools text': 'settings-dark' in read('lib/features/settings/app_settings_page.dart') and 'Colors.black54' not in read('lib/features/tools/tools_page.dart'),
}
assert len(checks)>=15
for name,passed in checks.items():
 print(('PASS' if passed else 'FAIL')+': '+name)
assert all(checks.values()),[k for k,v in checks.items() if not v]
fixture=json.loads((ROOT/'test/fixtures/backup_school_181.json').read_text())
assert len(fixture['initialPlacements'])==181
print('PASS: 181-lesson school fixture retained')
