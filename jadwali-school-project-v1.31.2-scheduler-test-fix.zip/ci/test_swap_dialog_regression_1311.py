#!/usr/bin/env python3
"""Static guard for regression in report/timetable swap rejection dialogs.

These checks complement Flutter widget and database tests; they cannot replace them.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class SwapDialogRegression(unittest.TestCase):
    def test_report_rejection_keeps_existing_widget_contract(self):
        src = (ROOT / 'lib/features/reports/reports_page.dart').read_text(encoding='utf-8')
        self.assertIn("title: const Text('هذا التبديل غير متاح')", src)
        self.assertIn("child: const Text('اختيار حصة أخرى')", src)
        self.assertIn('safeAlternatives(data, _swapFirst!)', src)
        self.assertIn('if (suggested != null && mounted)', src)
        self.assertIn('await _tapReportLesson(suggested, data)', src)
        self.assertIn('await DatabaseService.instance.swapLessons(', src)
        self.assertIn('await DatabaseService.instance.undoLastManualEdit()', src)
        # Closing the rejection dialog must not clear the selected first lesson.
        rejection = src[src.index('final alternatives = const LessonSwapService()'):src.index('if (suggested != null && mounted)')]
        self.assertNotIn('_swapFirst = null', rejection)

    def test_timetable_rejection_keeps_existing_widget_contract(self):
        src = (ROOT / 'lib/features/timetable/timetable_page.dart').read_text(encoding='utf-8')
        self.assertIn("title: const Text('هذا التبديل غير متاح')", src)
        self.assertIn("child: const Text('اختيار حصة أخرى')", src)
        self.assertIn('safeAlternatives(data, first)', src)
        self.assertIn('if (suggested != null && mounted)', src)
        self.assertIn('await _tapLesson(suggested, data)', src)
        self.assertIn('await DatabaseService.instance.swapLessons(', src)
        self.assertNotIn('_swapFirst = null', src[src.index('final alternatives = const LessonSwapService()'):src.index('if (suggested != null && mounted)')])

    def test_original_ui_widget_tests_still_present(self):
        for path in ['test/report_and_weekly_swap_test.dart', 'test/touch_swap_widget_test.dart']:
            test = (ROOT / path).read_text(encoding='utf-8')
            self.assertIn("find.text('هذا التبديل غير متاح')", test)
            self.assertIn("find.text('اختيار حصة أخرى')", test)

if __name__ == '__main__':
    unittest.main()
