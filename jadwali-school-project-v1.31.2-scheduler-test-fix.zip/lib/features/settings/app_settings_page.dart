import 'package:flutter/material.dart';

import '../../core/interface_settings.dart';
import '../../core/jadwali_visuals.dart';
import 'design_studio.dart';

class AppSettingsPage extends StatelessWidget {
  const AppSettingsPage({super.key, required this.onHelp, required this.onNavigate});
  final VoidCallback onHelp;
  final ValueChanged<int> onNavigate;

  Widget _panel(BuildContext context, {required String title,
    required String subtitle, required List<Widget> children}) {
    final c = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(23),
      decoration: JadwaliVisuals.panel(context, radius: 27),
      // Paint the panel background behind a local Material so ListTile and
      // SwitchListTile ink effects are visible and Flutter's debug assertion
      // is not triggered. The decoration, radius, layout and colors stay intact.
      child: Material(
        type: MaterialType.transparency,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(subtitle, style: TextStyle(fontSize: 12, color: c.onSurfaceVariant)),
          const SizedBox(height: 16),
          ...children,
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: InterfaceSettings.instance,
    builder: (context, _) {
      final ui = InterfaceSettings.instance;
      final c = Theme.of(context).colorScheme;
      return SingleChildScrollView(
        key: const ValueKey('settings-scroll'),
        padding: const EdgeInsets.fromLTRB(14, 21, 14, 30),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('تخصيص كامل', style: TextStyle(fontWeight: FontWeight.w800,
          color: c.primary, fontSize: 11)),
        const Text('اجعل جدولي على ذوقك',
          style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
        const SizedBox(height: 3),
        Text('الألوان، المسافات، الخط، الحركات والوضع الليلي؛ مع حفظ اختياراتك تلقائيًا.',
          style: TextStyle(fontSize: 12, color: c.onSurfaceVariant)),
        const SizedBox(height: 13),
        Wrap(spacing: 8, runSpacing: 8, children: [
          OutlinedButton.icon(
            key: const ValueKey('settings-reset-preview'),
            onPressed: () {
              ui.applyPalette('indigo');
              ui.dark = false;
              ui.compact = false;
              ui.fontScale = 1.0;
              ui.design = ui.design.change('density', 100.0).change('motion', true);
              ui.save();
            },
            icon: const Icon(Icons.restart_alt_outlined, size: 18),
            label: const Text('الإعدادات الافتراضية'),
          ),
          TextButton.icon(
            onPressed: () => showDialog<void>(
              context: context,
              builder: (ctx) => AlertDialog(
                icon: const Icon(Icons.auto_awesome_outlined, size: 33),
                title: const Text('انتقال ناعم'),
                content: const Text('هذه معاينة للحركات المستخدمة في فتح نوافذ التطبيق.'),
                actions: [TextButton(onPressed: () => Navigator.pop(ctx),
                  child: const Text('إغلاق'))],
              ),
            ),
            icon: const Icon(Icons.play_circle_outline, size: 18),
            label: const Text('جرب حركة المعاينة'),
          ),
        ]),
        const SizedBox(height: 20),
        LayoutBuilder(builder: (context, bounds) {
          final sections = <Widget>[
            _panel(context, title: 'لوحات الألوان',
              subtitle: '18 لوحة لونية من النموذج التفاعلي، مع الحفاظ على ألوان المواد والتقارير.',
              children: [
                const JadwaliPaletteSelector(),
                const SizedBox(height: 12),
                AnimatedContainer(
                  key: const ValueKey('active-palette-preview'),
                  duration: JadwaliVisuals.motion(context)
                      ? const Duration(milliseconds: 230) : Duration.zero,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                      c.primary.withValues(alpha: .13),
                      c.primary.withValues(alpha: .035),
                    ]),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: c.primary.withValues(alpha: .22)),
                  ),
                  child: Row(children: [
                    Icon(Icons.palette_outlined, color: c.primary),
                    const SizedBox(width: 10),
                    Expanded(child: Text('اللوحة الحالية: ${JadwaliVisuals.palettes[ui.palette]?.$1 ?? 'نيلي هادئ'}',
                      style: TextStyle(color: c.onSurface, fontWeight: FontWeight.w800))),
                  ]),
                ),
                const SizedBox(height: 10),
                Text('تتغير هوية التطبيق فقط؛ ألوان التقارير اليومية لا تختلط بألوان المواد. اللون الحالي: ${JadwaliVisuals.palettes[ui.palette]?.$1 ?? 'نيلي'}',
                  style: TextStyle(color: c.onSurfaceVariant, fontSize: 11)),
              ]),
            _panel(context, title: 'الخط والمسافات',
              subtitle: 'تحكم بالحجم وكثافة البطاقات على الهاتف أو الكمبيوتر.',
              children: [
                Text('حجم الخط · ${(ui.fontScale * 100).round()}٪',
                  style: Theme.of(context).textTheme.titleMedium),
                const Text('يضاف إلى حجم الخط المحدد في جهازك.'),
                Slider(key: const ValueKey('settings-font-slider'),
                  value: ui.fontScale, min: .85, max: 1.3, divisions: 9,
                  label: '${(ui.fontScale * 100).round()}٪',
                  onChanged: (v) { ui.fontScale = v; ui.save(); }),
                const Text('معاينة: حصص مدرستي واضحة ومنظمة'),
                Align(alignment: AlignmentDirectional.centerEnd,
                  child: TextButton(onPressed: () { ui.fontScale = 1; ui.save(); },
                    child: const Text('الحجم الافتراضي'))),
                const Divider(),
                const SizedBox(height: 8),
                const Text('كثافة بطاقات الجدول', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                SegmentedButton<bool>(
                  key: const ValueKey('settings-density'),
                  segments: const [
                    ButtonSegment(value: false, label: Text('مريح'), icon: Icon(Icons.view_agenda_outlined)),
                    ButtonSegment(value: true, label: Text('مدمج'), icon: Icon(Icons.view_compact_outlined)),
                  ],
                  selected: {ui.compact},
                  onSelectionChanged: (selection) {
                    ui.compact = selection.first;
                    ui.design = ui.design.change('density', ui.compact ? 88.0 : 100.0);
                    ui.save();
                  },
                ),
              ]),
            _panel(context, title: 'المظهر والإضاءة',
              subtitle: 'وضع ليلي ناعم وواجهة واضحة عند القراءة.',
              children: [
                SwitchListTile.adaptive(
                  key: const ValueKey('settings-dark'),
                  secondary: const Icon(Icons.dark_mode_outlined),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('الوضع الليلي'),
                  subtitle: const Text('يستمر بعد إغلاق التطبيق'),
                  value: ui.dark,
                  onChanged: (v) { ui.dark = v; ui.save(); },
                ),
                const Divider(),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  secondary: const Icon(Icons.motion_photos_off_outlined),
                  title: const Text('حركات الانتقال والبطاقات'),
                  subtitle: const Text('حركات قصيرة ويمكن إيقافها لتقليل التشتيت'),
                  value: ui.design.motion,
                  onChanged: ui.setMotion,
                ),
              ]),
            _panel(context, title: 'أدوات المدرسة',
              subtitle: 'كل وظائف القائمة الجانبية السابقة متاحة هنا كبطاقات، دون شغل مساحة الهاتف.',
              children: [
                LayoutBuilder(builder: (context, constraints) {
                  const links = <(int, String, IconData)>[
                    (1, 'الجدول', Icons.calendar_month_outlined),
                    (2, 'المعلمون', Icons.people_outline),
                    (3, 'الحصص المطلوبة', Icons.fact_check_outlined),
                    (4, 'المواد والقيود', Icons.menu_book_outlined),
                    (5, 'إتاحة المعلمين', Icons.event_available_outlined),
                    (6, 'التعارضات', Icons.rule_outlined),
                    (7, 'التوزيع والحلول', Icons.auto_fix_high_outlined),
                    (8, 'الغياب والبدلاء', Icons.person_off_outlined),
                    (10, 'التقارير', Icons.print_outlined),
                    (11, 'النسخ الاحتياطية', Icons.backup_outlined),
                    (12, 'إعدادات المدرسة', Icons.school_outlined),
                    (13, 'إعداد الجدول', Icons.tune_outlined),
                    (16, 'مختبر ماذا لو؟', Icons.auto_awesome_outlined),
                    (17, 'الصفوف والشعب', Icons.account_tree_outlined),
                    (18, 'الحصص اليومية', Icons.view_week_outlined),
                  ];
                  final width = constraints.maxWidth;
                  final count = width >= 480 ? 3 : 2;
                  return Wrap(spacing: 8, runSpacing: 8, children: [
                    for (final link in links)
                      SizedBox(width: (width - (count - 1) * 8) / count,
                        child: Material(color: c.surfaceContainerLow,
                          borderRadius: BorderRadius.circular(13),
                          child: InkWell(
                            key: ValueKey('settings-destination-${link.$1}'),
                            borderRadius: BorderRadius.circular(13),
                            onTap: () => onNavigate(link.$1),
                            child: Padding(padding: const EdgeInsets.symmetric(
                              horizontal: 7, vertical: 14),
                              child: Column(mainAxisSize: MainAxisSize.min, children: [
                                Icon(link.$3, color: c.primary, size: 23),
                                const SizedBox(height: 6),
                                Text(link.$2, maxLines: 2, textAlign: TextAlign.center,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 11, color: c.onSurface,
                                    fontWeight: FontWeight.w700)),
                              ]),
                            ),
                          ),
                        ),
                      ),
                  ]);
                }),
              ]),
            _panel(context, title: 'أدوات التخصيص المتقدمة',
              subtitle: 'خيارات التصميم السابقة باقية وتعمل مع الخيارات الحديثة.',
              children: [
                ListTile(
                  key: const ValueKey('open-design-settings'),
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.palette_outlined),
                  title: const Text('استوديو المظهر'),
                  subtitle: const Text('الزخارف، التدرجات، واستيراد تصميمك'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => showDesignStudio(context),
                ),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  secondary: const Icon(Icons.desktop_windows_outlined),
                  title: const Text('القائمة الجانبية على الكمبيوتر'),
                  value: ui.desktopRail,
                  onChanged: (v) { ui.desktopRail = v; ui.save(); },
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.dashboard_customize_outlined),
                  title: const Text('تخصيص الرئيسية'),
                  subtitle: const Text('اختيار أربع بطاقات وترتيبها'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => customizeHome(context),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.help_outline),
                  title: const Text('دليل الاستخدام'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: onHelp,
                ),
              ]),
          ];
          if (bounds.maxWidth < 760) return Column(children: [
            for (final section in sections) ...[
              section, const SizedBox(height: 15),
            ],
          ]);
          return Wrap(spacing: 16, runSpacing: 16, children: [
            for (final section in sections)
              SizedBox(width: (bounds.maxWidth - 16) / 2, child: section),
          ]);
        }),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(
          color: c.primary.withValues(alpha: .05),
          borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            Icon(Icons.info_outline, size: 20, color: c.primary),
            const SizedBox(width: 9),
            Expanded(child: Text('تتغير هوية التطبيق فقط، وتُحفظ التفضيلات. بيانات المدرسة والقيود والتقارير لا تتغير.',
              style: TextStyle(fontSize: 11, color: c.onSurfaceVariant))),
          ])),
      ]));
    },
  );
}
