import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

import '../../core/timetable_ordering.dart';
import '../../core/ui_helpers.dart';
import '../../data/database_service.dart';

class AvailabilityPage extends StatefulWidget {
  const AvailabilityPage({
    required this.onChanged,
    required this.onEditTeachers,
    super.key,
  });
  final VoidCallback onChanged, onEditTeachers;
  @override
  State<AvailabilityPage> createState() => _AvailabilityPageState();
}

class _AvailabilityPageState extends State<AvailabilityPage> {
  late Future<List<dynamic>> _future;
  final _scroll = ScrollController();
  int? _teacherId;
  int? _gradeId;
  int? _subjectId;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  Future<List<dynamic>> _load() => Future.wait([
    DatabaseService.instance.rows('teachers', orderBy: 'name'),
    DatabaseService.instance.rows('school_days', orderBy: 'position'),
    DatabaseService.instance.rows('time_slots', orderBy: 'position'),
    DatabaseService.instance.rows('teacher_availability'),
    DatabaseService.instance.entriesDetailed(),
    DatabaseService.instance.rows('grades', orderBy: 'position'),
    DatabaseService.instance.rows('subjects', orderBy: 'name'),
  ]);

  Future<void> _setAvailability(
    List<Map<String, Object?>> cells,
    bool available,
  ) async {
    if (_saving || _teacherId == null) return;
    final teacher = _teacherId!;
    final grade = _gradeId;
    final subject = _subjectId;
    setState(() => _saving = true);
    try {
      final db = await DatabaseService.instance.database;
      await db.transaction((txn) async {
        for (final cell in cells) {
          await txn.delete(
            'teacher_availability',
            where: 'teacher_id=? AND day_id=? AND slot_id=? AND grade_id IS ? AND subject_id IS ?',
            whereArgs: [
              teacher,
              cell['day_id'],
              cell['slot_id'],
              grade,
              subject,
            ],
          );
          if (!available) {
            await txn.insert('teacher_availability', {
              'teacher_id': teacher,
              'day_id': cell['day_id'],
              'slot_id': cell['slot_id'],
              'grade_id': grade,
              'subject_id': subject,
              'is_available': 0,
            });
          }
        }
      });
      // Await data while keeping the existing grid and its scroll position.
      final refreshed = await _load();
      if (!mounted) return;
      setState(() => _future = SynchronousFuture<List<dynamic>>(refreshed));
      widget.onChanged();
      showMessage(
        context,
        available
            ? 'أُزيل منع الاختيار الحالي. أي منع عام يظل سارياً.'
            : 'حُفظ المنع للاختيار الحالي. أعد التوزيع لتطبيقه على الحصص.',
      );
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر حفظ الإتاحة: $e', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: FutureBuilder<List<dynamic>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.hasError)
          return emptyState(
            icon: Icons.error_outline,
            title: 'تعذر تحميل الإتاحة',
            message: '${snapshot.error}',
          );
        if (!snapshot.hasData)
          return const Center(child: CircularProgressIndicator());
        List<Map<String, Object?>> rows(int index) =>
            (snapshot.data![index] as List).cast<Map<String, Object?>>();
        final teachers = rows(0);
        final days = rows(1).where((d) => d['is_active'] == 1).toList();
        final slots =
            rows(2)
                .where((s) => s['kind'] == 'lesson' && s['is_available'] == 1)
                .toList()
              ..sort(TimetableOrdering.compare);
        final availability = rows(3);
        final entries = rows(4);
        final grades = rows(5);
        final subjects = rows(6);
        if (!teachers.any((t) => t['id'] == _teacherId)) {
          _teacherId = teachers.isEmpty ? null : teachers.first['id'] as int;
        }
        if (!grades.any((g) => g['id'] == _gradeId)) _gradeId = null;
        if (!subjects.any((s) => s['id'] == _subjectId)) _subjectId = null;
        if (teachers.isEmpty)
          return emptyState(
            icon: Icons.person_add_alt,
            title: 'أضف المعلمين أولاً',
            message: 'بعد إضافة المعلم يمكنك تحديد أيامه وحصصه المتاحة هنا.',
          );
        bool matchingScope(Map<String, Object?> rule) =>
            (rule['grade_id'] == null || rule['grade_id'] == _gradeId) &&
            (rule['subject_id'] == null || rule['subject_id'] == _subjectId);
        final matching = availability
            .where(
              (r) =>
                  r['teacher_id'] == _teacherId &&
                  r['is_available'] == 0 &&
                  matchingScope(r),
            )
            .toList();
        final blocked = matching
            .map((r) => '${r['day_id']}:${r['slot_id']}')
            .toSet();
        final inherited = matching
            .where(
              (r) => r['grade_id'] != _gradeId || r['subject_id'] != _subjectId,
            )
            .map((r) => '${r['day_id']}:${r['slot_id']}')
            .toSet();
        final colors = Theme.of(context).colorScheme;
        final gradeLabel = _gradeId == null
            ? 'جميع الصفوف'
            : displayGradeName(
                grades.firstWhere((g) => g['id'] == _gradeId)['name'],
              );
        final subjectLabel = _subjectId == null
            ? 'جميع المواد'
            : '${subjects.firstWhere((s) => s['id'] == _subjectId)['name']}';
        String lessons(Object? day, Object? slot) {
          final titles = entries
              .where(
                (e) =>
                    e['teacher_id'] == _teacherId &&
                    e['day_id'] == day &&
                    e['slot_id'] == slot &&
                    (_gradeId == null ||
                        (e['section_grade_id'] ?? e['grade_id']) == _gradeId) &&
                    (_subjectId == null || e['subject_id'] == _subjectId),
              )
              .map(
                (e) =>
                    '${e['subject_name']} · ${displayGradeName(e['grade_name'])}',
              )
              .join(' / ');
          return titles.isEmpty ? 'لا توجد حصة' : titles;
        }

        Widget selector({
          required String keyName,
          required String label,
          required IconData icon,
          required int? value,
          required List<Map<String, Object?>> options,
          String? allLabel,
          required ValueChanged<int?> changed,
        }) => DropdownButtonFormField<int>(
          key: ValueKey('$keyName:${value ?? 0}'),
          initialValue: value ?? (allLabel == null ? null : 0),
          isExpanded: true,
          borderRadius: BorderRadius.circular(18),
          decoration: InputDecoration(
            labelText: label,
            prefixIcon: Icon(icon),
            filled: true,
            fillColor: colors.surface,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
          ),
          items: [
            if (allLabel != null)
              DropdownMenuItem(value: 0, child: Text(allLabel)),
            for (final option in options)
              DropdownMenuItem(
                value: option['id'] as int,
                child: Text(
                  keyName == 'availability-grade'
                      ? displayGradeName(option['name'])
                      : '${option['name']}',
                  overflow: TextOverflow.ellipsis,
                ),
              ),
          ],
          onChanged: _saving ? null : (v) => changed(v == 0 ? null : v),
        );
        return ListView(
          controller: _scroll,
          key: const PageStorageKey('teacher-availability-scroll'),
          padding: const EdgeInsets.all(16),
          children: [
            pageHeading(
              'وقت التدريس المتاح',
              'اختر المعلم ثم الصف والمادة. اضغط الفترة لحفظ المنع أو السماح لهذا الاختيار.',
            ),
            Card(
              color: colors.primaryContainer.withValues(alpha: .35),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.tune_rounded, color: colors.primary),
                        const SizedBox(width: 8),
                        const Expanded(
                          child: Text(
                            'تخصيص الإتاحة',
                            style: TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    selector(
                      keyName: 'availability-teacher',
                      label: 'المعلم',
                      icon: Icons.person_outline,
                      value: _teacherId,
                      options: teachers,
                      changed: (v) => setState(() => _teacherId = v),
                    ),
                    const SizedBox(height: 12),
                    LayoutBuilder(
                      builder: (context, bounds) {
                        final grade = selector(
                          keyName: 'availability-grade',
                          label: 'الصف',
                          icon: Icons.school_outlined,
                          value: _gradeId,
                          options: grades,
                          allLabel: 'جميع الصفوف',
                          changed: (v) => setState(() => _gradeId = v),
                        );
                        final subject = selector(
                          keyName: 'availability-subject',
                          label: 'المادة',
                          icon: Icons.menu_book_outlined,
                          value: _subjectId,
                          options: subjects,
                          allLabel: 'جميع المواد',
                          changed: (v) => setState(() => _subjectId = v),
                        );
                        return bounds.maxWidth >= 600
                            ? Row(
                                children: [
                                  Expanded(child: grade),
                                  const SizedBox(width: 12),
                                  Expanded(child: subject),
                                ],
                              )
                            : Column(
                                children: [
                                  grade,
                                  const SizedBox(height: 12),
                                  subject,
                                ],
                              );
                      },
                    ),
                    const SizedBox(height: 12),
                    Text(
                      '$gradeLabel · $subjectLabel',
                      style: TextStyle(
                        color: colors.primary,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'اختيار جميع الصفوف وجميع المواد يجعل المنع عاماً للمعلم. المنع العام يظل سارياً عند تخصيص صف أو مادة.',
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${blocked.length} فترة ممنوعة لهذا الاختيار',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    if (inherited.isNotEmpty)
                      const Padding(
                        padding: EdgeInsets.only(top: 8),
                        child: Text(
                          'الخانات ذات القفل ممنوعة بقاعدة أوسع. افتح جميع الصفوف أو جميع المواد لتعديل تلك القاعدة.',
                        ),
                      ),
                    const SizedBox(height: 8),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: DataTable(
                        dataRowMinHeight: 90,
                        dataRowMaxHeight: 90,
                        horizontalMargin: 8,
                        columnSpacing: 8,
                        columns: [
                          const DataColumn(label: Text('اليوم')),
                          for (final slot in slots)
                            DataColumn(label: Text('${slot['name']}')),
                        ],
                        rows: [
                          for (final day in days)
                            DataRow(
                              cells: [
                                DataCell(
                                  PopupMenuButton<bool>(
                                    enabled: !_saving,
                                    tooltip: 'إتاحة اليوم كاملاً',
                                    onSelected: (v) => _setAvailability([
                                      for (final slot in slots)
                                        {
                                          'day_id': day['id'],
                                          'slot_id': slot['id'],
                                        },
                                    ], v),
                                    itemBuilder: (_) => const [
                                      PopupMenuItem(
                                        value: true,
                                        child: Text(
                                          'السماح طوال اليوم لهذا الاختيار',
                                        ),
                                      ),
                                      PopupMenuItem(
                                        value: false,
                                        child: Text(
                                          'منع اليوم كاملاً لهذا الاختيار',
                                        ),
                                      ),
                                    ],
                                    child: Padding(
                                      padding: const EdgeInsets.all(8),
                                      child: Text('${day['name']}'),
                                    ),
                                  ),
                                ),
                                for (final slot in slots)
                                  DataCell(
                                    Semantics(
                                      button: true,
                                      label:
                                          '${day['name']} ${slot['name']}: ${blocked.contains('${day['id']}:${slot['id']}') ? 'ممنوع' : 'متاح'}',
                                      child: SizedBox(
                                        width: 126,
                                        height: 78,
                                        child: FilledButton.tonal(
                                          key: ValueKey(
                                            'availability-cell:${day['id']}:${slot['id']}',
                                          ),
                                          style: FilledButton.styleFrom(
                                            padding: const EdgeInsets.all(8),
                                            backgroundColor:
                                                blocked.contains(
                                                  '${day['id']}:${slot['id']}',
                                                )
                                                ? colors.errorContainer
                                                : colors.secondaryContainer,
                                            foregroundColor:
                                                blocked.contains(
                                                  '${day['id']}:${slot['id']}',
                                                )
                                                ? colors.onErrorContainer
                                                : colors.onSecondaryContainer,
                                          ),
                                          onPressed:
                                              _saving ||
                                                  inherited.contains(
                                                    '${day['id']}:${slot['id']}',
                                                  )
                                              ? null
                                              : () => _setAvailability(
                                                  [
                                                    {
                                                      'day_id': day['id'],
                                                      'slot_id': slot['id'],
                                                    },
                                                  ],
                                                  blocked.contains(
                                                    '${day['id']}:${slot['id']}',
                                                  ),
                                                ),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  if (inherited.contains(
                                                    '${day['id']}:${slot['id']}',
                                                  )) ...[
                                                    const Icon(
                                                      Icons.lock_outline,
                                                      size: 14,
                                                    ),
                                                    const SizedBox(width: 4),
                                                  ],
                                                  Flexible(
                                                    child: Text(
                                                      blocked.contains(
                                                            '${day['id']}:${slot['id']}',
                                                          )
                                                          ? 'غير متاح'
                                                          : 'متاح',
                                                      style: const TextStyle(
                                                        fontSize: 12,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                      ),
                                                      maxLines: 1,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(height: 4),
                                              Text(
                                                lessons(day['id'], slot['id']),
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.center,
                                                style: const TextStyle(
                                                  fontSize: 10,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                        ],
                      ),
                    ),
                    if (_saving) const LinearProgressIndicator(),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: widget.onEditTeachers,
              icon: const Icon(Icons.school_outlined),
              label: const Text('تعديل المواد والصفوف المسموحة للمعلمين'),
            ),
          ],
        );
      },
    ),
  );
}
