import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';

import '../../core/ui_helpers.dart';
import '../../data/database_service.dart';
import '../../services/auto_scheduler_service.dart';
import '../../services/conflict_detection_service.dart';
import '../../services/minimal_change_repair_service.dart';
import '../../services/repair_history_service.dart';
import '../timetable/minimal_repair_dialog.dart';
import '../timetable/repair_undo_dialog.dart';

List<Map<String, Object?>> _repairMapList(Object? value) => (value as List)
    .map((row) => Map<String, Object?>.from(row as Map))
    .toList();

/// Generates a timetable in a background isolate using the same hardened scheduler
/// used by the timetable editor. This action creates a new version; it never edits
/// or deletes the current saved version.
Map<String, Object?> _generateConflictRepairInBackground(
  Map<String, Object?> input,
) {
  final result = const AutoSchedulerService(nodeLimit: 180000).generate(
    sections: _repairMapList(input['sections']),
    requirements: _repairMapList(input['requirements']),
    teachers: _repairMapList(input['teachers']),
    qualifications: _repairMapList(input['qualifications']),
    teacherGrades: _repairMapList(input['teacherGrades']),
    teacherSubjectGrades: _repairMapList(input['teacherSubjectGrades']),
    subjectBlockedSlots: _repairMapList(input['subjectBlockedSlots']),
    days: _repairMapList(input['days']),
    slots: _repairMapList(input['slots']),
    teacherAvailability: _repairMapList(input['availability']),
  );
  return <String, Object?>{
    'placements': result.placements,
    'unscheduled': result.unscheduled,
    'requestedCount': result.requestedCount,
    'exploredNodes': result.exploredNodes,
    'searchLimitReached': result.searchLimitReached,
    'dailySpreadIssues': result.dailySpreadIssues,
  };
}

class ConflictsPage extends StatefulWidget {
  const ConflictsPage({required this.onNavigateToIssue, super.key});
  final ValueChanged<ConflictIssue> onNavigateToIssue;
  @override
  State<ConflictsPage> createState() => _ConflictsPageState();
}

class _ConflictsPageState extends State<ConflictsPage> {
  Future<Map<String, Object?>>? _future;
  String _filter = 'الكل';
  String _query = '';
  bool _showOnlyActionable = false;
  bool _scanned = false;
  bool _isRepairingSchedule = false;
  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() => _future = _load();

  Future<Map<String, Object?>> _load() async {
    final db = DatabaseService.instance;
    final versionId = await db.activeVersionId(await db.activeYearId());
    final data = <String, Object?>{
      'yearId': await db.activeYearId(),
      'year': await db.activeYear() ?? <String, Object?>{},
      'sections': await db.sectionsDetailed(),
      'availability': await db.rows('teacher_availability'),
      'versionId': versionId,
      'version': versionId == null
          ? <String, Object?>{}
          : (await db.rows('timetable_versions')).firstWhere(
              (v) => v['id'] == versionId,
              orElse: () => <String, Object?>{},
            ),
      'entries': await db.entriesDetailed(versionId: versionId),
      'requirements': await db.requirementsDetailed(),
      'slots': await db.rows('time_slots'),
      'teachers': await db.rows('teachers'),
      'qualifications': await db.rows('teacher_subjects'),
      'teacherGrades': await db.rows('teacher_grades'),
      'teacherSubjectGrades': await db.rows('teacher_subject_grades'),
      'subjectBlockedSlots': await db.rows('subject_blocked_slots'),
      'days': await db.rows('school_days'),
    };
    return data;
  }

  List<ConflictIssue> _scan(
    Map<String, Object?> data,
  ) => const ConflictDetectionService().scan(
    entries: (data['entries'] as List).cast<Map<String, Object?>>(),
    requirements: (data['requirements'] as List).cast<Map<String, Object?>>(),
    sections: (data['sections'] as List).cast<Map<String, Object?>>(),
    slots: (data['slots'] as List).cast<Map<String, Object?>>(),
    teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
    qualifications: (data['qualifications'] as List)
        .cast<Map<String, Object?>>(),
    days: (data['days'] as List).cast<Map<String, Object?>>(),
    teacherGrades: (data['teacherGrades'] as List).cast<Map<String, Object?>>(),
    teacherSubjectGrades: (data['teacherSubjectGrades'] as List)
        .cast<Map<String, Object?>>(),
    subjectBlockedSlots: (data['subjectBlockedSlots'] as List)
        .cast<Map<String, Object?>>(),
    teacherAvailability: (data['availability'] as List)
        .cast<Map<String, Object?>>(),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    body: FutureBuilder<Map<String, Object?>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.hasError)
          return emptyState(
            icon: Icons.error_outline,
            title: 'تعذر فحص الجدول',
            message: '${snapshot.error}',
          );
        if (snapshot.connectionState != ConnectionState.done)
          return Center(child: CircularProgressIndicator());
        if (!snapshot.hasData)
          return emptyState(
            icon: Icons.info_outline,
            title: 'لا توجد بيانات',
            message: 'لم تُرجع قاعدة البيانات بيانات للفحص. حدّث الصفحة وحاول مرة أخرى.',
          );
        final data = snapshot.data!;
        final entries = (data['entries'] as List).cast<Map<String, Object?>>();
        final issues = _scan(data);
        final teacherCapacityNotes = [
          ...const MinimalChangeRepairService().capacityDiagnostics(data),
          ...const MinimalChangeRepairService().feasibilityDiagnostics(data),
        ];
        final blockers = issues.where((i) => i.severity == 'خطأ مانع').length;
        final warnings = issues.where((i) => i.severity == 'تحذير').length;
        final notes = issues.where((i) => i.severity == 'ملاحظة').length;
        final filtered =
            issues.where((i) {
              if (_filter != 'الكل' && i.severity != _filter) return false;
              if (_showOnlyActionable && i.sectionId == null) return false;
              final term = _query.trim().toLowerCase();
              if (term.isNotEmpty &&
                  !'${i.type} ${i.message} ${i.suggestion ?? ''} ${i.teacherId ?? ''} ${i.sectionId ?? ''}'
                      .toLowerCase()
                      .contains(term))
                return false;
              return true;
            }).toList()..sort((a, b) {
              int rank(String severity) => severity == 'خطأ مانع'
                  ? 0
                  : severity == 'تحذير'
                  ? 1
                  : 2;
              return rank(a.severity).compareTo(rank(b.severity));
            });
        final version = (data['version'] as Map).cast<String, Object?>();
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            pageHeading(
              'إصلاح التعارضات بأقل تغيير',
              'حلول مرتبة مع تفسير سبب الترشيح ومعاينة التغييرات قبل الاعتماد.',
              trailing: IconButton(
                onPressed: () => setState(() {
                  _reload();
                  _scanned = true;
                }),
                icon: const Icon(Icons.refresh, color: Color(0xFF6655BE)),
              ),
            ),
            Container(
              padding: const EdgeInsets.all(17),
              margin: const EdgeInsets.only(bottom: 14),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  Theme.of(context).colorScheme.primary.withValues(alpha: .10),
                  Theme.of(context).colorScheme.surface,
                ]),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(Icons.auto_awesome_outlined,
                    color: Theme.of(context).colorScheme.primary),
                  const SizedBox(width: 9),
                  Expanded(child: Text('الإصلاح الجماعي الذكي · بياناتك الفعلية',
                    style: Theme.of(context).textTheme.titleMedium)),
                ]),
                const SizedBox(height: 9),
                Text('الحلول تُعرض أولاً للمعاينة، ولا تُحفظ إلا بعد اعتمادك.',
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                const SizedBox(height: 14),
                Wrap(spacing: 9, runSpacing: 9, children: [
                  Chip(avatar: const Icon(Icons.report_gmailerrorred, size: 17, color: Color(0xffe36b6f)),
                    label: Text('$blockers أخطاء مانعة')),
                  Chip(avatar: const Icon(Icons.warning_amber_rounded, size: 17, color: Color(0xffe89c36)),
                    label: Text('$warnings تحذيرات')),
                  Chip(avatar: Icon(Icons.info_outline, size: 17,
                    color: Theme.of(context).colorScheme.primary),
                    label: Text('$notes ملاحظات')),
                ]),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: FilledButton.icon(
                onPressed: _isRepairingSchedule || entries.isEmpty
                    ? null : () async {
                      final saved = await showMinimalRepairDialog(
                        context: context, data: data, entry: entries.first,
                        batch: true,
                      );
                      if (saved && mounted) setState(() { _future = _load(); _scanned = true; });
                    },
                icon: const Icon(Icons.manage_history),
                label: const Text('الإصلاح الجماعي الذكي · أقل تغيير · معاينة أولاً'),
              ),
            ),
            if (const RepairHistoryService().sourceVersionId(version['notes']) != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: OutlinedButton.icon(
                  onPressed: _isRepairingSchedule ? null : () async {
                    try {
                      final done = await showRepairUndoDialog(context: context, data: data);
                      if (done && mounted) setState(() { _future = _load(); _scanned = true; });
                    } catch (error) {
                      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('تعذر التراجع الآمن: $error')),
                      );
                    }
                  },
                  icon: const Icon(Icons.settings_backup_restore),
                  label: const Text('التراجع عن آخر إصلاح · النسخ السابقة محفوظة'),
                ),
              ),
            Padding(
              padding: const EdgeInsets.only(bottom: 18),
              child: Text(
                'النسخة النشطة: ${version['name'] ?? 'لا توجد نسخة'} · ${entries.length} حصة',
                style: TextStyle(
                  fontSize: 12,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            if (issues.any(
              (i) =>
                  i.severity == 'خطأ مانع' &&
                  const {
                    'تأهيل المعلم',
                    'الصف غير مسموح للمعلم',
                    'تعذر تحديد صف الشعبة',
                  }.contains(i.type),
            ))
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'إصلاح الإسنادات المخالفة',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                        ),
                      ),
                      SizedBox(height: 6),
                      Text(
                        'المسودة النشطة تحتوي إسنادات محفوظة لا تطابق صلاحيات المعلمين. أنشئ جدولاً جديداً من الصفر وفق صلاحيات كل مادة وصف؛ ستبقى النسخة الحالية محفوظة ضمن سجل النسخ ولن تُحذف بيانات المدرسة.',
                      ),
                      SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: _isRepairingSchedule
                              ? null
                              : () => _createCorrectedVersion(data),
                          icon: _isRepairingSchedule
                              ? SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Icon(Icons.auto_fix_high),
                          label: Text(
                            _isRepairingSchedule
                                ? 'جارٍ إنشاء توزيع متحقق منه…'
                                : 'إنشاء نسخة جديدة بصلاحيات صحيحة',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            SizedBox(height: 12),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 3,
              mainAxisSpacing: 9,
              crossAxisSpacing: 9,
              mainAxisExtent: 125,
              children: [
                _IssueSummary(
                  title: 'أخطاء مانعة',
                  value: blockers,
                  color: Colors.red.shade700,
                  icon: Icons.error_outline,
                ),
                _IssueSummary(
                  title: 'تحذيرات',
                  value: warnings,
                  color: Colors.deepOrange.shade700,
                  icon: Icons.warning_amber_outlined,
                ),
                _IssueSummary(
                  title: 'ملاحظات',
                  value: notes,
                  color: const Color(0xFF6655BE),
                  icon: Icons.info_outline,
                ),
              ],
            ),
            SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'النتيجة النهائية',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      blockers > 0
                          ? 'لا يمكن اعتماد الجدول حالياً؛ يجب معالجة الأخطاء المانعة أولاً.'
                          : warnings > 0
                          ? 'لا توجد أخطاء مانعة مكتشفة، لكن توجد تحذيرات ينبغي مراجعتها قبل الاعتماد.'
                          : 'لم تُكتشف أخطاء مانعة أو تحذيرات ضمن الفحوص المفعلة.',
                    ),
                    if (_scanned)
                      Padding(
                        padding: EdgeInsets.only(top: 6),
                        child: Text(
                          'أُعيد تشغيل الفحص بناءً على البيانات الحالية.',
                          style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            if (teacherCapacityNotes.isNotEmpty) ...[
              SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('كشف مبكر للقيود غير القابلة للتحقيق بالإسناد الحالي',
                        style: TextStyle(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      ...teacherCapacityNotes.take(5).map((note) => Padding(
                        padding: const EdgeInsets.only(bottom: 7),
                        child: Text('• $note', style: const TextStyle(fontSize: 12)),
                      )),
                    ],
                  ),
                ),
              ),
            ],
            SizedBox(height: 12),
            Card(
              color: Theme.of(context).colorScheme.surface,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      onChanged: (value) => setState(() => _query = value),
                      decoration: const InputDecoration(
                        labelText: 'بحث ذكي في الأسباب والمعلمين والشعب',
                        hintText: 'مثال: نصاب، لغة عربية، رقم المعلم…',
                        prefixIcon: Icon(Icons.search_rounded),
                      ),
                    ),
                    CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      controlAffinity: ListTileControlAffinity.leading,
                      title: Text(
                        'المشكلات التي يمكن الانتقال إلى موقعها',
                        style: TextStyle(fontSize: 12),
                      ),
                      value: _showOnlyActionable,
                      onChanged: (value) =>
                          setState(() => _showOnlyActionable = value ?? false),
                    ),
                    Text(
                      'يعرض ${filtered.length} من أصل ${issues.length} نتيجة، مرتبة بحسب الخطورة.',
                      style: TextStyle(color: Color(0xFF43556F), fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'تفاصيل النتائج',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                  ),
                ),
                SizedBox(
                  width: 160,
                  child: DropdownButtonFormField<String>(
                    initialValue: _filter,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'تصفية'),
                    items: const [
                      DropdownMenuItem(
                        value: 'الكل',
                        child: Text('كل النتائج'),
                      ),
                      DropdownMenuItem(
                        value: 'خطأ مانع',
                        child: Text('أخطاء مانعة'),
                      ),
                      DropdownMenuItem(value: 'تحذير', child: Text('تحذيرات')),
                      DropdownMenuItem(value: 'ملاحظة', child: Text('ملاحظات')),
                    ],
                    onChanged: (v) => setState(() => _filter = v ?? 'الكل'),
                  ),
                ),
              ],
            ),
            SizedBox(height: 8),
            if (filtered.isEmpty)
              emptyState(
                icon: Icons.check_circle_outline,
                title: 'لا توجد نتائج ضمن هذا التصنيف',
                message: 'قد يكون الجدول خالياً أو اجتاز الفحوص الحالية. تحقق من تسجيل متطلبات المواد إذا كان ذلك مطلوباً.',
              ),
            ...filtered.map(
              (issue) => Padding(
                padding: const EdgeInsets.only(bottom: 9),
                child: Card(
                  color: _colorFor(issue.severity).withValues(alpha: .035),
                  child: ExpansionTile(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                    leading: CircleAvatar(
                      backgroundColor: _colorFor(issue.severity)
                          .withValues(alpha: .12),
                      child: Icon(
                        _iconFor(issue.severity),
                        color: _colorFor(issue.severity),
                      ),
                    ),
                    title: Text(
                      issue.type,
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      issue.message,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                    childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: Chip(
                          label: Text(issue.severity),
                          backgroundColor: _colorFor(issue.severity)
                              .withValues(alpha: .12),
                        ),
                      ),
                      if (issue.suggestion != null)
                        Align(
                          alignment: Alignment.centerRight,
                          child: Text('الاقتراح: ${issue.suggestion}'),
                        ),
                      if (issue.sectionId != null || issue.teacherId != null) ...[
                        SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerRight,
                          child: OutlinedButton.icon(
                            onPressed: _isRepairingSchedule
                                ? null : () => _repairIssue(data, issue),
                            icon: const Icon(Icons.auto_fix_high),
                            label: const Text('أصلح هذه الحصة · عرض أقل التغييرات'),
                          ),
                        ),
                      ],
                      if (issue.sectionId != null) ...[
                        SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerRight,
                          child: FilledButton.tonalIcon(
                            onPressed: () => widget.onNavigateToIssue(issue),
                            icon: const Icon(Icons.my_location),
                            label: Text(
                              issue.dayId != null && issue.slotId != null
                                  ? 'الانتقال إلى موضع المشكلة في الجدول'
                                  : 'فتح جدول الشعبة المرتبطة بالمشكلة',
                            ),
                          ),
                        ),
                      ],
                      SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 6,
                        children: [
                          if (issue.sectionId != null)
                            _InfoPill(
                              label: 'معرّف الشعبة',
                              value: '${issue.sectionId}',
                            ),
                          if (issue.teacherId != null)
                            _InfoPill(
                              label: 'معرّف المعلم',
                              value: '${issue.teacherId}',
                            ),
                          if (issue.dayId != null)
                            _InfoPill(label: 'اليوم', value: '${issue.dayId}'),
                          if (issue.slotId != null)
                            _InfoPill(
                              label: 'الفترة',
                              value: '${issue.slotId}',
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    ),
  );

  Future<void> _repairIssue(Map<String, Object?> data, ConflictIssue issue) async {
    final entries = (data['entries'] as List).cast<Map<String, Object?>>();
    // Prefer the precise cell; teacher-only problems select the related teacher.
    int rank(Map<String, Object?> e) {
      var score = 0;
      if (issue.sectionId != null && e['section_id'] == issue.sectionId) score += 8;
      if (issue.teacherId != null && e['teacher_id'] == issue.teacherId) score += 8;
      if (issue.subjectId != null && e['subject_id'] == issue.subjectId) score += 4;
      if (issue.dayId != null && e['day_id'] == issue.dayId) score += 2;
      if (issue.slotId != null && e['slot_id'] == issue.slotId) score += 2;
      return score;
    }
    final eligible = entries.where((e) => e['is_locked'] != 1).toList()
      ..sort((a, b) => rank(b).compareTo(rank(a)));
    if (eligible.isEmpty || rank(eligible.first) == 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('لم تُحدد حصة يمكن تحريكها لهذه المشكلة؛ راجع البيانات أو افتح القفل.'),
      ));
      return;
    }
    final saved = await showMinimalRepairDialog(
      context: context, data: data, entry: eligible.first);
    if (saved && mounted) setState(() { _future = _load(); _scanned = true; });
  }

  Future<void> _createCorrectedVersion(Map<String, Object?> data) async {
    if (_isRepairingSchedule) return;
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: Text('إنشاء نسخة مصححة'),
        content: Text(
          'سيعيد التطبيق توزيع الحصص لجميع شعب المدرسة باستخدام صلاحية (المعلم + المادة + الصف). '
          'ستُحفظ النتيجة كنسخة جديدة وتصبح النشطة، بينما تبقى المسودة الحالية وسائر بيانات المدرسة دون حذف. '
          'قد تكون النتيجة جزئية إذا كانت بعض الحصص لا تملك معلماً متاحاً ومسموحاً له.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('ابدأ الإصلاح'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    setState(() => _isRepairingSchedule = true);
    try {
      final yearId = data['yearId'] as int?;
      if (yearId == null) throw StateError('لا يوجد عام دراسي نشط.');
      List<Map<String, Object?>> list(String key) =>
          (data[key] as List).cast<Map<String, Object?>>();
      final sections = list('sections');
      final requirements = list('requirements');
      if (sections.isEmpty || requirements.isEmpty) {
        throw StateError('لا توجد شعب أو حصص مطلوبة كافية لإنشاء جدول جديد.');
      }

      final generated = await compute(
        _generateConflictRepairInBackground,
        <String, Object?>{
          'sections': sections,
          'requirements': requirements,
          'teachers': list('teachers'),
          'qualifications': list('qualifications'),
          'teacherGrades': list('teacherGrades'),
          'teacherSubjectGrades': list('teacherSubjectGrades'),
          'subjectBlockedSlots': list('subjectBlockedSlots'),
          'days': list('days'),
          'slots': list('slots'),
          'availability': list('availability'),
        },
        debugLabel: 'jadwali_conflict_repair',
      );

      final placements = _repairMapList(generated['placements']);
      final requestedCount = generated['requestedCount'] as int;
      final unscheduled = (generated['unscheduled'] as List).cast<String>();
      final exploredNodes = generated['exploredNodes'] as int;
      final searchLimitReached = generated['searchLimitReached'] as bool;
      final dailySpreadIssues =
          (generated['dailySpreadIssues'] as List? ?? const []).cast<String>();
      if (placements.isEmpty) {
        throw StateError(
          'لم ينتج التوزيع أي حصة مسندة. لم تتغير النسخة الحالية. راجع تأهيل المعلمين، وصفوف المواد، والفترات والنصاب، ثم حاول مرة أخرى.',
        );
      }

      final scanIssues = const ConflictDetectionService().scan(
        entries: placements,
        requirements: requirements,
        sections: sections,
        slots: list('slots'),
        teachers: list('teachers'),
        qualifications: list('qualifications'),
        days: list('days'),
        teacherGrades: list('teacherGrades'),
        teacherSubjectGrades: list('teacherSubjectGrades'),
        subjectBlockedSlots: list('subjectBlockedSlots'),
        teacherAvailability: list('availability'),
        enforceQualifications: true,
      );
      final dailySpreadBlockers = scanIssues
          .where(
            (issue) =>
                issue.severity == 'خطأ مانع' &&
                issue.type == 'توزيع المادة على كل أيام الأسبوع',
          )
          .toList();

      final allDailySpreadMessages = <String>{
        ...dailySpreadIssues,
        ...dailySpreadBlockers.map((issue) => issue.message),
      }.toList(growable: false);
      final complete =
          placements.length == requestedCount &&
          unscheduled.isEmpty &&
          allDailySpreadMessages.isEmpty;
      final blockers = scanIssues
          .where(
            (issue) =>
                issue.severity == 'خطأ مانع' &&
                !(!complete &&
                    (issue.type == 'نقص الحصص' ||
                        issue.type == 'توزيع المادة على كل أيام الأسبوع')),
          )
          .toList();
      if (blockers.isNotEmpty) {
        final details = blockers
            .take(8)
            .map((issue) => '• ${issue.type}: ${issue.message}')
            .join('\n');
        throw StateError(
          'أوقف الإصلاح لأن فحص التوزيع الجديد اكتشف أخطاء مانعة؛ لم تتغير النسخة الحالية:\n$details',
        );
      }

      if (!mounted) return;
      final save = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          title: Text(
            complete
                ? 'التوزيع الجديد اجتاز فحص الإسناد'
                : 'التوزيع الجديد آمن لكنه غير مكتمل',
          ),
          content: SizedBox(
            width: 460,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('المطلوب: $requestedCount حصة'),
                  Text('الموزع: ${placements.length} حصة'),
                  Text('المتبقي: ${requestedCount - placements.length} حصة'),
                  Text(
                    'عُقد البحث: $exploredNodes${searchLimitReached ? ' (وصل إلى حد البحث)' : ''}',
                  ),
                  if (allDailySpreadMessages.isNotEmpty) ...[
                    SizedBox(height: 10),
                    Text(
                      'تغطية الأيام تحتاج إلى استكمال',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: Colors.deepOrange,
                      ),
                    ),
                    ...allDailySpreadMessages
                        .take(6)
                        .map(
                          (message) => Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              '• $message',
                              style: TextStyle(fontSize: 12),
                            ),
                          ),
                        ),
                  ],
                  SizedBox(height: 10),
                  Text(
                    complete
                        ? 'لم يجد فحص الإسناد مخالفات مانعة في التوزيع الجديد. ستُحفظ نسخة جديدة نشطة، وستبقى النسخة القديمة محفوظة.'
                        : 'لم تُسند جميع الحصص أو لم تستوفَ تغطية جميع الأيام بسبب القيود المسجلة. إذا حفظت، ستصبح النتيجة مسودة جديدة غير نشطة بعد التحقق من صلاحية الإسنادات. ستبقى النسخة القديمة محفوظة، ويمكنك مراجعة الحصص والتغطية المتبقية.',
                  ),
                  if (unscheduled.isNotEmpty) ...[
                    SizedBox(height: 10),
                    Text(
                      'أسباب الحصص المتبقية:',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: Colors.deepOrange,
                      ),
                    ),
                    ...unscheduled
                        .take(6)
                        .map(
                          (reason) => Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: Text(
                              '• $reason',
                              style: TextStyle(fontSize: 12),
                            ),
                          ),
                        ),
                    if (unscheduled.length > 6)
                      Text('... و${unscheduled.length - 6} أسباب أخرى'),
                  ],
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text('إلغاء دون تغيير الجدول'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(complete ? 'حفظ النسخة المصححة' : 'حفظ كمسودة جديدة'),
            ),
          ],
        ),
      );
      if (save != true || !mounted) return;

      final year = (data['year'] as Map).cast<String, Object?>();
      final yearName = year['name']?.toString() ?? 'العام الدراسي';
      final versionId = await DatabaseService.instance.saveAsNewVersion(
        yearId: yearId,
        name:
            'نسخة مصححة لصلاحيات المعلمين ${DateTime.now().toString().substring(0, 16)}',
        entries: placements,
        activate: complete,
        notes: complete
            ? 'توزيع جديد للعام $yearName بعد فحص قواعد المعلم والمادة والصف. عُقد البحث: $exploredNodes.'
            : 'توزيع جزئي جديد للعام $yearName؛ اجتاز فحص إسناد المعلم للمادة والصف. وُزعت ${placements.length} من $requestedCount حصة. المتبقي: ${requestedCount - placements.length}. تغطية الأيام الناقصة: ${allDailySpreadMessages.length}. مسودة غير نشطة؛ بقي الجدول السابق نشطاً. عُقد البحث: $exploredNodes.',
      );
      if (!mounted) return;
      setState(() {
        _future = _load();
        _scanned = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            complete
                ? 'تم إنشاء النسخة المصححة رقم $versionId وتفعيلها. النسخة السابقة محفوظة.'
                : requestedCount > placements.length
                ? 'تم إنشاء المسودة الجديدة رقم $versionId. بقيت ${requestedCount - placements.length} حصة غير موزعة؛ النسخة السابقة محفوظة.'
                : 'تم إنشاء المسودة الجديدة رقم $versionId. اكتمل عدد الحصص لكن تغطية الأيام تحتاج إلى مراجعة؛ النسخة السابقة محفوظة.',
          ),
          duration: const Duration(seconds: 6),
        ),
      );
    } catch (error) {
      if (mounted) {
        await showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text('لم يكتمل إصلاح الجدول'),
            content: SelectableText('$error'),
            actions: [
              FilledButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text('إغلاق'),
              ),
            ],
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isRepairingSchedule = false);
    }
  }

  IconData _iconFor(String severity) => switch (severity) {
    'خطأ مانع' => Icons.error_outline,
    'تحذير' => Icons.warning_amber_outlined,
    _ => Icons.info_outline,
  };
  Color _colorFor(String severity) => switch (severity) {
    'خطأ مانع' => Colors.red.shade700,
    'تحذير' => Colors.deepOrange.shade700,
    _ => const Color(0xFF6655BE),
  };
}

class _IssueSummary extends StatelessWidget {
  const _IssueSummary({
    required this.title,
    required this.value,
    required this.color,
    required this.icon,
  });
  final String title;
  final int value;
  final Color color;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 11,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 8),
          Text(
            '$value',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ],
      ),
    ),
  );
}

class _InfoPill extends StatelessWidget {
  const _InfoPill({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) =>
      Chip(label: Text('$label: $value'), visualDensity: VisualDensity.compact);
}
