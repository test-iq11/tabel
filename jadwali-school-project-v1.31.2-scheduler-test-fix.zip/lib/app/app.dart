import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import '../core/interface_settings.dart';
import '../features/setup/readiness_card.dart';
import '../features/settings/app_settings_page.dart';
import '../features/settings/design_studio.dart';

import '../core/theme.dart';
import '../core/design_widgets.dart';
import '../core/editor_navigation_guard.dart';
import '../features/conflicts/conflicts_page.dart';
import '../services/conflict_detection_service.dart';
import '../features/dashboard/dashboard_page.dart';
import '../features/smart/smart_workspace_page.dart';
import '../features/smart/smart_access_dialog.dart';
import '../features/data_management/data_management_page.dart';
import '../features/data_management/availability_page.dart';
import '../features/setup/grade_daily_lessons_page.dart';
import '../features/timetable/timetable_page.dart';
import '../features/timetable/teacher_absence_page.dart';
import '../features/reports/reports_page.dart';
import '../features/notifications/jadwali_notification_center.dart';
import '../features/tools/tools_page.dart';

class TimetableApp extends StatefulWidget {
  const TimetableApp({this.settingsPreloaded = false, super.key});

  final bool settingsPreloaded;
  @override
  State<TimetableApp> createState() => _TimetableAppState();
}

class _TimetableAppState extends State<TimetableApp> {
  @override
  void initState() {
    super.initState();
    if (!widget.settingsPreloaded) InterfaceSettings.instance.load();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: InterfaceSettings.instance,
    builder: (context, _) => MaterialApp(
      title: 'الجدول المدرسي',
      debugShowCheckedModeBanner: false,
      themeAnimationDuration: InterfaceSettings.instance.design.motion
          ? const Duration(milliseconds: 260) : Duration.zero,
      themeAnimationCurve: Curves.easeOutCubic,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: buildAppTheme(
        dark: InterfaceSettings.instance.dark,
        design: InterfaceSettings.instance.design,
      ),
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(
          disableAnimations:
              MediaQuery.disableAnimationsOf(context) ||
              !InterfaceSettings.instance.design.motion,
          textScaler: TextScaler.linear(
            MediaQuery.textScalerOf(context).scale(1) *
                InterfaceSettings.instance.fontScale,
          ),
        ),
        child: child!,
      ),
      home: AppShell(),
    ),
  );
}

class AppShell extends StatefulWidget {
  const AppShell({
    this.style = 'calm',
    this.textScale = 1,
    this.onAppearance,
    super.key,
  });
  final String style;
  final double textScale;
  final void Function(String, double)? onAppearance;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0, _focusToken = 0;
  final _editorGuard = EditorNavigationGuard();
  final _visited = <int>{0};
  final _epochs = List.filled(19, 0);
  Map<String, int?>? _focusTarget;
  String? _smartRequest;
  static const _destinations = <({String label, IconData icon})>[
    (label: 'الرئيسية', icon: Icons.dashboard_outlined),
    (label: 'الجدول', icon: Icons.calendar_month_outlined),
    (label: 'المعلمون', icon: Icons.people_outline),
    (label: 'الحصص المطلوبة', icon: Icons.fact_check_outlined),
    (label: 'المواد والقيود', icon: Icons.menu_book_outlined),
    (label: 'إتاحة المعلمين', icon: Icons.event_available_outlined),
    (label: 'التعارضات', icon: Icons.rule_outlined),
    (label: 'التوزيع والحلول', icon: Icons.auto_awesome_outlined),
    (label: 'الغياب والبدلاء', icon: Icons.person_off_outlined),
    (label: 'النسخ والاعتماد', icon: Icons.history_outlined),
    (label: 'التقارير', icon: Icons.print_outlined),
    (label: 'النسخ الاحتياطية', icon: Icons.backup_outlined),
    (label: 'إعدادات المدرسة', icon: Icons.settings_outlined),
    (label: 'إعداد الجدول', icon: Icons.school_outlined),
    (label: 'المزيد', icon: Icons.grid_view_outlined),
    (label: 'إعدادات التطبيق', icon: Icons.tune_outlined),
    (label: 'مختبر ماذا لو؟', icon: Icons.auto_awesome_outlined),
    (label: 'الصفوف والشعب', icon: Icons.account_tree_outlined),
    (label: 'الحصص المخصصة لكل صف', icon: Icons.view_week_outlined),
  ];
  Future<void> _goTo(int index, {String? request}) async {
    if (index == _index || index == 9) return;
    InterfaceSettings.instance.stopReading();
    if (_index == 3 &&
        !await (_editorGuard.beforeLeave?.call() ?? Future.value(true)))
      return;
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    setState(() {
      if (index == 16) _smartRequest = request;
      _epochs[index]++;
      _visited.add(index);
      _index = index;
    });
  }

  void _refreshApp() => setState(() {
    for (var i = 0; i < _epochs.length; i++) {
      if (i != _index) _epochs[i]++;
    }
  });
  void _openIssue(ConflictIssue issue) {
    _focusTarget = {
      'sectionId': issue.sectionId,
      'dayId': issue.dayId,
      'slotId': issue.slotId,
      'subjectId': issue.subjectId,
      'token': ++_focusToken,
    };
    _goTo(1);
  }

  void _openTable({int? sectionId, int? teacherId}) {
    _focusTarget = {
      'sectionId': sectionId,
      'teacherId': teacherId,
      'token': ++_focusToken,
    };
    _goTo(1);
  }

  Widget _page(int index) {
    if (!_visited.contains(index)) return const SizedBox.shrink();
    final key = ValueKey('screen-$index-${_epochs[index]}');
    return switch (index) {
      0 => DashboardPage(
        key: key,
        onNavigate: _goTo,
        onOpenSection: (id) => _openTable(sectionId: id),
        onOpenTeacher: (id) => _openTable(teacherId: id),
      ),
      1 => TimetablePage(
        key: key,
        onChanged: _refreshApp,
        focusTarget: _focusTarget,
      ),
      2 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.teachers,
        onOpenTeacher: (id) => _openTable(teacherId: id),
        onScenario: () => _goTo(16, request: 'تغيير إتاحة معلم بأقل تعديل ممكن'),
      ),
      3 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.requirements,
        navigationGuard: _editorGuard,
      ),
      4 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.subjects,
        onRepair: () => _goTo(7),
      ),
      5 => AvailabilityPage(
        key: key,
        onChanged: _refreshApp,
        onEditTeachers: () => _goTo(2),
      ),
      6 => ConflictsPage(key: key, onNavigateToIssue: _openIssue),
      7 => TimetablePage(key: key, onChanged: _refreshApp, searchPage: true),
      8 => TeacherAbsencePage(key: key, onChanged: _refreshApp),
      10 => ReportsPage(key: key, onChanged: _refreshApp),
      11 => ToolsPage(
        key: key,
        onChanged: _refreshApp,
        section: ToolsSection.backups,
      ),
      13 => _hub(true),
      14 => _hub(false),
      15 => AppSettingsPage(key: key, onHelp: _help, onNavigate: _goTo),
      16 => SmartWorkspacePage(
        key: key,
        request: _smartRequest,
        onNavigate: _goTo,
      ),
      17 => GradesSectionsPage(key: key, onChanged: _refreshApp),
      18 => GradeDailyLessonsPage(
        key: key,
        onChanged: _refreshApp,
        onSchoolTimes: () => _goTo(12),
      ),
      _ => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.settings,
      ),
    };
  }

  void _help() {
    final text = switch (_index) {
      15 => 'ابدأ من إعداد الجدول: أدخل الصفوف والأوقات والمعلمين والمواد، ثم حدد حصص كل صف وإتاحة المعلمين. افتح التوزيع لمراجعة الشروط والبحث عن حل. في الجدول اضغط الحصة لعرض تفاصيلها أو اضغط مطولاً لقفلها. التوزيع والتقارير في إعداد الجدول، والنسخ الاحتياطية داخل إعدادات التطبيق. تكرار المادة يفضّل حصة مبكرة وأخرى في السادسة أو السابعة المتاحة، دون فرض ذلك على الحل.',
      1 => 'اختر الصف واليوم من الشريط الثابت. اضغط الحصة لعرض أدواتها، واضغط مطولاً لقفلها أو فك قفلها. النقل من مقبض السحب. القفل يحمي حصة محددة؛ منع الفترة يخص المادة في كل الصفوف.',
      3 => 'اختر الصف وعدّل الأعداد. يظهر شريط الحفظ والتراجع عند أول تعديل. لن تفقد المسودة عند محاولة المغادرة دون حفظ.',
      4 => 'حدد الفترات الممنوعة على بطاقة المادة. يبقى موضع الصفحة ثابتاً بعد الحفظ. اضغط تعديل المادة لبقية التفاصيل.',
      0 => 'اسم المدرسة في بطاقتها الرئيسية. خصّص أربع بطاقات من زر تخصيص الرئيسية. يمكنك تغيير اسم المدرسة من إعدادات المدرسة.',
      _ => 'إعداد الجدول يجمع بيانات المدرسة والإتاحة والتوزيع والتقارير. في إعدادات التطبيق ستجد التعارضات والغياب والنسخ الاحتياطية.',
    };
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      constraints: BoxConstraints(
        maxHeight: MediaQuery.sizeOf(context).height * .85,
      ),
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'دليل الاستخدام',
                  style: Theme.of(ctx).textTheme.titleLarge,
                ),
                const SizedBox(height: 14),
                Text(text),
                const SizedBox(height: 18),
                FilledButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                    _goTo(
                      _index == 15
                          ? 13
                          : _index == 0
                          ? 12
                          : _index == 4
                          ? 4
                          : _index == 3
                          ? 3
                          : 1,
                    );
                  },
                  child: Text(
                    _index == 15
                        ? 'فتح إعداد الجدول'
                        : _index == 0
                        ? 'فتح إعدادات المدرسة'
                        : 'الذهاب إلى الإجراء',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _hub(bool school) {
    final descriptions = <int, String>{
      0: 'ملخص المدرسة والوصول السريع',
      1: 'حصص الصفوف والمعلمين',
      13: 'جميع البيانات اللازمة لملء الجدول',
      15: 'المظهر، حجم الخط والمساعدة والإصدار',
      16: 'جرّب تغيير الشروط على نسخة من بياناتك',
      2: 'النصاب، الاختصاص والإتاحة',
      3: 'أعداد المواد لكل صف',
      4: 'شروط المواد والفترات',
      12: 'بيانات المدرسة وأيام الدوام وأوقات الحصص',
      7: 'مراجعة ثم بحث ثم نتيجة',
      6: 'مراجعة الشروط الحالية',
      8: 'تنظيم حصص المعلم الغائب',
      10: 'معاينة وطباعة وتصدير',
      9: 'الأرشيف ومقارنة الجداول',
      11: 'حفظ البيانات واستعادتها',
      5: 'أوقات التدريس المتاحة',
      17: 'إضافة وتعديل الصفوف والشعب دون مغادرة إعداد الجدول',
      18: 'ست حصص يومياً لكل صف، والسادس سبع حصص يوم الأحد عند الحاجة',
    };
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(
          school ? 'بيانات إعداد الجدول' : 'كل أدوات المدرسة',
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 6),
        Text(
          school
              ? 'بيانات المدرسة والإتاحة والتوزيع والتقارير، من البداية حتى طباعة جدولك.'
              : 'جميع الأقسام والأدوات في مكان واحد.',
          style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12),
        ),
        const SizedBox(height: 22),
        if (!school)
          Padding(
            padding: const EdgeInsets.only(bottom: 18),
            child: OutlinedButton.icon(
              onPressed: () => showSmartAccess(
                context,
                onNavigate: _goTo,
                onTeacher: (id) => _openTable(teacherId: id),
                onSection: (id) => _openTable(sectionId: id),
              ),
              icon: const Icon(Icons.search),
              label: const Text('الوصول الذكي'),
            ),
          ),
        if (!school)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: ActionTile(
              key: const ValueKey('more-design-studio'),
              title: 'استوديو المظهر',
              subtitle: 'بطاقتك وألوانك وخيارات التصميم',
              icon: Icons.tune,
              onTap: () => showDesignStudio(context),
            ),
          ),
        if (school)
          ReadinessCard(
            key: ValueKey('readiness-${_epochs[13]}'),
            onNavigate: _goTo,
          ),
        for (final group
            in (school
                ? [
                    ('بيانات المدرسة والصفوف', [17, 18, 12, 2, 4, 3, 5]),
                    ('التوزيع والتقارير', [7, 10]),
                  ]
                : [
                    ('التنقل الرئيسي', [0, 1]),
                    ('التفضيلات والمساعدة', [15]),
                    ('أدوات الجدول', [16, 6, 8]),
                    ('حفظ البيانات', [11]),
                  ])) ...[
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(
              group.$1,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
            ),
          ),
          ActionGrid(
            children: [
              for (var n = 0; n < group.$2.length; n++)
                ActionTile(
                  key: ValueKey('more-destination-${group.$2[n]}'),
                  title: _destinations[group.$2[n]].label,
                  subtitle: descriptions[group.$2[n]]!,
                  icon: _destinations[group.$2[n]].icon,
                  tone: n % 4,
                  onTap: () => _goTo(group.$2[n]),
                ),
            ],
          ),
        ],
        const SizedBox(height: 18),
        if (school)
          Padding(
            padding: const EdgeInsets.only(bottom: 18),
            child: FilledButton.icon(
              onPressed: () => _goTo(7),
              icon: const Icon(Icons.auto_awesome_outlined),
              label: const Text('مراجعة البيانات وبدء التوزيع'),
            ),
          ),
        if (school)
          Text(
            'التكرار في اليوم: يفضّل حصة ضمن الثلاث الأولى وأخرى في السادسة أو السابعة المتاحة، مع المرونة عند الحاجة.',
            style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12),
          ),
      ],
    );
  }

  int get _tab => _index == 0
      ? 0
      : _index == 1
      ? 1
      : [2, 3, 4, 5, 7, 10, 12, 13, 17, 18].contains(_index)
      ? 2
      : 3;
  /// Current screens and callbacks stay intact. Only the HTML-inspired shell changes.
  static const _desktopLinks = <int>[0, 13, 1, 6, 10];
  // Five stable navigation tabs. Appearance and tools are in Settings.
  static const _mobileLinks = <int>[0, 13, 1, 6, 10];
  int get _activeBottom => _mobileLinks.contains(_index)
      ? _mobileLinks.indexOf(_index)
      : _index == 7 ? 3 : [2, 3, 4, 5, 12, 17, 18].contains(_index) ? 1 : -1;

  Color _navigationTone(int index) {
    const tones = <Color>[
      Color(0xff5d78cc), Color(0xff208f82), Color(0xff9171c3),
      Color(0xffc88a51), Color(0xff468ca6), Color(0xffbe7790),
    ];
    final base = tones[index % tones.length];
    return Theme.of(context).brightness == Brightness.dark
        ? Color.lerp(base, Colors.white, .17)!
        : base;
  }

  Widget _sideLink(int index, bool compact) {
    final c = Theme.of(context).colorScheme;
    final active = index == _index ||
        (index == 13 && _tab == 2 && ![2, 10].contains(_index)) ||
        (index == 14 && _tab == 3 && _index != 6 && _index != 15);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 10),
      child: Material(color: Colors.transparent,
        child: InkWell(
          key: ValueKey('rail-destination-$index'),
          borderRadius: BorderRadius.circular(13),
          onTap: () => _goTo(index),
          child: AnimatedContainer(
            duration: InterfaceSettings.instance.design.motion
                ? const Duration(milliseconds: 190) : Duration.zero,
            padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 14, vertical: 12),
            decoration: BoxDecoration(
              color: active ? c.primary.withValues(alpha: .10) : Colors.transparent,
              borderRadius: BorderRadius.circular(13),
            ),
            child: Row(mainAxisAlignment: compact ? MainAxisAlignment.center : MainAxisAlignment.start, children: [
              Icon(_destinations[index].icon, size: 21,
                color: active ? c.primary : _navigationTone(index)),
              if (!compact) ...[
                const SizedBox(width: 13),
                Expanded(child: Text(_destinations[index].label, maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: active ? c.primary : c.onSurfaceVariant,
                    fontWeight: active ? FontWeight.w800 : FontWeight.w600, fontSize: 12))),
              ],
            ]),
          ),
        ),
      ),
    );
  }

  Widget _sideRail() {
    final ui = InterfaceSettings.instance;
    final collapsed = ui.collapsed;
    final c = Theme.of(context).colorScheme;
    return AnimatedContainer(
      duration: ui.design.motion ? const Duration(milliseconds: 220) : Duration.zero,
      width: collapsed ? 82 : 264,
      decoration: BoxDecoration(color: c.surface, border: Border(left: BorderSide(color: c.outlineVariant))),
      child: Column(children: [
        Padding(padding: EdgeInsets.symmetric(horizontal: collapsed ? 10 : 20, vertical: 21),
          child: Row(children: [
            Container(width: 45, height: 45, decoration: BoxDecoration(
              gradient: LinearGradient(colors: [c.primary, ui.design.b]),
              borderRadius: BorderRadius.circular(15),
              boxShadow: [BoxShadow(color: c.primary.withValues(alpha: .23), blurRadius: 15, offset: const Offset(0, 7))]),
              child: const Icon(Icons.calendar_month_rounded, color: Colors.white)),
            if (!collapsed) ...[
              const SizedBox(width: 11),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('جدولي', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: c.onSurface)),
                Text('نظام الجداول المدرسية الذكي', maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 9, color: c.onSurfaceVariant)),
              ])),
            ],
          ])),
        Expanded(child: ListView(children: [
          if (!collapsed) Padding(padding: const EdgeInsets.fromLTRB(22, 10, 22, 12),
            child: Text('مساحة العمل', style: TextStyle(fontSize: 11, color: c.onSurfaceVariant))),
          for (final i in _desktopLinks) _sideLink(i, collapsed),
          Divider(height: 25, indent: 18, endIndent: 18, color: c.outlineVariant),
          if (!collapsed) Padding(padding: const EdgeInsets.fromLTRB(22, 0, 22, 10),
            child: Text('إدارة المدرسة', style: TextStyle(fontSize: 11, color: c.onSurfaceVariant))),
          _sideLink(14, collapsed),
        ])),
        IconButton(tooltip: collapsed ? 'توسيع القائمة' : 'طي القائمة',
          icon: Icon(collapsed ? Icons.keyboard_double_arrow_left : Icons.keyboard_double_arrow_right),
          onPressed: () { ui.collapsed = !ui.collapsed; ui.save(); }),
        const SizedBox(height: 8),
      ]),
    );
  }

  // A real, data-backed notification centre; it is loaded again on each
  // opening and never substitutes sample figures for the current school.
  void _openNotifications() {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => JadwaliNotificationPanel(
        onNavigate: (destination) => _goTo(destination),
      ),
    );
  }

  Widget _topBar(bool wide) {
    final c = Theme.of(context).colorScheme;
    return LayoutBuilder(builder: (context, _) {
      final mobile = !wide;
      return Container(
        height: mobile ? 75 : 81,
        padding: EdgeInsets.symmetric(horizontal: wide ? 29 : 11),
        decoration: BoxDecoration(color: c.surface.withValues(alpha: .96),
          border: Border(bottom: BorderSide(color: c.outlineVariant))),
        child: Row(children: [
          Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('مساحة العمل', maxLines: 1, style: TextStyle(fontSize: 11,
                fontWeight: FontWeight.w600, color: c.onSurfaceVariant)),
              const SizedBox(height: 2),
              Text(_index == 0 ? 'الرئيسية' : switch (_index) {
                1 => 'الجدول الدراسي', 2 => 'المعلمون والإتاحة',
                6 => 'التعارضات والإصلاح', 10 => 'التقارير والطباعة',
                15 => 'إعدادات التطبيق', _ => _destinations[_index].label,
              }, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: mobile ? 13 : 16,
                  fontWeight: FontWeight.w800, color: c.onSurface)),
            ])),
          if (wide) ...[
            SizedBox(width: 220, child: OutlinedButton.icon(
              onPressed: () => showSmartAccess(context, onNavigate: _goTo,
                onTeacher: (id) => _openTable(teacherId: id),
                onSection: (id) => _openTable(sectionId: id)),
              icon: const Icon(Icons.search, size: 17),
              label: const Text('ابحث عن معلم أو مادة...'))),
            const SizedBox(width: 14),
          ],
          if (wide) ...[
            Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
              decoration: BoxDecoration(color: const Color(0xff12a78e).withValues(alpha: .08),
                borderRadius: BorderRadius.circular(24)),
              child: Text('جدولي الذكي', style: TextStyle(fontSize: 10,
                fontWeight: FontWeight.bold, color: c.primary))),
            const SizedBox(width: 7),
          ],
          _topIcon(context, Icons.settings_outlined, 'إعدادات التطبيق',
            () => _goTo(15), key: const ValueKey('top-settings')),
          _topIcon(context, Icons.notifications_none_outlined, 'التنبيهات',
            _openNotifications, key: const ValueKey('top-notifications')),
        ]),
      );
    });
  }

  Widget _topIcon(BuildContext context, IconData icon, String hint, VoidCallback action,
      {Key? key}) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2),
      child: Material(color: colors.surface, borderRadius: BorderRadius.circular(12),
        child: InkWell(key: key, onTap: action, borderRadius: BorderRadius.circular(12),
          child: Tooltip(message: hint, child: Container(
            width: 39, height: 39, alignment: Alignment.center,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),
              border: Border.all(color: colors.outlineVariant)),
            child: Icon(icon, size: 22, color: hint == 'إعدادات التطبيق'
                ? _navigationTone(3) : hint == 'التنبيهات'
                ? _navigationTone(5) : colors.onSurface))))),
    );
  }

  Widget _bottomBar() {
    final c = Theme.of(context).colorScheme;
    final motion = InterfaceSettings.instance.design.motion;
    final labels = ['الرئيسية', 'إعداد الجدول', 'الجدول', 'الإصلاح', 'التقارير'];
    final icons = [Icons.home_outlined, Icons.tune_outlined,
      Icons.calendar_month_outlined, Icons.auto_fix_high_outlined,
      Icons.description_outlined];
    // Muted but distinct hues for navigation; readable in both theme modes.
    final iconColors = <Color>[
      const Color(0xff4f76c9), const Color(0xff168d7c),
      const Color(0xff7b63ca), const Color(0xffcf844e),
      const Color(0xffbd719b),
    ];
    return SafeArea(top: false, child: Container(
      width: double.infinity,
      decoration: BoxDecoration(color: c.surface,
        border: Border(top: BorderSide(color: c.outlineVariant))),
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 5),
      child: Row(children: [
        for (var tab = 0; tab < _mobileLinks.length; tab++)
          Expanded(child: Semantics(selected: _activeBottom == tab,
            child: Material(color: Colors.transparent,
              child: InkWell(key: ValueKey('main-tab-$tab'),
                borderRadius: BorderRadius.circular(12),
                onTap: () => _goTo(_mobileLinks[tab]),
                child: AnimatedContainer(
                  duration: motion ? const Duration(milliseconds: 190) : Duration.zero,
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(12)),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      width: 36, height: 32, alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: iconColors[tab].withValues(alpha: .12),
                        borderRadius: BorderRadius.circular(11)),
                      child: Icon(icons[tab], size: 23,
                        color: _activeBottom == tab ? c.primary : iconColors[tab])),
                    const SizedBox(height: 4),
                    Text(labels[tab], maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 10,
                        fontWeight: _activeBottom == tab ? FontWeight.w800 : FontWeight.w600,
                        color: _activeBottom == tab ? c.primary : c.onSurfaceVariant)),
                  ]),
                ),
              ),
            ),
          )),
      ]),
    ));
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: _index == 0 && !InterfaceSettings.instance.reading,
    onPopInvokedWithResult: (didPop, result) {
      if (InterfaceSettings.instance.reading) {
        InterfaceSettings.instance.stopReading();
        return;
      }
      if (!didPop) _goTo(_index == 7 ? 6 : 0);
    },
    child: Directionality(textDirection: TextDirection.rtl,
      child: LayoutBuilder(builder: (context, constraints) {
        final ui = InterfaceSettings.instance;
        final wide = constraints.maxWidth > 900 && ui.desktopRail && !ui.reading;
        final pages = IndexedStack(
          index: _index,
          children: List.generate(19, (i) => TickerMode(enabled: _index == i, child: _page(i))),
        );
        final main = Column(children: [
          if (!ui.reading) _topBar(wide),
          Expanded(child: ScreenEntrance(page: _index, child: pages)),
        ]);
        return Scaffold(
          body: SafeArea(child: wide
              ? Row(children: [_sideRail(), Expanded(child: main)])
              : main),
          bottomNavigationBar: wide || ui.reading ? null : _bottomBar(),
        );
      }),
    ),
  );
}
