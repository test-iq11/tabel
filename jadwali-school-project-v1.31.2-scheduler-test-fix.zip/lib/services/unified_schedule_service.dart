import 'auto_scheduler_service.dart';
import 'complete_schedule_solver.dart';
import 'lns_rescue_service.dart';
import 'mandatory_period_capacity.dart';
import 'section_time_domain_flow.dart';
import 'schedule_improvement_service.dart';

/// One local pipeline. A seed guides search but only explicit pins constrain it.
/// Each strategy shares a bounded attempt; exhaustion of time is never a proof.
class UnifiedScheduleService {
  const UnifiedScheduleService();

  SchedulerResult generate({
    required Map<String, Object?> input,
    int nodeLimit = 600000,
    Duration timeLimit = const Duration(seconds: 60),
    void Function(Map<String, Object?> event)? onProgress,
  }) {
    final clock = Stopwatch()..start();
    final requested = _rows(input['requirements'])
        .fold<int>(0, (sum, row) => sum + _n(row['weekly_lessons']));
    List<Map<String, Object?>> rows(String key) => _rows(input[key]);
    Duration remaining() => timeLimit - clock.elapsed;
    void publish(List<Map<String, Object?>> board, String phase, int nodes) =>
        onProgress?.call({
          'phase': phase,
          'placements': board,
          'bestCount': board.length,
          'requestedCount': requested,
          'exploredNodes': nodes,
        });
    final shortages = const MandatoryPeriodCapacity().inspect(input);
    if (shortages.isNotEmpty) {
      final safe = ScheduleImprovementService.retainValidSeed(input);
      publish(safe, 'infeasible', 0);
      return SchedulerResult(
        placements: safe,
        requestedCount: requested,
        exploredNodes: 0,
        searchLimitReached: false,
        provenInfeasible: true,
        unscheduled: shortages
            .map(
              (r) =>
                  '${r['dayName']}، ${r['slotName']}: تحتاج ${r['required']} شعب إلى معلمين متزامنين؛ المتاح وفق القيود ${r['capacity']} فقط.',
            )
            .toList(),
      );
    }
    // Detect a section-level Hall shortage before launching an expensive search.
    // Max-flow is a necessary bound only: success does not claim feasibility.
    final sectionShortages = const SectionTimeDomainFlow().inspect(input);
    if (sectionShortages.isNotEmpty) {
      final safe = ScheduleImprovementService.retainValidSeed(input);
      publish(safe, 'infeasible', 0);
      return SchedulerResult(
        placements: safe,
        requestedCount: requested,
        exploredNodes: 0,
        searchLimitReached: false,
        provenInfeasible: true,
        unscheduled: sectionShortages.map((r) => r.message).toList(),
      );
    }
    // Repair teacher allocation before rebuilding a previously filled week.
    // Failure here says nothing about the unrestricted problem.
    final initial = rows('initialPlacements');
    if (initial.length == requested &&
        requested > 0 &&
        remaining() > Duration.zero) {
      final repaired = const CompleteScheduleSolver().solve(
        input: input,
        preserveLessonPositions: true,
        timeLimit: Duration(
          microseconds: (remaining().inMicroseconds ~/ 10).clamp(1, 2000000).toInt(),
        ),
        nodeLimit: nodeLimit,
      );
      if (repaired.complete &&
          ScheduleImprovementService.valid(input, repaired.placements) &&
          ScheduleImprovementService.validPartial(input, repaired.placements)) {
        publish(
          repaired.placements,
          'teacher_reassignment',
          repaired.exploredNodes,
        );
        return SchedulerResult(
          placements: repaired.placements,
          requestedCount: requested,
          exploredNodes: repaired.exploredNodes,
          unscheduled: const [],
          searchLimitReached: false,
        );
      }
    }
    // Reserve a meaningful share for the complete search. Previously the
    // heuristic could consume 100% and starve that fallback entirely.
    final heuristicBudget = Duration(
      microseconds: (remaining().inMicroseconds * 55 ~/ 100).clamp(1, 300000000).toInt(),
    );
    var best = AutoSchedulerService(nodeLimit: nodeLimit).generate(
      sections: rows('sections'),
      requirements: rows('requirements'),
      teachers: rows('teachers'),
      qualifications: rows('qualifications'),
      teacherGrades: rows('teacherGrades'),
      teacherSubjectGrades: rows('teacherSubjectGrades'),
      subjectBlockedSlots: rows('subjectBlockedSlots'),
      days: rows('days'),
      slots: rows('slots'),
      teacherAvailability: _rows(
        input['teacherAvailability'] ?? input['availability'],
      ),
      initialPlacements: rows('initialPlacements'),
      lockedPlacements: rows('lockedPlacements'),
      subjectPreferences: rows('subjectPreferences'),
      feasibilityOnly: true,
      timeLimit: remaining() > Duration.zero ? heuristicBudget : Duration.zero,
      onProgress: onProgress,
    );
    bool validated(SchedulerResult r) =>
        r.complete &&
        ScheduleImprovementService.valid(input, r.placements) &&
        ScheduleImprovementService.validPartial(input, r.placements);
    if (validated(best) || best.provenInfeasible) return best;
    // Defensive boundary: no engine may promote an unverified full board.
    if (!ScheduleImprovementService.validPartial(input, best.placements) ||
        best.complete) {
      best = SchedulerResult(
        placements: ScheduleImprovementService.retainValidSeed(input),
        unscheduled: const ['لم يُعثر بعد على جدول كامل صالح.'],
        requestedCount: requested,
        exploredNodes: best.exploredNodes,
        searchLimitReached: true,
      );
    }
    if (remaining() > Duration.zero && best.placements.isNotEmpty) {
      publish(best.placements, 'rescuing', best.exploredNodes);
      final rescued = const LnsRescueService().rescue(
        input: input,
        seed: best,
        nodeLimit: nodeLimit ~/ 14,
        timeLimit: remaining() > const Duration(seconds: 10)
            ? const Duration(seconds: 10)
            : Duration(microseconds: (remaining().inMicroseconds ~/ 3).clamp(1, 10000000).toInt()),
        onImproved: (candidate, round) {
          if (ScheduleImprovementService.validPartial(
            input,
            candidate.placements,
          )) {
            publish(candidate.placements, 'rescuing', candidate.exploredNodes);
          }
        },
      );
      if (validated(rescued)) return rescued;
      if (rescued.placements.length > best.placements.length &&
          ScheduleImprovementService.validPartial(input, rescued.placements))
        best = rescued;
    }
    if (remaining() > Duration.zero) {
      publish(best.placements, 'constraint_search', best.exploredNodes);
      final exactBudget = remaining();
      final exact = const CompleteScheduleSolver().solve(
        input: {...input, 'initialPlacements': best.placements},
        timeLimit: exactBudget > Duration.zero ? exactBudget : remaining(),
        nodeLimit: nodeLimit,
        onProgress: (board, nodes) {
          if (board.length > best.placements.length &&
              ScheduleImprovementService.validPartial(input, board)) {
            best = SchedulerResult(
              placements: board,
              requestedCount: requested,
              unscheduled: const ['لم يكتمل البحث بعد.'],
              exploredNodes: nodes,
              searchLimitReached: true,
            );
            publish(board, 'constraint_search', nodes);
          }
        },
      );
      if (exact.complete &&
          ScheduleImprovementService.valid(input, exact.placements) &&
          ScheduleImprovementService.validPartial(input, exact.placements)) {
        return SchedulerResult(
          placements: exact.placements,
          unscheduled: const [],
          requestedCount: requested,
          exploredNodes: best.exploredNodes + exact.exploredNodes,
          searchLimitReached: false,
        );
      }
      if (exact.provenInfeasible) {
        return SchedulerResult(
          placements: best.placements,
          unscheduled: [exact.reason],
          requestedCount: requested,
          exploredNodes: best.exploredNodes + exact.exploredNodes,
          searchLimitReached: false,
          provenInfeasible: true,
        );
      }
      if (exact.placements.length > best.placements.length &&
          ScheduleImprovementService.validPartial(input, exact.placements)) {
        best = SchedulerResult(
          placements: exact.placements,
          unscheduled: const ['لم يكتمل البحث بعد.'],
          requestedCount: requested,
          exploredNodes: best.exploredNodes + exact.exploredNodes,
          searchLimitReached: true,
        );
      }
    }
    return SchedulerResult(
      placements: best.placements,
      unscheduled: [
        ...best.unscheduled,
        'انتهت المحاولة المحدودة؛ لم تثبت استحالة التوزيع.',
      ],
      dailySpreadIssues: best.dailySpreadIssues,
      requestedCount: requested,
      exploredNodes: best.exploredNodes,
      searchLimitReached: true,
    );
  }
}

List<Map<String, Object?>> _rows(Object? value) => value is List
    ? value.map((row) => Map<String, Object?>.from(row as Map)).toList()
    : [];
int _n(Object? value) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? 0;
