import 'dart:math' as math;

import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf_text_shaper/pdf_text_shaper.dart';
import 'package:printing/printing.dart';

import 'timetable_report_layout.dart';
import 'reference_timetable_layout.dart';
import 'file_save_service.dart';
import '../core/timetable_palette.dart';

/// يصدّر شبكة الجدول الأسبوعي لجميع الشعب إلى PDF أفقي قابل للطباعة.
class PdfReportService {
  /// The black-and-white school form supplied by the school. Each class owns
  /// two distinct columns, and only days with saved extra lessons grow taller.
  Future<Uint8List> buildReferenceTimetablePdf({
    required ReferenceTimetableLayout layout,
    required String schoolName,
    String reportNumber = '1',
    String effectiveDate = '',
    String managerName = '',
    bool colorTeacherSubjects = false,
    PdfPageFormat? pageFormat,
  }) async {
    final font = await _arabicFont(reference: true);
    try {
      final pdf = pw.Document();
      final format = pageFormat ?? PdfPageFormat.a3.landscape;
      final width = format.width - 56;
      const dayWidth = 44.0, periodWidth = 26.0;
      final tableHeight = format.height - 155;
      for (final group in layout.classGroups) {
        final rows = math.max(1, layout.rowCount(group));
        // Split long weeks into day blocks instead of making text unreadable.
        final maxRows = math.max(6, (tableHeight / 14).floor() - 3);
        final chunks =
            <
              List<
                ({Map<String, Object?> day, List<Map<String, Object?>> periods})
              >
            >[];
        var chunk =
            <
              ({Map<String, Object?> day, List<Map<String, Object?>> periods})
            >[];
        var count = 0;
        for (final day in layout.days) {
          final periods = layout.periodsForDay(day, group);
          for (var start = 0; start < periods.length; start += maxRows) {
            final part = periods.skip(start).take(maxRows).toList();
            if (count + part.length > maxRows && chunk.isNotEmpty) {
              chunks.add(chunk);
              chunk = [];
              count = 0;
            }
            chunk.add((day: day, periods: part));
            count += part.length;
          }
        }
        if (chunk.isNotEmpty || chunks.isEmpty) chunks.add(chunk);
        final classWidth =
            (width - dayWidth - periodWidth - 6 * (group.length - 1)) /
            group.length;
        final fontSize = (classWidth / 11).clamp(5.2, 10.0).toDouble();
        pw.Widget box(
          String text,
          double w,
          double h, {
          bool grey = false,
          PdfColor? fill,
          bool thick = false,
          bool rotate = false,
        }) {
          final label = _formText(text, font: font, size: fontSize);
          return pw.Container(
            width: w,
            height: h,
            alignment: pw.Alignment.center,
            padding: const pw.EdgeInsets.symmetric(horizontal: 1),
            decoration: pw.BoxDecoration(
              color: fill ?? (grey ? PdfColors.grey200 : PdfColors.white),
              border: pw.Border.all(
                color: PdfColors.black,
                width: thick ? .8 : .3,
              ),
            ),
            child: text.trim().isEmpty
                ? pw.SizedBox()
                : pw.FittedBox(
                    fit: pw.BoxFit.scaleDown,
                    child: rotate
                        ? pw.Transform.rotateBox(
                            angle: math.pi / 2,
                            child: label,
                          )
                        : label,
                  ),
          );
        }

        for (final part in chunks) {
          final partRows = part.fold(0, (n, block) => n + block.periods.length);
          final rowHeight =
              ((tableHeight - 44 - 7 * math.max(0, part.length - 1)) /
                      math.max(1, chunks.length == 1 ? rows : partRows))
                  .clamp(14.0, 25.0)
                  .toDouble();
          pdf.addPage(
            pw.Page(
              pageFormat: format,
              margin: const pw.EdgeInsets.all(28),
              build: (_) => pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.stretch,
                children: [
                  pw.Row(
                    children: [
                      pw.Expanded(
                        child: _formText(
                          'يعمل بموجبه اعتباراً من تاريخ $effectiveDate',
                          font: font,
                          size: 10,
                        ),
                      ),
                      pw.Expanded(
                        child: pw.Row(
                          mainAxisAlignment: pw.MainAxisAlignment.center,
                          children: [
                            _formText(
                              '(${ReferenceTimetableLayout.arabic(reportNumber)})',
                              font: font,
                              size: 11,
                            ),
                            pw.SizedBox(width: 5),
                            _formText(
                              'جدول الدروس الاسبوعي رقم',
                              font: font,
                              size: 12,
                            ),
                          ],
                        ),
                      ),
                      pw.Expanded(
                        child: _formText(
                          'إدارة مدرسة: ${schoolName.replaceFirst(RegExp(r'^\s*مدرسة\s+'), '')}',
                          font: font,
                          size: 11,
                        ),
                      ),
                    ],
                  ),
                  pw.SizedBox(height: 15),
                  pw.Row(
                    children: [
                      for (var gi = group.length - 1; gi >= 0; gi--) ...[
                        if (gi < group.length - 1) pw.SizedBox(width: 6),
                        pw.Column(
                          children: [
                            box(
                              group[gi] == null
                                  ? ''
                                  : layout.sectionTitle(group[gi]!),
                              classWidth,
                              20,
                              thick: true,
                            ),
                            pw.Row(
                              children: [
                                box('المعلم', classWidth / 2, 24, grey: true),
                                box('المادة', classWidth / 2, 24, grey: true),
                              ],
                            ),
                          ],
                        ),
                      ],
                      box('الدرس', periodWidth, 44, grey: true),
                      box('الأيام', dayWidth, 44, thick: true),
                    ],
                  ),
                  for (final block in part) ...[
                    if (block != part.first) pw.SizedBox(height: 7),
                    pw.Container(
                      child: pw.Row(
                        children: [
                          for (var gi = group.length - 1; gi >= 0; gi--) ...[
                            if (gi < group.length - 1) pw.SizedBox(width: 6),
                            pw.Container(
                              decoration: const pw.BoxDecoration(
                                border: pw.Border(
                                  right: pw.BorderSide(width: .8),
                                ),
                              ),
                              child: pw.Column(
                                children: [
                                  for (final slot in block.periods)
                                    pw.Row(
                                      children: [
                                        box(
                                          layout.cellText(
                                            group[gi],
                                            block.day,
                                            slot,
                                            teacher: true,
                                          ),
                                          classWidth / 2,
                                          rowHeight,
                                          fill: PdfColor.fromInt(
                                            layout.dayColor(block.day),
                                          ),
                                        ),
                                        box(
                                          layout.cellText(
                                            group[gi],
                                            block.day,
                                            slot,
                                            teacher: false,
                                          ),
                                          classWidth / 2,
                                          rowHeight,
                                          fill: PdfColor.fromInt(
                                            colorTeacherSubjects &&
                                                    layout.entriesAt(group[gi], block.day, slot).length == 1
                                                ? TimetablePalette.tint(
                                                    ReferenceTimetableLayout.number(
                                                      layout.entriesAt(group[gi], block.day, slot).single['subject_id'], 1))
                                                : layout.dayColor(block.day),
                                          ),
                                        ),
                                      ],
                                    ),
                                ],
                              ),
                            ),
                          ],
                          pw.Column(
                            children: [
                              for (final slot in block.periods)
                                box(
                                  ReferenceTimetableLayout.arabic(
                                    layout.lessonNumber(slot),
                                  ),
                                  periodWidth,
                                  rowHeight,
                                  fill: PdfColor.fromInt(
                                    layout.dayColor(block.day),
                                  ),
                                ),
                            ],
                          ),
                          box(
                            '${block.day['name']}',
                            dayWidth,
                            rowHeight * block.periods.length,
                            thick: true,
                            rotate: true,
                            fill: PdfColor.fromInt(layout.dayColor(block.day)),
                          ),
                        ],
                      ),
                    ),
                  ],
                  if (part.isEmpty)
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(20),
                      child: _formText(
                        'لا توجد أيام أو حصص للطباعة',
                        font: font,
                      ),
                    ),
                  pw.SizedBox(height: 12),
                  _formText('مدير المدرسة: $managerName', font: font, size: 11),
                ],
              ),
            ),
          );
        }
      }
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  Future<Uint8List> buildListReportPdf({
    required String title,
    required String schoolName,
    required List<List<String>> rows,
    List<int?> rowColors = const [],
    PdfPageFormat? pageFormat,
  }) async {
    final font = await _arabicFont(reference: true);
    try {
      final pdf = pw.Document();
      pdf.addPage(
        pw.MultiPage(
          pageFormat: pageFormat ?? PdfPageFormat.a4.landscape,
          margin: const pw.EdgeInsets.all(24),
          header: (_) => pw.Column(
            children: [
              _formText(schoolName, font: font, size: 14),
              _formText(title, font: font, size: 11),
              pw.SizedBox(height: 12),
            ],
          ),
          build: (_) => [
            pw.Table(
              border: pw.TableBorder.all(width: .5),
              children: [
                for (var i = 0; i < rows.length; i++)
                  pw.TableRow(
                    repeat: i == 0,
                    children: [
                      for (final text in rows[i].reversed)
                        pw.Container(
                          padding: const pw.EdgeInsets.all(5),
                          color: i == 0 ? PdfColors.grey200
                              : i < rowColors.length && rowColors[i] != null
                              ? PdfColor.fromInt(rowColors[i]!)
                              : PdfColors.white,
                          child: _formText(text, font: font, size: 9),
                        ),
                    ],
                  ),
              ],
            ),
          ],
        ),
      );
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  pw.Widget _formText(
    String value, {
    required ShapedFont font,
    double size = 10,
  }) {
    const ranges = <List<int>>[
      [32, 126],
      [1542, 1543],
      [1545, 1546],
      [1548, 1548],
      [1557, 1557],
      [1563, 1563],
      [1567, 1567],
      [1569, 1594],
      [1600, 1621],
      [1623, 1623],
      [1626, 1626],
      [1632, 1648],
      [1652, 1652],
      [1657, 1727],
      [1734, 1736],
      [1739, 1740],
      [1742, 1742],
      [1744, 1744],
      [1749, 1749],
      [1776, 1785],
      [8192, 8292],
      [8298, 8303],
    ];
    final safe = String.fromCharCodes(
      value.runes.where(
        (r) => r == 10 || ranges.any((v) => r >= v[0] && r <= v[1]),
      ),
    );
    final parts = <pw.Widget>[];
    var offset = 0;
    void add(String text, bool numeric) {
      if (text.isEmpty) return;
      parts.add(
        ShapedText(
          text,
          style: ShapedTextStyle(
            font: font,
            fontSize: size,
            direction: numeric
                ? ShapedTextDirection.leftToRight
                : ShapedTextDirection.rightToLeft,
            align: ShapedTextAlign.center,
            preserveUnicodeText: true,
          ),
        ),
      );
    }

    for (final match in RegExp(
      r'[0-9٠-٩]+(?:[/.:][0-9٠-٩]+)*',
    ).allMatches(safe)) {
      add(safe.substring(offset, match.start), false);
      add(match[0]!, true);
      offset = match.end;
    }
    add(safe.substring(offset), false);
    return pw.Row(
      mainAxisSize: pw.MainAxisSize.min,
      mainAxisAlignment: pw.MainAxisAlignment.center,
      children: parts.reversed.toList(),
    );
  }

  Future<ShapedFont> _arabicFont({bool reference = false}) async {
    final data = await rootBundle.load(
      reference
          ? 'assets/fonts/Report-Regular.ttf'
          : 'assets/fonts/Arabic-Regular.ttf',
    );
    return ShapedFont.fromBytes(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      name: reference ? 'DejaVu Sans' : 'Noto Naskh Arabic',
    );
  }

  pw.Widget _text(
    String value, {
    required ShapedFont font,
    double size = 10,
    PdfColor color = PdfColors.black,
    ShapedTextAlign align = ShapedTextAlign.center,
  }) {
    // The bundled font has a limited glyph map. Normalize punctuation first,
    // then remove any code point unsupported by that exact font so text entered
    // by users cannot make PDF generation fail at runtime.
    final normalized = value
        .replaceAll(RegExp(r'[\u002D\u2010-\u2015\u2212]'), ' إلى ')
        .replaceAll('/', ' أو ')
        .replaceAll('|', '،')
        .replaceAll('•', '،')
        .replaceAll('·', '،')
        .replaceAll(RegExp(r'[()\[\]{}]'), ' ')
        .replaceAll('_', ' ')
        .replaceAll('%', ' بالمئة ')
        .replaceAll('+', ' زائد ');
    final safeValue = String.fromCharCodes(
      normalized.runes.where(
        (rune) => rune == 10 || rune == 9 || _fontHasGlyph(rune),
      ),
    );
    return ShapedText(
      safeValue,
      style: ShapedTextStyle(
        font: font,
        fontSize: size,
        color: color,
        direction: ShapedTextDirection.rightToLeft,
        align: align,
        preserveUnicodeText: true,
      ),
    );
  }

  Future<Uint8List> buildTimetablePdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<Map<String, Object?>> entries,
    List<Map<String, Object?>> sections = const [],
    List<Map<String, Object?>> days = const [],
    List<Map<String, Object?>> slots = const [],
    PdfPageFormat? pageFormat,
    String title = 'الجدول الأسبوعي الشامل',
    bool schoolWideLayout = true,
  }) async {
    final font = await _arabicFont();
    try {
      final pdf = pw.Document();
      final format = pageFormat ?? PdfPageFormat.a3.landscape;
      final layout = TimetableReportLayout(
        entries: entries,
        sections: sections,
        days: days,
        slots: slots,
      );
      const periodWidth = 92.0;

      /// Common card styling with the in-app weekly editor. Accent/tint are
      /// derived from the subject id, not from the current cell position.
      pw.Widget cell(
        String text, {
        bool header = false,
        bool period = false,
        int? subjectId,
      }) {
        final accent = subjectId == null
            ? const PdfColor.fromInt(0xFF183B66)
            : PdfColor.fromInt(TimetablePalette.accent(subjectId));
        final background = header
            ? const PdfColor.fromInt(0xFF183B66)
            : period
            ? const PdfColor.fromInt(0xFFDCE9F8)
            : subjectId == null
            ? const PdfColor.fromInt(0xFFFAFBFD)
            : PdfColor.fromInt(TimetablePalette.tint(subjectId));
        return pw.Container(
          alignment: pw.Alignment.center,
          padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 4),
          decoration: pw.BoxDecoration(
            color: background,
            borderRadius: pw.BorderRadius.circular(7),
            border: pw.Border.all(
              color: subjectId == null
                  ? const PdfColor.fromInt(0xFFD9E5F2)
                  : accent,
              width: subjectId == null ? .45 : .8,
            ),
          ),
          child: _text(
            text,
            font: font,
            size: header ? 7.2 : (period ? 6.6 : 7.2),
            color: header
                ? PdfColors.white
                : (subjectId == null
                      ? const PdfColor.fromInt(0xFF18324D)
                      : accent),
          ),
        );
      }

      pw.Widget sectionDayCards(
        Map<String, Object?> section,
        Map<String, Object?> day,
      ) {
        final sectionId = _safeInt(section['id']);
        final dayId = _safeInt(day['id']);
        final cards = <pw.Widget>[];
        for (final slot in layout.slots) {
          final entry = layout.entryAt(sectionId, dayId, _safeInt(slot['id']));
          if (entry == null) continue;
          final subject = '${entry['subject_name'] ?? 'مادة'}';
          final teacher = '${entry['teacher_name'] ?? 'غير مسند'}';
          final period = '${slot['name'] ?? 'حصة'}';
          cards.add(
            cell(
              '$period: $subject، $teacher',
              subjectId: _safeInt(entry['subject_id']),
            ),
          );
          cards.add(pw.SizedBox(height: 2));
        }
        if (cards.isEmpty) return cell('—');
        return pw.Padding(
          padding: const pw.EdgeInsets.all(2),
          child: pw.Column(
            mainAxisSize: pw.MainAxisSize.min,
            crossAxisAlignment: pw.CrossAxisAlignment.stretch,
            children: cards,
          ),
        );
      }

      final reportBlocks = <pw.Widget>[];
      if (schoolWideLayout) {
        // The comprehensive print view is a school matrix: days are rows and
        // grades/sections are columns. Keep at most six classes per table so
        // the cells remain legible on A3 landscape when a grade has divisions.
        const maxSectionColumnsPerTable = 6;
        if (layout.sections.isEmpty) {
          reportBlocks.add(
            _text(
              'لا توجد شعب أو فترات تدريس متاحة. راجع إعدادات المدرسة.',
              font: font,
              size: 9,
            ),
          );
        } else {
          for (
            var start = 0;
            start < layout.sections.length;
            start += maxSectionColumnsPerTable
          ) {
            final end =
                (start + maxSectionColumnsPerTable < layout.sections.length)
                ? start + maxSectionColumnsPerTable
                : layout.sections.length;
            final sectionChunk = layout.sections.sublist(start, end);
            final tableRows = <pw.TableRow>[
              pw.TableRow(
                children: [
                  ...sectionChunk.reversed.map(
                    (section) =>
                        cell(layout.sectionColumnTitle(section), header: true),
                  ),
                  cell('اليوم', header: true),
                ],
              ),
              ...layout.days.map(
                (day) => pw.TableRow(
                  children: [
                    ...sectionChunk.reversed.map(
                      (section) => sectionDayCards(section, day),
                    ),
                    cell('${day['name'] ?? ''}', period: true),
                  ],
                ),
              ),
            ];
            reportBlocks.add(
              pw.Table(
                columnWidths: <int, pw.TableColumnWidth>{
                  for (var i = 0; i < sectionChunk.length; i++)
                    i: const pw.FlexColumnWidth(1),
                  sectionChunk.length: const pw.FixedColumnWidth(48),
                },
                border: pw.TableBorder.all(
                  color: PdfColors.grey400,
                  width: 0.45,
                ),
                defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
                children: tableRows,
              ),
            );
            if (end < layout.sections.length) {
              reportBlocks.add(pw.SizedBox(height: 10));
              reportBlocks.add(
                _text(
                  'تابع الصفوف/الشعب في الصفحة التالية',
                  font: font,
                  size: 7,
                ),
              );
              reportBlocks.add(pw.SizedBox(height: 4));
            }
          }
        }
      } else {
        // Individual-section printouts keep the familiar period-by-day grid.
        for (final section in layout.sections) {
          reportBlocks.add(
            pw.Container(
              width: double.infinity,
              padding: const pw.EdgeInsets.symmetric(
                horizontal: 6,
                vertical: 4,
              ),
              decoration: const pw.BoxDecoration(
                color: PdfColor.fromInt(0xFFDCE9F8),
              ),
              child: _text(
                layout.sectionTitle(section),
                font: font,
                size: 9.2,
                color: const PdfColor.fromInt(0xFF183B66),
              ),
            ),
          );
          reportBlocks.add(pw.SizedBox(height: 2));
          final tableRows = <pw.TableRow>[
            pw.TableRow(
              children: [
                ...layout.slots.reversed.map(
                  (slot) => cell(layout.periodLabel(slot), header: true),
                ),
                cell('اليوم', header: true),
              ],
            ),
            ...layout.days.map(
              (day) => pw.TableRow(
                children: [
                  ...layout.slots.reversed.map((slot) {
                    final entry = layout.entryAt(
                      _safeInt(section['id']),
                      _safeInt(day['id']),
                      _safeInt(slot['id']),
                    );
                    return cell(
                      layout.lessonCell(section, day, slot),
                      subjectId: entry == null
                          ? null
                          : _safeInt(entry['subject_id']),
                    );
                  }),
                  cell('${day['name'] ?? ''}', period: true),
                ],
              ),
            ),
          ];
          reportBlocks.add(
            pw.Table(
              columnWidths: <int, pw.TableColumnWidth>{
                for (var i = 0; i < layout.slots.length; i++)
                  i: const pw.FlexColumnWidth(1),
                layout.slots.length: const pw.FixedColumnWidth(periodWidth),
              },
              border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.45),
              defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
              children: tableRows,
            ),
          );
          reportBlocks.add(pw.SizedBox(height: 8));
        }
      }
      if (reportBlocks.isEmpty) {
        reportBlocks.add(
          _text(
            'لا توجد شعب أو فترات تدريس متاحة. راجع إعدادات المدرسة.',
            font: font,
            size: 9,
          ),
        );
      }

      pdf.addPage(
        pw.MultiPage(
          pageFormat: format,
          margin: const pw.EdgeInsets.all(14),
          header: (context) => pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.stretch,
            children: [
              _text(
                schoolName,
                font: font,
                size: 13.5,
                color: const PdfColor.fromInt(0xFF183B66),
              ),
              _text(
                title,
                font: font,
                size: 9.5,
                color: const PdfColor.fromInt(0xFF23354B),
              ),
              _text(
                'العام الدراسي: $academicYear، النسخة: $versionName، الحالة: $status',
                font: font,
                size: 7.2,
              ),
              pw.SizedBox(height: 5),
            ],
          ),
          footer: (context) => pw.Align(
            alignment: pw.Alignment.centerRight,
            child: _text(
              'تاريخ التقرير: ${_dateStamp(DateTime.now())} • صفحة ${context.pageNumber} من ${context.pagesCount}',
              font: font,
              size: 6,
            ),
          ),
          build: (context) => reportBlocks,
        ),
      );
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  /// A teacher-specific weekly view: each cell shows subject and section,
  /// while the period/time remains exactly once in the first column.
  Future<Uint8List> buildTeacherTimetablePdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required Map<String, Object?> teacher,
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    required int targetLoad,
    PdfPageFormat? pageFormat,
  }) async {
    final font = await _arabicFont();
    try {
      final pdf = pw.Document();
      final teacherId = _safeInt(teacher['id']);
      final teacherEntries = entries
          .where(
            (entry) => _safeInt(entry['teacher_id'], fallback: -1) == teacherId,
          )
          .toList();
      final layout = TimetableReportLayout(
        entries: teacherEntries,
        sections: const [],
        days: days,
        slots: slots,
      );
      final dailyCounts = <int, int>{};
      for (final entry in teacherEntries) {
        final dayId = _safeInt(entry['day_id']);
        dailyCounts[dayId] = (dailyCounts[dayId] ?? 0) + 1;
      }
      final bodyRows = <pw.TableRow>[
        pw.TableRow(
          children: [
            ...layout.slots.reversed.map(
              (slot) => _reportCell(
                layout.periodLabel(slot),
                font: font,
                header: true,
              ),
            ),
            _reportCell('اليوم', font: font, header: true),
          ],
        ),
        ...layout.days.map(
          (day) => pw.TableRow(
            children: [
              ...layout.slots.reversed.map((slot) {
                final matchingEntries = teacherEntries
                    .where(
                      (row) =>
                          _safeInt(row['day_id']) == _safeInt(day['id']) &&
                          _safeInt(row['slot_id']) == _safeInt(slot['id']),
                    )
                    .toList();
                if (matchingEntries.isEmpty) return _reportCell('', font: font);
                final entry = matchingEntries.first;
                final subject = '${entry['subject_name'] ?? 'مادة'}';
                final grade =
                    '${entry['grade_name'] ?? entry['section_grade_name'] ?? ''}'
                        .replaceFirst(RegExp(r'^الصف\s+'), '');
                final section = '${entry['section_name'] ?? ''}';
                return _reportCell(
                  '$subject\n$grade - $section',
                  font: font,
                  subjectId: _safeInt(entry['subject_id']),
                );
              }),
              _reportCell('${day['name'] ?? ''}', font: font, period: true),
            ],
          ),
        ),
      ];
      final actualLoad = teacherEntries.length;
      final dayNames = <String>[];
      for (final day in layout.days) {
        if (dailyCounts.containsKey(_safeInt(day['id']))) {
          dayNames.add('${day['name']} (${dailyCounts[_safeInt(day['id'])]})');
        }
      }
      pdf.addPage(
        pw.MultiPage(
          pageFormat: pageFormat ?? PdfPageFormat.a3.landscape,
          margin: const pw.EdgeInsets.all(16),
          header: (context) => pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.stretch,
            children: [
              _text(
                schoolName,
                font: font,
                size: 14,
                color: const PdfColor.fromInt(0xFF183B66),
              ),
              _text(
                'الجدول الأسبوعي للمعلم: ${teacher['name'] ?? 'المعلم'}',
                font: font,
                size: 11,
              ),
              _text(
                'العام الدراسي: $academicYear، النسخة: $versionName، الحالة: $status',
                font: font,
                size: 7.5,
              ),
              _text(
                'النصاب المحدد: $targetLoad حصة، الموزع: $actualLoad، ${actualLoad > targetLoad ? 'التجاوز: ${actualLoad - targetLoad}' : 'المتبقي: ${targetLoad - actualLoad}'}',
                font: font,
                size: 8,
              ),
              if (dayNames.isNotEmpty)
                _text(
                  'الحصص حسب اليوم: ${dayNames.join('، ')}',
                  font: font,
                  size: 7.5,
                ),
              pw.SizedBox(height: 6),
            ],
          ),
          footer: (context) => pw.Align(
            alignment: pw.Alignment.centerRight,
            child: _text(
              'تاريخ التقرير: ${_dateStamp(DateTime.now())} • صفحة ${context.pageNumber} من ${context.pagesCount}',
              font: font,
              size: 6,
            ),
          ),
          build: (context) => [
            pw.Table(
              columnWidths: <int, pw.TableColumnWidth>{
                for (var i = 0; i < layout.slots.length; i++)
                  i: const pw.FlexColumnWidth(1),
                layout.slots.length: const pw.FixedColumnWidth(100),
              },
              border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
              defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
              children: bodyRows,
            ),
            if (teacherEntries.isEmpty)
              pw.Padding(
                padding: const pw.EdgeInsets.all(12),
                child: _text(
                  'لا توجد حصص مسندة لهذا المعلم في النسخة المحددة.',
                  font: font,
                  size: 9,
                ),
              ),
          ],
        ),
      );
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  pw.Widget _reportCell(
    String value, {
    required ShapedFont font,
    bool header = false,
    bool period = false,
    int? subjectId,
  }) {
    final background = header
        ? const PdfColor.fromInt(0xFF183B66)
        : period
        ? const PdfColor.fromInt(0xFFDCE9F8)
        : subjectId == null
        ? const PdfColor.fromInt(0xFFFAFBFD)
        : PdfColor.fromInt(TimetablePalette.tint(subjectId));
    return pw.Container(
      alignment: pw.Alignment.center,
      padding: const pw.EdgeInsets.symmetric(horizontal: 3, vertical: 4),
      decoration: pw.BoxDecoration(
        color: background,
        borderRadius: pw.BorderRadius.circular(6),
        border: pw.Border.all(
          color: subjectId == null
              ? const PdfColor.fromInt(0xFFD9E5F2)
              : PdfColor.fromInt(TimetablePalette.accent(subjectId)),
          width: .65,
        ),
      ),
      child: _text(
        value,
        font: font,
        size: header ? 7.4 : (period ? 6.8 : 7),
        color: header
            ? PdfColors.white
            : (subjectId == null
                  ? const PdfColor.fromInt(0xFF18324D)
                  : PdfColor.fromInt(TimetablePalette.accent(subjectId))),
      ),
    );
  }

  int _safeInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }

  String _dateStamp(DateTime date) =>
      '${date.year}.${date.month.toString().padLeft(2, '0')}.${date.day.toString().padLeft(2, '0')}';

  // Character ranges were derived from assets/fonts/Arabic-Regular.ttf's cmap.
  bool _fontHasGlyph(int rune) {
    const ranges = <List<int>>[
      [0, 0],
      [13, 13],
      [32, 33],
      [44, 44],
      [46, 46],
      [48, 58],
      [160, 160],
      [171, 171],
      [187, 187],
      [1536, 1540],
      [1542, 1563],
      [1566, 1791],
      [1872, 1919],
      [2208, 2208],
      [2210, 2220],
      [2276, 2302],
      [8203, 8209],
      [8271, 8271],
      [9676, 9676],
      [11841, 11841],
      [64336, 64449],
      [64467, 64831],
      [64848, 64911],
      [64914, 64967],
      [65008, 65021],
      [65136, 65140],
      [65142, 65276],
      [65279, 65279],
    ];
    for (final range in ranges) {
      if (rune >= range[0] && rune <= range[1]) return true;
    }
    return false;
  }

  Future<String?> savePdf(
    Uint8List bytes, {
    String fileName = 'الجدول-المدرسي.pdf',
  }) async {
    return FileSaveService().saveBytes(
      dialogTitle: 'حفظ تقرير PDF',
      fileName: fileName,
      allowedExtensions: ['pdf'],
      bytes: bytes,
    );
  }

  Future<void> preview(Uint8List bytes) async {
    await Printing.layoutPdf(onLayout: (_) async => bytes);
  }
}
