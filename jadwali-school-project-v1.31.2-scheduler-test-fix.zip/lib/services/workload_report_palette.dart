import 'reference_timetable_layout.dart';

/// Reuses printable pastel fills already defined for the reference report.
/// Overload -> warm coral; remaining lessons -> pale yellow; completed -> green.
class WorkloadReportPalette {
  const WorkloadReportPalette._();

  static List<int?> colors(List<List<String>> rows) => [
    if (rows.isNotEmpty) null,
    for (final row in rows.skip(1)) color(row),
  ];

  static int color(List<String> row) {
    int number(int index) => index < row.length
        ? int.tryParse(row[index].trim()) ?? 0
        : 0;
    final palette = ReferenceTimetableLayout.dayColors;
    // Export data uses the workload column layout: remaining=3, extra=4.
    if (number(4) > 0) return palette[4 % palette.length];
    if (number(3) > 0) return palette[2 % palette.length];
    return palette[1 % palette.length];
  }
}
