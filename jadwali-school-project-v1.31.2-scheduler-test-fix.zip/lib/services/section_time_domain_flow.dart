import '../core/timetable_ordering.dart';
import 'required_repeat_policy.dart';
import 'school_timetable_policy.dart';
import 'teacher_assignment_policy.dart';
import 'teacher_availability_policy.dart';

/// A necessary (not sufficient) feasibility bound for each section.
///
/// Max flow allocates subject demand to distinct day/period cells, respecting
/// school day quotas, subject-period bans, per-subject daily quotas, and the
/// existence of an eligible teacher available in that cell. Teacher collision
/// and teacher weekly loads are deliberately RELAXED: a shortage is a sound
/// proof of impossibility, while a full flow does not promise a solution.
/// This prevents treating a search timeout as a mathematical impossibility.
class SectionTimeDomainShortage {
  const SectionTimeDomainShortage({
    required this.sectionId,
    required this.requested,
    required this.maximum,
    required this.sectionLabel,
  });

  final int sectionId, requested, maximum;
  final String sectionLabel;
  int get deficit => requested - maximum;

  String get message =>
      '$sectionLabel: تتطلب $requested حصة، لكن توزيع المواد على الأيام '
      'والفترات المسموحة وإتاحة معلميها لا يستوعب أكثر من $maximum حصة '
      '(نقص $deficit). راجع منع الفترات وإتاحة المعلمين والحد اليومي؛ '
      'لم يتم تغيير أي قيد تلقائياً.';
}

class SectionTimeDomainFlow {
  const SectionTimeDomainFlow();

  List<SectionTimeDomainShortage> inspect(Map<String, Object?> input) {
    List<Map<String, Object?>> rows(String key) =>
        (input[key] as List? ?? const [])
            .map((row) => Map<String, Object?>.from(row as Map))
            .toList();
    int n(Object? value, [int fallback = 0]) => value is num
        ? value.toInt()
        : int.tryParse('$value') ?? fallback;

    final sections = rows('sections');
    final requirements = rows('requirements');
    final days = rows('days')
        .where((day) => n(day['is_active'], 1) == 1).toList()
      ..sort(TimetableOrdering.compare);
    final slots = rows('slots')
        .where((slot) => slot['kind'] == 'lesson' &&
            n(slot['is_available'], 1) == 1).toList()
      ..sort(TimetableOrdering.compare);
    final blockedRows = rows('subjectBlockedSlots');
    final blocked = {
      for (final entry in blockedRows)
        '${n(entry['subject_id'])}:${n(entry['slot_id'])}',
    };
    final policy = TeacherAssignmentPolicy(
      qualifications: rows('qualifications'),
      teacherGrades: rows('teacherGrades'),
      teacherSubjectGrades: rows('teacherSubjectGrades'),
    );
    final availability = TeacherAvailabilityPolicy(
      input.containsKey('teacherAvailability')
          ? rows('teacherAvailability') : rows('availability'),
    );
    final teachers = rows('teachers');
    final shortages = <SectionTimeDomainShortage>[];

    for (final section in sections) {
      final sectionId = n(section['id']);
      final group = requirements.where((req) =>
          n(req['section_id']) == sectionId &&
          n(req['weekly_lessons']) > 0).toList();
      if (group.isEmpty) continue;
      final total = group.fold<int>(0, (sum, req) => sum +
          n(req['weekly_lessons']).clamp(0, 1000).toInt());
      if (total == 0) continue;

      // The 'periodLimit' is a cap on the period index, whereas 'dailyLimit'
      // caps the number of occupied cells on that day. They can differ.
      final candidateSlots = <List<int>>[];
      final dailyCapacity = <int>[];
      for (final day in days) {
        final limit = SchoolTimetablePolicy.periodLimit(
          section: section, day: day, activeDays: days,
          lessonSlots: slots, weeklyDemand: total,
        );
        candidateSlots.add([
          for (var i = 0; i < slots.length && i < limit; i++) i,
        ]);
        dailyCapacity.add(SchoolTimetablePolicy.dailyLimit(
          section: section, day: day, activeDays: days,
          lessonSlots: slots, weeklyDemand: total,
        ));
      }

      // Graph: source -> subject -> (subject,day) -> (day,slot)
      // -> day -> sink. All cells are single-occupancy; a day has a quota.
      final subjectCount = group.length;
      final source = 0;
      final subjectsStart = 1;
      final subjectDaysStart = subjectsStart + subjectCount;
      final cellStart = subjectDaysStart + subjectCount * days.length;
      final dayCells = <List<int>>[];
      var numberOfCells = 0;
      for (final row in candidateSlots) {
        dayCells.add([
          for (var i = 0; i < row.length; i++) numberOfCells + i,
        ]);
        numberOfCells += row.length;
      }
      final dayStart = cellStart + numberOfCells;
      final sink = dayStart + days.length;
      final network = _CapacityNetwork(sink + 1);
      for (var dayIndex = 0; dayIndex < days.length; dayIndex++) {
        final dayNode = dayStart + dayIndex;
        for (final cell in dayCells[dayIndex]) {
          network.connect(cellStart + cell, dayNode, 1);
        }
        network.connect(dayNode, sink, dailyCapacity[dayIndex]);
      }
      for (var reqIndex = 0; reqIndex < group.length; reqIndex++) {
        final req = group[reqIndex];
        final subjectId = n(req['subject_id']);
        final gradeId = n(section['grade_id']);
        final weekly = n(req['weekly_lessons']).clamp(0, 1000).toInt();
        final eligible = teachers.where((teacher) {
          final id = n(teacher['id']);
          return policy.isSubjectQualified(id, subjectId) &&
              policy.isGradeAllowed(id, subjectId, gradeId);
        }).map((row) => n(row['id'])).toList();
        network.connect(source, subjectsStart + reqIndex, weekly);
        final repeatAllowed = n(req['allow_same_day']) == 1;
        final configuredDaily = n(req['max_daily_lessons'], 2);
        final needsLateRepeat = RequiredRepeatPolicy.allowsLatePeriodRepeat(
          requirement: req, section: section, activeDays: days,
          sectionWeeklyDemand: total, lessonSlots: slots,
          subjectBlockedSlots: blockedRows,
        );
        // Deliberately optimistic: necessary late repeats need not be assigned
        // to the late period here. That can only weaken, never falsify a proof.
        final subjectDailyLimit = repeatAllowed
            ? (configuredDaily > 0 ? configuredDaily : 1)
            : (needsLateRepeat ? 2 : 1);
        for (var dayIndex = 0; dayIndex < days.length; dayIndex++) {
          final dayId = n(days[dayIndex]['id']);
          final subjectDay = subjectDaysStart + reqIndex * days.length + dayIndex;
          network.connect(subjectsStart + reqIndex, subjectDay,
              subjectDailyLimit);
          for (var p = 0; p < candidateSlots[dayIndex].length; p++) {
            final slotId = n(slots[candidateSlots[dayIndex][p]]['id']);
            if (blocked.contains('$subjectId:$slotId')) continue;
            final canStaff = eligible.any((teacherId) =>
                availability.isAvailable(teacherId: teacherId,
                    dayId: dayId, slotId: slotId,
                    gradeId: gradeId, subjectId: subjectId));
            if (canStaff) {
              network.connect(subjectDay, cellStart + dayCells[dayIndex][p], 1);
            }
          }
        }
      }
      final maximum = network.maxFlow(source, sink);
      if (maximum < total) {
        final grade = '${section['grade_name'] ?? ''}'.trim();
        final name = '${section['section_name'] ?? section['name'] ?? sectionId}';
        shortages.add(SectionTimeDomainShortage(
          sectionId: sectionId,
          requested: total,
          maximum: maximum,
          sectionLabel: grade.isEmpty ? 'الشعبة $name' : 'الصف $grade، الشعبة $name',
        ));
      }
    }
    return shortages;
  }
}

class _Edge {
  _Edge(this.to, this.reverse, this.available);
  final int to, reverse;
  int available;
}

class _CapacityNetwork {
  _CapacityNetwork(int count) : graph = List.generate(count, (_) => <_Edge>[]);
  final List<List<_Edge>> graph;

  void connect(int from, int to, int capacity) {
    if (capacity <= 0) return;
    final forward = _Edge(to, graph[to].length, capacity);
    final backward = _Edge(from, graph[from].length, 0);
    graph[from].add(forward);
    graph[to].add(backward);
  }

  // Edmonds-Karp is deterministic and adequate for 30-35 weekly cells per
  // section. No arbitrary node/time budget is required for this upper bound.
  int maxFlow(int source, int sink) {
    var total = 0;
    while (true) {
      final parent = List<int>.filled(graph.length, -1);
      final via = List<int>.filled(graph.length, -1);
      final queue = <int>[source];
      parent[source] = source;
      for (var head = 0; head < queue.length && parent[sink] < 0; head++) {
        final from = queue[head];
        for (var e = 0; e < graph[from].length; e++) {
          final edge = graph[from][e];
          if (edge.available == 0 || parent[edge.to] >= 0) continue;
          parent[edge.to] = from;
          via[edge.to] = e;
          queue.add(edge.to);
        }
      }
      if (parent[sink] < 0) return total;
      var pushed = 1 << 60;
      for (var at = sink; at != source; at = parent[at]) {
        final edge = graph[parent[at]][via[at]];
        if (edge.available < pushed) pushed = edge.available;
      }
      for (var at = sink; at != source; at = parent[at]) {
        final edge = graph[parent[at]][via[at]];
        edge.available -= pushed;
        graph[at][edge.reverse].available += pushed;
      }
      total += pushed;
    }
  }
}
