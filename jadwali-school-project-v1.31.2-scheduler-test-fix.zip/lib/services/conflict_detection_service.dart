import 'teacher_availability_policy.dart';
import '../core/timetable_ordering.dart';
import 'teacher_assignment_policy.dart';
import 'required_repeat_policy.dart';
import 'school_timetable_policy.dart';

/// خدمة مستقلة لفحص الجدول؛ لا تعتمد على واجهات Flutter أو قاعدة البيانات مباشرة.
class ConflictIssue {
  const ConflictIssue({
    required this.type,
    required this.severity,
    required this.message,
    this.sectionId,
    this.teacherId,
    this.dayId,
    this.slotId,
    this.subjectId,
    this.suggestion,
  });

  final String type;
  final String severity; // خطأ مانع | تحذير | ملاحظة
  final String message;
  final int? sectionId;
  final int? teacherId;
  final int? dayId;
  final int? slotId;
  final int? subjectId;
  final String? suggestion;
}

class ConflictDetectionService {
  const ConflictDetectionService();

  List<ConflictIssue> scan({
    required List<Map<String, Object?>> entries,
    List<Map<String, Object?>> requirements = const [],
    List<Map<String, Object?>> sections = const [],
    List<Map<String, Object?>> slots = const [],
    List<Map<String, Object?>> teachers = const [],
    List<Map<String, Object?>> qualifications = const [],
    List<Map<String, Object?>> days = const [],
    List<Map<String, Object?>> teacherGrades = const [],
    List<Map<String, Object?>> teacherSubjectGrades = const [],
    List<Map<String, Object?>> subjectBlockedSlots = const [],
    List<Map<String, Object?>> teacherAvailability = const [],
    bool enforceQualifications = true,
  }) {
    final issues = <ConflictIssue>[];
    final sectionCells = <String, Map<String, Object?>>{};
    final teacherCells = <String, Map<String, Object?>>{};
    final roomCells = <String, Map<String, Object?>>{};
    final slotById = {for (final s in slots) _int(s['id']): s};
    final teacherById = {for (final t in teachers) _int(t['id']): t};
    final sectionById = <int, Map<String, Object?>>{
      for (final row in sections) _int(row['id']): row,
    };
    // Detailed requirement rows also carry the section's current maximum-day
    // setting. Use it as a compatibility fallback for callers that don't pass
    // the sections collection explicitly.
    for (final row in requirements) {
      final sectionId = _int(row['section_id']);
      if (!sectionById.containsKey(sectionId) && row.containsKey('section_max_daily_lessons')) {
        sectionById[sectionId] = <String, Object?>{
          'id': sectionId,
          'grade_id': row['grade_id'],
          'grade_name': row['grade_name'],
          'name': row['section_name'],
          'max_daily_lessons': row['section_max_daily_lessons'],
        };
      }
    }
    final assignmentPolicy = TeacherAssignmentPolicy(
      qualifications: qualifications,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
    );
    // Generated placements have no database IDs until they are saved. Treat
    // a missing ID as a distinct row when checking collisions; comparing
    // _int(null) == _int(null) would otherwise hide duplicates in pre-save scans.
    bool isDifferentEntry(Map<String, Object?> previous, Map<String, Object?> current) {
      final previousId = _nullableInt(previous['id']);
      final currentId = _nullableInt(current['id']);
      return previousId == null || currentId == null || previousId != currentId;
    }
    final blockedSubjectSlots = <String>{
      for (final row in subjectBlockedSlots) '${_int(row['subject_id'])}:${_int(row['slot_id'])}',
    };
    // The scheduler already respects this setting. The checker must apply the
    // exact same rule to manual edits, restored archives, and approval checks.
    final availabilityPolicy = TeacherAvailabilityPolicy(teacherAvailability);
    final activeLessonSlots = slots
        .where((s) => s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1)
        .toList()
      ..sort((a, b) => TimetableOrdering.compare(a, b));
    final activeDaysInOrder = days.where((d) => _int(d['is_active'], fallback: 1) == 1).toList()
      ..sort((a, b) => TimetableOrdering.compare(a, b));
    final activeDayRankById = <int, int>{
      for (var index = 0; index < activeDaysInOrder.length; index++)
        _int(activeDaysInOrder[index]['id']): index,
    };
    final activeDayById = {for (final day in days) _int(day['id']): day};
    final lessonRankBySlotId = <int, int>{
      for (var index = 0; index < activeLessonSlots.length; index++)
        _int(activeLessonSlots[index]['id']): index,
    };
    final activeDayCount = days.where((d) => _int(d['is_active'], fallback: 1) == 1).length;
    final requiredBySection = <int, int>{};
    for (final req in requirements) {
      final sectionId = _int(req['section_id']);
      requiredBySection[sectionId] = (requiredBySection[sectionId] ?? 0) +
          _int(req['weekly_lessons']).clamp(0, 1000).toInt();
    }
    bool hasNecessaryLateRepeat(Map<String, Object?> requirement) {
      final sectionId = _int(requirement['section_id']);
      final section = sectionById[sectionId];
      if (section == null) return false;
      return RequiredRepeatPolicy.allowsLatePeriodRepeat(
        requirement: requirement,
        section: section,
        activeDays: activeDaysInOrder,
        sectionWeeklyDemand: requiredBySection[sectionId] ?? 0,
        lessonSlots: activeLessonSlots,
        subjectBlockedSlots: subjectBlockedSlots,
      );
    }
    int entrySectionGradeId(Map<String, Object?> entry) {
      // Raw generated placements have no joined grade fields. The current
      // section record is authoritative, including after moving a section.
      final current = _int(sectionById[_int(entry['section_id'])]?['grade_id']);
      if (current > 0) return current;
      return _int(entry['section_grade_id'], fallback: _int(entry['grade_id']));
    }
    final gradeBySection = <int, int>{};
    for (final req in requirements) {
      final gradeId = _int(req['grade_id']);
      if (gradeId > 0) gradeBySection[_int(req['section_id'])] = gradeId;
    }
    for (final entry in entries) {
      // عند تعارض قيمة محفوظة قديمة مع قيمة صف الشعبة، نعتمد صف الشعبة.
      final gradeId = entrySectionGradeId(entry);
      if (gradeId > 0) gradeBySection[_int(entry['section_id'])] = gradeId;
    }
    final inactiveDays = <int>{for (final d in days) if (_int(d['is_active'], fallback: 1) == 0) _int(d['id'])};

    // تداخل الأوقات نفسها خطأ في إعداد الفترات حتى قبل توزيع الحصص.
    for (var i = 0; i < slots.length; i++) {
      final a = slots[i];
      final aStart = _minutes(a['start_time']);
      final aEnd = _minutes(a['end_time']);
      if (aStart == null || aEnd == null || aEnd <= aStart) continue;
      for (var j = i + 1; j < slots.length; j++) {
        final b = slots[j];
        final bStart = _minutes(b['start_time']);
        final bEnd = _minutes(b['end_time']);
        if (bStart == null || bEnd == null || bEnd <= bStart) continue;
        if (aStart < bEnd && bStart < aEnd) {
          issues.add(ConflictIssue(
            type: 'تداخل أوقات الفترات', severity: 'خطأ مانع',
            message: 'الفترتان ${a['name'] ?? a['id']} و${b['name'] ?? b['id']} متداخلتان زمنياً.',
            slotId: _int(b['id']), suggestion: 'عدّل بداية أو نهاية إحدى الفترتين حتى لا تتداخلا.',
          ));
        }
      }
    }

    for (final entry in entries) {
      final sectionId = _int(entry['section_id']);
      final teacherId = _nullableInt(entry['teacher_id']);
      final subjectId = _int(entry['subject_id']);
      final dayId = _int(entry['day_id']);
      final slotId = _int(entry['slot_id']);
      final roomId = _nullableInt(entry['room_id']);
      final sectionGradeId = entrySectionGradeId(entry);
      final storedGradeId = _int(entry['stored_grade_id']);
      final key = '$dayId:$slotId';
      if (days.isNotEmpty && !activeDayById.containsKey(dayId)) {
        issues.add(ConflictIssue(
          type: 'يوم غير معروف', severity: 'خطأ مانع',
          message: 'الحصة في ${entry['section_name'] ?? 'الشعبة $sectionId'} مرتبطة بيوم غير موجود في إعدادات الدوام (رقم $dayId).',
          sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId, subjectId: subjectId,
          suggestion: 'أعد إسناد الحصة إلى يوم دوام موجود، ثم أعد فحص الجدول.',
        ));
      }
      if (slots.isNotEmpty && !slotById.containsKey(slotId)) {
        issues.add(ConflictIssue(
          type: 'فترة غير معروفة', severity: 'خطأ مانع',
          message: 'الحصة في ${entry['section_name'] ?? 'الشعبة $sectionId'} مرتبطة بفترة غير موجودة في إعدادات الدوام (رقم $slotId).',
          sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId, subjectId: subjectId,
          suggestion: 'افتح الجدول وأعد إسناد الحصة إلى فترة دراسية موجودة.',
        ));
      }
      if (storedGradeId > 0 && sectionGradeId > 0 && storedGradeId != sectionGradeId) {
        final actualGradeName = entry['section_grade_name'] ?? entry['grade_name'] ?? 'رقم $sectionGradeId';
        final storedGradeName = entry['stored_grade_name'] ?? 'رقم $storedGradeId';
        issues.add(ConflictIssue(
          type: 'عدم تطابق صف الحصة المحفوظ', severity: 'تحذير',
          message: 'الحصة في ${entry['section_name'] ?? 'الشعبة $sectionId'} تابعة حالياً للصف $actualGradeName، لكن سجل الحصة القديم يحمل الصف $storedGradeName.',
          sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId, subjectId: subjectId,
          suggestion: 'فُحصت صلاحية المعلم وفق صف الشعبة الحالي. افتح هذه الخانة من الجدول وأعد حفظها لتحديث بيانات الصف القديمة؛ وإذا لم تكن هذه الحصة مقصودة لهذه الشعبة، صحح إسنادها.',
        ));
      }
      if (inactiveDays.contains(dayId)) {
        issues.add(ConflictIssue(
          type: 'يوم غير مفعل', severity: 'خطأ مانع',
          message: 'توجد حصة في يوم تم تعطيله من إعدادات المدرسة.',
          sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId, subjectId: subjectId,
          suggestion: 'انقل الحصة إلى يوم دوام فعّال أو أعد تفعيل اليوم.',
        ));
      }

      final lessonRank = lessonRankBySlotId[slotId];
      final configuredSection = sectionById[sectionId];
      final configuredDay = activeDayById[dayId];
      if (lessonRank != null && configuredSection != null &&
          configuredDay != null) {
        final limitForThisDay = SchoolTimetablePolicy.periodLimit(
          section: configuredSection, day: configuredDay,
          activeDays: activeDaysInOrder, lessonSlots: activeLessonSlots,
          weeklyDemand: requiredBySection[sectionId] ?? 0,
        );
        if (lessonRank >= limitForThisDay) {
          issues.add(ConflictIssue(
            type: 'حصة خارج العدد اليومي المخصص', severity: 'خطأ مانع',
            message: 'الحصة رقم ${lessonRank + 1} خارج حد '
                '${configuredDay['name']} المحدد للشعبة '
                '${configuredSection['section_name'] ?? configuredSection['name'] ?? sectionId}: '
                '$limitForThisDay حصص.',
            sectionId: sectionId, teacherId: teacherId, dayId: dayId,
            slotId: slotId, subjectId: subjectId,
            suggestion: 'انقل الحصة إلى فترة مسموحة، أو افتح إعداد الجدول '
                '> الحصص المخصصة لكل صف لتعديل عدد هذا اليوم.',
          ));
        }
      }
      if (lessonRank != null && lessonRank >= 6) {
        final section = sectionById[sectionId];
        final sixPeriodCapacity = activeDayCount * 6;
        final weeklyDemand = requiredBySection[sectionId] ?? 0;
        final day = activeDayById[dayId];
        final seventhIsJustified = lessonRank == 6 && section != null && day != null &&
            SchoolTimetablePolicy.canUseSeventhPeriod(
              section: section,
              day: day,
              activeDays: activeDaysInOrder,
              lessonSlots: activeLessonSlots,
              weeklyDemand: weeklyDemand,
            );
        final beyondSeventh = lessonRank > 6;
        if (beyondSeventh || !seventhIsJustified) {
          final wrongSixthGradeOrDay = section == null || day == null ||
              !SchoolTimetablePolicy.isSixthGrade(section) ||
              !SchoolTimetablePolicy.isSunday(day);
          // A day-specific user override, if present, takes priority over
          // the older automatic sixth-grade Sunday rule.
          issues.add(ConflictIssue(
            type: beyondSeventh
                ? 'تجاوز الحصة السابعة'
                : wrongSixthGradeOrDay
                    ? 'الحصة السابعة خارج الصف السادس يوم الأحد'
                    : 'الحصة السابعة دون اضطرار',
            severity: 'خطأ مانع',
            message: beyondSeventh
                ? 'توجد حصة في فترة تتجاوز السابعة للشعبة ${entry['section_name'] ?? sectionId}.'
                : wrongSixthGradeOrDay
                    ? 'الحصة السابعة للشعبة ${entry['section_name'] ?? sectionId} غير مسموحة إلا للصف السادس يوم الأحد.'
                    : 'الحصة السابعة للشعبة ${entry['section_name'] ?? sectionId} مستخدمة دون اضطرار مثبت؛ المطلوب $weeklyDemand حصة أسبوعياً، والسعة المعتادة ست حصص يومياً هي $sixPeriodCapacity.',
            sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId,
            subjectId: subjectId,
            suggestion: beyondSeventh
                ? 'انقل الحصة إلى إحدى الفترات الست الأولى؛ لا يسمح التطبيق بالحصة الثامنة أو بعدها.'
                : wrongSixthGradeOrDay
                    ? 'انقل الحصة إلى فترة أخرى؛ يسمح بالفترة السابعة للصف السادس يوم الأحد فقط، عند الحاجة وبوجود سبع فترات مفعّلة، مع بقاء الحد المعتاد ست حصص.'
                    : 'أعد الحصة إلى إحدى الفترات الست الأولى، أو راجع المتطلبات؛ تُدار السابعة كاستثناء تلقائي ولا يلزم رفع الحد المعتاد إلى 7.',
          ));
        }
      }
      final sectionKey = '$sectionId:$key';
      final previousSection = sectionCells[sectionKey];
      if (previousSection != null && isDifferentEntry(previousSection, entry)) {
        issues.add(ConflictIssue(
          type: 'تعارض الشعبة', severity: 'خطأ مانع',
          message: 'الشعبة ${entry['section_name'] ?? sectionId} لديها أكثر من حصة في الفترة نفسها.',
          sectionId: sectionId, dayId: dayId, slotId: slotId,
          suggestion: 'انقل إحدى الحصتين إلى فترة فارغة.',
        ));
      } else {
        sectionCells[sectionKey] = entry;
      }

      if (teacherId != null) {
        final teacherKey = '$teacherId:$key';
        final previousTeacher = teacherCells[teacherKey];
        if (previousTeacher != null && isDifferentEntry(previousTeacher, entry)) {
          final teacherDisplayName = entry['teacher_name'] ?? teacherById[teacherId]?['name'] ?? teacherId;
          final previousSectionId = _int(previousTeacher['section_id']);
          final previousSectionName = previousTeacher['section_name'] ??
              sectionById[previousSectionId]?['section_name'] ??
              sectionById[previousSectionId]?['name'] ?? 'الشعبة $previousSectionId';
          final currentSectionName = entry['section_name'] ??
              sectionById[sectionId]?['section_name'] ??
              sectionById[sectionId]?['name'] ?? 'الشعبة $sectionId';
          final dayDisplayName = entry['day_name'] ?? activeDayById[dayId]?['name'] ?? 'اليوم $dayId';
          final slotDisplayName = entry['slot_name'] ?? slotById[slotId]?['name'] ?? 'الحصة ${lessonRankBySlotId[slotId] == null ? slotId : lessonRankBySlotId[slotId]! + 1}';
          issues.add(ConflictIssue(
            type: 'تعارض المعلم',
            severity: 'خطأ مانع',
            message: 'المعلم $teacherDisplayName مسند إلى الشعبتين $previousSectionName و$currentSectionName يوم $dayDisplayName، الفترة $slotDisplayName. لا يجوز تكليف المعلم بأكثر من شعبة في الوقت نفسه، بما فيها الحصة السادسة.',
            sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId,
            subjectId: subjectId,
            suggestion: 'انقل إحدى الحصتين إلى فترة متاحة أو اختر معلماً آخر مؤهلاً للمادة والصف ثم أعد الفحص.',
          ));
        } else {
          teacherCells[teacherKey] = entry;
        }
        if (enforceQualifications && !assignmentPolicy.isSubjectQualified(teacherId, subjectId)) {
          issues.add(ConflictIssue(
            type: 'تأهيل المعلم', severity: 'خطأ مانع',
            message: 'المعلم ${entry['teacher_name'] ?? teacherId} غير مسجل ضمن مؤهلي مادة ${entry['subject_name'] ?? subjectId}.',
            sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId,
            subjectId: subjectId, suggestion: 'أضف تأهيل المعلم لهذه المادة أو اختر معلماً مؤهلاً.',
          ));
        }
        if (!availabilityPolicy.isAvailable(teacherId: teacherId, dayId: dayId, slotId: slotId, gradeId: entrySectionGradeId(entry), subjectId: subjectId)) {
          issues.add(ConflictIssue(
            type: 'المعلم غير متاح في الفترة', severity: 'خطأ مانع',
            message: 'المعلم ${entry['teacher_name'] ?? teacherId} محدد على أنه غير متاح في ${entry['day_name'] ?? 'اليوم $dayId'}، ${entry['slot_name'] ?? 'الفترة $slotId'}.',
            sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId,
            subjectId: subjectId,
            suggestion: 'انقل الحصة إلى فترة متاحة لهذا المعلم أو اختر معلماً مؤهلاً متاحاً.',
          ));
        }
        final gradeId = sectionGradeId > 0 ? sectionGradeId : (gradeBySection[sectionId] ?? 0);
        if (enforceQualifications && gradeId <= 0) {
          final dayName = (entry['day_name'] ?? '').toString().trim();
          final slotName = (entry['slot_name'] ?? '').toString().trim();
          final when = [if (dayName.isNotEmpty) 'يوم $dayName', if (slotName.isNotEmpty) 'الفترة $slotName'].join('، ');
          issues.add(ConflictIssue(
            type: 'تعذر تحديد صف الشعبة', severity: 'خطأ مانع',
            message: 'لا يمكن التحقق من صلاحية ${entry['teacher_name'] ?? 'المعلم $teacherId'} لمادة ${entry['subject_name'] ?? subjectId} لأن صف الشعبة غير محدد${when.isEmpty ? '' : '، $when'}.',
            sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId,
            subjectId: subjectId,
            suggestion: 'تحقق من ربط الشعبة بصف صحيح في إدارة البيانات، ثم أعد فحص الجدول.',
          ));
        } else if (enforceQualifications && !assignmentPolicy.isGradeAllowed(teacherId, subjectId, gradeId)) {
          final matchingRequirements = requirements.where((r) => _int(r['section_id']) == sectionId).toList();
          final req = matchingRequirements.isEmpty ? null : matchingRequirements.first;
          final gradeName = entry['section_grade_name'] ?? entry['grade_name'] ?? req?['grade_name'] ?? 'رقم $gradeId';
          final dayName = (entry['day_name'] ?? '').toString().trim();
          final slotName = (entry['slot_name'] ?? '').toString().trim();
          final when = [if (dayName.isNotEmpty) 'يوم $dayName', if (slotName.isNotEmpty) 'الفترة $slotName'].join('، ');
          issues.add(ConflictIssue(
            type: 'الصف غير مسموح للمعلم', severity: 'خطأ مانع',
            message: 'المعلم ${entry['teacher_name'] ?? teacherId} غير مسموح له بتدريس مادة ${entry['subject_name'] ?? subjectId} في الصف $gradeName، ضمن الشعبة ${entry['section_name'] ?? sectionId}${when.isEmpty ? '' : '، $when'}.',
            sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId,
            subjectId: subjectId,
            suggestion: 'تحقق من صلاحية هذه المادة تحديداً لهذا الصف من «البيانات > المعلمون». إذا كان المعلم لا يدرّس هذه الحصة، غيّر المعلم المسند إليها من صفحة الجدول.',
          ));
        }
      } else {
        issues.add(ConflictIssue(
          type: 'حصة بلا معلم', severity: 'تحذير',
          message: 'حصة ${entry['subject_name'] ?? subjectId} في ${entry['section_name'] ?? sectionId} غير مسندة إلى معلم.',
          sectionId: sectionId, dayId: dayId, slotId: slotId, subjectId: subjectId,
          suggestion: 'أسند الحصة إلى معلم مؤهل قبل اعتماد الجدول.',
        ));
      }

      if (roomId != null) {
        final roomKey = '$roomId:$key';
        final priorRoom = roomCells[roomKey];
        if (priorRoom != null && isDifferentEntry(priorRoom, entry)) {
          issues.add(ConflictIssue(
            type: 'تعارض القاعة', severity: 'خطأ مانع',
            message: 'القاعة ${entry['room_name'] ?? roomId} مستخدمة في حصتين متزامنتين.',
            sectionId: sectionId, dayId: dayId, slotId: slotId,
            suggestion: 'اختر قاعة أخرى أو انقل إحدى الحصتين.',
          ));
        } else {
          roomCells[roomKey] = entry;
        }
      }

      final slot = slotById[slotId];
      if (slot != null && (slot['kind'] != 'lesson' || _int(slot['is_available'], fallback: 1) == 0)) {
        issues.add(ConflictIssue(
          type: 'فترة غير متاحة', severity: 'خطأ مانع',
          message: 'الحصة مدرجة في ${slot['name'] ?? 'فترة غير متاحة'} وليست فترة تدريس متاحة.',
          sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId,
          subjectId: subjectId, suggestion: 'انقل الحصة إلى فترة دراسية متاحة.',
        ));
      }
      if (blockedSubjectSlots.contains('$subjectId:$slotId')) {
        final sectionLabel = entry['section_name'] ?? 'الشعبة $sectionId';
        issues.add(ConflictIssue(
          type: 'المادة في فترة ممنوعة', severity: 'خطأ مانع',
          message: 'مادة ${entry['subject_name'] ?? subjectId} في ${slot?['name'] ?? 'الفترة $slotId'} غير مسموحة للشعبة $sectionLabel.',
          sectionId: sectionId, teacherId: teacherId, dayId: dayId, slotId: slotId, subjectId: subjectId,
          suggestion: 'انقل المادة إلى فترة أخرى أو عدّل الفترات الممنوعة للمادة من «البيانات > المواد».',
        ));
      }
    }

    // Check the actual daily count for each section. This was previously only
    // enforced by the generator, so manual placement could silently exceed it.
    final sectionDailyCounts = <String, int>{};
    for (final entry in entries) {
      final sectionId = _int(entry['section_id']);
      final dayId = _int(entry['day_id']);
      final key = '$sectionId:$dayId';
      sectionDailyCounts[key] = (sectionDailyCounts[key] ?? 0) + 1;
    }
    for (final item in sectionDailyCounts.entries) {
      final parts = item.key.split(':').map(int.parse).toList();
      final sectionId = parts[0];
      final dayId = parts[1];
      final section = sectionById[sectionId];
      final configuredLimit = _int(section?['max_daily_lessons'], fallback: 6);
      final rankCount = item.value;
      final day = activeDayById[dayId];
      final effectiveLimit = section != null && day != null
          ? SchoolTimetablePolicy.dailyLimit(
              section: section, day: day, activeDays: activeDaysInOrder,
              lessonSlots: activeLessonSlots,
              weeklyDemand: requiredBySection[sectionId] ?? 0,
            )
          : configuredLimit;
      if (rankCount > effectiveLimit) {
        issues.add(ConflictIssue(
          type: 'تجاوز الحد اليومي للشعبة', severity: 'خطأ مانع',
          message: 'الشعبة ${section?['name'] ?? section?['section_name'] ?? sectionId} لديها $rankCount حصص في اليوم رقم $dayId، بينما الحد المحدد $effectiveLimit.',
          sectionId: sectionId, dayId: dayId,
          suggestion: 'انقل الحصص الزائدة إلى أيام أخرى أو صحح الحد اليومي للشعبة إذا كانت الإعدادات خاطئة.',
        ));
      }
    }

    // مقارنة الحصص الفعلية مع الحصص المطلوبة لكل شعبة ومادة.
    final actual = <String, int>{};
    for (final entry in entries) {
      final key = '${_int(entry['section_id'])}:${_int(entry['subject_id'])}';
      actual[key] = (actual[key] ?? 0) + 1;
    }
    for (final req in requirements) {
      final sectionId = _int(req['section_id']);
      final subjectId = _int(req['subject_id']);
      final required = _int(req['weekly_lessons']).clamp(0, 1000).toInt();
      final placed = actual['$sectionId:$subjectId'] ?? 0;
      // عدم وجود متطلب أو تسجيل صفر حصص يعني أن المادة غير مطلوبة لهذه الشعبة؛
      // لا نعرض تحذيراً عن مادة لم يسجل المستخدم أنها تُدرّس في هذا الصف.
      if (required == 0 && placed == 0) continue;
      final stage = (req['stage_name'] ?? '').toString().trim();
      final grade = (req['grade_name'] ?? '').toString().trim();
      final section = (req['section_name'] ?? 'الشعبة $sectionId').toString().trim();
      final location = [
        if (stage.isNotEmpty) 'المرحلة $stage',
        if (grade.isNotEmpty) 'الصف $grade',
        'الشعبة $section',
      ].join('، ');
      final subject = (req['subject_name'] ?? 'المادة $subjectId').toString();
      final label = '$location، مادة $subject';
      if (placed < required) {
        final subjectTeacherIds = qualifications.where((q) => _int(q['subject_id']) == subjectId)
            .map((q) => _int(q['teacher_id'])).toSet();
        final reqGradeId = _int(req['grade_id']);
        final teachersAllowedForGrade = subjectTeacherIds.where((teacherId) =>
          reqGradeId > 0 && assignmentPolicy.isSubjectQualified(teacherId, subjectId) &&
            assignmentPolicy.isGradeAllowed(teacherId, subjectId, reqGradeId)).toList();
        final availableSubjectSlots = activeLessonSlots.where((slot) =>
            !blockedSubjectSlots.contains('$subjectId:${_int(slot['id'])}')).length;
        final blockedCount = activeLessonSlots.length - availableSubjectSlots;
        final repeatAllowed = _int(req['allow_same_day']) == 1;
        final configuredSubjectDaily = _int(req['max_daily_lessons'], fallback: 2);
        final necessaryLateRepeat = hasNecessaryLateRepeat(req);
        final subjectDailyLimit = repeatAllowed
            ? (configuredSubjectDaily > 0 ? configuredSubjectDaily : 1)
            : (necessaryLateRepeat ? 2 : 1);
        final effectiveSubjectDaily = availableSubjectSlots < subjectDailyLimit
            ? availableSubjectSlots
            : subjectDailyLimit;
        final weeklyRuleCapacity = activeDayCount * effectiveSubjectDaily;
        final String? capacityGuidance = activeDayCount > 0 && required > weeklyRuleCapacity
            ? (!repeatAllowed && required > activeDayCount
                ? 'لا توجد سعة لتوزيع الحصة الإضافية. يلزم تفعيل الفترة السادسة والسماح للمادة بها (أو الفترة السابعة إذا كانت مسموحة للشعبة)، مع فترة عادية أخرى متاحة للمادة في اليوم نفسه. تحقق من عدد الفترات وحد الشعبة والفترات الممنوعة. '
                : 'قواعد المادة والفترات الممنوعة تسمح بحد أقصى $weeklyRuleCapacity حصص أسبوعياً، وهو أقل من العدد المطلوب $required. راجع حد التكرار اليومي والفترات الممنوعة. ')
            : (necessaryLateRepeat && placed < required
                ? 'المطلوب $required حصة عبر $activeDayCount أيام؛ يمكن استكمال الحصة الزائدة بتكرار المادة في الفترة السادسة (أو السابعة إن كانت مسموحة) في يوم واحد. أعد التوزيع لتطبيق هذا الاستثناء. '
                : null);
        final String causeSuggestion;
        if (subjectTeacherIds.isEmpty) {
          causeSuggestion = 'لا يوجد معلم مسجّل لاختصاص مادة $subject. إذا كانت المادة مطلوبة لهذه الشعبة، افتح «البيانات > المعلمون» وأضفها إلى اختصاص معلم، وتأكد من تحديد الصف لهذه المادة. وإذا لم تكن المادة مقررة لهذا الصف، افتح «البيانات > الحصص المطلوبة» وتأكد من عدم وجود متطلب لها. هذا يوضح سبب بقاء الحصص المطلوبة دون توزيع.';
        } else if (teachersAllowedForGrade.isEmpty) {
          causeSuggestion = 'يوجد معلمون مؤهلون لمادة $subject، لكن لا يوجد بينهم معلم مسموح له بتدريس الصف $grade في هذه الشعبة. افتح «البيانات > المعلمون» وحدد هذا الصف لدى معلم مناسب أو فعّل «جميع الصفوف».';
        } else if (activeLessonSlots.isNotEmpty && blockedCount >= activeLessonSlots.length) {
          causeSuggestion = 'مادة $subject ممنوعة في جميع فترات التدريس المتاحة. افتح «البيانات > المواد» واسمح بفترة تدريس واحدة على الأقل.';
        } else {
          causeSuggestion = 'المادة مسجلة كمطلوبة لهذه الشعبة، لكن لم تُوزّع جميع حصصها. أكمل ${required - placed} حصة متبقية، ثم أعد فحص الجدول.';
        }
        final suggestion = '${capacityGuidance ?? ''}$causeSuggestion إذا كانت مادة $subject غير مقررة فعلاً في $location، فصحّح المتطلب من «البيانات > الحصص المطلوبة» واحذف المتطلب لهذه الشعبة أو اجعل العدد 0. أما إذا كانت مقررة، فأبقِ المتطلب وأصلح السبب المذكور أعلاه. المواد التي لا يوجد لها متطلب مسجل أو التي سجّل عددها 0 لا تُعد نقصاً.';
        issues.add(ConflictIssue(
          type: 'نقص الحصص', severity: 'خطأ مانع',
          message: '$label: المطلوب $required حصة أسبوعياً، الموزع $placed، المتبقي ${required - placed}.',
          sectionId: sectionId, subjectId: subjectId,
          suggestion: suggestion,
        ));
      } else if (placed > required) {
        issues.add(ConflictIssue(
          type: 'حصص زائدة', severity: 'خطأ مانع',
          message: '$label: المطلوب $required حصة أسبوعياً، الموزع $placed، الزائد ${placed - required}.',
          sectionId: sectionId, subjectId: subjectId,
          suggestion: 'احذف أو أعد إسناد ${placed - required} حصة زائدة، أو صحّح العدد المطلوب إذا كان المنهج يتطلب ذلك.',
        ));
      }
    }

    // Reject malformed demand records at the same layer used by the conflict
    // screen and approval gate; duplicate keys can otherwise make scheduler
    // targets overwrite one another and create misleading lesson counts.
    final requirementRowsByKey = <String, List<Map<String, Object?>>>{};
    for (final req in requirements) {
      final sectionId = _int(req['section_id']);
      final subjectId = _int(req['subject_id']);
      final weekly = _int(req['weekly_lessons']);
      if (weekly < 0) {
        issues.add(ConflictIssue(
          type: 'عدد حصص مطلوب غير صالح', severity: 'خطأ مانع',
          message: 'متطلب ${req['subject_name'] ?? 'المادة $subjectId'} في ${req['section_name'] ?? 'الشعبة $sectionId'} يحتوي على عدد حصص سالب ($weekly).',
          sectionId: sectionId, subjectId: subjectId,
          suggestion: 'صحح عدد الحصص الأسبوعية إلى صفر أو عدد موجب من صفحة الحصص المطلوبة.',
        ));
      }
      (requirementRowsByKey['$sectionId:$subjectId'] ??= <Map<String, Object?>>[]).add(req);
    }
    for (final item in requirementRowsByKey.entries) {
      if (item.value.length < 2) continue;
      final sample = item.value.first;
      final sectionId = _int(sample['section_id']);
      final subjectId = _int(sample['subject_id']);
      final total = item.value.fold<int>(0, (sum, row) => sum + _int(row['weekly_lessons']));
      issues.add(ConflictIssue(
        type: 'متطلبات مكررة', severity: 'خطأ مانع',
        message: 'توجد ${item.value.length} سجلات لمادة ${sample['subject_name'] ?? subjectId} في ${sample['section_name'] ?? 'الشعبة $sectionId'}، ومجموعها $total حصة أسبوعياً.',
        sectionId: sectionId, subjectId: subjectId,
        suggestion: 'احتفظ بمتطلب واحد للمادة في هذه الشعبة، واجمع العدد الأسبوعي الصحيح فيه ثم أعد الفحص.',
      ));
    }

    // اكتشاف تجاوز مجموع الحصص المطلوبة سعة الجدول الأسبوعي للشعبة.
    // يعتمد فقط على المتطلبات المسجلة لهذه الشعبة؛ لا يفترض مواداً منهجية غير مدخلة.
    final requestedBySection = <int, int>{};
    final sectionRequirementSample = <int, Map<String, Object?>>{};
    for (final req in requirements) {
      final sectionId = _int(req['section_id']);
      requestedBySection[sectionId] = (requestedBySection[sectionId] ?? 0) +
          _int(req['weekly_lessons']).clamp(0, 1000).toInt();
      sectionRequirementSample.putIfAbsent(sectionId, () => req);
    }
    final lessonSlotCount = slots.where((s) =>
        s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1).length;
    if (activeDayCount > 0 && lessonSlotCount > 0) {
      for (final item in requestedBySection.entries) {
        final sample = sectionRequirementSample[item.key]!;
        final sectionPolicy = sectionById[item.key] ?? <String, Object?>{
          'id': item.key,
          'grade_name': sample['grade_name'],
          'stage_name': sample['stage_name'],
          'max_daily_lessons': sample['section_max_daily_lessons'],
        };
        final capacity = SchoolTimetablePolicy.weeklyCapacity(
          section: sectionPolicy,
          activeDays: activeDaysInOrder,
          lessonSlots: activeLessonSlots,
          weeklyDemand: item.value,
        );
        final effectiveDailyLimit = SchoolTimetablePolicy.normalDailyLimit(
          section: sectionPolicy,
          lessonSlotCount: lessonSlotCount,
        );
        if (item.value <= capacity) continue;
        final stage = (sample['stage_name'] ?? '').toString().trim();
        final grade = (sample['grade_name'] ?? '').toString().trim();
        final section = (sample['section_name'] ?? 'الشعبة ${item.key}').toString().trim();
        final location = [if (stage.isNotEmpty) 'المرحلة $stage', if (grade.isNotEmpty) 'الصف $grade', 'الشعبة $section'].join('، ');
        issues.add(ConflictIssue(
          type: 'الحصص المطلوبة تتجاوز سعة الشعبة', severity: 'خطأ مانع',
          message: '$location: مجموع المواد المسجلة ${item.value} حصة أسبوعياً، بينما سعة الدوام $capacity خانة فقط؛ الحد المعتاد $effectiveDailyLimit حصص يومياً، والحصة السابعة محصورة بالصف السادس يوم الأحد عند الحاجة.',
          sectionId: item.key,
          suggestion: 'راجع مجموع المواد في «البيانات > الحصص المطلوبة». إذا كانت الأعداد صحيحة، أضف فترات تدريس متاحة أو عدّل حد الحصص اليومي؛ لا يمكن ملء جدول كامل ما دام المطلوب أكبر من السعة.',
        ));
      }
    }

    // حدود النصاب الأسبوعي للمعلمين.
    final weeklyCounts = <int, int>{};
    final dailyCounts = <String, int>{};
    final teacherDaySlots = <String, List<int>>{};
    final subjectDailyCounts = <String, int>{};
    final requirementByKey = <String, Map<String, Object?>>{
      for (final r in requirements) '${_int(r['section_id'])}:${_int(r['subject_id'])}': r,
    };
    for (final entry in entries) {
      final teacherId = _nullableInt(entry['teacher_id']);
      if (teacherId == null) continue;
      final key = '$teacherId:${_int(entry['day_id'])}';
      dailyCounts[key] = (dailyCounts[key] ?? 0) + 1;
      weeklyCounts[teacherId] = (weeklyCounts[teacherId] ?? 0) + 1;
      // Stored positions are sorting hints, not consecutive-period numbers:
      // older backups use position=99 for both the sixth and seventh lessons.
      // Use the same normalized lesson ranks as the scheduling engines.
      final rank = lessonRankBySlotId[_int(entry['slot_id'])];
      if (rank != null) (teacherDaySlots[key] ??= <int>[]).add(rank);
    }
    for (final item in weeklyCounts.entries) {
      final teacher = teacherById[item.key];
      final limit = teacher == null ? 0 : _int(teacher['weekly_load']);
      if (limit > 0 && item.value > limit) {
        issues.add(ConflictIssue(
          type: 'تجاوز النصاب الأسبوعي', severity: 'تحذير',
          message: 'المعلم ${teacher?['name'] ?? item.key} لديه ${item.value} حصة، متجاوزاً النصاب المسجل ${limit}.',
          teacherId: item.key, suggestion: 'أعد توزيع بعض الحصص أو عدّل النصاب إذا كانت سياسة المدرسة تسمح.',
        ));
      }
    }
    final subjectDailyRanks = <String, List<int>>{};
    final subjectDailySlotIds = <String, List<int>>{};
    for (final entry in entries) {
      final key = '${_int(entry['section_id'])}:${_int(entry['subject_id'])}:${_int(entry['day_id'])}';
      subjectDailyCounts[key] = (subjectDailyCounts[key] ?? 0) + 1;
      final slotId = _int(entry['slot_id']);
      final rank = lessonRankBySlotId[slotId];
      if (rank != null) {
        (subjectDailyRanks[key] ??= <int>[]).add(rank);
        (subjectDailySlotIds[key] ??= <int>[]).add(slotId);
      }
    }
    for (final req in requirements) {
      final weekly = _int(req['weekly_lessons']);
      if (weekly < 5) continue;
      final sectionId = _int(req['section_id']);
      final subjectId = _int(req['subject_id']);
      for (final day in activeDaysInOrder) {
        final dayId = _int(day['id']);
        final key = '$sectionId:$subjectId:$dayId';
        if ((subjectDailyCounts[key] ?? 0) > 0) continue;
        issues.add(ConflictIssue(
          type: 'توزيع المادة على كل أيام الأسبوع',
          severity: 'خطأ مانع',
          message: 'مادة ${req['subject_name'] ?? 'المادة $subjectId'} في ${req['grade_name'] ?? ''}، الشعبة ${req['section_name'] ?? sectionId} مطلوبة 5 حصص أسبوعياً أو أكثر، لكنها لا تظهر يوم ${day['name'] ?? dayId}. يجب أن تحتوي كل أيام الدوام على حصة واحدة منها على الأقل.',
          sectionId: sectionId,
          dayId: dayId,
          subjectId: subjectId,
          suggestion: 'انقل حصة من يوم فيه تكرار إلى يوم ${day['name'] ?? dayId}، مع التأكد من توفر المعلم والخانة وعدم إنشاء تعارض جديد.',
        ));
      }
    }
    for (final item in subjectDailyCounts.entries) {
      final parts = item.key.split(':').map(int.parse).toList();
      final req = requirementByKey['${parts[0]}:${parts[1]}'];
      if (req == null) continue;
      final maxDaily = _int(req['max_daily_lessons'], fallback: 2);
      final repeatAllowed = _int(req['allow_same_day']) == 1;
      final necessaryLateRepeat = hasNecessaryLateRepeat(req);
      final limit = repeatAllowed ? (maxDaily <= 0 ? 1 : maxDaily) : (necessaryLateRepeat ? 2 : 1);
      if (item.value > limit) {
        issues.add(ConflictIssue(
          type: 'تكرار المادة يومياً', severity: 'خطأ مانع',
          message: 'تكررت ${req['subject_name'] ?? 'المادة ${parts[1]}'} في الشعبة ${req['section_name'] ?? parts[0]} ${item.value} مرات في اليوم نفسه (الحد $limit).',
          sectionId: parts[0], subjectId: parts[1], dayId: parts[2],
          suggestion: 'وزّع حصص المادة على أيام مختلفة أو راجع حد التكرار اليومي.',
        ));
      } else if (necessaryLateRepeat && item.value > 1 &&
          !(subjectDailyRanks[item.key] ?? const <int>[]).any((rank) => rank >= 5 && rank <= 6)) {
        final ranks = subjectDailyRanks[item.key] ?? const <int>[];
        final slotIds = subjectDailySlotIds[item.key] ?? const <int>[];
        var latestRank = -1;
        var misplacedSlotId = 0;
        for (var i = 0; i < ranks.length && i < slotIds.length; i++) {
          if (ranks[i] > latestRank) {
            latestRank = ranks[i];
            misplacedSlotId = slotIds[i];
          }
        }
        issues.add(ConflictIssue(
          type: 'تكرار المادة خارج الفترة السادسة أو السابعة', severity: 'خطأ مانع',
          message: 'تحتاج مادة ${req['subject_name'] ?? 'المادة ${parts[1]}'} إلى تكرار استثنائي لإكمال متطلبها الأسبوعي، لكن التكرار في اليوم ${parts[2]} لا يقع في الفترة السادسة أو السابعة المسموحة.',
          sectionId: parts[0], subjectId: parts[1], dayId: parts[2],
          slotId: misplacedSlotId > 0 ? misplacedSlotId : null,
          suggestion: 'انقل إحدى حصص المادة المكررة إلى الفترة السادسة؛ لا تستخدم السابعة إلا إذا كانت سياسة الشعبة تسمح بها.',
        ));
      }
    }
    for (final item in teacherDaySlots.entries) {
      final parts = item.key.split(':');
      final teacherId = int.parse(parts[0]);
      final dayId = int.parse(parts[1]);
      final teacher = teacherById[teacherId];
      final maxConsecutive = teacher == null ? 0 : _int(teacher['max_consecutive_lessons']);
      if (maxConsecutive > 0) {
        final positions = [...item.value]..sort();
        var run = positions.isEmpty ? 0 : 1;
        var longest = run;
        for (var i = 1; i < positions.length; i++) {
          run = positions[i] == positions[i - 1] + 1 ? run + 1 : 1;
          if (run > longest) longest = run;
        }
        if (longest > maxConsecutive) {
          issues.add(ConflictIssue(
            type: 'حصص متتالية زائدة', severity: 'تحذير',
            message: 'لدى المعلم ${teacher?['name'] ?? teacherId} ${longest} حصص متتالية في اليوم رقم $dayId، والحد $maxConsecutive.',
            teacherId: teacherId, dayId: dayId, suggestion: 'أدخل فترة فاصلة أو أعد توزيع حصة على يوم آخر.',
          ));
        }
      }
    }
    for (final item in dailyCounts.entries) {
      final parts = item.key.split(':');
      final teacherId = int.parse(parts[0]);
      final dayId = int.parse(parts[1]);
      final teacher = teacherById[teacherId];
      final limit = teacher == null ? 0 : _int(teacher['max_daily_lessons']);
      if (limit > 0 && item.value > limit) {
        issues.add(ConflictIssue(
          type: 'تجاوز الحد اليومي', severity: 'تحذير',
          message: 'تجاوز المعلم ${teacher?['name'] ?? teacherId} الحد اليومي في اليوم رقم $dayId (${item.value} من $limit).',
          teacherId: teacherId, dayId: dayId,
          suggestion: 'انقل بعض حصص المعلم إلى يوم آخر.',
        ));
      }
    }

    // A balance advisory, not a blocking conflict: a subject placed in the
    // exact same period on adjacent active school days is valid but less fair.
    final subjectDaySlotEntry = <String, Map<String, Object?>>{};
    for (final entry in entries) {
      final dayRank = activeDayRankById[_int(entry['day_id'])];
      final slotRank = lessonRankBySlotId[_int(entry['slot_id'])];
      if (dayRank == null || slotRank == null) continue;
      final key = '${_int(entry['section_id'])}:${_int(entry['subject_id'])}:$dayRank:$slotRank';
      subjectDaySlotEntry.putIfAbsent(key, () => entry);
    }
    for (final item in subjectDaySlotEntry.entries) {
      final parts = item.key.split(':').map(int.parse).toList();
      final sectionId = parts[0];
      final subjectId = parts[1];
      final dayRank = parts[2];
      final slotRank = parts[3];
      if (dayRank + 1 >= activeDaysInOrder.length) continue;
      final nextKey = '$sectionId:$subjectId:${dayRank + 1}:$slotRank';
      final nextEntry = subjectDaySlotEntry[nextKey];
      if (nextEntry == null) continue;
      final currentEntry = item.value;
      final firstDay = activeDayById[_int(currentEntry['day_id'])];
      final secondDay = activeDayById[_int(nextEntry['day_id'])];
      final period = slotById[_int(currentEntry['slot_id'])];
      final periodName = (period?['name'] ?? 'رقم ${slotRank + 1}').toString();
      final firstDayName = (firstDay?['name'] ?? 'رقم ${_int(currentEntry['day_id'])}').toString();
      final secondDayName = (secondDay?['name'] ?? 'رقم ${_int(nextEntry['day_id'])}').toString();
      final subjectName = currentEntry['subject_name'] ?? 'المادة $subjectId';
      final sectionName = currentEntry['section_name'] ?? 'الشعبة $sectionId';
      issues.add(ConflictIssue(
        type: 'تكرار توقيت المادة في أيام متتالية',
        severity: 'ملاحظة',
        message: 'مادة $subjectName في $sectionName تقع في الفترة $periodName يوم $firstDayName ويوم $secondDayName على التوالي. هذا ليس تعارضاً مانعاً، لكنه يقلل تنويع توزيع المواد خلال الأسبوع.',
        sectionId: sectionId,
        dayId: _int(nextEntry['day_id']),
        slotId: _int(nextEntry['slot_id']),
        subjectId: subjectId,
        suggestion: 'يفضّل نقل إحدى الحصتين إلى فترة مختلفة إذا توفرت خلية آمنة، مع الحفاظ على صلاحيات المعلم وبقية قيود الجدول.',
      ));
    }
    return issues;
  }

  static int? _minutes(Object? value) {
    if (value is! String) return null;
    final parts = value.split(':');
    if (parts.length != 2) return null;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null || hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
    return hour * 60 + minute;
  }
  static int _int(Object? value, {int fallback = 0}) => value is int ? value : int.tryParse('$value') ?? fallback;
  static int? _nullableInt(Object? value) => value == null ? null : _int(value);
}
