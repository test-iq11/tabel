import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';

void main() {
  final sections = <Map<String, Object?>>[
    {
      'id': 1,
      'grade_id': 1,
      'grade_name': 'الأول',
      'section_name': 'أ',
      'max_daily_lessons': 5,
    },
  ];
  final requirements = <Map<String, Object?>>[
    {
      'section_id': 1,
      'subject_id': 10,
      'subject_name': 'العلوم',
      'weekly_lessons': 1,
    },
  ];
  final teachers = <Map<String, Object?>>[
    {
      'id': 7,
      'name': 'معلم لا يمتلك صلاحية الصف',
      'weekly_load': 5,
      'max_daily_lessons': 5,
    },
  ];
  final qualifications = <Map<String, Object?>>[
    {'teacher_id': 7, 'subject_id': 10},
  ];
  final teacherSubjectGrades = <Map<String, Object?>>[
    {'teacher_id': 9, 'subject_id': 11, 'grade_id': 1},
  ];
  final days = <Map<String, Object?>>[
    {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
  ];
  final slots = <Map<String, Object?>>[
    {
      'id': 1,
      'name': 'الأولى',
      'position': 0,
      'kind': 'lesson',
      'is_available': 1,
    },
  ];

  SchedulerResult run({bool feasibilityOnly = false}) =>
      const AutoSchedulerService(nodeLimit: 5000).generate(
        sections: sections,
        requirements: requirements,
        teachers: teachers,
        qualifications: qualifications,
        teacherSubjectGrades: teacherSubjectGrades,
        days: days,
        slots: slots,
        feasibilityOnly: feasibilityOnly,
      );

  test('a missing lesson has one actionable explanation, not two errors', () {
    final result = run();
    expect(result.placements, isEmpty);
    expect(result.complete, isFalse);
    expect(result.unscheduled, hasLength(1));
    expect(result.unscheduled.single, contains('لا يوجد معلم مسموح له'));
    expect(result.provenInfeasible, isTrue);
  });

  test('feasibility-only preserves the independent mathematical proof', () {
    final result = run(feasibilityOnly: true);
    expect(result.provenInfeasible, isTrue);
    expect(result.unscheduled, hasLength(1));
    expect(result.unscheduled.single, contains('نقص 1'));
  });
}
