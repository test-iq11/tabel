import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/lesson_swap_service.dart';
import 'package:iraqi_school_timetable/services/reference_office_service.dart';
import 'package:iraqi_school_timetable/services/section_time_domain_flow.dart';
import 'package:iraqi_school_timetable/services/complete_schedule_solver.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';

Map<String, Object?> fixture() => Map<String, Object?>.from(
  jsonDecode(File('test/fixtures/backup_school_181.json').readAsStringSync()) as Map,
);

void main() {
  test('A4 landscape and portrait are respected in Word and Excel', () {
    const exporter = ReferenceOfficeService();
    const rows = <List<String>>[
      ['المعلم', 'النصاب', 'الموزع'],
      ['المعلم الأول', '20', '19'],
    ];
    for (final orientation in ['portrait', 'landscape']) {
      final word = ZipDecoder().decodeBytes(exporter.list(
        title: 'نصاب المعلم', schoolName: 'مدرستي', rows: rows,
        word: true, paper: 'A4', orientation: orientation,
      ));
      final xml = utf8.decode(word.findFile('word/document.xml')!.readBytes()!);
      expect(xml, contains('w:orient="$orientation"'));
      expect(xml, contains(orientation == 'portrait'
          ? 'w:w="11906" w:h="16838"' : 'w:w="16838" w:h="11906"'));
      final excel = ZipDecoder().decodeBytes(exporter.list(
        title: 'نصاب المعلم', schoolName: 'مدرستي', rows: rows,
        word: false, paper: 'A4', orientation: orientation,
      ));
      final sheet = utf8.decode(excel.findFile('xl/worksheets/sheet1.xml')!.readBytes()!);
      expect(sheet, contains('paperSize="9" orientation="$orientation"'));
    }
  });

  test('fast swap preview does not confuse a candidate with a validated swap', () {
    const swaps = LessonSwapService();
    final base = <String, Object?>{
      'id': 1, 'version_id': 8, 'section_id': 7,
      'day_id': 3, 'slot_id': 3, 'subject_id': 12, 'is_locked': 0,
    };
    final second = <String, Object?>{
      ...base, 'id': 2, 'slot_id': 5, 'subject_id': 2,
    };
    expect(swaps.validateShape(base, second), isNull);
    expect(swaps.validateShape(base, {...second, 'is_locked': 1}),
        contains('مقفلة'));
    expect(swaps.validateShape(base, {...second, 'section_id': 99}),
        contains('الشعبة'));
    expect(swaps.validateShape(base, {...second, 'subject_id': 12}),
        contains('مختلفة'));
  });

  test('181-lesson stress witness is sound and exact local solver accepts it', () {
    final input = fixture();
    expect((input['initialPlacements'] as List), hasLength(181));
    expect(const SectionTimeDomainFlow().inspect(input), isEmpty);
    expect(ScheduleImprovementService.valid(input,
        (input['initialPlacements'] as List)
            .map((e) => Map<String, Object?>.from(e as Map)).toList()), isTrue);
    final answer = const CompleteScheduleSolver().solve(
      input: input, timeLimit: const Duration(seconds: 3), nodeLimit: 3000,
    );
    expect(answer.complete, isTrue,
        reason: 'a supplied fully valid school should not be rebuilt');
    expect(answer.placements.length, 181);
  });

  test('blocking a mandatory subject in every period proves impossibility', () {
    final input = fixture();
    final slots = (input['slots'] as List).cast<Map<String, Object?>>();
    input['subjectBlockedSlots'] = [
      ...(input['subjectBlockedSlots'] as List),
      for (final slot in slots)
        if (slot['kind'] == 'lesson')
          <String, Object?>{'subject_id': 2, 'slot_id': slot['id']},
    ];
    final shortages = const SectionTimeDomainFlow().inspect(input);
    expect(shortages, isNotEmpty);
    expect(shortages.any((s) => s.deficit > 0), isTrue);
  });
}
