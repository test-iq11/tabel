import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:iraqi_school_timetable/services/constraint_explanation_service.dart';
import 'package:iraqi_school_timetable/services/section_time_domain_flow.dart';

void main() {
  final sample = jsonDecode(File('test/fixtures/backup_school_181.json')
      .readAsStringSync()) as Map<String, dynamic>;
  List<Map<String, Object?>> rows(String key) => (sample[key] as List)
      .map((row) => Map<String, Object?>.from(row as Map)).toList();

  Map<String, Object?> fixture({
    List<Map<String, Object?>>? availability,
    List<Map<String, Object?>>? bans,
  }) => {
    for (final key in [
      'sections', 'requirements', 'teachers', 'qualifications',
      'teacherGrades', 'teacherSubjectGrades', 'days', 'slots',
    ]) key: rows(key),
    'teacherAvailability': availability ?? <Map<String, Object?>>[],
    'subjectBlockedSlots': bans ?? <Map<String, Object?>>[],
  };

  test('all 181 real-shaped reference lessons have no time-domain shortage', () {
    final input = fixture();
    expect(const SectionTimeDomainFlow().inspect(input), isEmpty);
  });

  test('169 free teacher cells and 12 unused subject periods remain feasible', () {
    final board = rows('initialPlacements');
    final teachers = rows('teachers').map((r) => r['id'] as int);
    final days = rows('days').where((r) => r['is_active'] == 1)
        .map((r) => r['id'] as int);
    final slots = rows('slots').where((r) =>
        r['kind'] == 'lesson' && r['is_available'] == 1)
        .map((r) => r['id'] as int);
    final occupied = board.map((r) =>
        '${r['teacher_id']}:${r['day_id']}:${r['slot_id']}').toSet();
    final pairs = board.map((r) =>
        '${r['subject_id']}:${r['slot_id']}').toSet();
    final unavailable = <Map<String, Object?>>[
      for (final t in teachers)
        for (final d in days)
          for (final s in slots)
            if (!occupied.contains('$t:$d:$s'))
              {'teacher_id': t, 'day_id': d, 'slot_id': s, 'is_available': 0},
    ];
    final bans = <Map<String, Object?>>[
      for (final subject in rows('requirements')
          .map((r) => r['subject_id'] as int).toSet())
        for (final s in slots)
          if (!pairs.contains('$subject:$s'))
            {'subject_id': subject, 'slot_id': s},
    ];
    expect(unavailable, hasLength(169));
    expect(bans, hasLength(12));
    expect(const SectionTimeDomainFlow().inspect(
        fixture(availability: unavailable, bans: bans)), isEmpty);
  });

  test('all periods forbidden for a required subject yield a proof', () {
    final subject = rows('requirements').first['subject_id'] as int;
    final bans = [
      for (final slot in rows('slots').where((r) => r['kind'] == 'lesson'))
        <String, Object?>{'subject_id': subject, 'slot_id': slot['id']},
    ];
    final input = fixture(bans: bans);
    final shortages = const SectionTimeDomainFlow().inspect(input);
    expect(shortages, isNotEmpty);
    expect(shortages.every((s) => s.deficit > 0), isTrue);
    expect(const ConstraintExplanationService().explain(input)
        .any((e) => e.proven && e.code.startsWith('section_time_domain:')),
        isTrue);
  });

  test('daily quota one permits a later period when the first is banned', () {
    final input = <String, Object?>{
      'sections': [<String, Object?>{'id': 1, 'grade_id': 1,
        'max_daily_lessons': 1}],
      'requirements': [<String, Object?>{'section_id': 1,
        'subject_id': 1, 'weekly_lessons': 1}],
      'days': [<String, Object?>{'id': 1, 'is_active': 1}],
      'slots': [
        <String, Object?>{'id': 1, 'kind': 'lesson', 'is_available': 1},
        <String, Object?>{'id': 2, 'kind': 'lesson', 'is_available': 1},
      ],
      'teachers': [<String, Object?>{'id': 1}],
      'qualifications': [<String, Object?>{'teacher_id': 1, 'subject_id': 1}],
      'subjectBlockedSlots': [<String, Object?>{'subject_id': 1, 'slot_id': 1}],
    };
    expect(const SectionTimeDomainFlow().inspect(input), isEmpty);
    input['teacherAvailability'] = [<String, Object?>{
      'teacher_id': 1, 'day_id': 1, 'slot_id': 2, 'is_available': 0,
    }];
    expect(const SectionTimeDomainFlow().inspect(input).single.maximum, 0);
  });

  test('Hall-type overlap catches two subjects competing for five cells', () {
    // Both 3-hour subjects can individually fit in five weekdays, but six
    // lessons cannot fit in their SHARED five allowed time cells.
    final days = [for (var i = 1; i <= 5; i++)
      <String, Object?>{'id': i, 'name': 'يوم $i', 'is_active': 1}];
    final input = <String, Object?>{
      'sections': [<String, Object?>{'id': 1, 'grade_id': 1,
        'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 2}],
      'requirements': [
        <String, Object?>{'section_id': 1, 'subject_id': 1,
          'weekly_lessons': 3, 'allow_same_day': 0, 'max_daily_lessons': 1},
        <String, Object?>{'section_id': 1, 'subject_id': 2,
          'weekly_lessons': 3, 'allow_same_day': 0, 'max_daily_lessons': 1},
      ],
      'days': days,
      'slots': [
        <String, Object?>{'id': 1, 'kind': 'lesson', 'is_available': 1},
        <String, Object?>{'id': 2, 'kind': 'lesson', 'is_available': 1},
      ],
      'teachers': [<String, Object?>{'id': 1, 'weekly_load': 24}],
      'qualifications': [
        <String, Object?>{'teacher_id': 1, 'subject_id': 1},
        <String, Object?>{'teacher_id': 1, 'subject_id': 2},
      ],
      'teacherGrades': <Map<String, Object?>>[],
      'teacherSubjectGrades': <Map<String, Object?>>[],
      'subjectBlockedSlots': [
        <String, Object?>{'subject_id': 1, 'slot_id': 2},
        <String, Object?>{'subject_id': 2, 'slot_id': 2},
      ],
      'teacherAvailability': <Map<String, Object?>>[],
    };
    final shortage = const SectionTimeDomainFlow().inspect(input).single;
    expect(shortage.requested, 6);
    expect(shortage.maximum, 5);
    expect(shortage.deficit, 1);
    final result = const AutoSchedulerService(nodeLimit: 500).generate(
      sections: (input['sections'] as List).cast<Map<String, Object?>>(),
      requirements: (input['requirements'] as List).cast<Map<String, Object?>>(),
      teachers: (input['teachers'] as List).cast<Map<String, Object?>>(),
      qualifications: (input['qualifications'] as List).cast<Map<String, Object?>>(),
      days: (input['days'] as List).cast<Map<String, Object?>>(),
      slots: (input['slots'] as List).cast<Map<String, Object?>>(),
      subjectBlockedSlots: (input['subjectBlockedSlots'] as List)
          .cast<Map<String, Object?>>(),
      feasibilityOnly: true,
    );
    expect(result.provenInfeasible, isTrue);
    expect(result.searchLimitReached, isFalse);
    expect(result.exploredNodes, 0);
    expect(result.unscheduled, isNotEmpty);
  });
}
