import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  late Directory directory;
  late DatabaseService service;
  setUp(() async {
    sqfliteFfiInit();
    directory = await Directory.systemTemp.createTemp('jadwali-scoped-db-');
    service = DatabaseService.withStorage(
      factory: databaseFactoryFfi,
      directory: directory.path,
    );
  });
  tearDown(() async {
    await service.close();
    await directory.delete(recursive: true);
  });

  test('version8 global bans survive migration and scoped bans coexist and roundtrip', () async {
    var db = await service.database;
    final teacher = await db.insert('teachers', {'name': 'معلم الإتاحة'});
    final subject = await db.insert('subjects', {'name': 'مادة الإتاحة'});
    await db.execute('DROP TABLE teacher_availability');
    await db.execute('''CREATE TABLE teacher_availability (
      teacher_id INTEGER NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
      day_id INTEGER NOT NULL REFERENCES school_days(id) ON DELETE CASCADE,
      slot_id INTEGER NOT NULL REFERENCES time_slots(id) ON DELETE CASCADE,
      is_available INTEGER NOT NULL DEFAULT 1,
      PRIMARY KEY(teacher_id, day_id, slot_id))''');
    await db.insert('teacher_availability', {
      'teacher_id': teacher,
      'day_id': 1,
      'slot_id': 1,
      'is_available': 0,
    });
    await db.setVersion(8);
    await service.close();
    db = await service.database;
    expect(await db.getVersion(), DatabaseService.schemaVersion);
    final original = (await db.query('teacher_availability')).single;
    expect(original['grade_id'], isNull);
    expect(original['subject_id'], isNull);
    expect(original['is_available'], 0);
    final scoped = {
      'teacher_id': teacher,
      'day_id': 1,
      'slot_id': 1,
      'is_available': 0,
      'grade_id': 1,
      'subject_id': subject,
    };
    await db.insert('teacher_availability', scoped);
    await db.insert('teacher_availability', {...scoped, 'grade_id': 2});
    await expectLater(
      db.insert('teacher_availability', scoped),
      throwsA(isA<DatabaseException>()),
    );
    await expectLater(
      db.insert('teacher_availability', original),
      throwsA(isA<DatabaseException>()),
    );
    final backup = await service.exportAll();
    await db.delete('teacher_availability');
    await service.importAll(backup);
    final restored = await db.query('teacher_availability');
    expect(restored, hasLength(3));
    expect(
      restored.where((r) => r['grade_id'] == 1).single['subject_id'],
      subject,
    );
    await db.delete(
      'teacher_availability',
      where: 'teacher_id=? AND day_id=? AND slot_id=? AND grade_id IS ? AND subject_id IS ?',
      whereArgs: [teacher, 1, 1, 1, subject],
    );
    expect(await db.query('teacher_availability'), hasLength(2));
    expect(
      (await db.query('teacher_availability'))
          .any((r) => r['grade_id'] == null),
      isTrue,
    );
    await service.close();
    expect(
      await (await service.database).query('teacher_availability'),
      hasLength(2),
    );
  });

  test('schema8 backup imports old bans as global rules', () async {
    final db = await service.database;
    final teacher = await db.insert('teachers', {'name': 'معلم قديم'});
    final backup = await service.exportAll();
    backup['schema_version'] = 8;
    (backup['tables'] as Map)['teacher_availability'] = [
      {'teacher_id': teacher, 'day_id': 1, 'slot_id': 2, 'is_available': 0},
    ];
    await service.importAll(backup);
    final restored = (await db.query('teacher_availability')).single;
    expect(restored['grade_id'], isNull);
    expect(restored['subject_id'], isNull);
    expect(restored['slot_id'], 2);
  });
}
