import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:iraqi_school_timetable/services/same_day_spacing_preference.dart';

void main() {
  SchedulerResult run({
    List<int> blocked = const [],
    List<Map<String, Object?>> locks = const [],
  }) => const AutoSchedulerService(nodeLimit: 10000).generate(
    sections: [
      {'id': 1, 'grade_id': 1, 'max_daily_lessons': 6},
    ],
    requirements: [
      {
        'section_id': 1,
        'subject_id': 1,
        'weekly_lessons': 2,
        'allow_same_day': 1,
        'max_daily_lessons': 2,
      },
    ],
    teachers: [
      {'id': 1, 'weekly_load': 2, 'max_daily_lessons': 6},
    ],
    qualifications: [
      {'teacher_id': 1, 'subject_id': 1},
    ],
    days: [
      {'id': 31, 'position': 0, 'name': 'الأحد', 'is_active': 1},
    ],
    slots: [
      for (var rank = 0; rank < 7; rank++)
        {
          'id': 100 + rank * 3,
          'position': rank,
          'kind': 'lesson',
          'is_available': 1,
        },
    ],
    subjectBlockedSlots: [
      for (final rank in blocked) {'subject_id': 1, 'slot_id': 100 + rank * 3},
    ],
    lockedPlacements: locks,
  );
  test(
    'prefers early and sixth when feasible, with nonconsecutive slot IDs',
    () {
      final r = run();
      expect(r.complete, isTrue);
      final ranks =
          r.placements.map((e) => ((e['slot_id'] as int) - 100) ~/ 3).toList()
            ..sort();
      expect(ranks.first, lessThanOrEqualTo(2));
      expect(ranks.last, 5);
      expect(ranks, isNot(contains(6)));
    },
  );
  test('blocked late periods do not prevent a complete valid schedule', () {
    final r = run(blocked: [5, 6]);
    expect(r.complete, isTrue);
    expect(r.placements.every((e) => (e['slot_id'] as int) < 115), isTrue);
  });
  test('locked adjacent duplicates stay locked despite spacing preference', () {
    final locks = [
      for (var rank = 0; rank < 2; rank++)
        <String, Object?>{
          'section_id': 1,
          'subject_id': 1,
          'teacher_id': 1,
          'day_id': 31,
          'slot_id': 100 + rank * 3,
          'room_id': null,
        },
    ];
    final r = run(locks: locks);
    expect(r.complete, isTrue);
    expect(r.placements, containsAll(locks));
  });
  test('early and seventh is preferred when the caller has already allowed that slot', () {
    expect(
      SameDaySpacingPreference.cost(candidateRank: 6, existingRanks: [1]),
      lessThan(
        SameDaySpacingPreference.cost(candidateRank: 2, existingRanks: [1]),
      ),
    );
  });
}
