import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iraqi_school_timetable/core/interface_settings.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('appearance density and ordered shortcuts survive loading; reading is transient', () async {
    SharedPreferences.setMockInitialValues({});
    final first = InterfaceSettings();
    first.fontScale = 1.25;
    first.dark = true;
    first.compact = true;
    first.collapsed = true;
    first.shortcuts = [2, 4, 8, 11];
    first.reading = true;
    await first.save();
    final loaded = InterfaceSettings();
    await loaded.load();
    expect(loaded.fontScale, 1.25);
    expect(loaded.dark, isTrue);
    expect(loaded.compact, isTrue);
    expect(loaded.collapsed, isTrue);
    expect(loaded.shortcuts, [2, 4, 8, 11]);
    expect(loaded.reading, isFalse);
    first.dispose();
    loaded.dispose();
  });
  test(
    'invalid or duplicate shortcut IDs cannot expose removed destinations',
    () async {
      SharedPreferences.setMockInitialValues({
        'ui_shortcuts': ['9', '9', '999', '3'],
      });
      final settings = InterfaceSettings();
      await settings.load();
      expect(settings.shortcuts, [7, 10, 3, 6]);
      settings.dispose();
    },
  );
}
