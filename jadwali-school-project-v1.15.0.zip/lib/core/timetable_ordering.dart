/// Deterministic visual and algorithmic time-slot ordering.
/// Older backups assigned both sixth and seventh periods position=99.
class TimetableOrdering {
  const TimetableOrdering._();
  static int compare(Map<String, Object?> a, Map<String, Object?> b) {
    final av = _int(a['position']);
    final bv = _int(b['position']);
    final byPosition = av.compareTo(bv);
    if (byPosition != 0) return byPosition;
    final byTime = '${a['start_time'] ?? ''}'.compareTo(
      '${b['start_time'] ?? ''}',
    );
    if (byTime != 0) return byTime;
    return _int(a['id']).compareTo(_int(b['id']));
  }

  static int _int(Object? v) => v is int ? v : (int.tryParse('$v') ?? 0);
}
