import 'package:flutter/material.dart';

const previewInk = Color(0xFF28314F);
const previewMuted = Color(0xFF6F758B);
const previewLine = Color(0xFFE6E6F0);

class PreviewPanel extends StatelessWidget {
  const PreviewPanel({
    required this.title,
    required this.child,
    this.subtitle,
    this.trailing,
    super.key,
  });
  final String title;
  final String? subtitle;
  final Widget child;
  final Widget? trailing;
  @override
  Widget build(BuildContext context) => Card(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    if (subtitle != null)
                      Text(
                        subtitle!,
                        style: TextStyle(
                          fontSize: 11,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                  ],
                ),
              ),
              if (trailing != null) trailing!,
            ],
          ),
        ),
        child,
      ],
    ),
  );
}

class PreviewStats extends StatelessWidget {
  const PreviewStats({
    required this.distributed,
    required this.requiredCount,
    required this.sections,
    required this.teachers,
    super.key,
  });
  final int distributed, requiredCount, sections, teachers;
  @override
  Widget build(BuildContext context) {
    final rate = requiredCount == 0
        ? 0
        : (distributed / requiredCount * 100).round();
    final metrics = [
      (
        '$distributed',
        'حصة موزعة',
        'المطلوب $requiredCount حصة',
        Icons.calendar_month_outlined,
      ),
      (
        '$sections',
        'صفوف دراسية',
        'الصفوف والشعب المسجلة',
        Icons.menu_book_outlined,
      ),
      (
        '$teachers',
        'معلمين',
        'نصاب كل معلم ظاهر في بطاقته',
        Icons.people_outline,
      ),
      (
        '$rate٪',
        'اكتمال العدد',
        'مراجعة التعارضات قبل الاعتماد',
        Icons.check_circle_outline,
      ),
    ];
    return LayoutBuilder(
      builder: (context, c) => Wrap(
        spacing: 10,
        runSpacing: 10,
        children: [
          for (final m in metrics)
            SizedBox(
              width:
                  (c.maxWidth - (c.maxWidth > 700 ? 30 : 10)) /
                  (c.maxWidth > 700 ? 4 : 2),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              m.$2,
                              style: TextStyle(
                                fontSize: 11,
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurfaceVariant,
                              ),
                            ),
                          ),
                          Icon(m.$4, size: 18),
                        ],
                      ),
                      Text(
                        m.$1,
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w700,
                          height: 1.6,
                        ),
                      ),
                      Text(
                        m.$3,
                        style: TextStyle(
                          fontSize: 10,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class PreviewGrid extends StatelessWidget {
  const PreviewGrid({required this.children, this.minWidth = 280, super.key});
  final List<Widget> children;
  final double minWidth;
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, c) {
      final n = (c.maxWidth / minWidth).floor().clamp(1, 4);
      return Wrap(
        spacing: 16,
        runSpacing: 16,
        children: [
          for (final child in children)
            SizedBox(width: (c.maxWidth - (n - 1) * 16) / n, child: child),
        ],
      );
    },
  );
}
