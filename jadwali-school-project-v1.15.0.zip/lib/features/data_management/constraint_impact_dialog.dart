import 'package:flutter/material.dart';

import '../../data/database_service.dart';

/// Returns 0 to cancel, 1 to save, 2 to save and open repair. Read-only preview.
Future<int> previewSubjectBlockImpact(
  BuildContext context,
  int subjectId,
  Set<int> newlyBlocked, {
  bool canRepair = false,
}) async {
  if (newlyBlocked.isEmpty) return 1;
  final db = DatabaseService.instance;
  final version = await db.activeVersionId(await db.activeYearId());
  final affected = (await db.entriesDetailed(versionId: version))
      .where(
        (e) =>
            e['subject_id'] == subjectId && newlyBlocked.contains(e['slot_id']),
      )
      .toList();
  if (affected.isEmpty) return 1;
  if (!context.mounted) return 0;
  return await showDialog<int>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('يتأثر بهذا المنع ${affected.length} حصص'),
          content: SizedBox(
            width: 500,
            height: MediaQuery.sizeOf(ctx).height * .5,
            child: ListView(
              children: [
                const Text(
                  'حفظ الشرط لا ينقل الحصص الحالية. تحتاج هذه الحصص إلى إصلاح التوزيع؛ الحصص المقفلة لن تُنقل حتى تفك قفلها بنفسك.',
                ),
                const SizedBox(height: 12),
                for (final e in affected)
                  ListTile(
                    leading: Icon(
                      e['is_locked'] == 1
                          ? Icons.lock_outline
                          : Icons.swap_horiz,
                    ),
                    title: Text(
                      '${e['grade_name'] ?? ''} ${e['section_name'] ?? ''} — ${e['subject_name'] ?? ''}',
                    ),
                    subtitle: Text(
                      '${e['day_name'] ?? e['day_id']} · ${e['slot_name'] ?? e['slot_id']} · ${e['teacher_name'] ?? ''}',
                    ),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, 0),
              child: const Text('إلغاء'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(ctx, 1),
              child: const Text('حفظ الشرط فقط'),
            ),
            if (canRepair)
              FilledButton(
                onPressed: () => Navigator.pop(ctx, 2),
                child: const Text('حفظ وفتح الإصلاح'),
              ),
          ],
        ),
      ) ??
      0;
}
