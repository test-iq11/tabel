import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';

import '../../data/database_service.dart';
import '../../services/conflict_detection_service.dart';
import '../../services/teacher_absence_service.dart';
import 'schedule_comparison_dialog.dart';

Map<String, Object?> _absenceInBackground(Map<String, Object?> request) =>
    const TeacherAbsenceService()
        .plan(
          Map<String, Object?>.from(request['input'] as Map),
          teacherId: request['teacherId'] as int,
          dayId: request['dayId'] as int,
          slotIds: (request['slotIds'] as List).cast<int>(),
          nodeLimit: 180000,
        )
        .toMap();

class TeacherAbsencePage extends StatefulWidget {
  const TeacherAbsencePage({required this.onChanged, super.key});
  final VoidCallback onChanged;
  @override
  State<TeacherAbsencePage> createState() => _TeacherAbsencePageState();
}

class _TeacherAbsencePageState extends State<TeacherAbsencePage> {
  late Future<Map<String, Object?>> _future;
  int? _teacherId;
  int? _dayId;
  bool _wholeDay = true;
  final Set<int> _slotIds = {};
  bool _busy = false;
  bool _reviewed = false;
  bool _saved = false;
  TeacherAbsencePlan? _plan;
  Map<String, Object?>? _input;

  @override
  void initState() {
    super.initState();
    _future = _loadData();
  }

  Future<Map<String, Object?>> _loadData() async {
    final db = DatabaseService.instance;
    final yearId = await db.activeYearId();
    final versionId = await db.activeVersionId(yearId);
    return {
      'yearId': yearId,
      'versionId': versionId,
      'entries': versionId == null
          ? <Map<String, Object?>>[]
          : await db.entriesDetailed(versionId: versionId),
      'sections': await db.sectionsDetailed(),
      'requirements': await db.requirementsDetailed(),
      'teachers': await db.rows('teachers', orderBy: 'name'),
      'subjects': await db.rows('subjects', orderBy: 'name'),
      'qualifications': await db.rows('teacher_subjects'),
      'teacherGrades': await db.rows('teacher_grades'),
      'teacherSubjectGrades': await db.rows('teacher_subject_grades'),
      'subjectBlockedSlots': await db.rows('subject_blocked_slots'),
      'teacherAvailability': await db.rows('teacher_availability'),
      'days': await db.rows('school_days', orderBy: 'position'),
      'slots': await db.rows('time_slots', orderBy: 'position'),
    };
  }

  void _invalidate() {
    _plan = null;
    _input = null;
    _reviewed = false;
    _saved = false;
  }

  void _message(String text) {
    if (mounted)
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _generate() async {
    if (_teacherId == null ||
        _dayId == null ||
        (!_wholeDay && _slotIds.isEmpty)) {
      _message(
        'اختر المعلم واليوم، وحدد فترة واحدة على الأقل عند اختيار غياب جزئي.',
      );
      return;
    }
    setState(() {
      _busy = true;
      _invalidate();
    });
    try {
      final input = await _loadData();
      if (input['versionId'] == null || _rows(input, 'entries').isEmpty) {
        throw StateError('أنشئ جدولاً نشطاً قبل تخطيط الغياب.');
      }
      final output = await compute(_absenceInBackground, <String, Object?>{
        'input': input,
        'teacherId': _teacherId!,
        'dayId': _dayId!,
        'slotIds': _wholeDay ? <int>[] : _slotIds.toList(),
      });
      if (!mounted) return;
      setState(() {
        _input = input;
        _plan = TeacherAbsencePlan.fromMap(output);
      });
    } catch (error) {
      _message('تعذر إعداد خطة الغياب: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _preview() async {
    final input = _input, plan = _plan;
    if (input == null || plan == null || !plan.complete) return;
    final approved = await showScheduleComparisonDialog(
      context,
      before: _rows(input, 'entries'),
      after: plan.entries,
      sections: _rows(input, 'sections'),
      teachers: _rows(input, 'teachers'),
      subjects: _rows(input, 'subjects'),
      days: _rows(input, 'days'),
      slots: _rows(input, 'slots'),
      title: 'معاينة خطة الغياب',
    );
    if (mounted && approved == true) setState(() => _reviewed = true);
  }

  Future<void> _save() async {
    final input = _input, plan = _plan;
    if (input == null || plan == null || !plan.complete || !_reviewed || _saved)
      return;
    setState(() => _busy = true);
    try {
      final current = await _loadData();
      if (current['versionId'] != input['versionId'] ||
          _fingerprint(_rows(current, 'entries')) !=
              _fingerprint(_rows(input, 'entries'))) {
        throw StateError(
          'تغير الجدول الحالي بعد المعاينة؛ أعد إعداد الخطة قبل الحفظ.',
        );
      }
      final currentSlots = _rows(current, 'slots');
      final absenceSlots = _wholeDay
          ? currentSlots
                .where(
                  (s) =>
                      s['kind'] == 'lesson' && _int(s['is_available'], 1) == 1,
                )
                .map((s) => _int(s['id']))
                .toList()
          : _slotIds.toList();
      final availability = [
        ..._rows(current, 'teacherAvailability'),
        for (final slot in absenceSlots)
          <String, Object?>{
            'teacher_id': _teacherId!,
            'day_id': _dayId!,
            'slot_id': slot,
            'is_available': 0,
          },
      ];
      final issues = const ConflictDetectionService()
          .scan(
            entries: plan.entries,
            requirements: _rows(current, 'requirements'),
            sections: _rows(current, 'sections'),
            slots: currentSlots,
            teachers: _rows(current, 'teachers'),
            qualifications: _rows(current, 'qualifications'),
            days: _rows(current, 'days'),
            teacherGrades: _rows(current, 'teacherGrades'),
            teacherSubjectGrades: _rows(current, 'teacherSubjectGrades'),
            subjectBlockedSlots: _rows(current, 'subjectBlockedSlots'),
            teacherAvailability: availability,
          )
          .where((issue) => issue.type != 'تكرار توقيت المادة في أيام متتالية')
          .toList();
      if (issues.isNotEmpty)
        throw StateError(
          'لم تعد الخطة تستوفي القيود الحالية: ${issues.first.message}',
        );
      final locked = _rows(
        current,
        'entries',
      ).where((e) => _int(e['is_locked']) == 1).toList();
      if (!locked.every(
        (lock) => plan.entries.any((e) => _samePlacement(lock, e)),
      )) {
        throw StateError('تغيرت الحصص المثبتة؛ أعد إعداد الخطة.');
      }
      final entries = plan.entries
          .map(
            (e) => <String, Object?>{
              for (final key in [
                'section_id',
                'subject_id',
                'teacher_id',
                'day_id',
                'slot_id',
                'room_id',
              ])
                key: e[key],
              if (locked.any((lock) => _samePlacement(lock, e))) 'is_locked': 1,
            },
          )
          .toList();
      final teacher = _rows(
        current,
        'teachers',
      ).firstWhere((t) => t['id'] == _teacherId);
      final day = _rows(current, 'days').firstWhere((d) => d['id'] == _dayId);
      await DatabaseService.instance.saveAsNewVersion(
        yearId: current['yearId'] as int,
        name: 'خطة غياب ${teacher['name']} — ${day['name']}',
        entries: entries,
        notes:
            'خطة غياب مقترحة للمعلم ${teacher['name']} يوم ${day['name']}، '
            '${_wholeDay ? 'اليوم كاملاً' : 'الفترات ${absenceSlots.join('، ')}'}. '
            'هذه الخطة لنسخة الجدول فقط؛ لم تتغير الإتاحة الأسبوعية المحفوظة. راجع الخطة قبل التفعيل.',
        activate: false,
      );
      if (!mounted) return;
      setState(() => _saved = true);
      widget.onChanged();
      _message('حُفظت خطة الغياب كمسودة غير نشطة؛ بقي الجدول الحالي كما هو.');
    } catch (error) {
      _message('لم تُحفظ الخطة: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('خطة غياب معلم')),
      body: FutureBuilder<Map<String, Object?>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.hasError)
            return Center(
              child: Text('تعذر تحميل بيانات المدرسة: ${snapshot.error}'),
            );
          if (!snapshot.hasData)
            return const Center(child: CircularProgressIndicator());
          final data = snapshot.data!;
          final teachers = _rows(data, 'teachers');
          final days = _rows(
            data,
            'days',
          ).where((d) => _int(d['is_active'], 1) == 1).toList();
          final slots = _rows(data, 'slots')
              .where(
                (s) => s['kind'] == 'lesson' && _int(s['is_available'], 1) == 1,
              )
              .toList();
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text(
                'اختر المعلم وفترة الغياب. يبحث البرنامج عن بديل مؤهل، ثم يحاول تبديلات في الأسبوع عند الحاجة. '
                'لا تتغير الإتاحة الأسبوعية أو النسخة المعتمدة؛ يمكنك حفظ خطة كاملة كمسودة جديدة بعد المعاينة.',
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<int>(
                initialValue: _teacherId,
                decoration: const InputDecoration(labelText: 'المعلم الغائب'),
                items: teachers
                    .map(
                      (t) => DropdownMenuItem(
                        value: _int(t['id']),
                        child: Text('${t['name']}'),
                      ),
                    )
                    .toList(),
                onChanged: _busy
                    ? null
                    : (value) => setState(() {
                        _teacherId = value;
                        _invalidate();
                      }),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<int>(
                initialValue: _dayId,
                decoration: const InputDecoration(
                  labelText: 'يوم الغياب في الجدول',
                ),
                items: days
                    .map(
                      (d) => DropdownMenuItem(
                        value: _int(d['id']),
                        child: Text('${d['name']}'),
                      ),
                    )
                    .toList(),
                onChanged: _busy
                    ? null
                    : (value) => setState(() {
                        _dayId = value;
                        _invalidate();
                      }),
              ),
              SwitchListTile(
                title: const Text('غياب اليوم كاملاً'),
                value: _wholeDay,
                onChanged: _busy
                    ? null
                    : (value) => setState(() {
                        _wholeDay = value;
                        _invalidate();
                      }),
              ),
              if (!_wholeDay)
                Wrap(
                  spacing: 8,
                  children: slots.map((s) {
                    final id = _int(s['id']);
                    return FilterChip(
                      label: Text('${s['name']}'),
                      selected: _slotIds.contains(id),
                      onSelected: _busy
                          ? null
                          : (selected) => setState(() {
                              if (selected) {
                                _slotIds.add(id);
                              } else {
                                _slotIds.remove(id);
                              }
                              _invalidate();
                            }),
                    );
                  }).toList(),
                ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: _busy ? null : _generate,
                icon: const Icon(Icons.person_search),
                label: const Text('إعداد خطة الغياب'),
              ),
              if (_busy)
                const Padding(
                  padding: EdgeInsets.all(20),
                  child: LinearProgressIndicator(),
                ),
              if (_plan != null) ...[
                const SizedBox(height: 16),
                Text(
                  _plan!.complete
                      ? 'خطة كاملة قابلة للمراجعة'
                      : 'لم يُعثر على خطة كاملة',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                Text(
                  'الحصص المتأثرة: ${_plan!.affectedCount}، البدائل المباشرة: ${_plan!.substitutionCount}',
                ),
                for (final message in _plan!.messages)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(message),
                  ),
                if (_plan!.complete && _plan!.affectedCount > 0) ...[
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: _busy ? null : _preview,
                    icon: const Icon(Icons.compare_arrows),
                    label: const Text('معاينة التغييرات'),
                  ),
                  FilledButton.icon(
                    onPressed: _busy || !_reviewed || _saved ? null : _save,
                    icon: const Icon(Icons.save_outlined),
                    label: Text(
                      _saved ? 'حُفظت المسودة' : 'حفظ مسودة جديدة دون تفعيل',
                    ),
                  ),
                ],
              ],
            ],
          );
        },
      ),
    ),
  );
}

List<Map<String, Object?>> _rows(Map<String, Object?> input, String key) =>
    (input[key] as List? ?? const [])
        .map((row) => Map<String, Object?>.from(row as Map))
        .toList();
int _int(Object? value, [int fallback = 0]) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
String _fingerprint(List<Map<String, Object?>> entries) {
  final values =
      entries
          .map(
            (e) => [
              for (final key in [
                'section_id',
                'subject_id',
                'teacher_id',
                'day_id',
                'slot_id',
                'room_id',
                'is_locked',
              ])
                e[key] ?? 0,
            ].join(':'),
          )
          .toList()
        ..sort();
  return values.join('|');
}

bool _samePlacement(Map<String, Object?> a, Map<String, Object?> b) => [
  'section_id',
  'subject_id',
  'teacher_id',
  'day_id',
  'slot_id',
  'room_id',
].every((key) => a[key] == b[key]);
