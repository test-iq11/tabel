import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

import '../../services/constraint_relief_service.dart';

import '../../services/constraint_explanation_service.dart';

/// Read-only review. Suggestions never change school rules automatically.
Future<void> showConstraintExplanations(
  BuildContext context,
  List<ConstraintExplanation> explanations, {
  Map<String, Object?>? input,
}) async {
  final tryRelief = await showDialog<bool>(
    context: context,
    builder: (context) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: const Text('لماذا تعذّر التوزيع؟'),
        content: SizedBox(
          width: 720,
          height: MediaQuery.sizeOf(context).height * .62,
          child: explanations.isEmpty
              ? const Center(
                  child: Text(
                    'لم يظهر تعارض مؤكد في فحص السعة والإعدادات. '
                    'قد يحتاج المحرك وقتاً أطول للبحث أو تحرير بعض الحصص المثبتة.',
                    textAlign: TextAlign.center,
                  ),
                )
              : ListView.separated(
                  itemCount: explanations.length,
                  separatorBuilder: (_, _) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final item = explanations[index];
                    final theme = Theme.of(context);
                    return Card(
                      margin: EdgeInsets.zero,
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(
                                  item.proven
                                      ? Icons.block_outlined
                                      : Icons.search,
                                  color: item.proven
                                      ? theme.colorScheme.error
                                      : theme.colorScheme.primary,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    item.title,
                                    style: theme.textTheme.titleMedium,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(
                              item.code == 'verified_relief'
                                  ? 'حل تجريبي موثّق بعد التخفيف المقترح'
                                  : item.proven
                                  ? 'تعارض مؤكد بالشروط الحالية'
                                  : 'تنبيه بحث؛ ليس إثبات استحالة',
                              style: theme.textTheme.labelMedium,
                            ),
                            const SizedBox(height: 8),
                            SelectableText(item.reason),
                            if (item.suggestions.isNotEmpty) ...[
                              const SizedBox(height: 10),
                              const Text(
                                'تعديلات يمكنك مراجعتها:',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              for (final suggestion in item.suggestions)
                                Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Icon(Icons.chevron_left, size: 18),
                                      const SizedBox(width: 4),
                                      Expanded(child: Text(suggestion)),
                                    ],
                                  ),
                                ),
                            ],
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
        actions: [
          if (input != null)
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('تجربة اقتراح تخفيف محدود'),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إغلاق'),
          ),
        ],
      ),
    ),
  );
  if (tryRelief == true && input != null && context.mounted) {
    final navigator = Navigator.of(context);
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const PopScope(
        canPop: false,
        child: AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('تجربة تخفيف شروط دون تغيير البيانات…'),
            ],
          ),
        ),
      ),
    );
    List<ConstraintExplanation> result;
    try {
      result = await compute(suggestConstraintRelief, input);
    } catch (e) {
      result = [
        ConstraintExplanation(
          code: 'trial_error',
          title: 'تعذر إكمال التجربة',
          reason: '$e',
          suggestions: const [],
          proven: false,
        ),
      ];
    }
    if (navigator.mounted) navigator.pop();
    if (context.mounted) await showConstraintExplanations(context, result);
  }
}
