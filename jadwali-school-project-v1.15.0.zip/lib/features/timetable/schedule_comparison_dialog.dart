import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../services/schedule_comparison_service.dart';

/// Preview only. The caller saves the chosen schedule after a true result.
Future<bool?> showScheduleComparisonDialog(
  BuildContext context, {
  required List<Map<String, Object?>> before,
  required List<Map<String, Object?>> after,
  required List<Map<String, Object?>> sections,
  required List<Map<String, Object?>> teachers,
  required List<Map<String, Object?>> subjects,
  required List<Map<String, Object?>> days,
  required List<Map<String, Object?>> slots,
  String title = 'معاينة التغييرات',
  bool readOnly = false,
}) {
  final comparison = const ScheduleComparisonService().compare(before, after);
  final sectionNames = {
    for (final row in sections)
      _id(row['id']): [row['grade_name'], row['section_name'] ?? row['name']]
          .where((value) => value != null && '$value'.trim().isNotEmpty)
          .join(' — '),
  };
  final teacherNames = _names(teachers), subjectNames = _names(subjects);
  final dayNames = _names(days), slotNames = _names(slots);
  return showDialog<bool>(
    context: context,
    builder: (dialogContext) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: Text(title),
        content: SizedBox(
          width: 900,
          height: math.min(
            620.0,
            MediaQuery.sizeOf(dialogContext).height * .65,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  Chip(
                    label: Text('تغيّرت ${comparison.changedLessonCount} حصة'),
                  ),
                  Chip(
                    label: Text(
                      'صفوف متأثرة: ${comparison.changes.map((c) => c.lesson['section_id']).toSet().length}',
                    ),
                  ),
                  Chip(
                    label: Text(
                      'معلمون متأثرون: ${comparison.changes.expand((c) => [c.before?['teacher_id'], c.after?['teacher_id']]).where((id) => id != null).toSet().length}',
                    ),
                  ),
                  Chip(label: Text('منقولة: ${comparison.moves.length}')),
                  Chip(
                    label: Text(
                      'تبديل معلم: ${comparison.teacherChanges.length}',
                    ),
                  ),
                  Chip(label: Text('إضافة: ${comparison.additions.length}')),
                  Chip(label: Text('حذف: ${comparison.removals.length}')),
                  Chip(label: Text('دون تغيير: ${comparison.unchangedCount}')),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                readOnly ? 'مقارنة النسخة المؤرشفة بالنسخة النشطة الحالية.' : 'هذه معاينة فقط؛ لن يتغير الجدول المحفوظ قبل اختيار الحفظ.',
              ),
              const Divider(),
              Expanded(
                child: comparison.changes.isEmpty
                    ? const Center(
                        child: Text('لا توجد تغييرات في إسناد الحصص.'),
                      )
                    : ListView.builder(
                        itemCount: comparison.changes.length,
                        itemBuilder: (context, index) {
                          final change = comparison.changes[index];
                          final row = change.lesson;
                          final section =
                              sectionNames[_id(row['section_id'])] ??
                              'الشعبة ${row['section_id']}';
                          final subject =
                              subjectNames[_id(row['subject_id'])] ??
                              'المادة ${row['subject_id']}';
                          return Card(
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Text(
                                    '$section — $subject',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleSmall,
                                  ),
                                  const SizedBox(height: 8),
                                  LayoutBuilder(
                                    builder: (context, constraints) {
                                      final old = _PlacementCard(
                                        title: 'قبل',
                                        row: change.before,
                                        color: Colors.red,
                                        teachers: teacherNames,
                                        days: dayNames,
                                        slots: slotNames,
                                      );
                                      final next = _PlacementCard(
                                        title: 'بعد',
                                        row: change.after,
                                        color: Colors.green,
                                        teachers: teacherNames,
                                        days: dayNames,
                                        slots: slotNames,
                                      );
                                      if (constraints.maxWidth < 550) {
                                        return Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.stretch,
                                          children: [
                                            old,
                                            const SizedBox(height: 6),
                                            next,
                                          ],
                                        );
                                      }
                                      return Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Expanded(child: old),
                                          const SizedBox(width: 8),
                                          Expanded(child: next),
                                        ],
                                      );
                                    },
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('رجوع'),
          ),
          if (!readOnly)
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('متابعة إلى الحفظ'),
            ),
        ],
      ),
    ),
  );
}

/// Each alternative contains label/profile, placements, complete, and a quality
/// or metrics map produced by ScheduleQuality.toMap(). Returns its list index.
Future<int?> showScheduleAlternativesDialog(
  BuildContext context, {
  required List<Map<String, Object?>> alternatives,
  String title = 'مقارنة حلول التوزيع',
}) => showDialog<int>(
  context: context,
  builder: (dialogContext) => Directionality(
    textDirection: TextDirection.rtl,
    child: AlertDialog(
      title: Text(title),
      content: SizedBox(
        width: 650,
        height: math.min(560.0, MediaQuery.sizeOf(dialogContext).height * .65),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('اختر الحل الأنسب. ستظهر معاينة التغييرات قبل الحفظ.'),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: alternatives.length,
                itemBuilder: (context, index) {
                  final option = alternatives[index];
                  final metrics = _map(option['quality'] ?? option['metrics']);
                  final placements = _rows(option['placements']);
                  final complete = option['complete'] == true;
                  int? duplicate;
                  for (var i = 0; i < index; i++) {
                    if (const ScheduleComparisonService()
                            .compare(
                              _rows(alternatives[i]['placements']),
                              placements,
                            )
                            .changedLessonCount ==
                        0) {
                      duplicate = i;
                      break;
                    }
                  }
                  return Card(
                    child: ListTile(
                      isThreeLine: true,
                      leading: Icon(
                        complete
                            ? Icons.check_circle_outline
                            : Icons.warning_amber_rounded,
                        color: complete ? Colors.green : Colors.orange,
                      ),
                      title: Text(
                        '${option['label'] ?? _profileLabel('${option['profile'] ?? ''}')} — '
                        '${complete ? 'كامل' : 'مسودة ناقصة'}',
                      ),
                      subtitle: Text(
                        '${placements.length} حصة، تغيّرت ${metrics['changedLessons'] ?? '—'} حصة\n'
                        'فراغات المعلمين: ${metrics['teacherGaps'] ?? '—'}، '
                        'أسوأ فراغات يومية: ${metrics['worstTeacherDayGaps'] ?? '—'}\n'
                        'تفاوت حمل الصف: ${metrics['worstSectionDaySpread'] ?? '—'}، '
                        'مؤشر فصل الحصتين: ${metrics['repeatSpacingPenalty'] ?? '—'} (الأقل أفضل)\n'
                        'مؤشر تكرار التوقيت: ${metrics['subjectBalancePenalty'] ?? '—'} (الأقل أفضل)'
                        '${duplicate == null ? '' : '\nمطابق للجدول في الخيار ${duplicate + 1}'}',
                      ),
                      trailing: const Icon(Icons.chevron_left),
                      onTap: () => Navigator.pop(dialogContext, index),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(dialogContext),
          child: const Text('رجوع'),
        ),
      ],
    ),
  ),
);

class _PlacementCard extends StatelessWidget {
  const _PlacementCard({
    required this.title,
    required this.row,
    required this.color,
    required this.teachers,
    required this.days,
    required this.slots,
  });
  final String title;
  final Map<String, Object?>? row;
  final MaterialColor color;
  final Map<int, String> teachers, days, slots;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(
      color: color.shade50,
      border: Border.all(color: color.shade200),
      borderRadius: BorderRadius.circular(8),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(color: color.shade900, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        if (row == null)
          const Text('لا توجد حصة')
        else ...[
          Text(
            '${days[_id(row!['day_id'])] ?? 'اليوم ${row!['day_id']}'} — '
            '${slots[_id(row!['slot_id'])] ?? 'الفترة ${row!['slot_id']}'}',
          ),
          Text(
            'المعلم: ${teachers[_id(row!['teacher_id'])] ?? 'رقم ${row!['teacher_id']}'}',
          ),
          if (row!['room_id'] != null) Text('القاعة: ${row!['room_id']}'),
        ],
      ],
    ),
  );
}

Map<int, String> _names(List<Map<String, Object?>> rows) => {
  for (final row in rows)
    _id(row['id']): '${row['name'] ?? row['label'] ?? row['id']}',
};
int _id(Object? value) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? 0;
List<Map<String, Object?>> _rows(Object? value) => value is List
    ? value.map((row) => Map<String, Object?>.from(row as Map)).toList()
    : [];
Map<String, Object?> _map(Object? value) =>
    value is Map ? Map<String, Object?>.from(value) : {};
String _profileLabel(String profile) => switch (profile) {
  'teacher_gaps' => 'فراغات أقل للمعلمين',
  'balanced_subjects' => 'توازن توقيت المواد',
  _ => 'تغييرات أقل على الجدول الحالي',
};
