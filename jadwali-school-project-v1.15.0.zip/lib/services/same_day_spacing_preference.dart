/// Soft ranking only. This never removes a feasible candidate or unlocks a slot.
class SameDaySpacingPreference {
  const SameDaySpacingPreference._();
  static int cost({
    required int candidateRank,
    required Iterable<int> existingRanks,
    bool likelyRepeat = false,
  }) {
    final existing = existingRanks.toList();
    if (existing.isEmpty) return likelyRepeat && candidateRank > 2 ? 3000 : 0;
    var cost = 0;
    for (final rank in existing) {
      final early = rank < candidateRank ? rank : candidateRank;
      final late = rank > candidateRank ? rank : candidateRank;
      // Ranks are chronological lesson positions, not database IDs.
      if (early <= 2 && (late == 5 || late == 6)) continue;
      cost += 20000 + (6 - (rank - candidateRank).abs()).clamp(0, 6) * 500;
    }
    return cost;
  }
}
