import '../core/timetable_ordering.dart';
import 'same_day_spacing_preference.dart';

/// A semantic lesson change. Database row IDs differ between saved versions and
/// deliberately do not identify a lesson here. A moved lesson may also change
/// teacher; [ScheduleComparison.changedLessonCount] counts it only once.
class ScheduleChange {
  ScheduleChange({Map<String, Object?>? before, Map<String, Object?>? after})
    : before = before == null ? null : Map.unmodifiable(before),
      after = after == null ? null : Map.unmodifiable(after);

  final Map<String, Object?>? before;
  final Map<String, Object?>? after;
  bool get added => before == null;
  bool get removed => after == null;
  bool get moved =>
      before != null &&
      after != null &&
      (_int(before!['day_id']) != _int(after!['day_id']) ||
          _int(before!['slot_id']) != _int(after!['slot_id']));
  bool get teacherChanged =>
      before != null &&
      after != null &&
      _int(before!['teacher_id']) != _int(after!['teacher_id']);
  bool get roomChanged =>
      before != null &&
      after != null &&
      _int(before!['room_id']) != _int(after!['room_id']);
  Map<String, Object?> get lesson => after ?? before!;
}

class ScheduleComparison {
  ScheduleComparison({
    required this.unchangedCount,
    required List<ScheduleChange> changes,
  }) : changes = List.unmodifiable(changes);

  final int unchangedCount;
  final List<ScheduleChange> changes;
  List<ScheduleChange> get additions =>
      changes.where((c) => c.added).toList(growable: false);
  List<ScheduleChange> get removals =>
      changes.where((c) => c.removed).toList(growable: false);
  List<ScheduleChange> get moves =>
      changes.where((c) => c.moved).toList(growable: false);
  List<ScheduleChange> get teacherChanges =>
      changes.where((c) => c.teacherChanged).toList(growable: false);
  int get changedLessonCount => changes.length;

  Map<String, Object?> toMap() => {
    'unchanged': unchangedCount,
    'changedLessons': changedLessonCount,
    'additions': additions.length,
    'removals': removals.length,
    'moves': moves.length,
    'teacherChanges': teacherChanges.length,
  };
}

/// Quality metrics rank already-validated schedules; they are not feasibility
/// checks and cannot override any teacher, section, availability, or lock rule.
class ScheduleQuality {
  const ScheduleQuality({
    required this.teacherGaps,
    required this.changedLessons,
    required this.subjectBalancePenalty,
    required this.lessonCount,
    this.worstTeacherDayGaps = 0,
    this.worstSectionDaySpread = 0,
    this.repeatSpacingPenalty = 0,
  });
  final int worstTeacherDayGaps, worstSectionDaySpread, repeatSpacingPenalty;
  final int teacherGaps;
  final int changedLessons;
  final int subjectBalancePenalty;
  final int lessonCount;

  int scoreFor(String preference) => switch (preference) {
    'teacher_gaps' =>
      teacherGaps * 1000 + changedLessons * 10 + subjectBalancePenalty,
    'balanced_subjects' =>
      subjectBalancePenalty * 1000 + teacherGaps * 10 + changedLessons,
    _ => changedLessons * 1000 + teacherGaps * 10 + subjectBalancePenalty,
  };

  Map<String, Object?> toMap() => {
    'worstTeacherDayGaps': worstTeacherDayGaps,
    'worstSectionDaySpread': worstSectionDaySpread,
    'repeatSpacingPenalty': repeatSpacingPenalty,
    'teacherGaps': teacherGaps,
    'changedLessons': changedLessons,
    'subjectBalancePenalty': subjectBalancePenalty,
    'lessonCount': lessonCount,
  };
}

class ScheduleComparisonService {
  const ScheduleComparisonService();

  ScheduleComparison compare(
    List<Map<String, Object?>> before,
    List<Map<String, Object?>> after,
  ) {
    final oldGroups = _groups(before);
    final newGroups = _groups(after);
    final keys = {...oldGroups.keys, ...newGroups.keys}.toList()..sort();
    var unchanged = 0;
    final changes = <ScheduleChange>[];
    for (final key in keys) {
      final oldRows = [...(oldGroups[key] ?? const <Map<String, Object?>>[])];
      final newRows = [...(newGroups[key] ?? const <Map<String, Object?>>[])];
      oldRows.sort(_compareRows);
      newRows.sort(_compareRows);
      // Consume exact multiset matches first. This guarantees an unchanged
      // copy is never turned into two invented movements by row ordering.
      for (var i = oldRows.length - 1; i >= 0; i--) {
        final match = newRows.indexWhere(
          (row) => _samePlacement(oldRows[i], row),
        );
        if (match < 0) continue;
        unchanged++;
        oldRows.removeAt(i);
        newRows.removeAt(match);
      }
      final size = oldRows.length > newRows.length
          ? oldRows.length
          : newRows.length;
      if (size == 0) continue;
      final costs = List.generate(
        size,
        (i) => List.generate(
          size,
          (j) => i < oldRows.length && j < newRows.length
              ? _cost(oldRows[i], newRows[j])
              : 0,
        ),
      );
      final matches = _minimumAssignment(costs);
      final matchedNew = <int>{};
      for (var i = 0; i < oldRows.length; i++) {
        final j = matches[i];
        if (j < newRows.length) {
          matchedNew.add(j);
          changes.add(ScheduleChange(before: oldRows[i], after: newRows[j]));
        } else {
          changes.add(ScheduleChange(before: oldRows[i]));
        }
      }
      for (var j = 0; j < newRows.length; j++) {
        if (!matchedNew.contains(j))
          changes.add(ScheduleChange(after: newRows[j]));
      }
    }
    return ScheduleComparison(unchangedCount: unchanged, changes: changes);
  }

  static ScheduleQuality evaluate({
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> slots,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> requirements,
    List<Map<String, Object?>> before = const [],
  }) {
    final orderedSlots =
        slots
            .where(
              (s) =>
                  s['kind'] == 'lesson' &&
                  _int(s['is_available'], fallback: 1) == 1,
            )
            .toList()
          ..sort(TimetableOrdering.compare);
    final orderedDays =
        days.where((d) => _int(d['is_active'], fallback: 1) == 1).toList()
          ..sort(TimetableOrdering.compare);
    final ranks = {
      for (var i = 0; i < orderedSlots.length; i++)
        _int(orderedSlots[i]['id']): i,
    };
    final dayRanks = {
      for (var i = 0; i < orderedDays.length; i++)
        _int(orderedDays[i]['id']): i,
    };
    final teacherDays = <String, Set<int>>{};
    final subjectPeriods = <String, Map<int, int>>{};
    final subjectDayPeriods = <String, Map<int, Set<int>>>{};
    final demand = {
      for (final r in requirements) _groupKey(r): _int(r['weekly_lessons']),
    };
    for (final row in entries) {
      final rank = ranks[_int(row['slot_id'])];
      final day = dayRanks[_int(row['day_id'])];
      if (rank == null || day == null) continue;
      final teacher = _int(row['teacher_id']);
      if (teacher > 0) (teacherDays['$teacher:$day'] ??= <int>{}).add(rank);
      final key = _groupKey(row);
      final periodCounts = subjectPeriods[key] ??= <int, int>{};
      periodCounts[rank] = (periodCounts[rank] ?? 0) + 1;
      ((subjectDayPeriods[key] ??= <int, Set<int>>{})[day] ??= <int>{}).add(
        rank,
      );
    }
    var gaps = 0, worstGaps = 0;
    for (final ranks in teacherDays.values) {
      if (ranks.isEmpty) continue;
      final sorted = ranks.toList()..sort();
      final count = sorted.last - sorted.first + 1 - sorted.length;
      gaps += count;
      if (count > worstGaps) worstGaps = count;
    }
    var balance = 0;
    for (final entry in subjectPeriods.entries) {
      final weight = 1 + ((demand[entry.key] ?? 0) ~/ 5);
      for (final count in entry.value.values) {
        balance += (count * (count - 1) ~/ 2) * weight;
      }
      final byDay = subjectDayPeriods[entry.key]!;
      for (var day = 1; day < orderedDays.length; day++) {
        final previous = byDay[day - 1] ?? const <int>{};
        final current = byDay[day] ?? const <int>{};
        balance += previous.intersection(current).length * 4 * weight;
      }
    }
    var spacing = 0, worstSpread = 0;
    for (final byDay in subjectDayPeriods.values) {
      for (final positions in byDay.values) {
        final ordered = positions.toList()..sort();
        for (var i = 1; i < ordered.length; i++) {
          spacing +=
              SameDaySpacingPreference.cost(
                candidateRank: ordered[i],
                existingRanks: ordered.take(i),
              ) ~/
              500;
        }
      }
    }
    final sectionDays = <int, Map<int, int>>{};
    for (final row in entries) {
      final counts = sectionDays[_int(row['section_id'])] ??= {};
      counts[_int(row['day_id'])] = (counts[_int(row['day_id'])] ?? 0) + 1;
    }
    for (final counts in sectionDays.values) {
      final loads = [
        for (final day in orderedDays) counts[_int(day['id'])] ?? 0,
      ]..sort();
      if (loads.isNotEmpty && loads.last - loads.first > worstSpread)
        worstSpread = loads.last - loads.first;
    }
    return ScheduleQuality(
      teacherGaps: gaps,
      worstTeacherDayGaps: worstGaps,
      worstSectionDaySpread: worstSpread,
      repeatSpacingPenalty: spacing,
      changedLessons: const ScheduleComparisonService()
          .compare(before, entries)
          .changedLessonCount,
      subjectBalancePenalty: balance,
      lessonCount: entries.length,
    );
  }

  static Map<String, List<Map<String, Object?>>> _groups(
    List<Map<String, Object?>> entries,
  ) {
    final groups = <String, List<Map<String, Object?>>>{};
    for (final row in entries) (groups[_groupKey(row)] ??= []).add(row);
    return groups;
  }

  static String _groupKey(Map<String, Object?> row) =>
      '${_int(row['section_id'])}:${_int(row['subject_id'])}';
  static bool _samePlacement(Map<String, Object?> a, Map<String, Object?> b) =>
      _int(a['teacher_id']) == _int(b['teacher_id']) &&
      _int(a['day_id']) == _int(b['day_id']) &&
      _int(a['slot_id']) == _int(b['slot_id']) &&
      _int(a['room_id']) == _int(b['room_id']);
  static int _compareRows(Map<String, Object?> a, Map<String, Object?> b) {
    for (final key in ['day_id', 'slot_id', 'teacher_id', 'room_id']) {
      final result = _int(a[key]).compareTo(_int(b[key]));
      if (result != 0) return result;
    }
    return 0;
  }

  static int _cost(Map<String, Object?> a, Map<String, Object?> b) =>
      (_int(a['teacher_id']) == _int(b['teacher_id']) ? 0 : 1000) +
      (_int(a['day_id']) == _int(b['day_id']) ? 0 : 100) +
      (_int(a['slot_id']) == _int(b['slot_id']) ? 0 : 10) +
      (_int(a['room_id']) == _int(b['room_id']) ? 0 : 1);

  // Hungarian minimum-cost assignment, padded with dummy rows/columns when
  // lesson counts differ. Each real lesson is matched at most once.
  static List<int> _minimumAssignment(List<List<int>> cost) {
    final n = cost.length;
    final u = List<int>.filled(n + 1, 0), v = List<int>.filled(n + 1, 0);
    final p = List<int>.filled(n + 1, 0), way = List<int>.filled(n + 1, 0);
    for (var i = 1; i <= n; i++) {
      p[0] = i;
      var j0 = 0;
      final min = List<int>.filled(n + 1, 1 << 60);
      final used = List<bool>.filled(n + 1, false);
      do {
        used[j0] = true;
        final i0 = p[j0];
        var delta = 1 << 60, j1 = 0;
        for (var j = 1; j <= n; j++) {
          if (used[j]) continue;
          final current = cost[i0 - 1][j - 1] - u[i0] - v[j];
          if (current < min[j]) {
            min[j] = current;
            way[j] = j0;
          }
          if (min[j] < delta) {
            delta = min[j];
            j1 = j;
          }
        }
        for (var j = 0; j <= n; j++) {
          if (used[j]) {
            u[p[j]] += delta;
            v[j] -= delta;
          } else {
            min[j] -= delta;
          }
        }
        j0 = j1;
      } while (p[j0] != 0);
      do {
        final j1 = way[j0];
        p[j0] = p[j1];
        j0 = j1;
      } while (j0 != 0);
    }
    final answer = List<int>.filled(n, -1);
    for (var j = 1; j <= n; j++) answer[p[j] - 1] = j - 1;
    return answer;
  }
}

int _int(Object? value, {int fallback = 0}) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
