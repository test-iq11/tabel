/// Shared week-grid layout used by PDF, Word, Excel and CSV exports.
/// The period and its time range live only in the first column of each row.
class TimetableReportLayout {
  TimetableReportLayout({
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> sections,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
  })  : entries = List<Map<String, Object?>>.unmodifiable(entries),
        sections = List<Map<String, Object?>>.unmodifiable(_orderedSections(sections, entries)),
        // Physical left-to-right columns: time, Thursday ... Sunday (Sunday at far right).
        days = List<Map<String, Object?>>.unmodifiable(
          _ordered(days.where((d) => _asInt(d['is_active'], fallback: 1) == 1).toList()).reversed,
        ),
        slots = List<Map<String, Object?>>.unmodifiable(_ordered(slots.where((s) => s['kind'] == 'lesson' && _asInt(s['is_available'], fallback: 1) == 1).toList())) {
    final entryMap = <String, Map<String, Object?>>{};
    for (final entry in entries) {
      entryMap['${_asInt(entry['section_id'])}:${_asInt(entry['day_id'])}:${_asInt(entry['slot_id'])}'] = entry;
    }
    _entryByCell = entryMap;
  }

  final List<Map<String, Object?>> entries;
  final List<Map<String, Object?>> sections;
  final List<Map<String, Object?>> days;
  final List<Map<String, Object?>> slots;
  late final Map<String, Map<String, Object?>> _entryByCell;

  static List<Map<String, Object?>> _ordered(List<Map<String, Object?>> values) {
    final result = List<Map<String, Object?>>.from(values);
    result.sort((a, b) => _asInt(a['position']).compareTo(_asInt(b['position'])));
    return result;
  }

  static List<Map<String, Object?>> _orderedSections(
    List<Map<String, Object?>> input,
    List<Map<String, Object?>> entries,
  ) {
    final result = List<Map<String, Object?>>.from(input);
    if (result.isEmpty) {
      final seen = <int>{};
      for (final entry in entries) {
        final id = _asInt(entry['section_id']);
        if (seen.add(id)) {
          result.add({
            'id': id,
            'grade_name': entry['grade_name'] ?? entry['section_grade_name'] ?? '',
            'section_name': entry['section_name'] ?? 'الشعبة $id',
            'grade_position': entry['grade_position'] ?? 0,
            'stage_position': entry['stage_position'] ?? 0,
          });
        }
      }
    }
    // sectionsDetailed() already returns the official stage/grade/section order.
    // Sort only when the source explicitly includes the order fields.
    if (result.any((s) => s.containsKey('stage_position') || s.containsKey('grade_position'))) {
      result.sort((a, b) {
        var c = _asInt(a['stage_position']).compareTo(_asInt(b['stage_position']));
        if (c != 0) return c;
        c = _asInt(a['grade_position']).compareTo(_asInt(b['grade_position']));
        if (c != 0) return c;
        c = _asInt(a['grade_id']).compareTo(_asInt(b['grade_id']));
        if (c != 0) return c;
        return '${a['section_name'] ?? ''}'.compareTo('${b['section_name'] ?? ''}');
      });
    }
    return result;
  }

  String sectionTitle(Map<String, Object?> section) {
    final grade = _shortGradeName(section['grade_name'] ?? section['section_grade_name']);
    final name = '${section['section_name'] ?? 'الشعبة ${section['id']}'}'.trim();
    final parts = <String>[if (grade.isNotEmpty) 'الصف $grade', if (name.isNotEmpty) 'الشعبة $name'];
    return 'جدول ${parts.join('، ')}';
  }

  /// Uses left-to-right marks around clock values so Arabic RTL rendering does
  /// not reverse values such as 08:00 and 08:45 in PDF/Word.
  String periodLabel(Map<String, Object?> slot) {
    final name = '${slot['name'] ?? 'الحصة'}'.trim();
    final start = _normalTime(slot['start_time']);
    final end = _normalTime(slot['end_time']);
    if (start.isEmpty && end.isEmpty) return name;
    final range = start.isNotEmpty && end.isNotEmpty
        ? '\u200E$start\u200E إلى \u200E$end\u200E'
        : '\u200E${start.isNotEmpty ? start : end}\u200E';
    return '$name\n$range';
  }

  String lessonCell(Map<String, Object?> section, Map<String, Object?> day, Map<String, Object?> slot) {
    final entry = _entryByCell['${_asInt(section['id'])}:${_asInt(day['id'])}:${_asInt(slot['id'])}'];
    if (entry == null) return '';
    final subject = '${entry['subject_name'] ?? 'مادة'}'.trim();
    final teacher = '${entry['teacher_name'] ?? ''}'.trim();
    final room = '${entry['room_name'] ?? ''}'.trim();
    return [subject, if (teacher.isNotEmpty) teacher, if (room.isNotEmpty) room].join('\n');
  }

  /// Flat block rows consumed by Word, Excel and CSV. Each section gets a title,
  /// one day header and one row per period; time is never repeated in lesson cells.
  List<List<String>> rowsForAllSections() {
    final columnCount = days.length + 1;
    final rows = <List<String>>[];
    for (var sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
      final section = sections[sectionIndex];
      rows.add([sectionTitle(section), ...List<String>.filled(days.length, '')]);
      rows.add(['الحصة والوقت', ...days.map((day) => '${day['name'] ?? ''}')]);
      for (final slot in slots) {
        rows.add([
          periodLabel(slot),
          ...days.map((day) => lessonCell(section, day, slot)),
        ]);
      }
      if (sectionIndex != sections.length - 1) rows.add(List<String>.filled(columnCount, ''));
    }
    if (sections.isEmpty) {
      rows.add(['لا توجد شعب', ...List<String>.filled(days.length, '')]);
    }
    return rows;
  }

  static String _normalTime(Object? value) {
    var result = '${value ?? ''}'.trim();
    if (result.isEmpty) return '';
    const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
    const persianDigits = '۰۱۲۳۴۵۶۷۸۹';
    final converted = StringBuffer();
    for (final rune in result.runes) {
      final char = String.fromCharCode(rune);
      final arabicIndex = arabicDigits.indexOf(char);
      final persianIndex = persianDigits.indexOf(char);
      if (arabicIndex >= 0) {
        converted.write(arabicIndex);
      } else if (persianIndex >= 0) {
        converted.write(persianIndex);
      } else {
        converted.write(char);
      }
    }
    result = converted.toString();
    final match = RegExp(r'^(\d{1,2}):(\d{2})$').firstMatch(result);
    if (match != null) return '${match.group(1)!.padLeft(2, '0')}:${match.group(2)}';
    return result;
  }

  static String _shortGradeName(Object? value) => (value?.toString() ?? '')
      .replaceFirst(RegExp(r'^\s*الصف\s+'), '')
      .replaceFirst(RegExp(r'\s+الابتدائي\s*$'), '')
      .trim();

  static int _asInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
