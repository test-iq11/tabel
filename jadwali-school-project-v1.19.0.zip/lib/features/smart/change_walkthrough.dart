import 'dart:async';

import 'package:flutter/material.dart';

import '../../services/schedule_comparison_service.dart';

Future<void> showChangeWalkthrough(
  BuildContext context, {
  required List<ScheduleChange> changes,
  required Map<int, String> sections,
  required Map<int, String> subjects,
  required Map<int, String> teachers,
  required Map<int, String> days,
  required Map<int, String> slots,
}) => showDialog<void>(
  context: context,
  builder: (_) => _Walkthrough(
    changes: changes,
    sections: sections,
    subjects: subjects,
    teachers: teachers,
    days: days,
    slots: slots,
  ),
);

class _Walkthrough extends StatefulWidget {
  const _Walkthrough({
    required this.changes,
    required this.sections,
    required this.subjects,
    required this.teachers,
    required this.days,
    required this.slots,
  });
  final List<ScheduleChange> changes;
  final Map<int, String> sections, subjects, teachers, days, slots;
  @override
  State<_Walkthrough> createState() => _WalkthroughState();
}

class _WalkthroughState extends State<_Walkthrough> {
  int _index = 0;
  Timer? _timer;
  bool get _playing => _timer?.isActive ?? false;
  void _stop() {
    _timer?.cancel();
    _timer = null;
  }

  void _step(int delta) {
    _stop();
    setState(
      () => _index = (_index + delta).clamp(0, widget.changes.length - 1),
    );
  }

  void _play() {
    if (_playing) {
      setState(_stop);
      return;
    }
    if (_index == widget.changes.length - 1) _index = 0;
    setState(() {
      _timer = Timer.periodic(const Duration(milliseconds: 1800), (_) {
        if (!mounted) return;
        if (_index >= widget.changes.length - 1) {
          setState(_stop);
        } else {
          setState(() => _index++);
        }
      });
    });
  }

  @override
  void dispose() {
    _stop();
    super.dispose();
  }

  int id(Object? value) =>
      value is num ? value.toInt() : int.tryParse('$value') ?? 0;
  Widget _place(
    String title,
    Map<String, Object?>? row,
    Color color,
  ) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(17),
    decoration: BoxDecoration(
      color: color.withValues(alpha: .08),
      border: Border.all(color: color.withValues(alpha: .3)),
      borderRadius: BorderRadius.circular(18),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(color: color, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 8),
        if (row == null)
          const Text('لا توجد حصة')
        else ...[
          Text(
            '${widget.days[id(row['day_id'])] ?? row['day_id']} · ${widget.slots[id(row['slot_id'])] ?? row['slot_id']}',
          ),
          Text(
            widget.teachers[id(row['teacher_id'])] ?? 'دون معلم',
            style: const TextStyle(fontSize: 12),
          ),
        ],
      ],
    ),
  );
  @override
  Widget build(BuildContext context) {
    if (widget.changes.isEmpty)
      return const AlertDialog(content: Text('لا توجد تغييرات لعرضها.'));
    final change = widget.changes[_index];
    final row = change.lesson;
    return AlertDialog(
      title: const Text('شاهد التغييرات خطوة بخطوة'),
      content: SizedBox(
        width: 540,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                '${_index + 1} من ${widget.changes.length} · معاينة فقط، لا يتغير الجدول أثناء العرض',
                style: TextStyle(
                  fontSize: 12,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 13),
              LinearProgressIndicator(
                value: (_index + 1) / widget.changes.length,
              ),
              const SizedBox(height: 18),
              AnimatedSwitcher(
                duration: MediaQuery.disableAnimationsOf(context)
                    ? Duration.zero
                    : const Duration(milliseconds: 280),
                child: Column(
                  key: ValueKey(_index),
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      '${widget.subjects[id(row['subject_id'])] ?? row['subject_id']}',
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      widget.sections[id(row['section_id'])] ??
                          'الصف ${row['section_id']}',
                    ),
                    const SizedBox(height: 16),
                    _place(
                      'قبل',
                      change.before,
                      Theme.of(context).colorScheme.error,
                    ),
                    const Padding(
                      padding: EdgeInsets.all(8),
                      child: Icon(Icons.south),
                    ),
                    _place(
                      'بعد',
                      change.after,
                      Theme.of(context).colorScheme.primary,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
            ],
          ),
        ),
      ),
      actions: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            OutlinedButton(
              onPressed: _index == 0 ? null : () => _step(-1),
              child: const Text('السابق'),
            ),
            FilledButton.icon(
              onPressed: _play,
              icon: Icon(_playing ? Icons.pause : Icons.play_arrow),
              label: Text(_playing ? 'إيقاف' : 'عرض تلقائي'),
            ),
            OutlinedButton(
              onPressed: _index >= widget.changes.length - 1
                  ? null
                  : () => _step(1),
              child: const Text('التالي'),
            ),
          ],
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('العودة للمقارنة'),
        ),
      ],
    );
  }
}
