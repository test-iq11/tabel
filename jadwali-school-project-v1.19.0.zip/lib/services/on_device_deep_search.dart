/// Progressive, cancellable on-device constraint search configuration.
/// This is a stronger OFFLINE Dart search, not Google's OR-Tools CP-SAT.
class DeepSearchStage {
  const DeepSearchStage(this.number, this.nodes, this.seconds, this.label);
  final int number;
  final int nodes;
  final int seconds;
  final String label;
}

class OnDeviceDeepSearch {
  const OnDeviceDeepSearch._();

  static const stages = <DeepSearchStage>[
    DeepSearchStage(1, 650000, 45, 'إصلاح المجموعات المتعثرة'),
    DeepSearchStage(2, 1250000, 90, 'بحث تراجعي أوسع'),
    DeepSearchStage(3, 2000000, 180, 'إنقاذ شامل ضمن الوقت المحدد'),
  ];

  /// Return the best currently known schedule, never prefer an incomplete
  /// board over a complete one. This is used between independent attempts.
  static Map<String, Object?>? best(List<Map<String, Object?>> results) {
    Map<String, Object?>? winner;
    for (final candidate in results) {
      if (candidate['placements'] is! List) continue;
      if (winner == null) {
        winner = candidate;
        continue;
      }
      final count = (candidate['placements'] as List).length;
      final previous = (winner['placements'] as List).length;
      final complete = candidate['complete'] == true;
      final wasComplete = winner['complete'] == true;
      if ((complete && !wasComplete) ||
          (complete == wasComplete && count > previous)) {
        winner = candidate;
      }
    }
    return winner;
  }
}
