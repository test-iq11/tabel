import 'dart:convert';
import 'dart:io';

import 'schedule_improvement_service.dart';

/// Optional real OR-Tools CP-SAT engine running on the school's own computer.
/// No request is sent unless the user explicitly presses the CP-SAT button.
/// It is NOT a local Android native solver; the offline Dart engine remains.
class CpSatClient {
  const CpSatClient();

  Future<Map<String, Object?>> solve({
    required Uri endpoint,
    required String token,
    required Map<String, Object?> input,
    Duration timeout = const Duration(seconds: 65),
  }) async {
    if (endpoint.scheme != 'http' && endpoint.scheme != 'https') {
      throw const FormatException('يجب استخدام عنوان HTTP أو HTTPS لمحرك المدرسة.');
    }
    if (endpoint.host.isEmpty || token.trim().length < 16) {
      throw const FormatException('أدخل رابط المحرك ورمز وصول مكوناً من 16 حرفاً على الأقل.');
    }
    final uri = endpoint.replace(path: '/solve', query: null, fragment: null);
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    try {
      final request = await client.postUrl(uri).timeout(const Duration(seconds: 12));
      request.headers.set(HttpHeaders.contentTypeHeader, 'application/json; charset=utf-8');
      request.headers.set(HttpHeaders.authorizationHeader, 'Bearer $token');
      request.headers.set(HttpHeaders.cacheControlHeader, 'no-store');
      request.add(utf8.encode(jsonEncode({
        'input': input,
        'timeLimitSeconds': (timeout.inSeconds - 10).clamp(1, 180),
      })));
      final response = await request.close().timeout(timeout);
      final body = await utf8.decoder.bind(response).join().timeout(timeout);
      if (response.statusCode != 200) {
        throw StateError('رفض المحرك الطلب (${response.statusCode}). تحقق من الرمز وتشغيل الخادم.');
      }
      final value = jsonDecode(body);
      if (value is! Map) throw const FormatException('استجابة CP-SAT غير صحيحة.');
      final result = Map<String, Object?>.from(value);
      final status = '${result['status'] ?? ''}';
      if (status != 'OPTIMAL' && status != 'FEASIBLE') {
        return <String, Object?>{
          'status': status,
          'message': '${result['message'] ?? 'لم يتم التوصل إلى حل.'}',
          'complete': false,
        };
      }
      final rows = (result['placements'] as List?)?.map((e) =>
          Map<String, Object?>.from(e as Map)).toList() ?? [];
      // The phone independently validates EVERY hard rule and locked cell.
      if (!ScheduleImprovementService.valid(input, rows)) {
        throw StateError('رفض التطبيق نتيجة CP-SAT لأنها تخالف أحد القيود المحلية. لم يُحفظ أي تعديل.');
      }
      return <String, Object?>{
        'status': status,
        'complete': true,
        'profile': 'minimal_changes',
        'label': 'CP-SAT الرياضي (OR-Tools)',
        'placements': rows,
        'unscheduled': <String>[],
        'dailySpreadIssues': <String>[],
        'requestedCount': rows.length,
        'exploredNodes': result['exploredBranches'] ?? 0,
        'searchLimitReached': false,
      };
    } finally {
      client.close(force: true);
    }
  }
}
