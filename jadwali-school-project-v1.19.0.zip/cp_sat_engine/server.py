"""Optional local-network OR-Tools solver: python -m cp_sat_engine.server.

Use a secret token and HTTPS reverse proxy if exposing beyond a trusted LAN.
No data are written to disk. The HTTP server limits payload size and time.
"""
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .solver import solve

TOKEN = os.environ.get('JADWALI_CP_SAT_TOKEN', '')
HOST = os.environ.get('JADWALI_CP_SAT_HOST', '127.0.0.1')
PORT = int(os.environ.get('JADWALI_CP_SAT_PORT', '8765'))


class Handler(BaseHTTPRequestHandler):
    def _json(self, status, data):
        raw = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path == '/health':
            try:
                import ortools
                self._json(200, {'status': 'ok', 'engine': 'OR-Tools CP-SAT', 'version': ortools.__version__})
            except ImportError:
                self._json(503, {'status': 'missing_dependency', 'message': 'Install ortools first.'})
        else:
            self._json(404, {'status': 'not_found'})

    def do_POST(self):
        if self.path != '/solve':
            return self._json(404, {'status': 'not_found'})
        if not TOKEN or self.headers.get('Authorization') != f'Bearer {TOKEN}':
            return self._json(401, {'status': 'unauthorized'})
        size = int(self.headers.get('Content-Length') or 0)
        if size < 1 or size > 2_000_000:
            return self._json(413, {'status': 'invalid_size'})
        try:
            body = json.loads(self.rfile.read(size))
            if not isinstance(body, dict) or not isinstance(body.get('input'), dict):
                return self._json(400, {'status': 'invalid_input'})
            result = solve(body['input'], body.get('timeLimitSeconds', 45))
            return self._json(200, result)
        except (ValueError, TypeError, KeyError) as err:
            return self._json(400, {'status': 'invalid_input', 'message': str(err)[:300]})
        except ImportError:
            return self._json(503, {'status': 'missing_dependency', 'message': 'Install ortools.'})
        except Exception:
            return self._json(500, {'status': 'error', 'message': 'CP-SAT failed; review server logs.'})

    def log_message(self, format, *args):
        # Do not log personally identifying school data or HTTP bodies.
        pass


def main():
    if not TOKEN or len(TOKEN) < 16:
        raise SystemExit('Set JADWALI_CP_SAT_TOKEN to a secret of 16+ characters before starting.')
    print(f'Jadwali CP-SAT ready at http://{HOST}:{PORT}; /health')
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()


if __name__ == '__main__':
    main()
