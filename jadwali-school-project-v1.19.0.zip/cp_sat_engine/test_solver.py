import json
import unittest
from pathlib import Path

from cp_sat_engine.solver import solve

try:
    from ortools.sat.python import cp_model  # noqa: F401
    HAS_CP = True
except ImportError:
    HAS_CP = False


@unittest.skipUnless(HAS_CP, 'Install the real OR-Tools runtime to test CP-SAT')
class CpSatTests(unittest.TestCase):
    def setUp(self):
        self.small = dict(
            sections=[{'id': 1, 'grade_id': 1, 'max_daily_lessons': 6, 'grade_name': 'الأول'}],
            requirements=[{'section_id': 1, 'subject_id': 1, 'weekly_lessons': 2,
                           'max_daily_lessons': 1, 'allow_same_day': 0}],
            teachers=[{'id': 1, 'weekly_load': 2, 'max_daily_lessons': 2, 'max_consecutive_lessons': 1}],
            qualifications=[{'teacher_id': 1, 'subject_id': 1}],
            days=[{'id': 1, 'position': 0, 'is_active': 1, 'name': 'الأحد'},
                  {'id': 2, 'position': 1, 'is_active': 1, 'name': 'الاثنين'}],
            slots=[{'id': 1, 'position': 0, 'kind': 'lesson', 'is_available': 1},
                   {'id': 2, 'position': 1, 'kind': 'lesson', 'is_available': 1}],
            teacherSubjectGrades=[], teacherGrades=[], teacherAvailability=[],
            subjectBlockedSlots=[], lockedPlacements=[], initialPlacements=[])

    def test_finds_complete_without_teacher_clashes(self):
        result = solve(self.small, 10)
        self.assertIn(result['status'], ('OPTIMAL', 'FEASIBLE'))
        self.assertEqual(len(result['placements']), 2)
        self.assertEqual({p['day_id'] for p in result['placements']}, {1, 2})

    def test_proves_infeasible_when_teacher_unavailable_all_week(self):
        self.small['teacherAvailability'] = [
            {'teacher_id': 1, 'day_id': day, 'slot_id': slot, 'is_available': 0}
            for day in (1, 2) for slot in (1, 2)]
        self.assertEqual(solve(self.small, 10)['status'], 'INFEASIBLE')

    def test_keeps_valid_locked_lesson(self):
        self.small['lockedPlacements'] = [{'section_id': 1, 'subject_id': 1,
            'teacher_id': 1, 'day_id': 1, 'slot_id': 2}]
        result = solve(self.small, 10)
        self.assertIn(result['status'], ('OPTIMAL', 'FEASIBLE'))
        self.assertTrue(any(p['day_id'] == 1 and p['slot_id'] == 2 for p in result['placements']))

    def test_reference_backup_full_181(self):
        source = Path(__file__).resolve().parents[1] / 'test/fixtures/backup_school_181.json'
        data = json.loads(source.read_text(encoding='utf-8'))
        result = solve(data, 75)
        # Its exported full timetable is a valid seed. Result must be verified
        # independently by Flutter tests before it is published in Android.
        self.assertIn(result['status'], ('OPTIMAL', 'FEASIBLE'), result.get('message'))
        self.assertEqual(len(result['placements']), 181)
        keys = {(p['section_id'], p['day_id'], p['slot_id']) for p in result['placements']}
        self.assertEqual(len(keys), 181)


if __name__ == '__main__':
    unittest.main()
