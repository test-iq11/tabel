"""Genuine Google OR-Tools CP-SAT engine for Jadwali.

Does not import teacher names in logs. Accepts the exact JSON input sent to the
Flutter ScheduleSearchController, never changes the database, and returns
candidate placements for independent validation on the phone.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any


def as_int(v: Any, fallback: int = 0) -> int:
    try:
        return int(v)
    except (ValueError, TypeError):
        return fallback


def ordered(rows, active=False):
    result = [row for row in rows if not active or as_int(row.get('is_active'), 1) == 1]
    return sorted(result, key=lambda r: (as_int(r.get('position'), 999), as_int(r.get('id'))))


def grade_allowed(tid, sid, grade, qualified, legacy, modern, modern_teachers):
    if (tid, sid) not in qualified or grade <= 0:
        return False
    grades = modern.get((tid, sid))
    if grades:
        return 0 in grades or grade in grades
    if tid in modern_teachers:
        return False
    if tid in legacy:
        return grade in legacy[tid]
    return not modern


def sunday(day):
    name = str(day.get('name', '')).strip().lower().replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
    return name.startswith('الاحد') or name == 'sunday' or (not name and as_int(day.get('position'), -1) == 0)


def sixth(section):
    name = str(section.get('grade_name') or section.get('grade') or '').strip().lower()
    return 'السادس' in name or 'سادس' in name or name in ('6', '٦', 'grade 6', 'sixth grade') or (not name and as_int(section.get('grade_position'), -1) == 5)


def solve(payload: dict, timeout_seconds: int = 45) -> dict:
    # Imported on demand, so the server emits a descriptive health error if
    # OR-Tools was not installed instead of silently mimicking CP-SAT.
    from ortools.sat.python import cp_model

    sections = {as_int(x['id']): x for x in payload.get('sections', [])}
    teachers = {as_int(x['id']): x for x in payload.get('teachers', [])}
    requirements = [r for r in payload.get('requirements', []) if as_int(r.get('weekly_lessons')) > 0]
    days = ordered(payload.get('days', []), True)
    slots = ordered([s for s in payload.get('slots', []) if s.get('kind') == 'lesson' and as_int(s.get('is_available'), 1) == 1])
    qualified = {(as_int(r.get('teacher_id')), as_int(r.get('subject_id'))) for r in payload.get('qualifications', [])}
    legacy = defaultdict(set)
    modern = defaultdict(set)
    for r in payload.get('teacherGrades', []):
        legacy[as_int(r.get('teacher_id'))].add(as_int(r.get('grade_id')))
    for r in payload.get('teacherSubjectGrades', []):
        modern[as_int(r.get('teacher_id')), as_int(r.get('subject_id'))].add(as_int(r.get('grade_id')))
    modern_teachers = {t for t, _ in modern}
    blocks = {(as_int(r.get('subject_id')), as_int(r.get('slot_id'))) for r in payload.get('subjectBlockedSlots', [])}
    unavailable = {(as_int(r.get('teacher_id')), as_int(r.get('day_id')), as_int(r.get('slot_id')))
                   for r in payload.get('teacherAvailability', payload.get('availability', []))
                   if as_int(r.get('is_available'), 1) == 0}
    required_by_section = defaultdict(int)
    for r in requirements:
        required_by_section[as_int(r.get('section_id'))] += as_int(r.get('weekly_lessons'))
    by_key = defaultdict(list)
    for r in requirements:
        by_key[(as_int(r.get('section_id')), as_int(r.get('subject_id')))].append(r)
    if any(len(v) != 1 for v in by_key.values()):
        return {'status': 'INVALID_INPUT', 'message': 'يوجد متطلب مكرر للمادة والشعبة.'}
    if not days or not slots or not sections:
        return {'status': 'INVALID_INPUT', 'message': 'أيام أو فترات أو شعب المدرسة غير مكتملة.'}
    # Seven-period exception matches the Flutter policy: sixth grade, Sunday,
    # full six daily periods and >6*activeDays weekly demand.
    section_limit = {}
    seventh = {}
    for sec_id, sec in sections.items():
        configured = as_int(sec.get('max_daily_lessons'), 6)
        normal = min(configured if configured > 0 else len(slots), len(slots), 6)
        section_limit[sec_id] = normal
        seventh[sec_id] = (sixth(sec) and normal >= 6 and len(slots) >= 7
                           and any(sunday(d) for d in days)
                           and required_by_section[sec_id] > len(days) * 6)

    model = cp_model.CpModel()
    choices = defaultdict(list)
    by_section_cell = defaultdict(list)
    by_teacher_cell = defaultdict(list)
    by_teacher_day = defaultdict(list)
    by_teacher_week = defaultdict(list)
    by_section_day = defaultdict(list)
    by_group_day = defaultdict(list)
    by_group_day_early = defaultdict(list)
    by_group_day_late = defaultdict(list)
    hint_keys = {(as_int(r.get('section_id')), as_int(r.get('subject_id')),
                  as_int(r.get('teacher_id')), as_int(r.get('day_id')), as_int(r.get('slot_id')))
                 for r in payload.get('initialPlacements', [])}
    fixed_keys = {(as_int(r.get('section_id')), as_int(r.get('subject_id')),
                   as_int(r.get('teacher_id')), as_int(r.get('day_id')), as_int(r.get('slot_id')))
                  for r in payload.get('lockedPlacements', [])}
    # Avoid weakening room locks: the application currently generates no rooms.
    if any(r.get('room_id') is not None for r in payload.get('lockedPlacements', [])):
        return {'status': 'UNSUPPORTED', 'message': 'محرك CP-SAT لا يدعم تثبيت القاعات حتى الآن؛ استخدم البحث المحلي.'}
    if len(fixed_keys) != len(payload.get('lockedPlacements', [])):
        return {'status': 'INVALID_INPUT', 'message': 'هناك حصص مثبتة مكررة.'}
    var_by_key = {}
    for (sec_id, sub_id), group in by_key.items():
        req = group[0]
        sec = sections.get(sec_id)
        if sec is None:
            return {'status': 'INVALID_INPUT', 'message': 'المتطلبات تشير إلى شعبة غير موجودة.'}
        eligible = [tid for tid in teachers if grade_allowed(tid, sub_id, as_int(sec.get('grade_id')),
                     qualified, legacy, modern, modern_teachers)]
        if not eligible:
            return {'status': 'INFEASIBLE', 'message': f'المتطلب {sec_id}/{sub_id}: لا يوجد معلم مؤهل.'}
        for tid in eligible:
            for day in days:
                did = as_int(day['id'])
                for rank, slot in enumerate(slots):
                    sid = as_int(slot['id'])
                    if rank >= section_limit[sec_id]:
                        if not (rank == 6 and seventh[sec_id] and sunday(day)):
                            continue
                    if ((sub_id, sid) in blocks or (tid, did, sid) in unavailable):
                        continue
                    key = (sec_id, sub_id, tid, did, sid)
                    v = model.new_bool_var('x_' + '_'.join(map(str, key)))
                    var_by_key[key] = v
                    choices[sec_id, sub_id].append(v)
                    by_section_cell[sec_id, did, sid].append(v)
                    by_teacher_cell[tid, did, sid].append(v)
                    by_teacher_day[tid, did].append(v)
                    by_teacher_week[tid].append(v)
                    by_section_day[sec_id, did].append(v)
                    by_group_day[sec_id, sub_id, did].append(v)
                    if rank < 5:
                        by_group_day_early[sec_id, sub_id, did].append(v)
                    elif rank in (5, 6):
                        by_group_day_late[sec_id, sub_id, did].append(v)
                    if key in hint_keys:
                        model.add_hint(v, 1)
        if len(choices[sec_id, sub_id]) < as_int(req['weekly_lessons']):
            return {'status': 'INFEASIBLE', 'message': f'المادة {sub_id} للشعبة {sec_id}: الخانات المتاحة أقل من المطلوب.'}
        model.add(sum(choices[sec_id, sub_id]) == as_int(req['weekly_lessons']))
        for day in days:
            did = as_int(day['id'])
            values = by_group_day[sec_id, sub_id, did]
            weekly = as_int(req['weekly_lessons'])
            allow_same = as_int(req.get('allow_same_day')) == 1
            max_daily = as_int(req.get('max_daily_lessons'), 2)
            # Necessary repeat only with sixth (or permitted seventh) and an
            # early slot. Replicate the effective restriction from Flutter.
            has_early = any((sub_id, as_int(s['id'])) not in blocks and rank < min(5, section_limit[sec_id])
                            for rank, s in enumerate(slots))
            has_late = any((sub_id, as_int(s['id'])) not in blocks and
                           (rank == 5 and section_limit[sec_id] >= 6 or
                            rank == 6 and seventh[sec_id] and sunday(day))
                           for rank, s in enumerate(slots))
            repeat = (weekly > len(days) and not allow_same and section_limit[sec_id] >= 6
                      and has_early and has_late)
            model.add(sum(values) <= (max(1, max_daily) if allow_same else (2 if repeat else 1)))
            if weekly >= 5:
                model.add(sum(values) >= 1)
            if repeat:
                early = by_group_day_early[sec_id, sub_id, did]
                late = by_group_day_late[sec_id, sub_id, did]
                model.add(sum(early) <= 1)
                model.add(sum(late) <= 1)
                # Having a second lesson requires one early and one late.
                # Early+late cannot exceed 2; max 1 for each is sufficient.
    for values in by_section_cell.values():
        model.add(sum(values) <= 1)
    for values in by_teacher_cell.values():
        model.add(sum(values) <= 1)
    for (sec_id, did), values in by_section_day.items():
        day = next(x for x in days if as_int(x['id']) == did)
        model.add(sum(values) <= (7 if seventh[sec_id] and sunday(day) else section_limit[sec_id]))
    for tid, teacher in teachers.items():
        weekly_max = as_int(teacher.get('weekly_load'), 24)
        if weekly_max > 0:
            model.add(sum(by_teacher_week[tid]) <= weekly_max)
        max_daily = as_int(teacher.get('max_daily_lessons'), 6)
        for day in days:
            did = as_int(day['id'])
            if max_daily > 0:
                model.add(sum(by_teacher_day[tid, did]) <= max_daily)
            run = as_int(teacher.get('max_consecutive_lessons'))
            if run > 0 and run < len(slots):
                for first in range(0, len(slots) - run):
                    seq = [v for rank in range(first, first + run + 1)
                           for v in by_teacher_cell[tid, did, as_int(slots[rank]['id'])]]
                    if seq:
                        model.add(sum(seq) <= run)
    missing_locks = fixed_keys - set(var_by_key)
    if missing_locks:
        return {'status': 'INFEASIBLE', 'message': 'إحدى الحصص المثبتة لم تعد متاحة أو لم يعد معلمها مؤهلاً.'}
    for key in fixed_keys:
        model.add(var_by_key[key] == 1)
    # Prefer few changes; this is a soft criterion, never at the expense of
    # feasibility. Only reward intact incumbent rows; no forced hints.
    if hint_keys:
        model.maximize(sum(v for key, v in var_by_key.items() if key in hint_keys))
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = max(1, min(as_int(timeout_seconds, 45), 180))
    solver.parameters.num_search_workers = 8
    solver.parameters.random_seed = 2026
    status = solver.solve(model)
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return {'status': solver.status_name(status), 'placements': [],
                'requestedCount': sum(as_int(r['weekly_lessons']) for r in requirements),
                'message': 'ثبت عدم وجود حل وفق القيود.' if status == cp_model.INFEASIBLE
                else 'انتهى البحث دون التوصل إلى حل مثبت، ولم تثبت الاستحالة.'}
    placements = [{'section_id': key[0], 'subject_id': key[1], 'teacher_id': key[2],
                   'day_id': key[3], 'slot_id': key[4], 'room_id': None}
                  for key, var in var_by_key.items() if solver.value(var)]
    return {'status': solver.status_name(status), 'placements': placements,
            'requestedCount': sum(as_int(r['weekly_lessons']) for r in requirements),
            'exploredBranches': solver.num_branches,
            'wallTime': solver.wall_time}
