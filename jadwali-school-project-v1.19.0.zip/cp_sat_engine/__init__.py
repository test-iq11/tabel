"""Optional CP-SAT engine. Runtime requires the official ortools wheel."""
