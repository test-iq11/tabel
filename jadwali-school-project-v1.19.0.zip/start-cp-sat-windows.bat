@echo off
setlocal
cd /d "%~dp0"
echo Jadwali CP-SAT - OR-Tools
where py >nul 2>nul
if errorlevel 1 (
  echo Install Python 3.11+ for Windows, then reopen this file.
  pause
  exit /b 1
)
set "JADWALI_CP_SAT_HOST=0.0.0.0"
set "JADWALI_CP_SAT_PORT=8765"
if not defined JADWALI_CP_SAT_TOKEN set /p "JADWALI_CP_SAT_TOKEN=Enter a 16+ character secret token: "
py -3 -m pip install -r cp_sat_engine\requirements.txt
if errorlevel 1 (
  echo Unable to install OR-Tools. Check Python and internet access.
  pause
  exit /b 1
)
echo Running on port 8765. Allow Windows firewall only on Private network.
echo Use your PC's local IPv4 address in the Android app.
py -3 -m cp_sat_engine.server
pause
