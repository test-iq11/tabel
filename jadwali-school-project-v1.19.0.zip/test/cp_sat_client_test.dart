import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/cp_sat_client.dart';

void main() {
  final input = <String, Object?>{
    'sections': <Map<String, Object?>>[
      {'id': 1, 'grade_id': 1, 'max_daily_lessons': 6, 'grade_name': 'الأول'},
    ],
    'requirements': <Map<String, Object?>>[
      {'section_id': 1, 'subject_id': 10, 'weekly_lessons': 1,
       'allow_same_day': 0, 'max_daily_lessons': 1},
    ],
    'teachers': <Map<String, Object?>>[
      {'id': 3, 'weekly_load': 5, 'max_daily_lessons': 5, 'max_consecutive_lessons': 4},
    ],
    'qualifications': <Map<String, Object?>>[
      {'teacher_id': 3, 'subject_id': 10},
    ],
    'days': <Map<String, Object?>>[
      {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
    ],
    'slots': <Map<String, Object?>>[
      {'id': 1, 'position': 0, 'kind': 'lesson', 'is_available': 1},
    ],
    'lockedPlacements': <Map<String, Object?>>[],
  };
  final validPlacement = <String, Object?>{
    'section_id': 1, 'subject_id': 10, 'teacher_id': 3,
    'day_id': 1, 'slot_id': 1, 'room_id': null,
  };

  Future<Map<String, Object?>> serve(Object? output, {int status = 200}) async {
    final server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    server.listen((request) async {
      final authorization = request.headers.value('Authorization');
      expect(authorization, 'Bearer 1234567890abcdef');
      final body = jsonDecode(await utf8.decoder.bind(request).join()) as Map;
      expect(body['input'], isA<Map>());
      request.response.statusCode = status;
      request.response.headers.contentType = ContentType.json;
      request.response.write(jsonEncode(output));
      await request.response.close();
      await server.close(force: true);
    });
    try {
      return await const CpSatClient().solve(
        endpoint: Uri.parse('http://127.0.0.1:${server.port}'),
        token: '1234567890abcdef', input: input,
      );
    } finally {
      await server.close(force: true);
    }
  }

  test('accepts only validated full solutions', () async {
    final result = await serve({'status': 'FEASIBLE', 'placements': [validPlacement]});
    expect(result['complete'], true);
    expect((result['placements'] as List).length, 1);
  });

  test('rejects a claimed complete solution in a blocked cell', () async {
    final blocked = Map<String, Object?>.from(input);
    blocked['subjectBlockedSlots'] = <Map<String, Object?>>[
      {'subject_id': 10, 'slot_id': 1}
    ];
    final server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    server.listen((request) async {
      await utf8.decoder.bind(request).join();
      request.response.headers.contentType = ContentType.json;
      request.response.write(jsonEncode({'status': 'FEASIBLE', 'placements': [validPlacement]}));
      await request.response.close();
      await server.close(force: true);
    });
    try {
      await expectLater(
        const CpSatClient().solve(endpoint: Uri.parse('http://127.0.0.1:${server.port}'),
          token: '1234567890abcdef', input: blocked),
        throwsA(isA<StateError>()),
      );
    } finally {
      await server.close(force: true);
    }
  });

  test('does not confuse INFEASIBLE with transport failure', () async {
    final result = await serve({'status': 'INFEASIBLE', 'message': 'لا يوجد حل'});
    expect(result['complete'], false);
    expect(result['status'], 'INFEASIBLE');
  });
}
