import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/on_device_deep_search.dart';

void main() {
  test('three bounded local stages fit the controller node cap', () {
    expect(OnDeviceDeepSearch.stages, hasLength(3));
    var previous = 0;
    for (final stage in OnDeviceDeepSearch.stages) {
      expect(stage.nodes, greaterThan(previous));
      expect(stage.nodes, lessThanOrEqualTo(2000000));
      expect(stage.seconds, greaterThan(0));
      previous = stage.nodes;
    }
  });

  test('complete incumbent beats later incomplete board', () {
    final results = <Map<String, Object?>>[
      {'complete': true, 'placements': List.filled(3, 1)},
      {'complete': false, 'placements': List.filled(4, 1)},
    ];
    expect(OnDeviceDeepSearch.best(results), same(results.first));
  });

  test('best partial board is preserved if search is interrupted', () {
    final results = <Map<String, Object?>>[
      {'complete': false, 'placements': [1]},
      {'complete': false, 'placements': [1, 2]},
    ];
    expect(OnDeviceDeepSearch.best(results), same(results.last));
    expect(OnDeviceDeepSearch.best([]), isNull);
  });
}
