import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:iraqi_school_timetable/services/lns_rescue_service.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';

void main() {
  test('rescue completes a partial schedule while retaining the hard lock', () {
    final input = <String, Object?>{
      'sections': <Map<String, Object?>>[
        {'id': 1, 'grade_id': 1, 'max_daily_lessons': 6, 'grade_name': 'الأول'},
      ],
      'requirements': <Map<String, Object?>>[
        {'section_id': 1, 'subject_id': 1, 'weekly_lessons': 2,
         'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      'teachers': <Map<String, Object?>>[
        {'id': 1, 'weekly_load': 2, 'max_daily_lessons': 2, 'max_consecutive_lessons': 4},
      ],
      'qualifications': <Map<String, Object?>>[
        {'teacher_id': 1, 'subject_id': 1},
      ],
      'days': <Map<String, Object?>>[
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
      ],
      'slots': <Map<String, Object?>>[
        {'id': 1, 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
      'lockedPlacements': <Map<String, Object?>>[
        {'section_id': 1, 'subject_id': 1, 'teacher_id': 1,
         'day_id': 1, 'slot_id': 1, 'room_id': null},
      ],
    };
    final seed = SchedulerResult(
      placements: (input['lockedPlacements'] as List).cast<Map<String, Object?>>(),
      unscheduled: const ['حصة لم توزع'], requestedCount: 2,
      exploredNodes: 0, searchLimitReached: false,
    );
    final result = const LnsRescueService().rescue(
      input: input, seed: seed, nodeLimit: 3000,
      timeLimit: const Duration(seconds: 5),
    );
    expect(result.complete, isTrue);
    expect(ScheduleImprovementService.valid(input, result.placements), isTrue);
  });
}
