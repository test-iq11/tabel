# Jadwali School v1.9.1 — analyzer warning cleanup

This is a focused maintenance patch against v1.9.0, not a rewrite of the scheduling engine.

- Removed `subjectNameById`, an unused local lookup in `lib/services/auto_scheduler_service.dart`.
- Removed `_isPreferredEmergencySubject`, an unreferenced private helper in the same file.
- Updated application version to `1.9.1+31`.
- Updated the matching GitHub Actions workflow to explicitly choose `jadwali-school-project-v1.9.1.zip` when present.

The cleanup leaves the scheduling logic unchanged. `flutter analyze` still treats warnings as actionable: no disabling lints or `--no-fatal-warnings` flags were introduced.

## Validation note
The exact two unused-code findings were removed by checking the source. This environment has no installed Flutter/Dart toolchain; run the supplied GitHub Actions workflow to verify analyzer, unit tests, and APK build.
