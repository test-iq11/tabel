"""Independent exact feasibility audit of the supplied JSON backup.
Run: python audit/verify_backup_schedule.py /path/to/backup.json
Uses scipy MILP; NOT bundled into the Android runtime.
"""
import json,sys,collections,time
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import lil_matrix
path=sys.argv[1] if len(sys.argv)>1 else '/mnt/data/مضبوطة.json'
D=json.load(open(path,encoding='utf-8')); T=D['tables'];secs={r['id']:r for r in T['sections']};grades={r['id']:r for r in T['grades']};teachers={r['id']:r for r in T['teachers']};rqs=T['section_subject_requirements'];days=sorted([d for d in T['school_days'] if d['is_active']], key=lambda z:z['position']);slots=sorted([s for s in T['time_slots'] if s['kind']=='lesson' and s['is_available']],key=lambda z:z['position']);
quals={(q['teacher_id'],q['subject_id'],q['grade_id']) for q in T['teacher_subject_grades']}; qsub={(q['teacher_id'],q['subject_id']) for q in T['teacher_subjects']}; blocked={(r['subject_id'],r['slot_id']) for r in T['subject_blocked_slots']}; unavailable={(r['teacher_id'],r['day_id'],r['slot_id']) for r in T['teacher_availability'] if not r['is_available']};
variables=[]; by_req=collections.defaultdict(list);by_section_time=collections.defaultdict(list);by_teacher_time=collections.defaultdict(list);by_section_day=collections.defaultdict(list);by_teacher_day=collections.defaultdict(list);by_req_day=collections.defaultdict(list);by_teacher_day_rank=collections.defaultdict(list);by_req_day_early=collections.defaultdict(list);by_req_day_late=collections.defaultdict(list)
for req in rqs:
 sec=secs[req['section_id']]; gr=grades[sec['grade_id']]; teacher_ids=[tid for tid in teachers if (tid,req['subject_id'],sec['grade_id']) in quals and (tid,req['subject_id']) in qsub];
 if not teacher_ids: print('NO ELIGIBLE TEACHER',req)
 for tid in teacher_ids:
  for d in days:
   for rank,slot in enumerate(slots):
    if rank>=6 and not ('السادس' in gr['name'] and d['name']=='الأحد' and len(slots)>=7 and sum(int(q['weekly_lessons']) for q in rqs if q['section_id']==sec['id'])>len(days)*6): continue
    if (req['subject_id'],slot['id']) in blocked or (tid,d['id'],slot['id']) in unavailable: continue
    # Mandatory second occurrences of a nonrepeatable subject must be in period 6/7.
    if int(req['weekly_lessons'])>len(days) and not req['allow_same_day']:
     if rank>=5 and rank!=5 and not ('السادس' in gr['name'] and d['name']=='الأحد'):continue
    idx=len(variables);variables.append((req,tid,d,slot,rank));by_req[req['id']].append(idx);by_section_time[(sec['id'],d['id'],slot['id'])].append(idx);by_teacher_time[(tid,d['id'],slot['id'])].append(idx);by_section_day[(sec['id'],d['id'])].append(idx);by_teacher_day[(tid,d['id'])].append(idx);by_req_day[(req['id'],d['id'])].append(idx);by_teacher_day_rank[(tid,d['id'],rank)].append(idx)
    (by_req_day_early if rank<5 else by_req_day_late)[(req['id'],d['id'])].append(idx)
A=[];lower=[];upper=[]
def constraint(indices,lo,hi):
 if not indices:
  if lo>0: raise RuntimeError('Impossible empty constraint')
  return
 A.append(indices);lower.append(lo);upper.append(hi)
for req in rqs:
 constraint(by_req[req['id']],req['weekly_lessons'],req['weekly_lessons']);
 for d in days:
  idx=by_req_day[(req['id'],d['id'])]
  repeat=req['weekly_lessons']>len(days) and not req['allow_same_day']; day_max=req['max_daily_lessons'] if req['allow_same_day'] else (2 if repeat else 1)
  constraint(idx,1 if req['weekly_lessons']>=len(days) else 0,day_max)
  if repeat:
   constraint(by_req_day_early[(req['id'],d['id'])],0,1)
   constraint(by_req_day_late[(req['id'],d['id'])],0,1)
   # Late only allowed on a day with an early lesson
   A.append([*by_req_day_late[(req['id'],d['id'])],*by_req_day_early[(req['id'],d['id'])]])
   # coefficients special later
   lower.append(-np.inf);upper.append(0)
for k,x in by_section_time.items():constraint(x,0,1)
for k,x in by_teacher_time.items():constraint(x,0,1)
for (sec,day),x in by_section_day.items():constraint(x,0,7 if 'السادس' in grades[secs[sec]['grade_id']]['name'] and day==days[0]['id'] else min(6,secs[sec]['max_daily_lessons']))
for (tid,day),x in by_teacher_day.items():
 lim=teachers[tid]['max_daily_lessons'];constraint(x,0,lim if lim>0 else 99)
 max_con=teachers[tid]['max_consecutive_lessons'];
 if max_con>0:
  for start in range(len(slots)-max_con):
   indices=[]
   for rank in range(start,start+max_con+1):indices+=by_teacher_day_rank[(tid,day,rank)]
   constraint(indices,0,max_con)
for tid,t in teachers.items():constraint([idx for idx,(_,tt,_,_,_) in enumerate(variables) if tt==tid],0,t['weekly_load'])
M=lil_matrix((len(A),len(variables)),dtype=np.float64)
for i,indices in enumerate(A):
 for idx in indices:M[i,idx]=1
# Correct the late <= early constraints (which include disjoint variable positions).
start=len(rqs)*(len(days)+1)
# Easier identify special ones from stored list by row lengths and indices of bounds:
for i,indices in enumerate(A):
 if np.isneginf(lower[i]) and upper[i]==0:
  # find a requirement/day where this special row matches exactly
  idx_set=set(indices)
  for req in rqs:
   for day in days:
    early=by_req_day_early[(req['id'],day['id'])]; late=by_req_day_late[(req['id'],day['id'])]
    if late and early and idx_set==set(early+late):
     for j in early:M[i,j]=-1
     break
   else:continue
   break
print('variables',len(variables),'constraints',len(A),flush=True)
c=np.array([rank*.001 + ((d['position']+rank+req['subject_id'])%5)*.0001 for req,tid,d,slot,rank in variables]); t=time.time()
res=milp(c,integrality=np.ones(len(variables)),bounds=Bounds(0,1),constraints=LinearConstraint(M.tocsr(),np.array(lower),np.array(upper)),options={'time_limit':90,'mip_rel_gap':.1})
print('status',res.status,res.message,'elapsed',round(time.time()-t,1),'objective',res.fun,flush=True)
if res.x is not None:
 sol=[]
 for i,x in enumerate(res.x):
  if x>=.99:
   q,tid,d,slot,rank=variables[i];sol.append({'section_id':q['section_id'],'subject_id':q['subject_id'],'teacher_id':tid,'day_id':d['id'],'slot_id':slot['id'],'room_id':None})
 print('placed',len(sol), 'requested',sum(q['weekly_lessons'] for q in rqs))
 if len(sol)==sum(q['weekly_lessons'] for q in rqs) and res.status in (0,1):
  outfile='/mnt/data/jadwali_final/audit/exact_backup_solution.json';json.dump({'entries':sol,'verified':True,'method':'scipy MILP independent constraint model'},open(outfile,'w',encoding='utf-8'),ensure_ascii=False,indent=2);print('SAVED',outfile)
