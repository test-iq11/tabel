"""Create a separately importable backup with one constraint-checked version.
Original backup remains unmodified. Only trusted local input paths are read.
"""
import sys,json,collections,copy,datetime
src=sys.argv[1] if len(sys.argv)>1 else '/mnt/data/مضبوطة.json'
solution_file=sys.argv[2] if len(sys.argv)>2 else '/mnt/data/jadwali_final/audit/exact_backup_solution.json'
output=sys.argv[3] if len(sys.argv)>3 else '/mnt/data/مضبوطة-181-حصة-متحققة.json'
backup=json.load(open(src,encoding='utf-8')); T=backup['tables']; sol=json.load(open(solution_file,encoding='utf-8'))['entries'];
secs={r['id']:r for r in T['sections']}; gr={r['id']:r for r in T['grades']};tchs={r['id']:r for r in T['teachers']}; reqs={(r['section_id'],r['subject_id']):r for r in T['section_subject_requirements']}; days={r['id']:r for r in T['school_days'] if r['is_active']}; slots={r['id']:r for r in T['time_slots'] if r['kind']=='lesson' and r['is_available']}; slotrank={r['id']:ix for ix,r in enumerate(sorted(slots.values(),key=lambda x:x['position']))};quals={(r['teacher_id'],r['subject_id'],r['grade_id']) for r in T['teacher_subject_grades']}; qsub={(r['teacher_id'],r['subject_id']) for r in T['teacher_subjects']};
assert len(sol)==sum(r['weekly_lessons'] for r in reqs.values()),'Unscheduled request';counts=collections.Counter((r['section_id'],r['subject_id']) for r in sol);
assert all(counts[k]==req['weekly_lessons'] for k,req in reqs.items()), 'Subject requirements mismatch';
scell=set();tcell=set(); td=collections.defaultdict(list);sd=collections.Counter();rday=collections.defaultdict(list);tl=collections.Counter();
for e in sol:
 sid=e['section_id'];tid=e['teacher_id'];day=e['day_id'];slot=e['slot_id'];sub=e['subject_id'];rank=slotrank[slot];
 assert (sid,sub) in reqs and day in days and slot in slots and tid in tchs
 assert (tid,sub,secs[sid]['grade_id']) in quals and (tid,sub) in qsub,'Unauthorized teacher';
 assert (sid,day,slot) not in scell,'Section collision';scell.add((sid,day,slot));
 assert (tid,day,slot) not in tcell,'Teacher collision';tcell.add((tid,day,slot));
 assert rank<6 or (rank==6 and 'السادس' in gr[secs[sid]['grade_id']]['name'] and days[day]['name']=='الأحد'), 'Unauthorized seventh';
 sd[sid,day]+=1;td[tid,day].append(rank);tl[tid]+=1;rday[(sid,sub,day)].append(rank)
for (sid,day),count in sd.items():
 assert count <= (7 if 'السادس' in gr[secs[sid]['grade_id']]['name'] and days[day]['name']=='الأحد' else 6)
for (tid,day),values in td.items():
 teach=tchs[tid];assert len(values)<=teach['max_daily_lessons']
 maxrun=teach['max_consecutive_lessons']; rankset=set(values)
 if maxrun>0:assert all(sum((i in rankset) for i in range(k,k+maxrun+1))<=maxrun for k in range(0,7-maxrun)),'Consecutive overload'
for tid in tchs: assert tl[tid]<=tchs[tid]['weekly_load']
for (sid,sub),req in reqs.items():
 for day in days:
  ranks=rday[sid,sub,day]; allow=req['allow_same_day']==1;repeat=req['weekly_lessons']>len(days) and not allow;
  limit=req['max_daily_lessons'] if allow else 2 if repeat else 1
  assert len(ranks)<=limit,'Daily subject violation';
  if req['weekly_lessons']>=len(days):assert len(ranks)>=1,'Missing required day';
  if repeat and len(ranks)>1:assert any(rank>=5 for rank in ranks) and any(rank<5 for rank in ranks),'Repeat not late'
new=copy.deepcopy(backup);t=new['tables'];now=datetime.datetime.now(datetime.timezone.utc).isoformat();newid=max((v['id'] for v in t['timetable_versions']),default=0)+1;lastid=max((e['id'] for e in t['timetable_entries']),default=0)
for v in t['timetable_versions']:v['is_active']=0
newver={'id':newid,'academic_year_id':t['academic_years'][0]['id'],'name':'الجدول المكتمل 181 حصة - فحص مستقل','status':'قيد التعديل','notes':'نسخة عمل جديدة من البيانات الاحتياطية بعد إيجاد حل 181/181 والتحقق من التصادمات والأنصبة والتأهيل وتغطية الأيام في نموذج قيود مستقل. راجعها قبل اعتمادها.','is_active':1,'created_at':now,'updated_at':now,'approved_at':None}
t['timetable_versions'].append(newver)
for i,e in enumerate(sorted(sol,key=lambda x:(x['day_id'],slotrank[x['slot_id']],x['section_id'])),start=lastid+1):
 t['timetable_entries'].append({'id':i,'version_id':newid,**e,'grade_id':None,'grade_name':None,'created_at':now})
new['exported_at']=now
with open(output,'w',encoding='utf-8') as f:json.dump(new,f,ensure_ascii=False,indent=2)
print('VALIDATED',len(sol),'entries, teachers',len(tchs),'new version',newid,'backup',output)
print('load:',dict(sorted(tl.items())))
