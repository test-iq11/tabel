import 'dart:io';
import 'dart:convert';
import '../lib/services/auto_scheduler_service.dart';
import '../lib/services/conflict_detection_service.dart';
void main(List<String> args) {
 final input=jsonDecode(File(args[0]).readAsStringSync()) as Map<String,dynamic>;
 List<Map<String,Object?>> rows(String key)=>(input[key] as List? ?? []).map((r)=>Map<String,Object?>.from(r as Map)).toList();
 // Always rebuild from scratch; the stored timetable is not used as a solution.
 input['initialPlacements']=<Object?>[];
 final sections=rows('sections'),requirements=rows('requirements'),teachers=rows('teachers'),qualifications=rows('qualifications'),teacherGrades=rows('teacherGrades'),teacherSubjectGrades=rows('teacherSubjectGrades'),days=rows('days'),slots=rows('slots'),availability=rows('teacherAvailability');
 final subjects=requirements.map((r)=>r['subject_id'] as int).toSet().toList()..sort();
 final slotIds=slots.where((r)=>r['kind']=='lesson'&&r['is_available']==1).map((r)=>r['id'] as int).toList();
 final cases=<List<Map<String,Object?>>>[[]];
 for(final subject in subjects)for(final slot in slotIds)cases.add([{'subject_id':subject,'slot_id':slot}]);
 if(args.contains('pairs'))for(final subject in subjects)for(var a=0;a<slotIds.length;a++)for(var b=a+1;b<slotIds.length;b++)cases.add([{'subject_id':subject,'slot_id':slotIds[a]},{'subject_id':subject,'slot_id':slotIds[b]}]);
 for(var index=0;index<cases.length;index++) {
  final blocked=[...rows('subjectBlockedSlots'),...cases[index]];
  final watch=Stopwatch()..start();
  final result=AutoSchedulerService(nodeLimit:int.parse(args[1])).generate(sections:sections,requirements:requirements,teachers:teachers,qualifications:qualifications,teacherGrades:teacherGrades,teacherSubjectGrades:teacherSubjectGrades,subjectBlockedSlots:blocked,days:days,slots:slots,teacherAvailability:availability,initialPlacements:rows('initialPlacements'));
  final issues=const ConflictDetectionService().scan(entries:result.placements,sections:sections,requirements:requirements,teachers:teachers,qualifications:qualifications,days:days,slots:slots,teacherGrades:teacherGrades,teacherSubjectGrades:teacherSubjectGrades,subjectBlockedSlots:blocked,teacherAvailability:availability);
  final blockers=issues.where((i)=>i.type != 'تكرار توقيت المادة في أيام متتالية' && (result.complete || !['نقص الحصص','توزيع المادة على كل أيام الأسبوع'].contains(i.type))).map((i)=>i.type).toSet().toList();
  stdout.writeln(jsonEncode({'case':index,'blocked':cases[index],'placed':result.placements.length,'requested':result.requestedCount,'complete':result.complete,'nodes':result.exploredNodes,'limit':result.searchLimitReached,'ms':watch.elapsedMilliseconds,'violations':blockers}));
 }
}
