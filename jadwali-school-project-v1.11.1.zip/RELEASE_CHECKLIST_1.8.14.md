# قائمة التحقق للإصدار 1.8.14+28

- [x] إصدار `1.8.14+28` مسجل في `pubspec.yaml`.
- [x] عنوان ورقة Excel يطابق العبارة التي يتوقعها اختبار الانحدار: «الأيام عمودية والصفوف والشعب أفقية».
- [x] إعداد Workflow يفضل أرشيف الإصدار `jadwali-school-project-v1.8.14.zip`.
- [ ] تشغيل `flutter analyze --no-fatal-infos` — غير منفذ محلياً لغياب Flutter/Dart.
- [ ] تشغيل `flutter test` — غير منفذ محلياً لغياب Flutter/Dart.
- [ ] بناء APK عبر GitHub Actions — يحتاج تشغيل Workflow فعلياً.
