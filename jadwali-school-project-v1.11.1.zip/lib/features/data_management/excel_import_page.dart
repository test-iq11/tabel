import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';

import '../../data/excel_import_repository.dart';
import '../../services/excel_import_service.dart';
import '../../services/file_save_service.dart';

ExcelImportWorkbook _parseWorkbook(Uint8List bytes) => const ExcelImportService().parse(bytes);

class ExcelImportPage extends StatefulWidget {
  const ExcelImportPage({required this.onChanged, super.key});
  final VoidCallback onChanged;
  @override
  State<ExcelImportPage> createState() => _ExcelImportPageState();
}

class _ExcelImportPageState extends State<ExcelImportPage> {
  final _repository = ExcelImportRepository();
  ExcelImportWorkbook? _workbook;
  ExcelImportPlan? _plan;
  String? _fileName;
  bool _busy = false;
  String? _message;

  Future<void> _pick() async {
    setState(() { _busy = true; _message = null; });
    try {
      final picked = await FilePicker.platform.pickFiles(
        dialogTitle: 'اختيار ملف Excel للاستيراد', type: FileType.custom,
        allowedExtensions: ['xlsx'], withData: false, allowMultiple: false,
      );
      if (picked == null || picked.files.isEmpty) return;
      final file = picked.files.single;
      if (!file.name.toLowerCase().endsWith('.xlsx')) throw const FormatException('اختر ملف XLSX فقط.');
      if (file.size > ExcelImportService.maxFileBytes) throw const FormatException('حجم الملف أكبر من 8 ميغابايت.');
      final bytes = file.bytes ?? (file.path == null ? null : await File(file.path!).readAsBytes());
      if (bytes == null) throw const FormatException('تعذر قراءة الملف.');
      final workbook = await compute(_parseWorkbook, bytes);
      final plan = const ExcelImportService().buildPlan(workbook, await _repository.snapshot());
      if (mounted) setState(() { _workbook = workbook; _plan = plan; _fileName = file.name; });
    } catch (error) {
      if (mounted) setState(() { _message = '$error'; _workbook = null; _plan = null; });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _refreshPreview() async {
    final workbook = _workbook;
    if (workbook == null) return;
    setState(() { _busy = true; _message = null; });
    try {
      final plan = const ExcelImportService().buildPlan(workbook, await _repository.snapshot());
      if (mounted) setState(() => _plan = plan);
    } catch (error) {
      if (mounted) setState(() => _message = '$error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _template() async {
    setState(() => _busy = true);
    try {
      final path = await FileSaveService().saveBytes(
        dialogTitle: 'حفظ قالب استيراد Excel', fileName: 'قالب-بيانات-المدرسة.xlsx',
        allowedExtensions: ['xlsx'], bytes: const ExcelImportService().buildTemplate(),
      );
      if (mounted && path != null) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('حُفظ القالب. املأ الأوراق ثم اختر الملف للمعاينة.')));
    } catch (error) {
      if (mounted) setState(() => _message = '$error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _apply() async {
    final workbook = _workbook, plan = _plan;
    if (workbook == null || plan == null || !plan.canApply) return;
    final confirmed = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('تأكيد استيراد بيانات المدرسة'),
      content: Text('سيُطبَّق ${plan.operations.length} تغييراً، منها ${plan.updateCount} تحديثاً لسجلات موجودة. راجع المعاينة قبل المتابعة. لن تُحذف سجلات أخرى أو يُستبدل الجدول الأسبوعي.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('رجوع للمعاينة')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تأكيد الاستيراد')),
      ],
    ));
    if (confirmed != true || !mounted) return;
    setState(() { _busy = true; _message = null; });
    try {
      final result = await _repository.apply(workbook, plan);
      if (!mounted) return;
      widget.onChanged();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('اكتمل الاستيراد: ${result.teachers} معلم، ${result.qualifications} اختصاص، ${result.requirements} متطلب.')));
      setState(() { _plan = null; _workbook = null; _fileName = null; });
    } catch (error) {
      if (mounted) setState(() => _message = '$error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final plan = _plan;
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: const Text('استيراد بيانات Excel')),
      body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('نزّل القالب واملأ أوراق المعلمين والاختصاصات والمتطلبات. يجب أن تكون أسماء الصفوف والشعب والمواد مطابقة للبيانات المسجلة.'),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          OutlinedButton.icon(onPressed: _busy ? null : _template, icon: const Icon(Icons.download_outlined), label: const Text('تنزيل القالب')),
          FilledButton.icon(onPressed: _busy ? null : _pick, icon: const Icon(Icons.upload_file), label: const Text('اختيار XLSX')),
          if (plan != null) OutlinedButton.icon(onPressed: _busy ? null : _refreshPreview, icon: const Icon(Icons.refresh), label: const Text('تحديث المعاينة')),
        ]),
        if (_busy) const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: LinearProgressIndicator()),
        if (_message != null) Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Text(_message!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
        if (plan != null) ...[
          const SizedBox(height: 12),
          Text('${_fileName ?? ''} — ${plan.operations.length} تغيير، ${plan.updateCount} تحديث، ${plan.errors.length} خطأ', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 6),
          const Text('الاختصاصات تُضاف دون حذف الاختصاصات الأخرى. الصف الفارغ في ورقة الاختصاصات يعني جميع الصفوف. لا يُستورد أي صف قبل تصحيح كل الأخطاء.'),
          Expanded(child: ListView.builder(
            itemCount: plan.issues.length + plan.operations.length,
            itemBuilder: (context, index) {
              if (index < plan.issues.length) {
                final issue = plan.issues[index];
                return ListTile(leading: Icon(issue.warning ? Icons.info_outline : Icons.error_outline,
                  color: issue.warning ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.error),
                  title: Text(issue.message), subtitle: Text(issue.location));
              }
              final operation = plan.operations[index - plan.issues.length];
              return ListTile(leading: Icon(operation.updatesExisting ? Icons.edit_outlined : Icons.add_circle_outline),
                title: Text(operation.description), subtitle: Text('${operation.sheet}، الصف ${operation.row}'));
            },
          )),
          FilledButton.icon(onPressed: !_busy && plan.canApply ? _apply : null,
            icon: const Icon(Icons.check), label: const Text('استيراد الصفوف بعد المراجعة')),
        ] else const Expanded(child: Center(child: Text('لم تُغيَّر أي بيانات. اختر ملفاً لعرض الإضافات والتحديثات قبل الاستيراد.'))),
      ])),
    ));
  }
}
