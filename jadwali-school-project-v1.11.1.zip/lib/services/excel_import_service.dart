import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:path/path.dart' as p;
import 'package:xml/xml.dart';

class ExcelImportIssue {
  const ExcelImportIssue(this.sheet, this.row, this.message, {this.warning = false});
  final String sheet;
  final int row;
  final String message;
  final bool warning;
  String get location => row > 0 ? '$sheet، الصف $row' : sheet;
}

class ExcelImportRow {
  const ExcelImportRow(this.sheet, this.number, this.values);
  final String sheet;
  final int number;
  final Map<String, String> values;
}

class ExcelImportWorkbook {
  const ExcelImportWorkbook(this.rows, this.issues);
  final List<ExcelImportRow> rows;
  final List<ExcelImportIssue> issues;
}

class ExcelImportSnapshot {
  const ExcelImportSnapshot({required this.teachers, required this.subjects,
    required this.grades, required this.sections, required this.requirements,
    this.qualifications = const [], this.teacherGrades = const [],
    this.teacherSubjectGrades = const []});
  final List<Map<String, Object?>> teachers, subjects, grades, sections,
      requirements, qualifications, teacherGrades, teacherSubjectGrades;

  String get signature {
    Object canonical(Object? value) {
      if (value is Map) {
        final keys = value.keys.map((key) => '$key').toList()..sort();
        return {for (final key in keys) key: canonical(value[key])};
      }
      if (value is List) {
        final entries = value.map(canonical).toList()
          ..sort((a, b) => jsonEncode(a).compareTo(jsonEncode(b)));
        return entries;
      }
      return value ?? '';
    }
    return jsonEncode(canonical([teachers, subjects, grades, sections,
      requirements, qualifications, teacherGrades, teacherSubjectGrades]));
  }
}

class ExcelImportOperation {
  const ExcelImportOperation({required this.kind, required this.sheet,
    required this.row, required this.description, required this.values,
    this.existingId, this.teacherKey});
  final String kind, sheet, description;
  final int row;
  final Map<String, Object?> values;
  final int? existingId;
  final String? teacherKey;
  bool get updatesExisting => existingId != null;
}

class ExcelImportPlan {
  const ExcelImportPlan({required this.operations, required this.issues,
    required this.snapshotSignature});
  final List<ExcelImportOperation> operations;
  final List<ExcelImportIssue> issues;
  final String snapshotSignature;
  List<ExcelImportIssue> get errors => issues.where((i) => !i.warning).toList();
  bool get canApply => errors.isEmpty && operations.isNotEmpty;
  int get updateCount => operations.where((op) => op.updatesExisting).length;
}

/// Reads real XLSX workbooks. It does not evaluate formulas, fetch external
/// links, or modify a database. Reference names are resolved during preview.
class ExcelImportService {
  const ExcelImportService();
  static const maxFileBytes = 8 * 1024 * 1024;
  static const maxExpandedBytes = 32 * 1024 * 1024;
  static const maxRows = 10000;
  static const maxColumns = 100;
  static const maxCellCharacters = 2000;
  static const headers = <String, List<String>>{
    'المعلمون': ['الاسم', 'الرمز', 'النصاب الأسبوعي', 'الحد اليومي', 'الحصص المتتالية'],
    'الاختصاصات': ['رمز/اسم المعلم', 'المادة', 'الصف'],
    'المتطلبات': ['الصف', 'الشعبة', 'المادة', 'الحصص الأسبوعية', 'الحد اليومي', 'السماح بالتكرار'],
  };

  ExcelImportWorkbook parse(Uint8List bytes) {
    if (bytes.length > maxFileBytes) throw const FormatException('حجم ملف Excel يتجاوز 8 ميغابايت.');
    if (bytes.length < 4 || bytes[0] != 0x50 || bytes[1] != 0x4b) {
      throw const FormatException('اختر ملف Excel بصيغة XLSX؛ صيغة XLS القديمة غير مدعومة.');
    }
    final archive = ZipDecoder().decodeBytes(bytes, verify: true);
    if (archive.files.length > 300) throw const FormatException('ملف Excel يحتوي أجزاء كثيرة جداً.');
    var expanded = 0;
    final files = <String, ArchiveFile>{};
    for (final file in archive.files) {
      if (!file.isFile) continue;
      final name = p.posix.normalize(file.name.replaceAll('\\', '/'));
      if (name.startsWith('../') || name.startsWith('/') || files.containsKey(name)) {
        throw const FormatException('بنية ملف Excel غير صالحة.');
      }
      expanded += file.size;
      if (expanded > maxExpandedBytes) throw const FormatException('محتوى ملف Excel أكبر من الحد المسموح.');
      files[name] = file;
    }
    XmlDocument document(String path) {
      final file = files[path];
      if (file == null) throw FormatException('جزء Excel مفقود: $path');
      final text = utf8.decode(file.readBytes()!);
      if (text.contains('<!DOCTYPE') || text.contains('<!ENTITY')) {
        throw const FormatException('إعلانات الكيانات غير مدعومة في ملف Excel.');
      }
      return XmlDocument.parse(text);
    }
    final workbook = document('xl/workbook.xml');
    final relationships = document('xl/_rels/workbook.xml.rels');
    final targets = <String, String>{};
    for (final element in relationships.descendants.whereType<XmlElement>()) {
      if (element.name.local != 'Relationship') continue;
      if (element.getAttribute('TargetMode') == 'External') continue;
      final id = element.getAttribute('Id'), target = element.getAttribute('Target');
      if (id == null || target == null) continue;
      final normalized = p.posix.normalize(target.startsWith('/') ? target.substring(1) : 'xl/$target');
      if (!normalized.startsWith('xl/')) throw const FormatException('مسار ورقة Excel غير صالح.');
      targets[id] = normalized;
    }
    final shared = <String>[];
    if (files.containsKey('xl/sharedStrings.xml')) {
      for (final element in document('xl/sharedStrings.xml').descendants.whereType<XmlElement>()) {
        if (element.name.local == 'si') shared.add(_textNodes(element));
      }
    }
    final issues = <ExcelImportIssue>[];
    final result = <ExcelImportRow>[];
    final kinds = <String>{};
    var totalRows = 0;
    for (final sheet in workbook.descendants.whereType<XmlElement>().where((e) => e.name.local == 'sheet')) {
      final name = sheet.getAttribute('name') ?? '';
      final kind = _sheetKind(name);
      if (kind == null) {
        if (_normalizeHeader(name) != _normalizeHeader('تعليمات')) {
          issues.add(ExcelImportIssue(name, 0, 'تجاهلت الورقة؛ الأوراق المدعومة: المعلمون، الاختصاصات، المتطلبات.', warning: true));
        }
        continue;
      }
      if (!kinds.add(kind)) {
        issues.add(ExcelImportIssue(name, 0, 'توجد ورقتان لنوع البيانات نفسه.'));
        continue;
      }
      String? relation;
      for (final attribute in sheet.attributes) {
        if (attribute.name.local == 'id') relation = attribute.value;
      }
      final target = targets[relation];
      if (target == null) {
        issues.add(ExcelImportIssue(name, 0, 'تعذر العثور على محتوى الورقة.'));
        continue;
      }
      Map<int, String>? columns;
      for (final row in document(target).descendants.whereType<XmlElement>().where((e) => e.name.local == 'row')) {
        final rowNumber = int.tryParse(row.getAttribute('r') ?? '') ?? totalRows + 1;
        final cells = <int, String>{};
        var inferredColumn = 0;
        for (final cell in row.childElements.where((e) => e.name.local == 'c')) {
          final reference = cell.getAttribute('r');
          final index = reference == null ? inferredColumn : _columnIndex(reference);
          inferredColumn = index + 1;
          if (index < 0 || index >= maxColumns || cells.containsKey(index)) {
            issues.add(ExcelImportIssue(name, rowNumber, 'مرجع خلية غير صالح أو أكثر من 100 عمود.'));
            continue;
          }
          if (cell.childElements.any((e) => e.name.local == 'f')) {
            issues.add(ExcelImportIssue(name, rowNumber, 'تحتوي الخلية $reference على صيغة؛ الصق النتيجة كقيمة قبل الاستيراد.'));
          }
          final type = cell.getAttribute('t');
          final valueElement = cell.childElements.where((e) => e.name.local == 'v').firstOrNull;
          var text = type == 'inlineStr' ? _textNodes(cell) : valueElement?.innerText ?? '';
          if (type == 's') {
            final sharedIndex = int.tryParse(text);
            if (sharedIndex == null || sharedIndex < 0 || sharedIndex >= shared.length) {
              issues.add(ExcelImportIssue(name, rowNumber, 'مرجع نص مشترك غير صالح في الخلية $reference.'));
              text = '';
            } else {
              text = shared[sharedIndex];
            }
          }
          if (text.length > maxCellCharacters) throw const FormatException('تحتوي خلية على نص أطول من 2000 حرف.');
          cells[index] = text.trim();
        }
        if (cells.values.every((text) => text.isEmpty)) continue;
        if (columns == null) {
          columns = {};
          final seenHeaders = <String>{};
          for (final entry in cells.entries) {
            if (entry.value.isEmpty) continue;
            final header = _canonicalHeader(kind, entry.value);
            if (header == null) {
              issues.add(ExcelImportIssue(name, rowNumber, 'عمود غير معروف: ${entry.value}؛ سيُتجاهل.', warning: true));
              continue;
            }
            if (!seenHeaders.add(header)) issues.add(ExcelImportIssue(name, rowNumber, 'عنوان عمود مكرر: $header.'));
            columns[entry.key] = header;
          }
          final required = kind == 'المعلمون' ? ['الاسم'] : kind == 'الاختصاصات' ? ['رمز/اسم المعلم', 'المادة'] : ['الصف', 'الشعبة', 'المادة', 'الحصص الأسبوعية'];
          for (final header in required) {
            if (!seenHeaders.contains(header)) issues.add(ExcelImportIssue(name, rowNumber, 'العمود المطلوب مفقود: $header.'));
          }
          continue;
        }
        if (++totalRows > maxRows) throw const FormatException('الحد الأقصى عشرة آلاف صف للاستيراد.');
        result.add(ExcelImportRow(kind, rowNumber, {
          for (final column in columns.entries) column.value: cells[column.key] ?? '',
        }));
      }
    }
    if (kinds.isEmpty) issues.add(const ExcelImportIssue('الملف', 0, 'لم أجد ورقة مدعومة. نزّل قالب الاستيراد واملأه.'));
    return ExcelImportWorkbook(List.unmodifiable(result), List.unmodifiable(issues));
  }

  ExcelImportPlan buildPlan(ExcelImportWorkbook workbook, ExcelImportSnapshot snapshot) {
    final issues = [...workbook.issues];
    final operations = <ExcelImportOperation>[];
    final teacherReferences = <String, List<_TeacherRef>>{};
    void addReference(String value, _TeacherRef ref) {
      if (value.trim().isEmpty) return;
      final key = _normalizeName(value);
      final list = teacherReferences.putIfAbsent(key, () => []);
      if (!list.any((other) => other.key == ref.key)) list.add(ref);
    }
    for (final teacher in snapshot.teachers) {
      final ref = _TeacherRef('id:${teacher['id']}', teacher['id'] as int);
      addReference('${teacher['name'] ?? ''}', ref);
      addReference('${teacher['code'] ?? ''}', ref);
    }
    final seenTeachers = <String>{}, seenQualifications = <String>{}, seenRequirements = <String>{};
    void error(ExcelImportRow row, String message) => issues.add(ExcelImportIssue(row.sheet, row.number, message));
    int? number(ExcelImportRow row, String field, {int? fallback, int min = 0}) {
      final text = _westernDigits(row.values[field] ?? '');
      if (text.isEmpty) return fallback;
      final parsed = num.tryParse(text);
      if (parsed == null || !parsed.isFinite || parsed != parsed.roundToDouble() || parsed < min || parsed > 1000) {
        error(row, '$field يجب أن يكون عدداً صحيحاً بين $min و1000.');
        return null;
      }
      return parsed.toInt();
    }
    Map<String, Object?>? resolve(List<Map<String, Object?>> rows, String name, ExcelImportRow source, String label) {
      final matches = rows.where((row) => _normalizeName('${row['name'] ?? ''}') == _normalizeName(name)).toList();
      if (matches.length != 1) {
        error(source, matches.isEmpty ? '$label غير موجود: $name. أضفه في البيانات أولاً.' : '$label غير محدد لأن الاسم مكرر: $name.');
        return null;
      }
      return matches.single;
    }
    for (final row in workbook.rows.where((row) => row.sheet == 'المعلمون')) {
      final name = row.values['الاسم']?.trim() ?? '', code = row.values['الرمز']?.trim() ?? '';
      if (name.isEmpty) { error(row, 'اسم المعلم مطلوب.'); continue; }
      final byCode = code.isEmpty ? <Map<String, Object?>>[] : snapshot.teachers.where((t) => _normalizeName('${t['code'] ?? ''}') == _normalizeName(code)).toList();
      final byName = snapshot.teachers.where((t) => _normalizeName('${t['name']}') == _normalizeName(name)).toList();
      Map<String, Object?>? existing;
      if (byCode.length > 1 || (byCode.isEmpty && byName.length > 1)) { error(row, 'المعلم غير محدد؛ استعمل رمزاً فريداً.'); continue; }
      if (byCode.length == 1) {
        existing = byCode.single;
        if (byName.any((t) => t['id'] != existing!['id'])) { error(row, 'اسم المعلم يطابق معلماً آخر غير صاحب الرمز.'); continue; }
      } else if (byName.length == 1) {
        existing = byName.single;
        final oldCode = '${existing['code'] ?? ''}';
        if (code.isNotEmpty && oldCode.isNotEmpty && _normalizeName(code) != _normalizeName(oldCode)) { error(row, 'الاسم موجود برمز مختلف؛ صحح الرمز قبل الاستيراد.'); continue; }
      }
      final teacherKey = existing == null ? 'new:${code.isEmpty ? _normalizeName(name) : _normalizeName(code)}' : 'id:${existing['id']}';
      if (!seenTeachers.add(teacherKey)) { error(row, 'المعلم مكرر في الملف.'); continue; }
      final weekly = number(row, 'النصاب الأسبوعي', fallback: _int(existing?['weekly_load'], 24));
      final daily = number(row, 'الحد اليومي', fallback: _int(existing?['max_daily_lessons'], 6));
      final consecutive = number(row, 'الحصص المتتالية', fallback: _int(existing?['max_consecutive_lessons'], 4));
      if (weekly == null || daily == null || consecutive == null) continue;
      final ref = _TeacherRef(teacherKey, existing?['id'] as int?);
      addReference(name, ref); addReference(code, ref);
      operations.add(ExcelImportOperation(kind: 'teacher', sheet: row.sheet, row: row.number,
        existingId: existing?['id'] as int?, teacherKey: teacherKey,
        description: '${existing == null ? 'إضافة' : 'تحديث'} المعلم $name',
        values: {'name': name, 'code': code.isEmpty ? (existing?['code'] ?? '') : code, 'weekly_load': weekly, 'max_daily_lessons': daily, 'max_consecutive_lessons': consecutive}));
    }
    for (final row in workbook.rows.where((row) => row.sheet == 'الاختصاصات')) {
      final teacherText = row.values['رمز/اسم المعلم']?.trim() ?? '';
      final matches = teacherReferences[_normalizeName(teacherText)] ?? [];
      if (matches.length != 1) { error(row, matches.isEmpty ? 'المعلم غير موجود: $teacherText.' : 'اسم/رمز المعلم غير فريد: $teacherText.'); continue; }
      final subject = resolve(snapshot.subjects, row.values['المادة'] ?? '', row, 'المادة');
      final gradeText = row.values['الصف']?.trim() ?? '';
      final grade = gradeText.isEmpty ? null : resolve(snapshot.grades, gradeText, row, 'الصف');
      if (subject == null || (gradeText.isNotEmpty && grade == null)) continue;
      final teacher = matches.single, gradeId = grade?['id'] as int? ?? 0;
      final key = '${teacher.key}:${subject['id']}:$gradeId';
      if (!seenQualifications.add(key)) { error(row, 'الاختصاص مكرر في الملف.'); continue; }
      final exists = teacher.id != null && snapshot.teacherSubjectGrades.any((q) => q['teacher_id'] == teacher.id && q['subject_id'] == subject['id'] && q['grade_id'] == gradeId) && snapshot.qualifications.any((q) => q['teacher_id'] == teacher.id && q['subject_id'] == subject['id']);
      if (exists) {
        issues.add(ExcelImportIssue(row.sheet, row.number, 'الاختصاص موجود مسبقاً؛ لن يتكرر.', warning: true));
        continue;
      }
      operations.add(ExcelImportOperation(kind: 'qualification', sheet: row.sheet, row: row.number,
        teacherKey: teacher.key, description: 'إضافة اختصاص $teacherText: ${subject['name']} / ${grade?['name'] ?? 'جميع الصفوف'}',
        values: {'subject_id': subject['id'], 'grade_id': gradeId}));
    }
    for (final row in workbook.rows.where((row) => row.sheet == 'المتطلبات')) {
      final grade = resolve(snapshot.grades, row.values['الصف'] ?? '', row, 'الصف');
      final subject = resolve(snapshot.subjects, row.values['المادة'] ?? '', row, 'المادة');
      if (grade == null || subject == null) continue;
      final section = resolve(snapshot.sections.where((s) => s['grade_id'] == grade['id']).toList(), row.values['الشعبة'] ?? '', row, 'الشعبة');
      if (section == null) continue;
      final key = '${section['id']}:${subject['id']}';
      if (!seenRequirements.add(key)) { error(row, 'متطلب المادة والشعبة مكرر في الملف.'); continue; }
      final existing = snapshot.requirements.where((r) => r['section_id'] == section['id'] && r['subject_id'] == subject['id']).firstOrNull;
      final weekly = number(row, 'الحصص الأسبوعية');
      if ((row.values['الحصص الأسبوعية'] ?? '').isEmpty) error(row, 'عدد الحصص الأسبوعية مطلوب.');
      final daily = number(row, 'الحد اليومي', fallback: _int(existing?['max_daily_lessons'], 2), min: 1);
      final allowText = _normalizeHeader(_westernDigits(row.values['السماح بالتكرار'] ?? ''));
      final allow = allowText.isEmpty ? _int(existing?['allow_same_day'], 0) : const {'1': 1, 'نعم': 1, 'true': 1, '0': 0, 'لا': 0, 'false': 0}[allowText];
      if (allow == null) error(row, 'السماح بالتكرار يقبل نعم/لا أو 1/0.');
      if (weekly == null || daily == null || allow == null) continue;
      operations.add(ExcelImportOperation(kind: 'requirement', sheet: row.sheet, row: row.number,
        existingId: existing?['id'] as int?, description: '${existing == null ? 'إضافة' : 'تحديث'} ${grade['name']} / ${section['name']} / ${subject['name']}: $weekly حصة',
        values: {'section_id': section['id'], 'subject_id': subject['id'], 'weekly_lessons': weekly, 'max_daily_lessons': daily, 'allow_same_day': allow}));
    }
    return ExcelImportPlan(operations: List.unmodifiable(operations), issues: List.unmodifiable(issues), snapshotSignature: snapshot.signature);
  }

  Uint8List buildTemplate() => buildWorkbook({
    ...{for (final entry in headers.entries) entry.key: [entry.value]},
    'تعليمات': [
      ['التعليمات'],
      ['املأ الصفوف تحت العناوين دون تغيير أسماء الأوراق. احفظ بصيغة XLSX.'],
      ['المعلمون: الرمز اختياري لكنه يجب أن يكون فريداً؛ البيانات الفارغة تحافظ على القيم السابقة عند التحديث.'],
      ['الاختصاصات: استعمل رمز المعلم أو اسمه الفريد. الصف الفارغ يعني جميع الصفوف. الاختصاصات تضاف ولا تحذف الاختصاصات الأخرى.'],
      ['المتطلبات: يجب أن تكون الصفوف والشعب والمواد موجودة في التطبيق بأسمائها نفسها.'],
      ['السماح بالتكرار: نعم أو لا، أو 1 أو 0. استعمل قيماً ثابتة بدلاً من صيغ Excel.'],
      ['راجع الإضافات والتحديثات والأخطاء في المعاينة قبل التأكيد. لا يستورد التطبيق أي صف إذا احتوى الملف على أخطاء.'],
    ],
  });

  /// Exposed for generating templates and deterministic XLSX test fixtures.
  Uint8List buildWorkbook(Map<String, List<List<Object?>>> sheets) {
    final archive = Archive();
    void add(String name, String text) => archive.addFile(ArchiveFile.string(name, text));
    const declaration = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
    add('[Content_Types].xml', '$declaration<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${List.generate(sheets.length, (i) => '<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join()}</Types>');
    add('_rels/.rels', '$declaration<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    add('xl/workbook.xml', '$declaration<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${List.generate(sheets.length, (i) => '<sheet name="${_xml(sheets.keys.elementAt(i))}" sheetId="${i + 1}" r:id="rId${i + 1}"/>').join()}</sheets></workbook>');
    add('xl/_rels/workbook.xml.rels', '$declaration<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${List.generate(sheets.length, (i) => '<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>').join()}</Relationships>');
    var index = 0;
    for (final sheet in sheets.entries) {
      final rows = StringBuffer();
      for (var r = 0; r < sheet.value.length; r++) {
        rows.write('<row r="${r + 1}">');
        for (var c = 0; c < sheet.value[r].length; c++) {
          final value = sheet.value[r][c];
          if (value == null || value == '') continue;
          final reference = '${_columnName(c)}${r + 1}';
          if (value is bool) {
            rows.write('<c r="$reference" t="b"><v>${value ? 1 : 0}</v></c>');
          } else if (value is num) {
            rows.write('<c r="$reference"><v>$value</v></c>');
          } else {
            rows.write('<c r="$reference" t="inlineStr"><is><t xml:space="preserve">${_xml('$value')}</t></is></c>');
          }
        }
        rows.write('</row>');
      }
      add('xl/worksheets/sheet${++index}.xml', '$declaration<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0" rightToLeft="1"/></sheetViews><sheetData>$rows</sheetData></worksheet>');
    }
    return Uint8List.fromList(ZipEncoder().encode(archive));
  }
}

class _TeacherRef {
  const _TeacherRef(this.key, this.id);
  final String key;
  final int? id;
}
int _int(Object? value, int fallback) => value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
String _normalizeName(String value) => value.trim().replaceAll(RegExp(r'\s+'), ' ');
String _normalizeHeader(String value) => _normalizeName(value).toLowerCase().replaceAll(RegExp('[أإآ]'), 'ا').replaceAll('ـ', '');
String _westernDigits(String value) {
  const arabic = '٠١٢٣٤٥٦٧٨٩', persian = '۰۱۲۳۴۵۶۷۸۹';
  var result = value.trim();
  for (var i = 0; i < 10; i++) result = result.replaceAll(arabic[i], '$i').replaceAll(persian[i], '$i');
  return result;
}
String _textNodes(XmlElement element) => element.descendants.whereType<XmlElement>().where((e) => e.name.local == 't').map((e) => e.innerText).join();
String? _sheetKind(String name) => const {'المعلمون': 'المعلمون', 'المعلمين': 'المعلمون', 'teachers': 'المعلمون', 'الاختصاصات': 'الاختصاصات', 'qualifications': 'الاختصاصات', 'المتطلبات': 'المتطلبات', 'requirements': 'المتطلبات'}[_normalizeHeader(name)];
String? _canonicalHeader(String kind, String name) {
  final normalized = _normalizeHeader(name);
  for (final header in ExcelImportService.headers[kind]!) {
    if (_normalizeHeader(header) == normalized) return header;
  }
  const aliases = {'name': 'الاسم', 'code': 'الرمز', 'weekly_load': 'النصاب الأسبوعي', 'daily_limit': 'الحد اليومي', 'consecutive_limit': 'الحصص المتتالية', 'teacher': 'رمز/اسم المعلم', 'اسم المعلم': 'رمز/اسم المعلم', 'رمز المعلم': 'رمز/اسم المعلم', 'subject': 'المادة', 'grade': 'الصف', 'section': 'الشعبة', 'weekly_lessons': 'الحصص الأسبوعية', 'allow_same_day': 'السماح بالتكرار'};
  final header = aliases[normalized];
  return ExcelImportService.headers[kind]!.contains(header) ? header : null;
}
int _columnIndex(String reference) {
  final match = RegExp(r'^([A-Za-z]+)[1-9][0-9]*$').firstMatch(reference);
  if (match == null) return -1;
  var value = 0;
  for (final code in match.group(1)!.toUpperCase().codeUnits) value = value * 26 + code - 64;
  return value - 1;
}
String _columnName(int value) {
  var result = '', number = value + 1;
  while (number > 0) { number--; result = String.fromCharCode(65 + number % 26) + result; number ~/= 26; }
  return result;
}
String _xml(String value) => value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&apos;');
