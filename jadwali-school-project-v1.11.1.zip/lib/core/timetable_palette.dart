/// One subject -> one stable accent in the editor and printable PDF.
/// Uses database subject ids, not row positions, so sorting does not recolor.
class TimetablePalette {
  const TimetablePalette._();
  static const int navy = 0xFF183B66;
  static const int paper = 0xFFF4F7FB;
  static const List<int> accents = <int>[
    0xFF3574C7, 0xFF168568, 0xFF8B62C9, 0xFFD18A38,
    0xFF18899A, 0xFFC85E79, 0xFF78943A, 0xFFB66D39,
    0xFF6070B5, 0xFF2F8A88, 0xFFA5619B, 0xFF6D849A,
  ];
  static const List<int> tints = <int>[
    0xFFE9F3FF, 0xFFE8F8F0, 0xFFF4ECFF, 0xFFFFF2E1,
    0xFFE8F7F8, 0xFFFFEEF1, 0xFFF1F7E4, 0xFFFFF1E8,
    0xFFEEF1FF, 0xFFE5F5F4, 0xFFFBEFFA, 0xFFEDF3F7,
  ];
  static int index(int subjectId) => (subjectId.abs() + accents.length - 1) % accents.length;
  static int accent(int subjectId) => accents[index(subjectId)];
  static int tint(int subjectId) => tints[index(subjectId)];
}
