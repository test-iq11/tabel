import 'dart:convert';

import 'package:sqflite/sqflite.dart';

import 'database_service.dart';
import '../services/excel_import_service.dart';

class ExcelImportResult {
  const ExcelImportResult(this.teachers, this.qualifications, this.requirements);
  final int teachers, qualifications, requirements;
}

/// Rebuilds the preview against the transaction snapshot before writing. Every
/// change succeeds together, or all rows are rolled back by SQLite.
class ExcelImportRepository {
  ExcelImportRepository({DatabaseService? database})
      : _database = database ?? DatabaseService.instance;
  final DatabaseService _database;

  Future<ExcelImportSnapshot> snapshot() async => _snapshot(await _database.database);

  Future<ExcelImportSnapshot> _snapshot(DatabaseExecutor db) async => ExcelImportSnapshot(
    teachers: await db.query('teachers'), subjects: await db.query('subjects'),
    grades: await db.query('grades'), sections: await db.query('sections'),
    requirements: await db.query('section_subject_requirements'),
    qualifications: await db.query('teacher_subjects'),
    teacherGrades: await db.query('teacher_grades'),
    teacherSubjectGrades: await db.query('teacher_subject_grades'),
  );

  Future<ExcelImportResult> apply(ExcelImportWorkbook workbook, ExcelImportPlan preview) async {
    if (!preview.canApply) throw StateError('صحح أخطاء الملف وأعد المعاينة قبل الاستيراد.');
    final db = await _database.database;
    return db.transaction((txn) async {
      final current = await _snapshot(txn);
      if (current.signature != preview.snapshotSignature) {
        throw StateError('تغيرت بيانات المدرسة منذ المعاينة. أعد فتح المعاينة قبل الاستيراد.');
      }
      final plan = const ExcelImportService().buildPlan(workbook, current);
      if (!plan.canApply) throw StateError('لم تعد صفوف الاستيراد صالحة؛ أعد المعاينة.');
      final teacherIds = <String, int>{
        for (final teacher in current.teachers) 'id:${teacher['id']}': teacher['id'] as int,
      };
      var teachers = 0, qualifications = 0, requirements = 0;
      for (final operation in plan.operations.where((op) => op.kind == 'teacher')) {
        final id = operation.existingId;
        if (id == null) {
          teacherIds[operation.teacherKey!] = await txn.insert('teachers', operation.values);
        } else {
          await txn.update('teachers', operation.values, where: 'id = ?', whereArgs: [id]);
          teacherIds[operation.teacherKey!] = id;
        }
        teachers++;
      }
      if (plan.operations.any((op) => op.kind == 'qualification')) {
        await _preserveLegacyPermissions(txn, current);
      }
      for (final operation in plan.operations.where((op) => op.kind == 'qualification')) {
        final teacherId = teacherIds[operation.teacherKey];
        if (teacherId == null) throw StateError('تعذر ربط صف اختصاص بالمعلم؛ لم يُستورد أي صف.');
        await txn.insert('teacher_subjects', {
          'teacher_id': teacherId, 'subject_id': operation.values['subject_id'],
        }, conflictAlgorithm: ConflictAlgorithm.ignore);
        await txn.insert('teacher_subject_grades', {
          'teacher_id': teacherId, 'subject_id': operation.values['subject_id'],
          'grade_id': operation.values['grade_id'],
        }, conflictAlgorithm: ConflictAlgorithm.ignore);
        qualifications++;
      }
      for (final operation in plan.operations.where((op) => op.kind == 'requirement')) {
        if (operation.existingId == null) {
          await txn.insert('section_subject_requirements', operation.values);
        } else {
          await txn.update('section_subject_requirements', operation.values,
            where: 'id = ?', whereArgs: [operation.existingId]);
        }
        requirements++;
      }
      await txn.insert('audit_log', {
        'action': 'استيراد Excel', 'entity': 'school_data',
        'details': jsonEncode({'teachers': teachers, 'qualifications': qualifications, 'requirements': requirements}),
        'created_at': DateTime.now().toIso8601String(),
      });
      return ExcelImportResult(teachers, qualifications, requirements);
    });
  }

  /// Adding the first modern subject/grade rule must not revoke unrelated
  /// legacy permissions. Materialize their previous effective permissions
  /// before extending the policy. Existing modern rules remain untouched.
  Future<void> _preserveLegacyPermissions(DatabaseExecutor db, ExcelImportSnapshot snapshot) async {
    final teachersWithRules = snapshot.teacherSubjectGrades.map((row) => row['teacher_id']).toSet();
    for (final qualification in snapshot.qualifications) {
      final teacherId = qualification['teacher_id'];
      if (teachersWithRules.contains(teacherId)) continue;
      final legacy = snapshot.teacherGrades.where((row) => row['teacher_id'] == teacherId).toList();
      final gradeIds = legacy.isNotEmpty
          ? legacy.map((row) => row['grade_id']).toList()
          : snapshot.teacherSubjectGrades.isEmpty ? <Object?>[0] : <Object?>[];
      for (final gradeId in gradeIds) {
        await db.insert('teacher_subject_grades', {
          'teacher_id': teacherId, 'subject_id': qualification['subject_id'], 'grade_id': gradeId,
        }, conflictAlgorithm: ConflictAlgorithm.ignore);
      }
    }
  }
}
