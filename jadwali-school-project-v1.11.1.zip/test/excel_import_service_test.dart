import 'dart:typed_data';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/excel_import_service.dart';

void main() {
  const service = ExcelImportService();
  final snapshot = ExcelImportSnapshot(
    teachers: [], subjects: [{'id': 1, 'name': 'الرياضيات'}],
    grades: [{'id': 1, 'name': 'الأول'}],
    sections: [{'id': 1, 'name': 'أ', 'grade_id': 1}], requirements: [],
  );
  ExcelImportPlan plan(Map<String, List<List<Object?>>> sheets, [ExcelImportSnapshot? data]) =>
      service.buildPlan(service.parse(service.buildWorkbook(sheets)), data ?? snapshot);
  Uint8List replacePart(Uint8List bytes, String name, String content, {Map<String, String> extra = const {}}) {
    final source = ZipDecoder().decodeBytes(bytes);
    final result = Archive();
    for (final file in source.files) {
      if (file.name == name) { result.addFile(ArchiveFile.string(name, content)); }
      else { result.addFile(file); }
    }
    for (final entry in extra.entries) { result.addFile(ArchiveFile.string(entry.key, entry.value)); }
    return Uint8List.fromList(ZipEncoder().encode(result));
  }
  test('imports a workbook produced by independent openpyxl with text codes and booleans', () {
    final bytes = File('test/fixtures/excel_import_openpyxl.xlsx').readAsBytesSync();
    final result = service.buildPlan(service.parse(bytes), snapshot);
    expect(result.errors, isEmpty);
    expect(result.canApply, isTrue);
    expect(result.operations, hasLength(3));
    expect(result.operations.first.values['code'], '007');
    expect(result.operations.last.values['allow_same_day'], 0);
    expect(result.operations.last.values['weekly_lessons'], 5);
  });
  test('blank downloadable template is a readable real XLSX with no mutations', () {
    final bytes = service.buildTemplate();
    expect(bytes.take(2), [0x50, 0x4b]);
    final parsed = service.parse(bytes);
    expect(parsed.rows, isEmpty);
    expect(parsed.issues.where((i) => !i.warning), isEmpty);
    expect(service.buildPlan(parsed, snapshot).canApply, isFalse);
  });
  test('teachers, qualifications and requirements resolve across workbook sheets', () {
    final result = plan({
      'المعلمون': [ExcelImportService.headers['المعلمون']!, ['معلم جديد', 'T1', '٢٤', '٦', '٤']],
      'الاختصاصات': [ExcelImportService.headers['الاختصاصات']!, ['T1', 'الرياضيات', 'الأول']],
      'المتطلبات': [ExcelImportService.headers['المتطلبات']!, ['الأول', 'أ', 'الرياضيات', 6, 2, 'نعم']],
    });
    expect(result.errors, isEmpty);
    expect(result.canApply, isTrue);
    expect(result.operations.map((r) => r.kind), ['teacher', 'qualification', 'requirement']);
    expect(result.operations.first.values['weekly_load'], 24);
    expect(result.operations.last.values['allow_same_day'], 1);
    expect(result.operations[1].teacherKey, result.operations.first.teacherKey);
  });
  test('blank update fields preserve previous teacher capacity and code', () {
    final data = ExcelImportSnapshot(teachers: [{'id': 3, 'name': 'معلم', 'code': 'T3', 'weekly_load': 17, 'max_daily_lessons': 4, 'max_consecutive_lessons': 2}],
      subjects: [], grades: [], sections: [], requirements: []);
    final result = plan({'المعلمون': [ExcelImportService.headers['المعلمون']!, ['معلم', '', '', '', '']]}, data);
    expect(result.canApply, isTrue);
    expect(result.updateCount, 1);
    expect(result.operations.single.values['weekly_load'], 17);
    expect(result.operations.single.values['code'], 'T3');
    expect(data.teachers.single['weekly_load'], 17);
  });
  test('invalid and duplicate teacher rows prevent the entire import plan', () {
    final result = plan({'المعلمون': [ExcelImportService.headers['المعلمون']!,
      ['صحيح', 'T1', 24, 6, 4], ['مكرر', 'T1', 24, 6, 4], ['خطأ', 'T2', -1, 6, 4]]});
    expect(result.errors.length, greaterThanOrEqualTo(2));
    expect(result.canApply, isFalse);
  });
  test('unknown subjects or teachers are reported before qualification writes', () {
    final result = plan({'الاختصاصات': [ExcelImportService.headers['الاختصاصات']!, ['missing', 'الرياضيات', 'الأول']]});
    expect(result.canApply, isFalse);
    expect(result.errors, isNotEmpty);
  });
  test('ambiguous subject names are rejected instead of choosing a random record', () {
    final data = ExcelImportSnapshot(teachers: [], subjects: [{'id': 1, 'name': 'الرياضيات'}, {'id': 2, 'name': 'الرياضيات'}], grades: snapshot.grades, sections: snapshot.sections, requirements: []);
    final result = plan({'المتطلبات': [ExcelImportService.headers['المتطلبات']!, ['الأول', 'أ', 'الرياضيات', 5, 1, 'لا']]}, data);
    expect(result.canApply, isFalse);
    expect(result.errors.any((i) => i.message.contains('مكرر')), isTrue);
  });
  test('formulas are rejected even when a cached numeric result exists', () {
    final base = service.buildWorkbook({'المعلمون': [ExcelImportService.headers['المعلمون']!]});
    final bytes = replacePart(base, 'xl/worksheets/sheet1.xml',
      '<worksheet><sheetData><row r="1"><c r="A1" t="inlineStr"><is><t>الاسم</t></is></c><c r="B1" t="inlineStr"><is><t>النصاب الأسبوعي</t></is></c></row><row r="2"><c r="A2" t="inlineStr"><is><t>معلم</t></is></c><c r="B2"><f>12+12</f><v>24</v></c></row></sheetData></worksheet>');
    final result = service.buildPlan(service.parse(bytes), snapshot);
    expect(result.canApply, isFalse);
    expect(result.errors.any((i) => i.message.contains('صيغة')), isTrue);
  });
  test('shared strings and sparse numeric cells keep their correct columns', () {
    final base = service.buildWorkbook({'المعلمون': [ExcelImportService.headers['المعلمون']!]});
    final bytes = replacePart(base, 'xl/worksheets/sheet1.xml',
      '<worksheet><sheetData><row r="1"><c r="A1" t="s"><v>0</v></c><c r="C1" t="s"><v>1</v></c></row><row r="2"><c r="A2" t="s"><v>2</v></c><c r="C2"><v>19</v></c></row></sheetData></worksheet>',
      extra: {'xl/sharedStrings.xml': '<sst><si><t>الاسم</t></si><si><t>النصاب الأسبوعي</t></si><si><r><t>معلم </t></r><r><t>تجريبي</t></r></si></sst>'});
    final result = service.buildPlan(service.parse(bytes), snapshot);
    expect(result.canApply, isTrue);
    expect(result.operations.single.values['name'], 'معلم تجريبي');
    expect(result.operations.single.values['weekly_load'], 19);
    expect(result.operations.single.values['max_daily_lessons'], 6);
  });
  test('duplicate headers are explicit errors', () {
    final result = plan({'المعلمون': [['الاسم', 'الاسم'], ['أ', 'ب']]});
    expect(result.canApply, isFalse);
    expect(result.errors, isNotEmpty);
  });
  test('XLS and XML entity declarations are not accepted as XLSX data', () {
    expect(() => service.parse(Uint8List.fromList([0xd0, 0xcf, 0x11, 0xe0])), throwsFormatException);
    final bytes = replacePart(service.buildTemplate(), 'xl/workbook.xml', '<!DOCTYPE x [<!ENTITY y "x">]><workbook/>');
    expect(() => service.parse(bytes), throwsFormatException);
  });
  test('snapshot signature is independent of row order and includes qualifications', () {
    final first = ExcelImportSnapshot(teachers: [{'id': 1, 'name': 'أ'}, {'id': 2, 'name': 'ب'}], subjects: [], grades: [], sections: [], requirements: []);
    final reverse = ExcelImportSnapshot(teachers: first.teachers.reversed.toList(), subjects: [], grades: [], sections: [], requirements: []);
    final changed = ExcelImportSnapshot(teachers: first.teachers, subjects: [], grades: [], sections: [], requirements: [], qualifications: [{'teacher_id': 1, 'subject_id': 1}]);
    expect(first.signature, reverse.signature);
    expect(changed.signature, isNot(first.signature));
  });
  test('missing required weekly counts and invalid booleans block requirement imports', () {
    final result = plan({'المتطلبات': [ExcelImportService.headers['المتطلبات']!, ['الأول', 'أ', 'الرياضيات', '', 1, 'ربما']]});
    expect(result.canApply, isFalse);
    expect(result.errors.length, greaterThanOrEqualTo(2));
  });
}
