import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:iraqi_school_timetable/data/excel_import_repository.dart';
import 'package:iraqi_school_timetable/services/excel_import_service.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  late Directory folder;
  late DatabaseService database;
  late ExcelImportRepository repository;
  const reader = ExcelImportService();
  setUp(() async {
    sqfliteFfiInit();
    folder = await Directory.systemTemp.createTemp('jadwali-excel-transaction-');
    database = DatabaseService.withStorage(factory: databaseFactoryFfi, directory: folder.path);
    repository = ExcelImportRepository(database: database);
    await database.database;
  });
  tearDown(() async { await database.close(); await folder.delete(recursive: true); });
  ExcelImportWorkbook workbook() => reader.parse(reader.buildWorkbook({
    'المعلمون': [ExcelImportService.headers['المعلمون']!, ['معلم استيراد', 'EX1', 20, 5, 3]],
  }));
  test('confirmed import inserts rows once and records its audit atomically', () async {
    final book = workbook();
    final plan = reader.buildPlan(book, await repository.snapshot());
    final result = await repository.apply(book, plan);
    expect(result.teachers, 1);
    final db = await database.database;
    expect(await db.query('teachers', where: 'code=?', whereArgs: ['EX1']), hasLength(1));
    expect(await db.query('audit_log', where: 'action=?', whereArgs: ['استيراد Excel']), hasLength(1));
  });
  test('failure after writing teacher rows rolls back the entire import', () async {
    final db = await database.database;
    await db.execute("CREATE TRIGGER reject_excel_audit BEFORE INSERT ON audit_log WHEN NEW.action = 'استيراد Excel' BEGIN SELECT RAISE(ABORT, 'test failure'); END");
    final book = workbook();
    final plan = reader.buildPlan(book, await repository.snapshot());
    await expectLater(repository.apply(book, plan), throwsA(isA<DatabaseException>()));
    expect(await db.query('teachers', where: 'code=?', whereArgs: ['EX1']), isEmpty);
  });
  test('changed school data invalidates the preview before any imported write', () async {
    final book = workbook();
    final plan = reader.buildPlan(book, await repository.snapshot());
    final db = await database.database;
    await db.insert('teachers', {'name': 'تغيير بعد المعاينة'});
    await expectLater(repository.apply(book, plan), throwsStateError);
    expect(await db.query('teachers', where: 'code=?', whereArgs: ['EX1']), isEmpty);
  });
}
