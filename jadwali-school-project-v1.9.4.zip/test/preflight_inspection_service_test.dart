import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/preflight_inspection_service.dart';

void main() {
  const service = PreflightInspectionService();

  final base = <String, Object?>{
    'sections': [
      {'id': 1, 'grade_id': 101, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 6},
    ],
    'requirements': [
      {'section_id': 1, 'grade_id': 101, 'subject_id': 1, 'weekly_lessons': 2, 'subject_name': 'العربية', 'section_name': 'أ', 'grade_name': 'الأول'},
    ],
    'teachers': [
      {'id': 7, 'name': 'طالب', 'weekly_load': 20, 'max_daily_lessons': 6},
    ],
    'subjects': [{'id': 1, 'name': 'العربية'}],
    'qualifications': [{'teacher_id': 7, 'subject_id': 1}],
    'teacherGrades': <Map<String, Object?>>[],
    'teacherSubjectGrades': [{'teacher_id': 7, 'subject_id': 1, 'grade_id': 101}],
    'days': [
      {'id': 1, 'name': 'الأحد', 'position': 1, 'is_active': 1},
      {'id': 2, 'name': 'الاثنين', 'position': 2, 'is_active': 1},
    ],
    'slots': [
      {'id': 1, 'name': 'الأولى', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      {'id': 2, 'name': 'الثانية', 'position': 2, 'kind': 'lesson', 'is_available': 1},
    ],
    'currentEntries': <Map<String, Object?>>[],
    'availability': <Map<String, Object?>>[],
    'subjectBlockedSlots': <Map<String, Object?>>[],
  };

  PreflightResult run(Map<String, Object?> data) => service.inspect(
    sections: (data['sections'] as List).cast<Map<String, Object?>>(),
    requirements: (data['requirements'] as List).cast<Map<String, Object?>>(),
    teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
    subjects: (data['subjects'] as List).cast<Map<String, Object?>>(),
    qualifications: (data['qualifications'] as List).cast<Map<String, Object?>>(),
    teacherGrades: (data['teacherGrades'] as List).cast<Map<String, Object?>>(),
    teacherSubjectGrades: (data['teacherSubjectGrades'] as List).cast<Map<String, Object?>>(),
    days: (data['days'] as List).cast<Map<String, Object?>>(),
    slots: (data['slots'] as List).cast<Map<String, Object?>>(),
    currentEntries: (data['currentEntries'] as List).cast<Map<String, Object?>>(),
    availability: (data['availability'] as List).cast<Map<String, Object?>>(),
    subjectBlockedSlots: (data['subjectBlockedSlots'] as List).cast<Map<String, Object?>>(),
  );

  test('passes a coherent teacher, subject, grade and capacity setup', () {
    final result = run(base);
    expect(result.canStart, isTrue);
    expect(result.findings.where((f) => f.code == 'no_teacher_allowed_grade'), isEmpty);
    expect(result.findings.where((f) => f.code == 'section_over_capacity'), isEmpty);
  });

  test('warns when a qualified teacher is not allowed to teach the requested grade', () {
    final data = Map<String, Object?>.from(base)
      ..['teacherSubjectGrades'] = [{'teacher_id': 7, 'subject_id': 1, 'grade_id': 102}];
    final result = run(data);
    expect(result.findings.any((f) => f.code == 'no_teacher_allowed_grade'), isTrue);
    // Recoverable: scheduler may create a partial draft for other requirements.
    expect(result.canStart, isTrue);
  });

  test('detects total weekly requirements greater than section capacity', () {
    final data = Map<String, Object?>.from(base)
      ..['requirements'] = [
        {'section_id': 1, 'grade_id': 101, 'subject_id': 1, 'weekly_lessons': 5, 'subject_name': 'العربية', 'section_name': 'أ', 'grade_name': 'الأول'},
      ];
    final result = run(data);
    expect(result.findings.any((f) => f.code == 'section_over_capacity'), isTrue);
  });

  test('blocks scheduling when there are no active days or available lesson periods', () {
    final data = Map<String, Object?>.from(base)
      ..['days'] = <Map<String, Object?>>[];
    final result = run(data);
    expect(result.canStart, isFalse);
    expect(result.findings.any((f) => f.code == 'no_days'), isTrue);
  });

  test('warns when a teacher has no subject qualifications or weekly target load', () {
    final data = Map<String, Object?>.from(base)
      ..['teachers'] = [{'id': 7, 'name': 'طالب', 'weekly_load': 0}]
      ..['qualifications'] = <Map<String, Object?>>[];
    final result = run(data);
    expect(result.findings.any((f) => f.code == 'teacher_without_subjects'), isTrue);
    expect(result.findings.any((f) => f.code == 'teacher_without_weekly_load'), isTrue);
    expect(result.canStart, isTrue);
  });

  test('blocks duplicate section-subject requirements because they can double-place lessons', () {
    final data = Map<String, Object?>.from(base)
      ..['requirements'] = [
        {'section_id': 1, 'grade_id': 101, 'subject_id': 1, 'weekly_lessons': 2, 'subject_name': 'العربية', 'section_name': 'أ', 'grade_name': 'الأول'},
        {'section_id': 1, 'grade_id': 101, 'subject_id': 1, 'weekly_lessons': 3, 'subject_name': 'العربية', 'section_name': 'أ', 'grade_name': 'الأول'},
      ];
    final result = run(data);
    expect(result.canStart, isFalse);
    final finding = result.findings.firstWhere((f) => f.code == 'duplicate_section_subject_requirement');
    expect(finding.blocking, isTrue);
    expect(finding.message, contains('5 حصة أسبوعياً'));
  });

  test('blocks a negative weekly lesson count instead of silently ignoring it', () {
    final data = Map<String, Object?>.from(base)
      ..['requirements'] = [
        {'section_id': 1, 'grade_id': 101, 'subject_id': 1, 'weekly_lessons': -2, 'subject_name': 'العربية', 'section_name': 'أ', 'grade_name': 'الأول'},
      ];
    final result = run(data);
    expect(result.canStart, isFalse);
    expect(result.findings.any((f) => f.code == 'negative_weekly_lessons' && f.blocking), isTrue);
  });

  // Six lessons over five days are possible with two distinct permitted
  // periods in one day; period six itself is not a prerequisite.
  final fiveDays = <Map<String, Object?>>[
    {'id': 1, 'name': 'الأحد', 'position': 1, 'is_active': 1},
    {'id': 2, 'name': 'الاثنين', 'position': 2, 'is_active': 1},
    {'id': 3, 'name': 'الثلاثاء', 'position': 3, 'is_active': 1},
    {'id': 4, 'name': 'الأربعاء', 'position': 4, 'is_active': 1},
    {'id': 5, 'name': 'الخميس', 'position': 5, 'is_active': 1},
  ];
  final sixArabicLessons = <Map<String, Object?>>[
    {'section_id': 1, 'grade_id': 101, 'subject_id': 1,
     'weekly_lessons': 6, 'max_daily_lessons': 2, 'allow_same_day': 0,
     'subject_name': 'اللغة العربية', 'section_name': 'أ', 'grade_name': 'الأول'},
  ];

  test('blocks six weekly lessons if only one teaching period exists each day', () {
    final data = Map<String, Object?>.from(base)
      ..['requirements'] = sixArabicLessons
      ..['days'] = fiveDays
      ..['slots'] = [
        {'id': 1, 'name': 'الأولى', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ];
    final result = run(data);
    expect(result.canStart, isFalse);
    final finding = result.findings.firstWhere((f) => f.code == 'requirement_rule_capacity');
    expect(finding.blocking, isTrue);
    expect(finding.message, contains('بحد أقصى 5'));
    expect(finding.recommendation, contains('فترتين مختلفتين'));
  });

  test('allows six weekly lessons if two early periods are available each day', () {
    final data = Map<String, Object?>.from(base)
      ..['requirements'] = sixArabicLessons
      ..['days'] = fiveDays;
    final result = run(data);
    expect(result.canStart, isTrue);
    expect(result.findings.where((f) => f.code == 'requirement_rule_capacity'), isEmpty);
  });

  test('detects when a subject ban leaves just one possible period per day', () {
    final data = Map<String, Object?>.from(base)
      ..['requirements'] = sixArabicLessons
      ..['days'] = fiveDays
      ..['subjectBlockedSlots'] = [
        {'subject_id': 1, 'slot_id': 2},
      ];
    final result = run(data);
    expect(result.canStart, isFalse);
    final finding = result.findings.firstWhere((f) => f.code == 'requirement_rule_capacity');
    expect(finding.message, contains('بحد أقصى 5'));
  });

  test('allows the necessary sixth Arabic lesson in period six without changing saved repeat settings', () {
    final data = Map<String, Object?>.from(base)
      ..['requirements'] = [
        {'section_id': 1, 'grade_id': 101, 'subject_id': 1,
         'weekly_lessons': 6, 'max_daily_lessons': 1, 'allow_same_day': 0,
         'subject_name': 'اللغة العربية', 'section_name': 'أ', 'grade_name': 'السادس الابتدائي'},
      ]
      ..['sections'] = [
        {'id': 1, 'grade_id': 101, 'grade_name': 'السادس الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 6},
      ]
      ..['days'] = [
        {'id': 1, 'name': 'الأحد', 'position': 1, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 2, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 3, 'is_active': 1},
        {'id': 4, 'name': 'الأربعاء', 'position': 4, 'is_active': 1},
        {'id': 5, 'name': 'الخميس', 'position': 5, 'is_active': 1},
      ]
      ..['slots'] = [
        for (var i = 1; i <= 6; i++)
          {'id': i, 'name': 'الحصة $i', 'position': i, 'kind': 'lesson', 'is_available': 1},
      ];
    final result = run(data);
    expect(result.canStart, isTrue);
    expect(result.findings.where((f) => f.code == 'requirement_rule_capacity'), isEmpty);
  });

  test('estimates subject capacity after teacher availability restrictions', () {
    final data = Map<String, Object?>.from(base)
      ..['requirements'] = [
        {'section_id': 1, 'grade_id': 101, 'subject_id': 1, 'weekly_lessons': 3, 'max_daily_lessons': 2, 'allow_same_day': 1, 'subject_name': 'العربية', 'section_name': 'أ', 'grade_name': 'الأول'},
      ]
      ..['availability'] = [
        {'teacher_id': 7, 'day_id': 1, 'slot_id': 1, 'is_available': 0},
        {'teacher_id': 7, 'day_id': 1, 'slot_id': 2, 'is_available': 0},
        {'teacher_id': 7, 'day_id': 2, 'slot_id': 1, 'is_available': 0},
        {'teacher_id': 7, 'day_id': 2, 'slot_id': 2, 'is_available': 1},
      ];
    final result = run(data);
    expect(result.findings.any((f) => f.code == 'subject_availability_capacity'), isTrue);
  });

  test('includes teacher availability violations in the preflight report of the current timetable', () {
    final data = Map<String, Object?>.from(base)
      ..['currentEntries'] = [
        {'id': 1, 'section_id': 1, 'section_grade_id': 101, 'grade_id': 101, 'subject_id': 1,
         'teacher_id': 7, 'day_id': 1, 'slot_id': 1, 'section_name': 'أ', 'grade_name': 'الأول',
         'subject_name': 'العربية', 'teacher_name': 'طالب', 'day_name': 'الأحد', 'slot_name': 'الأولى'},
      ]
      ..['availability'] = [
        {'teacher_id': 7, 'day_id': 1, 'slot_id': 1, 'is_available': 0},
      ];
    final result = run(data);
    final finding = result.findings.firstWhere((f) => f.code == 'current_timetable_issues');
    expect(finding.message, contains('المعلم غير متاح في الفترة'));
  });

  test('shows current teacher collisions before generating a replacement draft', () {
    final data = Map<String, Object?>.from(base)
      ..['sections'] = [
        {'id': 1, 'grade_id': 101, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 6},
        {'id': 2, 'grade_id': 101, 'grade_name': 'الأول', 'section_name': 'ب', 'max_daily_lessons': 6},
      ]
      ..['requirements'] = [
        {'section_id': 1, 'grade_id': 101, 'subject_id': 1, 'weekly_lessons': 1, 'subject_name': 'العربية', 'section_name': 'أ', 'grade_name': 'الأول'},
        {'section_id': 2, 'grade_id': 101, 'subject_id': 1, 'weekly_lessons': 1, 'subject_name': 'العربية', 'section_name': 'ب', 'grade_name': 'الأول'},
      ]
      ..['currentEntries'] = [
        {'id': 1, 'section_id': 1, 'section_grade_id': 101, 'grade_id': 101, 'subject_id': 1, 'teacher_id': 7, 'day_id': 1, 'slot_id': 1, 'section_name': 'أ', 'grade_name': 'الأول', 'subject_name': 'العربية', 'teacher_name': 'طالب'},
        {'id': 2, 'section_id': 2, 'section_grade_id': 101, 'grade_id': 101, 'subject_id': 1, 'teacher_id': 7, 'day_id': 1, 'slot_id': 1, 'section_name': 'ب', 'grade_name': 'الأول', 'subject_name': 'العربية', 'teacher_name': 'طالب'},
      ];
    final result = run(data);
    final finding = result.findings.where((f) => f.code == 'current_timetable_issues').toList();
    expect(finding, isNotEmpty);
    expect(finding.single.message, contains('تعارض المعلم'));
    // Old conflicts are reported, not used to block creation of a new draft.
    expect(result.canStart, isTrue);
  });
}
