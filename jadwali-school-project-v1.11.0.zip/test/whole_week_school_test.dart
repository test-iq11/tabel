import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:iraqi_school_timetable/services/conflict_detection_service.dart';
import 'package:iraqi_school_timetable/services/constraint_explanation_service.dart';
import 'package:iraqi_school_timetable/services/whole_week_local_search.dart';

Map<String, Object?> _school() => Map<String, Object?>.from(jsonDecode(
  File('test/fixtures/backup_school_181.json').readAsStringSync()) as Map);
List<Map<String, Object?>> _rows(Map<String, Object?> input, String key) =>
    (input[key] as List? ?? []).map((r) => Map<String, Object?>.from(r as Map)).toList();

SchedulerResult _solve(Map<String, Object?> input, {List<Map<String, Object?>>? seed}) =>
  const AutoSchedulerService(nodeLimit: 60000).generate(
    sections: _rows(input, 'sections'), requirements: _rows(input, 'requirements'),
    teachers: _rows(input, 'teachers'), qualifications: _rows(input, 'qualifications'),
    teacherGrades: _rows(input, 'teacherGrades'), teacherSubjectGrades: _rows(input, 'teacherSubjectGrades'),
    days: _rows(input, 'days'), slots: _rows(input, 'slots'),
    subjectBlockedSlots: _rows(input, 'subjectBlockedSlots'),
    teacherAvailability: _rows(input, 'teacherAvailability'),
    lockedPlacements: _rows(input, 'lockedPlacements'), initialPlacements: seed ?? [],
    timeLimit: const Duration(seconds: 10), feasibilityOnly: true,
  );

void _verify(Map<String, Object?> input, SchedulerResult result) {
  expect(result.complete, isTrue, reason: result.unscheduled.join('\n'));
  expect(result.placements, hasLength(181));
  final violations = const ConflictDetectionService().scan(
    entries: result.placements, sections: _rows(input, 'sections'), requirements: _rows(input, 'requirements'),
    teachers: _rows(input, 'teachers'), qualifications: _rows(input, 'qualifications'),
    teacherGrades: _rows(input, 'teacherGrades'), teacherSubjectGrades: _rows(input, 'teacherSubjectGrades'),
    days: _rows(input, 'days'), slots: _rows(input, 'slots'),
    subjectBlockedSlots: _rows(input, 'subjectBlockedSlots'), teacherAvailability: _rows(input, 'teacherAvailability'),
  ).where((i) => i.type != 'تكرار توقيت المادة في أيام متتالية');
  expect(violations, isEmpty, reason: violations.map((i) => '${i.type}: ${i.message}').join('\n'));
  final sixth = _rows(input, 'sections').singleWhere((s) => '${s['grade_name']}'.contains('السادس'))['id'];
  final sunday = _rows(input, 'days').singleWhere((d) => d['name'] == 'الأحد')['id'];
  expect(result.placements.where((e) => e['section_id'] == sixth && e['day_id'] == sunday), hasLength(7));
  for (final lock in _rows(input, 'lockedPlacements')) {
    expect(result.placements.any((e) => ['section_id', 'subject_id', 'teacher_id', 'day_id', 'slot_id', 'room_id']
        .every((k) => e[k] == lock[k])), isTrue);
  }
}

void _grant(Map<String, Object?> input, int teacher, int subject, List<int> grades) {
  final qualifications = _rows(input, 'qualifications');
  if (!qualifications.any((r) => r['teacher_id'] == teacher && r['subject_id'] == subject)) {
    qualifications.add({'teacher_id': teacher, 'subject_id': subject});
  }
  input['qualifications'] = qualifications;
  final rules = _rows(input, 'teacherSubjectGrades');
  for (final grade in grades) {
    if (!rules.any((r) => r['teacher_id'] == teacher && r['subject_id'] == subject && r['grade_id'] == grade)) {
      rules.add({'teacher_id': teacher, 'subject_id': subject, 'grade_id': grade});
    }
  }
  input['teacherSubjectGrades'] = rules;
}

void main() {
  final subjects = _rows(_school(), 'requirements').map((r) => r['subject_id'] as int).toSet().toList()..sort();
  for (final subject in subjects) {
    for (final periods in [[1], [2], [1, 2]]) {
      test('181 cold lessons: subject $subject excluded from $periods', () {
        final input = _school();
        input['subjectBlockedSlots'] = [for (final period in periods) {'subject_id': subject, 'slot_id': period}];
        final before = jsonEncode(input);
        _verify(input, _solve(input));
        expect(jsonEncode(input), before, reason: 'Search must not change school settings.');
      });
    }
  }
  final compound = [
    [[4, 1], [7, 1], [8, 1], [3, 1]],
    [[6, 1], [6, 2], [5, 1], [10, 1]],
    [[3, 1], [3, 2], [8, 1], [4, 2]],
  ];
  for (var i = 0; i < compound.length; i++) {
    test('181 cold lessons: independently feasible former failure $i', () {
      final input = _school();
      input['subjectBlockedSlots'] = [for (final pair in compound[i]) {'subject_id': pair[0], 'slot_id': pair[1]}];
      _verify(input, _solve(input));
    });
  }
  test('an extra teacher makes the old 21-in-20 bottleneck schedulable', () {
    final input = _school();
    input['subjectBlockedSlots'] = [for (final s in [2, 4]) for (final p in [1, 2]) {'subject_id': s, 'slot_id': p}];
    final proof = const ConstraintExplanationService().explain(input).singleWhere((e) => e.code == 'mandatory_teacher_capacity:4');
    expect(proof.reason, contains('21 حصة'));
    expect(proof.reason, contains('20 حصة'));
    final teachers = _rows(input, 'teachers');
    final original = teachers.singleWhere((t) => t['id'] == 4);
    original['weekly_load'] = 10;
    teachers.add({...original, 'id': 104, 'name': 'المعلم الإضافي', 'weekly_load': 11});
    input['teachers'] = teachers;
    for (final rule in _rows(input, 'teacherSubjectGrades').where((r) => r['teacher_id'] == 4)) {
      _grant(input, 104, rule['subject_id'] as int, [rule['grade_id'] as int]);
    }
    expect(const ConstraintExplanationService().explain(input).where((e) => e.proven), isEmpty);
    _verify(input, _solve(input));
  });
  test('nine teachers with redistributed expertise and sufficient capacity', () {
    final input = _school();
    final teachers = _rows(input, 'teachers')..removeWhere((t) => t['id'] == 6);
    for (final entry in {9: 25, 4: 25, 7: 21, 10: 22}.entries) {
      teachers.singleWhere((t) => t['id'] == entry.key)['weekly_load'] = entry.value;
    }
    input['teachers'] = teachers;
    for (final teacher in [9, 4, 7]) { _grant(input, teacher, 4, [5, 6]); }
    _grant(input, 10, 7, [3]);
    input['subjectBlockedSlots'] = [{'subject_id': 3, 'slot_id': 1}, {'subject_id': 3, 'slot_id': 2}];
    _verify(input, _solve(input, seed: _rows(input, 'initialPlacements')));
  });
  test('room-bearing locks survive a whole-week compound repair', () {
    final input = _school();
    input['subjectBlockedSlots'] = [for (final pair in compound.first) {'subject_id': pair[0], 'slot_id': pair[1]}];
    final lock = _rows(input, 'initialPlacements').firstWhere((r) => r['slot_id'] != 1);
    lock['room_id'] = 31;
    input['lockedPlacements'] = [lock];
    _verify(input, _solve(input));
  });
  test('181 lessons still fit after availability and consecutive limits change', () {
    final input = _school();
    final teachers = _rows(input, 'teachers');
    teachers.singleWhere((t) => t['id'] == 2)['max_consecutive_lessons'] = 2;
    teachers.singleWhere((t) => t['id'] == 8)['max_consecutive_lessons'] = 2;
    input['teachers'] = teachers;
    input['teacherAvailability'] = [{'teacher_id': 2, 'day_id': 2, 'slot_id': 2, 'is_available': 0}];
    _verify(input, _solve(input, seed: _rows(input, 'initialPlacements')));
  });
  test('whole-week search uses school data after IDs and row order change', () {
    final input = _school();
    final random = Random(1100);
    const idShift = {'sections': 100, 'teachers': 200, 'slots': 300, 'days': 400};
    const fieldShift = {'section_id': 100, 'teacher_id': 200, 'slot_id': 300, 'day_id': 400,
      'subject_id': 500, 'grade_id': 600};
    for (final key in ['sections', 'teachers', 'slots', 'days', 'requirements', 'qualifications', 'teacherSubjectGrades']) {
      final rows = _rows(input, key);
      for (final row in rows) {
        if (idShift.containsKey(key)) row['id'] = (row['id'] as int) + idShift[key]!;
        for (final field in fieldShift.keys) {
          if (row[field] is int) row[field] = (row[field] as int) + fieldShift[field]!;
        }
      }
      rows.shuffle(random); input[key] = rows;
    }
    input['subjectBlockedSlots'] = [{'subject_id': 503, 'slot_id': 301}, {'subject_id': 503, 'slot_id': 302}];
    _verify(input, _solve(input));
  });
  test('whole-week search respects immediate cancellation', () {
    final input = _school();
    final result = const WholeWeekLocalSearch().solve(
      sections: _rows(input, 'sections'), requirements: _rows(input, 'requirements'),
      teachers: _rows(input, 'teachers'), qualifications: _rows(input, 'qualifications'),
      teacherGrades: _rows(input, 'teacherGrades'), teacherSubjectGrades: _rows(input, 'teacherSubjectGrades'),
      days: _rows(input, 'days'), slots: _rows(input, 'slots'),
      subjectBlockedSlots: [], teacherAvailability: [], lockedPlacements: [], shouldStop: () => true,
    );
    expect(result, isNull);
  });
}
