import 'package:flutter/material.dart';

import '../../core/design_widgets.dart';
import '../../core/interface_settings.dart';
import '../../core/smart_widgets.dart';
import '../../core/html_dashboard_hero.dart';
import '../../core/ui_helpers.dart';
import '../../core/jadwali_visuals.dart';
import '../../data/database_service.dart';
import '../smart/smart_access_dialog.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({
    required this.onNavigate,
    this.onOpenSection,
    this.onOpenTeacher,
    super.key,
  });
  final ValueChanged<int> onNavigate;
  final ValueChanged<int>? onOpenSection, onOpenTeacher;
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  late Future<Map<String, Object?>> _future;
  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    _future = _load();
  }

  Future<Map<String, Object?>> _load() async {
    final db = DatabaseService.instance;
    final year = await db.activeYearId();
    final version = await db.activeVersionId(year);
    return {
      ...await db.summary(),
      'days': await db.rows('school_days', orderBy: 'position'),
      'school': (await db.getSettings())['school_name'],
      'entries': version == null
          ? <Map<String, Object?>>[]
          : await db.entriesDetailed(versionId: version),
    };
  }

  Future<void> _search() => showSmartAccess(
    context,
    onNavigate: widget.onNavigate,
    onTeacher: widget.onOpenTeacher,
    onSection: widget.onOpenSection,
  );
  Widget _hero() => HtmlDashboardHero(
        onRepair: () => widget.onNavigate(6),
        onTimetable: () => widget.onNavigate(1),
      );
  Widget _completionCard(int placed, int required) {
    final c = Theme.of(context).colorScheme;
    final double ratio = required == 0 ? 0.0 : (placed / required).clamp(0.0, 1.0).toDouble();
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: JadwaliVisuals.panel(context),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('مؤشر اكتمال توزيع الحصص', style: TextStyle(
          color: c.onSurface, fontWeight: FontWeight.w800, fontSize: 13)),
        const SizedBox(height: 14),
        Center(child: SizedBox(width: 124, height: 124, child: Stack(
          alignment: Alignment.center, children: [
            SizedBox(width: 119, height: 119, child: CircularProgressIndicator(
              value: ratio, strokeWidth: 11, strokeCap: StrokeCap.round,
              backgroundColor: c.primary.withValues(alpha: .1),
              color: c.primary)),
            Column(mainAxisSize: MainAxisSize.min, children: [
              Text('${(ratio * 100).round()}٪', style: const TextStyle(fontSize: 27,
                fontWeight: FontWeight.w900)),
              Text('موزعة', style: TextStyle(fontSize: 10, color: c.onSurfaceVariant)),
            ]),
          ]))),
        const SizedBox(height: 14),
        Text(required == 0 ? 'حدّد الحصص المطلوبة ليظهر المؤشر'
            : '$placed حصة موزعة من أصل $required حصة مطلوبة',
          style: TextStyle(fontSize: 11, color: c.onSurfaceVariant)),
        const SizedBox(height: 9),
        Text('مؤشر اكتمال فقط، وليس حكمًا بخلو الجدول من التعارضات.',
          style: TextStyle(fontSize: 10, color: c.onSurfaceVariant)),
        TextButton.icon(onPressed: () => widget.onNavigate(6),
          icon: const Icon(Icons.fact_check_outlined, size: 17),
          label: const Text('فحص التعارضات')),
      ]),
    );
  }

  Widget _pulseLine(IconData icon, String label, String detail, Color tint) {
    final c = Theme.of(context).colorScheme;
    return Row(children: [
      Container(width: 39, height: 39, alignment: Alignment.center,
        decoration: BoxDecoration(color: tint.withValues(alpha: .11),
          borderRadius: BorderRadius.circular(12)),
        child: Icon(icon, color: tint, size: 20)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
        Text(detail, style: TextStyle(color: c.onSurfaceVariant, fontSize: 10)),
      ])),
    ]);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: FutureBuilder<Map<String, Object?>>(
      future: _future,
      builder: (context, snap) {
        if (snap.hasError)
          return emptyState(
            icon: Icons.error_outline,
            title: 'تعذر تحميل الملخص',
            message: '${snap.error}',
          );
        if (!snap.hasData)
          return const Center(child: CircularProgressIndicator());
        final data = snap.data!;
        int value(String key) => (data[key] as num?)?.toInt() ?? 0;
        final entries = (data['entries'] as List).cast<Map<String, Object?>>();
        final days = (data['days'] as List)
            .cast<Map<String, Object?>>()
            .where((d) => d['is_active'] != 0)
            .toList();
        final pins = entries.where((e) => e['is_locked'] == 1).length;
        final day = days.isEmpty ? null : days.first;
        final firstDay = entries
            .where((e) => e['day_id'] == day?['id'])
            .take(4)
            .toList();
        return RefreshIndicator(
          onRefresh: () async {
            setState(_reload);
            await _future;
          },
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1280),
              child: ListView(
                key: const ValueKey('smart-dashboard-scroll'),
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
                children: [
                  Wrap(spacing: 10, runSpacing: 12,
                    crossAxisAlignment: WrapCrossAlignment.center, children: [
                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('لوحة التحكم الذكية', style: TextStyle(
                          color: Theme.of(context).colorScheme.primary,
                          fontWeight: FontWeight.w800, fontSize: 11)),
                        const Text('أهلاً بك في جدولي 👋', style: TextStyle(
                          fontSize: 25, fontWeight: FontWeight.w900)),
                        Text('كل ما تحتاجه لإدارة جدول مدرستك في مكان واحد.',
                          style: TextStyle(fontSize: 12,
                            color: Theme.of(context).colorScheme.onSurfaceVariant)),
                      ]),
                      FilledButton.icon(onPressed: () => widget.onNavigate(1),
                        icon: const Icon(Icons.calendar_month_outlined),
                        label: const Text('فتح الجدول')),
                    ]),
                  const SizedBox(height: 17),
                  LayoutBuilder(builder: (context, bounds) {
                    if (bounds.maxWidth < 800) return Column(children: [
                      _hero(),
                      const SizedBox(height: 13),
                      _completionCard(entries.length, value('الحصص المطلوبة')),
                    ]);
                    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Expanded(flex: 7, child: _hero()),
                      const SizedBox(width: 14),
                      Expanded(flex: 3, child: _completionCard(entries.length,
                        value('الحصص المطلوبة'))),
                    ]);
                  }),
                  const SizedBox(height: 18),
                  LayoutBuilder(
                    builder: (context, c) {
                      final columns = c.maxWidth > 750
                          ? 4
                          : c.maxWidth < 290 ||
                                MediaQuery.textScalerOf(context).scale(1) > 1.35
                          ? 1
                          : 2;
                      final metrics = [
                        (
                          '${entries.length}',
                          'حصة موزعة',
                          Icons.calendar_month_outlined,
                        ),
                        (
                          '${value('عدد الشعب')}',
                          'صفوف دراسية',
                          Icons.school_outlined,
                        ),
                        (
                          '${value('عدد المعلمين')}',
                          'معلمين',
                          Icons.people_outline,
                        ),
                        ('$pins', 'حصص مقفلة', Icons.lock_outline),
                      ];
                      return Wrap(
                        spacing: 12,
                        runSpacing: 12,
                        children: [
                          for (final m in metrics)
                            SizedBox(
                              width:
                                  (c.maxWidth - 12 * (columns - 1)) / columns,
                              child: JadwaliStatCard(value: m.$1, caption: m.$2,
                                icon: m.$3, tint: [
                                  const Color(0xff525fe8), const Color(0xff13a78c),
                                  const Color(0xffe36b6f), const Color(0xffe89c36),
                                ][metrics.indexOf(m)]),
                            ),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 14),
                  SmartHeading('نظرة سريعة على الحصص',
                    action: TextButton.icon(onPressed: () => widget.onNavigate(1),
                      icon: const Icon(Icons.fullscreen_outlined, size: 17),
                      label: const Text('الجدول كاملًا'))),
                  Container(padding: const EdgeInsets.all(13),
                    decoration: JadwaliVisuals.panel(context),
                    child: JadwaliWeekPreview(entries: entries,
                      dayId: day?['id'], onOpenSection: widget.onOpenSection)),
                  const SizedBox(height: 20),
                  SmartHeading('نبض الجدول', action: TextButton.icon(
                    onPressed: () => widget.onNavigate(6),
                    icon: const Icon(Icons.auto_fix_high_outlined, size: 17),
                    label: const Text('فتح فحص التعارضات'))),
                  Container(
                    decoration: JadwaliVisuals.panel(context),
                    padding: const EdgeInsets.all(16),
                    child: Column(children: [
                      _pulseLine(Icons.calendar_month_outlined, 'حصص موزعة',
                        '${entries.length} من ${value('الحصص المطلوبة')}', const Color(0xff525fe8)),
                      const Divider(height: 18),
                      _pulseLine(Icons.lock_outline, 'حصص مثبتة بقفل',
                        '$pins حصة لا يغيّرها الإصلاح دون موافقتك', const Color(0xff13a78c)),
                      const Divider(height: 18),
                      _pulseLine(Icons.info_outline, 'فحص التعارضات',
                        'افتح الفحص لمعرفة المشكلات الفعلية، لا تعتمد على نسبة الاكتمال',
                        const Color(0xffe89c36)),
                    ]),
                  ),
                  const SizedBox(height: 22),
                  const SmartHeading('أدوات تتجاوز عرض الجدول'),
                  ActionGrid(
                    children: [
                      ActionTile(
                        key: const ValueKey('smart-lab-entry'),
                        title: 'ماذا لو؟',
                        subtitle: 'جرّب شرطاً دون تغيير بياناتك',
                        icon: Icons.auto_awesome_outlined,
                        onTap: () => widget.onNavigate(16),
                      ),
                      ActionTile(
                        title: 'طوارئ اليوم',
                        subtitle: 'خطط لغياب معلم وراجع البدلاء',
                        icon: Icons.bolt_outlined,
                        tone: 1,
                        onTap: () => widget.onNavigate(8),
                      ),
                      ActionTile(
                        key: const ValueKey('smart-search-entry'),
                        title: 'وصول ذكي',
                        subtitle: 'ابحث عن معلم أو صف أو أداة',
                        icon: Icons.search,
                        tone: 2,
                        onTap: _search,
                      ),
                    ],
                  ),
                  SmartHeading(
                    'اختصاراتك',
                    action: TextButton.icon(
                      onPressed: () => customizeHome(context),
                      icon: const Icon(Icons.tune, size: 17),
                      label: const Text('تخصيص الرئيسية'),
                    ),
                  ),
                  ActionGrid(
                    children: [
                      for (final id in InterfaceSettings.instance.shortcuts)
                        ActionTile(
                          title: shortcutInfo[id]!.$1,
                          subtitle: shortcutInfo[id]!.$2,
                          icon: shortcutInfo[id]!.$3,
                          tone: shortcutInfo[id]!.$4,
                          onTap: () => widget.onNavigate(id),
                        ),
                    ],
                  ),
                  if (firstDay.isNotEmpty) ...[
                    SmartHeading('نظرة إلى ${day!['name']}'),
                    SmartPanel(
                      child: Column(
                        children: [
                          for (final e in firstDay)
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(Icons.schedule),
                              title: Text('${e['subject_name']}'),
                              subtitle: Text(
                                '${e['grade_name'] ?? ''} ${e['section_name'] ?? ''} · ${e['teacher_name'] ?? 'دون معلم'}\n${e['slot_name']} · ${e['start_time']}',
                              ),
                              trailing: const Icon(Icons.chevron_left),
                              onTap: () => widget.onOpenSection?.call(
                                e['section_id'] as int,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                  TextButton.icon(
                    onPressed: () => widget.onNavigate(13),
                    icon: const Icon(Icons.school_outlined),
                    label: const Text('إدارة بيانات المدرسة'),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    ),
  );
}
