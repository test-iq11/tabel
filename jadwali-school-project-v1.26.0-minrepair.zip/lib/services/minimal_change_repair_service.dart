import 'conflict_detection_service.dart';
import 'teacher_availability_policy.dart';

typedef RepairRow = Map<String, Object?>;

/// A proposal is only an in-memory draft. Nothing is changed until the user
/// reviews it and the database independently validates the new version.
class MinimalRepairOption {
  const MinimalRepairOption({
    required this.placements,
    required this.moved,
    required this.remainingBlockers,
    required this.reason,
  });
  final List<RepairRow> placements;
  final List<int> moved;
  final int remainingBlockers;
  final String reason;
  int get unchanged => placements.length - moved.length;
  String get title => moved.length == 1
      ? 'نقل حصة واحدة'
      : moved.length == 2
      ? 'تبديل مباشر بين حصتين'
      : moved.length == 3
      ? 'تبديل دائري بين ثلاث حصص'
      : 'سلسلة تبديل من ${moved.length} حصص';
}

class MinimalRepairSearchResult {
  const MinimalRepairSearchResult(this.options, this.diagnostics, this.explored);
  final List<MinimalRepairOption> options;
  final List<String> diagnostics;
  final int explored;
}

/// An incremental, bounded, lexicographically least-change search.
/// It keeps identities, teachers, subjects, sections, rooms and pins intact;
/// only day and period can move. Global school rules are checked by the SAME
/// ConflictDetectionService used by the normal editor, not by an approximation.
class MinimalChangeRepairService {
  const MinimalChangeRepairService();

  static int n(Object? value) => value is num ? value.toInt() : int.tryParse('$value') ?? 0;
  static List<RepairRow> rows(Map<String, Object?> data, String key) =>
      (data[key] as List? ?? const []).map((e) => Map<String, Object?>.from(e as Map)).toList();

  List<ConflictIssue> scan(Map<String, Object?> data, List<RepairRow> entries) =>
      const ConflictDetectionService().scan(
        entries: entries,
        sections: rows(data, 'sections'),
        requirements: rows(data, 'requirements'),
        teachers: rows(data, 'teachers'),
        qualifications: rows(data, 'qualifications'),
        teacherGrades: rows(data, 'teacherGrades'),
        teacherSubjectGrades: rows(data, 'teacherSubjectGrades'),
        days: rows(data, 'days'),
        slots: rows(data, 'slots'),
        subjectBlockedSlots: rows(data, 'subjectBlockedSlots'),
        teacherAvailability: rows(data, 'availability'),
        enforceQualifications: true,
      );

  static String signature(ConflictIssue issue) =>
      '${issue.type}|${issue.sectionId}|${issue.teacherId}|${issue.subjectId}|${issue.dayId}|${issue.slotId}';

  static Map<String, int> _hardCounts(List<ConflictIssue> issues) {
    final result = <String, int>{};
    for (final issue in issues.where((i) => i.severity == 'خطأ مانع')) {
      final key = signature(issue);
      result[key] = (result[key] ?? 0) + 1;
    }
    return result;
  }

  /// Capacity is an upper bound (not a proof that a solution exists):
  /// its deficit IS a proof that the fixed assignment cannot fit.
  List<String> capacityDiagnostics(Map<String, Object?> data, {int? teacherId}) {
    final entries = rows(data, 'entries');
    final days = rows(data, 'days').where((d) => n(d['is_active'] ?? 1) != 0);
    final slots = rows(data, 'slots').where((s) =>
        s['kind'] == 'lesson' && n(s['is_available'] ?? 1) != 0);
    final sections = {for (final s in rows(data, 'sections')) n(s['id']): s};
    final teachers = {for (final t in rows(data, 'teachers')) n(t['id']): t};
    final blocked = {for (final b in rows(data, 'subjectBlockedSlots'))
      '${n(b['subject_id'])}:${n(b['slot_id'])}'};
    final availability = TeacherAvailabilityPolicy(rows(data, 'availability'));
    final result = <String>[];
    final ids = teacherId != null && teacherId > 0
        ? <int>{teacherId}
        : entries.map((e) => n(e['teacher_id'])).where((id) => id > 0).toSet();
    for (final id in ids) {
      final assigned = entries.where((e) => n(e['teacher_id']) == id).toList();
      if (assigned.isEmpty) continue;
      final availableCells = <String>{};
      for (final entry in assigned) {
        final gradeId = n(sections[n(entry['section_id'])]?['grade_id'] ?? entry['grade_id']);
        for (final day in days) {
          for (final slot in slots) {
            final dayId = n(day['id']);
            final slotId = n(slot['id']);
            if (blocked.contains('${n(entry['subject_id'])}:$slotId')) continue;
            if (availability.isAvailable(
              teacherId: id, dayId: dayId, slotId: slotId,
              gradeId: gradeId, subjectId: n(entry['subject_id']),
            )) availableCells.add('$dayId:$slotId');
          }
        }
      }
      final teacherName = teachers[id]?['name'] ?? 'المعلم $id';
      if (assigned.length > availableCells.length) {
        final difference = assigned.length - availableCells.length;
        result.add('المعلم $teacherName مُسند إليه ${assigned.length} حصص، لكن الإتاحة وقيود مواده تسمح بحد أقصى ${availableCells.length} فترات مختلفة. يلزم توفير $difference فترة إضافية على الأقل، أو إعادة إسناد $difference حصة لمعلم مؤهل آخر. لن تُغيَّر شروطك تلقائياً.');
      }
      final load = n(teachers[id]?['weekly_load']);
      if (load > 0 && assigned.length > load) {
        result.add('المعلم $teacherName مُسند إليه ${assigned.length} حصص بينما نصابه المسجل $load. راجع الإسناد أو صحّح النصاب من إدارة البيانات؛ لن يغيّره الإصلاح.');
      }
    }
    return result;
  }

  /// Repair several availability conflicts after teacher edits. Each round
  /// begins with lessons in the affected teacher/day/period neighborhood, then
  /// rechecks the complete board. The final preview is one combined diff.
  MinimalRepairSearchResult findAffected({
    required Map<String, Object?> data,
    int maxRounds = 8,
  }) {
    final original = rows(data, 'entries');
    var current = original.map((e) => Map<String, Object?>.from(e)).toList();
    final firstIssues = scan(data, original).where((i) => i.severity == 'خطأ مانع').toList();
    final seenLessons = <int>{};
    var searches = 0;
    var explored = 0;
    for (var round = 0; round < maxRounds; round++) {
      final issues = scan({...data, 'entries': current}, current)
          .where((i) => i.severity == 'خطأ مانع').toList()
        ..sort((a, b) {
          int rank(ConflictIssue i) => i.type == 'المعلم غير متاح في الفترة' ? 0 :
              i.type == 'المادة في فترة ممنوعة' ? 1 :
              i.type == 'تعارض المعلم' ? 2 :
              i.type == 'تعارض الشعبة' ? 3 : 4;
          return rank(a).compareTo(rank(b));
        });
      var improved = false;
      for (final issue in issues) {
        final affected = current.where((e) =>
            (issue.teacherId == null || e['teacher_id'] == issue.teacherId) &&
            (issue.sectionId == null || e['section_id'] == issue.sectionId) &&
            (issue.dayId == null || e['day_id'] == issue.dayId) &&
            (issue.slotId == null || e['slot_id'] == issue.slotId) &&
            (issue.subjectId == null || e['subject_id'] == issue.subjectId) &&
            n(e['is_locked']) != 1).toList();
        for (final row in affected) {
          final id = n(row['id']);
          if (!seenLessons.add(id)) continue;
          searches++;
          final result = find(
            data: {...data, 'entries': current},
            targetEntryId: id, maxEvaluations: 220, maxOptions: 1,
          );
          explored += result.explored;
          if (result.options.isNotEmpty) {
            current = result.options.first.placements;
            improved = true;
            break;
          }
        }
        if (improved) break;
        if (searches >= maxRounds * 8) break;
      }
      if (!improved) break;
    }
    final changed = <int>[
      for (var i = 0; i < original.length; i++)
        if (original[i]['day_id'] != current[i]['day_id'] ||
            original[i]['slot_id'] != current[i]['slot_id']) i,
    ];
    final remaining = scan(data, current)
        .where((i) => i.severity == 'خطأ مانع').length;
    final diagnostics = capacityDiagnostics(data);
    if (changed.isEmpty || remaining >= firstIssues.length) {
      return MinimalRepairSearchResult(const [], [
        ...diagnostics,
        'لم يُعثر على سلسلة إصلاحات آمنة لجميع الحصص المتأثرة ضمن حدود البحث. لم تتغير بياناتك.',
      ], explored);
    }
    return MinimalRepairSearchResult([
      MinimalRepairOption(
        placements: current,
        moved: changed,
        remainingBlockers: remaining,
        reason: 'إصلاح موضعي متتابع بدأ بالمشكلات المتصلة بإتاحة المعلمين، '
            'ثم وسّع البحث عند الحاجة دون المساس بالحصص المقفلة.',
      ),
    ], diagnostics, explored);
  }

  MinimalRepairSearchResult find({
    required Map<String, Object?> data,
    required int targetEntryId,
    int maxEvaluations = 850,
    int maxOptions = 5,
  }) {
    final board = rows(data, 'entries');
    final index = board.indexWhere((e) => n(e['id']) == targetEntryId);
    if (index < 0 || maxEvaluations <= 0) {
      return const MinimalRepairSearchResult([], ['لم يتم العثور على الحصة في النسخة النشطة.'], 0);
    }
    final target = board[index];
    final diagnostics = capacityDiagnostics(data, teacherId: n(target['teacher_id']));
    if (n(target['is_locked']) == 1) {
      return MinimalRepairSearchResult(const [], [
        'الحصة مقفلة؛ افتح قفلها من الجدول أولاً. لن يتحرك أي موضع مقفل.',
        ...diagnostics,
      ], 0);
    }
    final baseline = scan(data, board);
    final baselineCounts = _hardCounts(baseline);
    final baselineTotal = baselineCounts.values.fold<int>(0, (a, b) => a + b);
    if (baselineTotal == 0) {
      return MinimalRepairSearchResult(const [], [
        'لم يكتشف الفاحص أي تعارض مانع في النسخة الحالية. يمكن مراجعة التحذيرات دون نقل الحصة.',
        ...diagnostics,
      ], 0);
    }
    final days = rows(data, 'days').where((e) => n(e['is_active'] ?? 1) != 0).toList();
    final slots = rows(data, 'slots').where((e) =>
        e['kind'] == 'lesson' && n(e['is_available'] ?? 1) != 0).toList();
    final cells = <(int, int)>[
      for (final day in days) for (final slot in slots) (n(day['id']), n(slot['id'])),
    ];
    final grades = {for (final s in rows(data, 'sections')) n(s['id']): n(s['grade_id'])};
    final blocked = {for (final b in rows(data, 'subjectBlockedSlots'))
      '${n(b['subject_id'])}:${n(b['slot_id'])}'};
    final availability = TeacherAvailabilityPolicy(rows(data, 'availability'));
    bool legalCell(int i, (int, int) cell) {
      final e = board[i];
      return !blocked.contains('${n(e['subject_id'])}:${cell.$2}') &&
        availability.isAvailable(
          teacherId: n(e['teacher_id']), dayId: cell.$1, slotId: cell.$2,
          gradeId: grades[n(e['section_id'])] ?? n(e['grade_id']),
          subjectId: n(e['subject_id']),
        );
    }
    (int, int) at(int i) => (n(board[i]['day_id']), n(board[i]['slot_id']));
    final proposals = <MinimalRepairOption>[];
    final seen = <String>{};
    var evaluated = 0;

    // Candidate maps carry the complete original row, modifying only the cell.
    // Reject any NEW blocking rule, even if another old problem disappears.
    void consider(Map<int, (int, int)> changes, String explanation) {
      if (evaluated >= maxEvaluations) return;
      final changed = changes.keys.where((i) => changes[i] != at(i)).toList()..sort();
      if (changed.isEmpty || changed.any((i) => n(board[i]['is_locked']) == 1)) return;
      if (!changed.contains(index)) return;
      if (changed.any((i) => !legalCell(i, changes[i]!))) return;
      final fingerprint = changed.map((i) => '$i:${changes[i]!.$1}:${changes[i]!.$2}').join('|');
      if (!seen.add(fingerprint)) return;
      evaluated++;
      final candidate = <RepairRow>[
        for (var i = 0; i < board.length; i++)
          if (changes.containsKey(i))
            {...board[i], 'day_id': changes[i]!.$1, 'slot_id': changes[i]!.$2}
          else
            Map<String, Object?>.from(board[i]),
      ];
      final candidateIssues = scan(data, candidate);
      final afterCounts = _hardCounts(candidateIssues);
      final afterTotal = afterCounts.values.fold<int>(0, (a, b) => a + b);
      if (afterTotal >= baselineTotal) return;
      for (final issue in afterCounts.entries) {
        if (issue.value > (baselineCounts[issue.key] ?? 0)) return;
      }
      // Do not introduce new workload or daily-warning violations either.
      bool protectedWarning(ConflictIssue i) => i.severity == 'تحذير' &&
          i.type != 'تكرار توقيت المادة في أيام متتالية';
      Map<String, int> warningCounts(List<ConflictIssue> found) {
        final counts = <String, int>{};
        for (final issue in found.where(protectedWarning)) {
          final key = signature(issue);
          counts[key] = (counts[key] ?? 0) + 1;
        }
        return counts;
      }
      final beforeWarnings = warningCounts(baseline);
      final afterWarnings = warningCounts(candidateIssues);
      if (afterWarnings.entries.any((e) => e.value > (beforeWarnings[e.key] ?? 0))) return;
      proposals.add(MinimalRepairOption(
        placements: candidate, moved: changed,
        remainingBlockers: afterTotal, reason: explanation,
      ));
      // Keep only top proposals; each draft contains a full school timetable.
      if (proposals.length > 16) {
        proposals.sort((a, b) {
          final size = a.moved.length.compareTo(b.moved.length);
          return size != 0 ? size : a.remainingBlockers.compareTo(b.remainingBlockers);
        });
        proposals.removeRange(12, proposals.length);
      }
    }

    final occupiedSameSection = <String>{
      for (final e in board.where((e) => e['section_id'] == target['section_id']))
        '${n(e['day_id'])}:${n(e['slot_id'])}',
    };
    // Stage 1: one-lesson move into a free cell. The global scanner also
    // rejects hidden teacher/room conflicts and daily distribution violations.
    for (final cell in cells) {
      if (evaluated >= maxEvaluations) break;
      if (occupiedSameSection.contains('${cell.$1}:${cell.$2}')) continue;
      if (!legalCell(index, cell)) continue;
      consider({index: cell}, 'لا يشغل صفّ هذه الحصة الموضع الجديد؛ يظل سائر الجدول ثابتاً.');
    }

    // Explore affected teacher / section first, then widen to other sections.
    final peers = <int>[
      for (var i = 0; i < board.length; i++) if (i != index && n(board[i]['is_locked']) != 1) i,
    ]..sort((a, b) {
      int rank(int i) {
        final e = board[i];
        return (e['section_id'] == target['section_id'] ? 0 : 1000) +
          (e['teacher_id'] == target['teacher_id'] ? 0 : 100) +
          (e['day_id'] == target['day_id'] ? 0 : 10) + i;
      }
      return rank(a).compareTo(rank(b));
    });
    final viable = peers.where((i) => legalCell(index, at(i))).toList();

    // Stage 2: direct exchange (two relocated lessons).
    for (final other in viable) {
      if (evaluated >= maxEvaluations) break;
      if (!legalCell(other, at(index))) continue;
      consider({index: at(other), other: at(index)},
        'تبديل متبادل بين موضعين؛ لم تتغير المواد أو المعلمون أو الغرف أو الحصص المثبتة.');
    }

    // Stage 3: displacing cycles, including chains crossing other sections.
    // Limited to mobile-safe search budgets, with full validation at the end.
    for (final a in viable.take(32)) {
      if (evaluated >= (maxEvaluations * 2 ~/ 3)) break;
      for (final b in peers) {
        if (evaluated >= (maxEvaluations * 2 ~/ 3)) break;
        if (b == a || !legalCell(a, at(b)) || !legalCell(b, at(index))) continue;
        consider({index: at(a), a: at(b), b: at(index)},
          'سلسلة ثلاثية: الأولى إلى مكان الثانية، والثانية إلى الثالثة، والثالثة إلى الأولى.');
      }
    }
    // Stage 4: widen only when small fixes were not found.
    if ((proposals.isEmpty || proposals.every((o) => o.remainingBlockers > 0)) &&
        evaluated < maxEvaluations) {
      for (final a in viable.take(14)) {
        for (final b in peers.take(35)) {
          if (evaluated >= maxEvaluations) break;
          if (a == b || !legalCell(a, at(b))) continue;
          for (final c in peers.take(35)) {
            if (evaluated >= maxEvaluations) break;
            if (c == a || c == b || !legalCell(b, at(c)) || !legalCell(c, at(index))) continue;
            consider({index: at(a), a: at(b), b: at(c), c: at(index)},
              'سلسلة تبادلات أوسع بعد تعذر النقل والتبديل الأقصر.');
          }
        }
      }
    }
    proposals.sort((a, b) {
      final moved = a.moved.length.compareTo(b.moved.length);
      return moved != 0 ? moved : a.remainingBlockers.compareTo(b.remainingBlockers);
    });
    // Do not offer multiple copies of the same changed cells or identical
    // location mappings. The first options are always the smallest edits.
    return MinimalRepairSearchResult(proposals.take(maxOptions).toList(), [
      ...diagnostics,
      if (proposals.isEmpty)
        'لم يُعثر على إصلاح يزيل مخالفة دون إضافة مخالفة جديدة ضمن $evaluated احتمالاً. راجع إتاحة المعلم وقيود المادة أو جرّب تعديل شروطك يدوياً ثم أعد الفحص.',
    ], evaluated);
  }
}
