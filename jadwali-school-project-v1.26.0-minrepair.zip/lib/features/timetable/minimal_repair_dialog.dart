import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';

import '../../data/database_service.dart';
import '../../services/minimal_change_repair_service.dart';

List<Map<String, Object?>> _repairRows(Object? value) =>
    (value as List).map((e) => Map<String, Object?>.from(e as Map)).toList();

MinimalRepairSearchResult _searchMinimalRepair(Map<String, Object?> args) {
  final data = Map<String, Object?>.from(args['data'] as Map);
  if (args['batch'] == true) {
    return const MinimalChangeRepairService().findAffected(data: data);
  }
  return const MinimalChangeRepairService().find(
    data: data, targetEntryId: args['entryId'] as int,
  );
}

/// Returns true only when the user explicitly approves and the database
/// atomically saves a validated new ACTIVE version. Cancellation changes nothing.
Future<bool> showMinimalRepairDialog({
  required BuildContext context,
  required Map<String, Object?> data,
  required Map<String, Object?> entry,
  bool batch = false,
}) async => await showDialog<bool>(
  context: context,
  builder: (_) => _MinimalRepairDialog(data: data, entry: entry, batch: batch),
) ?? false;

class _MinimalRepairDialog extends StatefulWidget {
  const _MinimalRepairDialog({required this.data, required this.entry, required this.batch});
  final Map<String, Object?> data;
  final Map<String, Object?> entry;
  final bool batch;
  @override
  State<_MinimalRepairDialog> createState() => _MinimalRepairDialogState();
}

class _MinimalRepairDialogState extends State<_MinimalRepairDialog> {
  late final Future<MinimalRepairSearchResult> _search;
  int? _preview;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _search = compute(_searchMinimalRepair, {
      'data': widget.data,
      'entryId': MinimalChangeRepairService.n(widget.entry['id']),
      'batch': widget.batch,
    }, debugLabel: 'jadwali_minimal_repair');
  }

  String _location(Map<String, Object?> row) {
    final days = MinimalChangeRepairService.rows(widget.data, 'days');
    final slots = MinimalChangeRepairService.rows(widget.data, 'slots');
    final day = days.where((d) => d['id'] == row['day_id']).firstOrNull;
    final slot = slots.where((s) => s['id'] == row['slot_id']).firstOrNull;
    return '${day?['name'] ?? row['day_id']} · ${slot?['name'] ?? row['slot_id']}';
  }

  Future<void> _apply(MinimalRepairOption option) async {
    if (_saving) return;
    setState(() { _saving = true; _error = null; });
    try {
      const allowed = [
        'section_id', 'subject_id', 'teacher_id', 'room_id',
        'day_id', 'slot_id', 'is_locked', 'grade_id', 'grade_name',
      ];
      final entries = <Map<String, Object?>>[
        for (final item in option.placements)
          {for (final key in allowed) if (item.containsKey(key)) key: item[key]},
      ];
      await DatabaseService.instance.saveAsNewVersion(
        yearId: widget.data['yearId'] as int,
        name: 'إصلاح بأقل تغيير ${DateTime.now().toString().substring(0, 16)}',
        entries: entries,
        activate: true,
        expectedActiveVersionId: widget.data['versionId'] as int,
        expectedOriginalEntries: _repairRows(widget.data['entries']),
        validateRelativeConflicts: true,
        notes: 'إصلاح بعد معاينة المستخدم: تغيرت ${option.moved.length} حصص وبقيت ${option.unchanged} دون تغيير. النسخة السابقة محفوظة.',
      );
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Widget _option(MinimalRepairOption option, int i) {
    final original = _repairRows(widget.data['entries']);
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${i + 1}. ${option.title}', style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text('سيتغير مكان ${option.moved.length} حصص، وتبقى ${option.unchanged} كما هي.'),
            Text('سيبقى ${option.remainingBlockers} تعارض مانع آخر بعد هذا الإصلاح.',
              style: const TextStyle(fontSize: 12)),
            Text(option.reason, style: const TextStyle(fontSize: 12)),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: _saving ? null : () => setState(() => _preview = i),
                icon: const Icon(Icons.visibility_outlined),
                label: const Text('معاينة التغييرات'),
              ),
            ),
            if (_preview == i) ...[
              const Divider(),
              const Text('المواضع القديمة والجديدة', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              for (final idx in option.moved) Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${original[idx]['subject_name'] ?? 'مادة ${original[idx]['subject_id']}'} · '
                         '${original[idx]['teacher_name'] ?? 'المعلم ${original[idx]['teacher_id']}'} · '
                         '${original[idx]['section_name'] ?? 'الشعبة ${original[idx]['section_id']}'}',
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                    Wrap(spacing: 7, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Chip(label: Text('قبل: ${_location(original[idx])}'),
                          backgroundColor: Colors.orange.withValues(alpha: .13)),
                        const Icon(Icons.arrow_back, size: 16),
                        Chip(label: Text('بعد: ${_location(option.placements[idx])}'),
                          backgroundColor: Colors.teal.withValues(alpha: .13)),
                      ]),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              Text('ستُحفظ نسخة جديدة، ولن تُحذف النسخة القديمة أو تُعدّل شروطك. '
                'ستُفحص جميع القيود مرة ثانية داخل قاعدة البيانات قبل الاعتماد.',
                style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 8),
              SizedBox(width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _saving ? null : () => _apply(option),
                  icon: _saving
                      ? const SizedBox(height: 17, width: 17, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.check_circle_outline),
                  label: Text(_saving ? 'يجري التحقق والحفظ…' : 'اعتماد هذا الحل بعد المعاينة'),
                )),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.batch ? 'إصلاح بعد تعديل المعلمين · معاينة' : 'أصلح هذه الحصة · أقل تغيير ممكن'),
    content: SizedBox(width: 540, child: ConstrainedBox(
      constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * .7),
      child: SingleChildScrollView(child: FutureBuilder<MinimalRepairSearchResult>(
        future: _search,
        builder: (context, snapshot) {
          if (snapshot.hasError) return SelectableText('تعذر البحث: ${snapshot.error}');
          if (!snapshot.hasData) return const Column(mainAxisSize: MainAxisSize.min, children: [
            CircularProgressIndicator(), SizedBox(height: 14),
            Text('يجري فحص نقل الحصة والتبديلات مع الحفاظ على بقية الجدول…'),
          ]);
          final result = snapshot.data!;
          return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min,
            children: [
              if (!widget.batch) Text('${widget.entry['subject_name'] ?? ''} · ${widget.entry['teacher_name'] ?? ''}'),
              Text('فُحص ${result.explored} احتمالاً. البدائل مرتبة من الأقل تغييراً، '
                'وتُرفض الحلول التي تضيف أخطاء مانعة.',
                style: const TextStyle(fontSize: 12)),
              for (final message in result.diagnostics) Card(
                child: Padding(padding: const EdgeInsets.all(10),
                  child: Text(message, style: const TextStyle(fontSize: 12))),
              ),
              if (result.options.isEmpty)
                const Padding(padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text('لا يوجد إصلاح آمن ضمن حدود البحث الحالية. لم يتغير الجدول أو أي شرط.')),
              for (var i = 0; i < result.options.length; i++) _option(result.options[i], i),
              if (_error != null) Padding(padding: const EdgeInsets.only(top: 8),
                child: SelectableText('تعذر اعتماد الحل: $_error',
                  style: const TextStyle(color: Colors.red))),
            ],
          );
        },
      )),
    )),
    actions: [
      TextButton(onPressed: _saving ? null : () => Navigator.pop(context, false),
        child: const Text('إلغاء دون تغيير')),
    ],
  );
}
