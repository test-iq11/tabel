import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf_text_shaper/pdf_text_shaper.dart';
import 'package:printing/printing.dart';

/// يصدّر شبكة الجدول الأسبوعي لجميع الشعب إلى PDF أفقي قابل للطباعة.
class PdfReportService {
  Future<ShapedFont> _arabicFont() async {
    final data = await rootBundle.load('assets/fonts/Arabic-Regular.ttf');
    return ShapedFont.fromBytes(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      name: 'Noto Naskh Arabic',
    );
  }

  pw.Widget _text(
    String value, {
    required ShapedFont font,
    double size = 10,
    PdfColor color = PdfColors.black,
    ShapedTextAlign align = ShapedTextAlign.center,
  }) {
    // The bundled Arabic font intentionally contains Arabic glyphs only. Replace
    // unsupported Latin punctuation with Arabic equivalents before shaping.
    final safeValue = value
        .replaceAll('-', ' إلى ')
        .replaceAll('—', 'فارغ')
        .replaceAll('|', '،')
        .replaceAll('•', '،')
        .replaceAll('/', 'ـ')
        .replaceAll('(', ' ')
        .replaceAll(')', ' ');
    return ShapedText(
      safeValue,
      style: ShapedTextStyle(
        font: font,
        fontSize: size,
        color: color,
        direction: ShapedTextDirection.rightToLeft,
        align: align,
        preserveUnicodeText: true,
      ),
    );
  }

  Future<Uint8List> buildTimetablePdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<Map<String, Object?>> entries,
    List<Map<String, Object?>> sections = const [],
    List<Map<String, Object?>> days = const [],
    List<Map<String, Object?>> slots = const [],
    PdfPageFormat? pageFormat,
    String title = 'الجدول الأسبوعي الشامل لجميع الصفوف والشعب',
  }) async {
    final font = await _arabicFont();
    try {
      final pdf = pw.Document();
      final format = pageFormat ?? PdfPageFormat.a3.landscape;
      final orderedDays = days.where((d) => _int(d['is_active'], fallback: 1) == 1).toList()
        ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));
      final orderedSlots = slots.where((s) => s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1).toList()
        ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));
      final orderedEntries = [...entries]..sort((a, b) {
        final section = '${a['grade_name'] ?? ''} ${a['section_name'] ?? ''}'.compareTo('${b['grade_name'] ?? ''} ${b['section_name'] ?? ''}');
        if (section != 0) return section;
        final day = _int(a['day_position']).compareTo(_int(b['day_position']));
        if (day != 0) return day;
        return _int(a['slot_position']).compareTo(_int(b['slot_position']));
      });

      final reportSections = <Map<String, Object?>>[];
      if (sections.isNotEmpty) {
        reportSections.addAll(sections);
      } else {
        final seen = <int>{};
        for (final entry in orderedEntries) {
          final id = _int(entry['section_id']);
          if (seen.add(id)) {
            reportSections.add({'id': id, 'grade_name': entry['grade_name'] ?? '', 'section_name': entry['section_name'] ?? 'الشعبة $id'});
          }
        }
      }
      reportSections.sort((a, b) => '${a['grade_name'] ?? ''} ${a['section_name'] ?? ''}'.compareTo('${b['grade_name'] ?? ''} ${b['section_name'] ?? ''}'));
      final entryByCell = <String, Map<String, Object?>>{};
      for (final entry in orderedEntries) {
        entryByCell['${_int(entry['section_id'])}:${_int(entry['day_id'])}:${_int(entry['slot_id'])}'] = entry;
      }

      final columns = 2 + orderedDays.length;
      final availableWidth = format.width - 28;
      final sectionWidth = availableWidth * 0.16;
      final periodWidth = availableWidth * 0.10;
      final dayWidth = (availableWidth - sectionWidth - periodWidth) / (orderedDays.isEmpty ? 1 : orderedDays.length);
      final widths = <int, pw.TableColumnWidth>{
        0: pw.FixedColumnWidth(sectionWidth),
        1: pw.FixedColumnWidth(periodWidth),
        for (var i = 2; i < columns; i++) i: pw.FixedColumnWidth(dayWidth),
      };

      pw.Widget cell(String text, {bool header = false, bool filled = false, bool period = false}) {
        final background = header
            ? const PdfColor.fromInt(0xFF183B66)
            : filled
                ? const PdfColor.fromInt(0xFFE7F1FC)
                : period
                    ? const PdfColor.fromInt(0xFFF0F3F7)
                    : const PdfColor.fromInt(0xFFFAFBFD);
        return pw.Container(
          alignment: pw.Alignment.center,
          padding: const pw.EdgeInsets.symmetric(horizontal: 2, vertical: 2),
          decoration: pw.BoxDecoration(color: background),
          child: _text(text, font: font, size: header ? 8 : 7,
              color: header ? PdfColors.white : const PdfColor.fromInt(0xFF23354B)),
        );
      }

      final rows = <pw.TableRow>[];
      rows.add(pw.TableRow(children: [
        cell('الصف والشعبة', header: true),
        cell('الفترة والوقت', header: true),
        ...orderedDays.reversed.map((day) => cell('${day['name'] ?? ''}', header: true)),
      ]));

      if (reportSections.isEmpty || orderedDays.isEmpty || orderedSlots.isEmpty) {
        rows.add(pw.TableRow(children: List.generate(columns, (i) => cell(
          i == 0 ? (reportSections.isEmpty ? 'لا توجد شعب' : 'الجدول') :
          i == 1 ? 'لا توجد حصص' : 'لا توجد بيانات',
        ))));
      } else {
        for (final section in reportSections) {
          final sectionId = _int(section['id']);
          final gradeName = _displayGradeName('${section['grade_name'] ?? ''}');
          final sectionName = '${section['section_name'] ?? 'الشعبة $sectionId'}';
          final label = [gradeName, sectionName].where((v) => v.trim().isNotEmpty).join('\n');
          for (final slot in orderedSlots) {
            rows.add(pw.TableRow(children: [
              cell(label),
              cell('${slot['name'] ?? ''}\n${slot['start_time'] ?? ''} - ${slot['end_time'] ?? ''}', period: true),
              ...orderedDays.reversed.map((day) {
                final entry = entryByCell['$sectionId:${_int(day['id'])}:${_int(slot['id'])}'];
                if (entry == null) return cell('فارغ');
                final subject = entry['subject_name']?.toString() ?? 'مادة';
                final teacher = entry['teacher_name']?.toString().trim();
                return cell(teacher == null || teacher.isEmpty ? subject : '$subject\n$teacher', filled: true);
              }),
            ]));
          }
        }
      }

      pdf.addPage(pw.Page(
        pageFormat: format,
        margin: const pw.EdgeInsets.all(14),
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            _text(schoolName, font: font, size: 14, color: const PdfColor.fromInt(0xFF183B66)),
            _text(title, font: font, size: 10, color: const PdfColor.fromInt(0xFF23354B)),
            _text('العام الدراسي: $academicYear، النسخة: $versionName، الحالة: $status', font: font, size: 8),
            pw.SizedBox(height: 5),
            pw.Expanded(
              child: pw.FittedBox(
                fit: pw.BoxFit.contain,
                child: pw.Table(
                  columnWidths: widths,
                  border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.35),
                  defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
                  children: rows,
                ),
              ),
            ),
            pw.SizedBox(height: 2),
            _text('تاريخ التقرير: ${DateTime.now().toIso8601String().split('T').first}', font: font, size: 6),
          ],
        ),
      ));
      return await pdf.save();
    } finally {
      font.dispose();
    }
  }

  String _displayGradeName(String value) => value.replaceFirst(RegExp(r'^\s*الصف\s+'), '').trim();

  Future<String?> savePdf(Uint8List bytes, {String fileName = 'الجدول-المدرسي.pdf'}) async {
    return FilePicker.platform.saveFile(
      dialogTitle: 'حفظ تقرير PDF',
      fileName: fileName,
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      bytes: bytes,
    );
  }

  Future<void> preview(Uint8List bytes) async {
    await Printing.layoutPdf(onLayout: (_) async => bytes);
  }

  int _int(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
