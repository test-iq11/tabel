import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/theme.dart';
import '../core/design_widgets.dart';
import '../core/editor_navigation_guard.dart';
import '../data/database_service.dart';
import '../features/conflicts/conflicts_page.dart';
import '../services/conflict_detection_service.dart';
import '../features/dashboard/dashboard_page.dart';
import '../features/data_management/data_management_page.dart';
import '../features/data_management/availability_page.dart';
import '../features/timetable/timetable_page.dart';
import '../features/timetable/teacher_absence_page.dart';
import '../features/reports/reports_page.dart';
import '../features/tools/tools_page.dart';

class TimetableApp extends StatefulWidget {
  const TimetableApp({super.key});
  @override
  State<TimetableApp> createState() => _TimetableAppState();
}

class _TimetableAppState extends State<TimetableApp> {
  String _style = 'calm';
  double _textScale = 1;
  @override
  void initState() {
    super.initState();
    _loadAppearance();
  }

  Future<void> _loadAppearance() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _style = prefs.getString('interface_style') ?? 'calm';
      _textScale = (prefs.getDouble('interface_scale') ?? 1).clamp(.9, 1.3);
    });
  }

  Future<void> _setAppearance(String style, double scale) async {
    setState(() {
      _style = style;
      _textScale = scale;
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('interface_style', style);
    await prefs.setDouble('interface_scale', scale);
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'جدولي المدرسي',
    debugShowCheckedModeBanner: false,
    locale: const Locale('ar'),
    supportedLocales: const [Locale('ar'), Locale('en')],
    localizationsDelegates: const [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    theme: buildAppTheme(style: _style),
    builder: (context, child) => MediaQuery(
      data: MediaQuery.of(context).copyWith(
        textScaler: TextScaler.linear(
          MediaQuery.textScalerOf(context).scale(1) * _textScale,
        ),
      ),
      child: child!,
    ),
    home: AppShell(
      style: _style,
      textScale: _textScale,
      onAppearance: _setAppearance,
    ),
  );
}

class AppShell extends StatefulWidget {
  const AppShell({
    this.style = 'calm',
    this.textScale = 1,
    this.onAppearance,
    super.key,
  });
  final String style;
  final double textScale;
  final void Function(String, double)? onAppearance;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0, _focusToken = 0;
  final _editorGuard = EditorNavigationGuard();
  final _visited = <int>{0};
  final _epochs = List.filled(15, 0);
  Map<String, int?>? _focusTarget;
  static const _destinations = <({String label, IconData icon})>[
    (label: 'الرئيسية', icon: Icons.dashboard_outlined),
    (label: 'الجدول', icon: Icons.calendar_month_outlined),
    (label: 'المعلمون', icon: Icons.people_outline),
    (label: 'الحصص المطلوبة', icon: Icons.fact_check_outlined),
    (label: 'المواد والقيود', icon: Icons.menu_book_outlined),
    (label: 'إتاحة المعلمين', icon: Icons.event_available_outlined),
    (label: 'التعارضات', icon: Icons.rule_outlined),
    (label: 'التوزيع والحلول', icon: Icons.auto_awesome_outlined),
    (label: 'الغياب والبدلاء', icon: Icons.person_off_outlined),
    (label: 'النسخ والاعتماد', icon: Icons.history_outlined),
    (label: 'التقارير', icon: Icons.print_outlined),
    (label: 'النسخ الاحتياطية', icon: Icons.backup_outlined),
    (label: 'إعدادات المدرسة', icon: Icons.settings_outlined),
    (label: 'المدرسة', icon: Icons.school_outlined),
    (label: 'المزيد', icon: Icons.grid_view_outlined),
  ];
  Future<void> _goTo(int index) async {
    if (index == _index) return;
    if (_index == 3 &&
        !await (_editorGuard.beforeLeave?.call() ?? Future.value(true)))
      return;
    if (!mounted) return;
    setState(() {
      _epochs[index]++;
      _visited.add(index);
      _index = index;
    });
  }

  void _refreshApp() => setState(() {
    for (var i = 0; i < _epochs.length; i++) {
      if (i != _index) _epochs[i]++;
    }
  });
  void _openIssue(ConflictIssue issue) {
    _focusTarget = {
      'sectionId': issue.sectionId,
      'dayId': issue.dayId,
      'slotId': issue.slotId,
      'subjectId': issue.subjectId,
      'token': ++_focusToken,
    };
    _goTo(1);
  }

  void _openTable({int? sectionId, int? teacherId}) {
    _focusTarget = {
      'sectionId': sectionId,
      'teacherId': teacherId,
      'token': ++_focusToken,
    };
    _goTo(1);
  }

  Widget _page(int index) {
    if (!_visited.contains(index)) return const SizedBox.shrink();
    final key = ValueKey('screen-$index-${_epochs[index]}');
    return switch (index) {
      0 => DashboardPage(
        key: key,
        onNavigate: _goTo,
        onOpenSection: (id) => _openTable(sectionId: id),
      ),
      1 => TimetablePage(
        key: key,
        onChanged: _refreshApp,
        focusTarget: _focusTarget,
      ),
      2 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.teachers,
        onOpenTeacher: (id) => _openTable(teacherId: id),
      ),
      3 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.requirements,
        navigationGuard: _editorGuard,
      ),
      4 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.subjects,
      ),
      5 => AvailabilityPage(
        key: key,
        onChanged: _refreshApp,
        onEditTeachers: () => _goTo(2),
      ),
      6 => ConflictsPage(key: key, onNavigateToIssue: _openIssue),
      7 => TimetablePage(key: key, onChanged: _refreshApp, searchPage: true),
      8 => TeacherAbsencePage(key: key, onChanged: _refreshApp),
      9 => ToolsPage(
        key: key,
        onChanged: _refreshApp,
        section: ToolsSection.versions,
      ),
      10 => ReportsPage(key: key),
      11 => ToolsPage(
        key: key,
        onChanged: _refreshApp,
        section: ToolsSection.backups,
      ),
      13 => _hub(true),
      14 => _hub(false),
      _ => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.settings,
      ),
    };
  }

  Widget _hub(bool school) {
    final indices = school ? [2, 3, 4, 12] : [7, 6, 8, 10, 9, 11, 5];
    final descriptions = <int, String>{
      2: 'النصاب، الاختصاص والإتاحة',
      3: 'أعداد المواد لكل صف',
      4: 'شروط المواد والفترات',
      12: 'الصفوف وأوقات الدوام',
      7: 'مراجعة ثم بحث ثم نتيجة',
      6: 'مراجعة الشروط الحالية',
      8: 'تنظيم حصص المعلم الغائب',
      10: 'معاينة وطباعة وتصدير',
      9: 'الأرشيف ومقارنة الجداول',
      11: 'حفظ البيانات واستعادتها',
      5: 'أوقات التدريس المتاحة',
    };
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(
          school ? 'تفاصيل صغيرة، مدرسة منظمة' : 'كل أدوات المدرسة',
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 6),
        Text(
          school
              ? 'كل بيانات المدرسة في أربع بطاقات واضحة.'
              : 'عمليات تحتاجها عند المراجعة أو التغيير.',
          style: const TextStyle(color: designMuted, fontSize: 12),
        ),
        const SizedBox(height: 22),
        ActionGrid(
          children: [
            for (var n = 0; n < indices.length; n++)
              ActionTile(
                title: _destinations[indices[n]].label,
                subtitle: descriptions[indices[n]]!,
                icon: _destinations[indices[n]].icon,
                tone: school ? [0, 2, 1, 3][n] : n % 4,
                onTap: () => _goTo(indices[n]),
              ),
          ],
        ),
        const SizedBox(height: 18),
        if (school)
          const Text(
            'ابدأ بالمعلمين والحصص، ثم أضف الشروط التي تحتاجها.',
            style: TextStyle(color: designMuted, fontSize: 12),
          ),
        if (!school)
          TextButton.icon(
            onPressed: _more,
            icon: const Icon(Icons.tune),
            label: const Text('المظهر وحجم النص'),
          ),
      ],
    );
  }

  int get _tab => _index == 0
      ? 0
      : _index == 1
      ? 1
      : [2, 3, 4, 5, 12, 13].contains(_index)
      ? 2
      : 3;
  Future<void> _more() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: .85,
          builder: (_, controller) => ListView(
            controller: controller,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            children: [
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  'كل أقسام جدولي',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                ),
              ),
              for (var i = 0; i < _destinations.length; i++)
                ListTile(
                  selected: _index == i,
                  leading: Icon(_destinations[i].icon),
                  title: Text(_destinations[i].label),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () {
                    Navigator.pop(sheetContext);
                    _goTo(i);
                  },
                ),
              const Divider(height: 24),
              const Text(
                'مظهر الواجهة',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Wrap(
                spacing: 8,
                children: [
                  for (final style in {
                    'calm': 'هادئ',
                    'blue': 'أزرق',
                    'paper': 'ورقي',
                  }.entries)
                    ChoiceChip(
                      label: Text(style.value),
                      selected: widget.style == style.key,
                      onSelected: (_) {
                        Navigator.pop(sheetContext);
                        widget.onAppearance?.call(style.key, widget.textScale);
                      },
                    ),
                ],
              ),
              const SizedBox(height: 12),
              const Text('حجم النص'),
              Wrap(
                spacing: 8,
                children: [
                  for (final scale in [1.0, 1.15, 1.3])
                    ChoiceChip(
                      label: Text('${(scale * 100).round()}٪'),
                      selected: widget.textScale == scale,
                      onSelected: (_) {
                        Navigator.pop(sheetContext);
                        widget.onAppearance?.call(widget.style, scale);
                      },
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: _index == 0,
    onPopInvokedWithResult: (didPop, result) {
      if (!didPop)
        _goTo(
          [1, 13, 14].contains(_index)
              ? 0
              : _tab == 2
              ? 13
              : 14,
        );
    },
    child: Directionality(
      textDirection: TextDirection.rtl,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final wide = constraints.maxWidth > 700;
          final content = IndexedStack(
            index: _index,
            children: List.generate(
              15,
              (i) => TickerMode(enabled: _index == i, child: _page(i)),
            ),
          );
          return Scaffold(
            body: SafeArea(
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 14,
                    ),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surface,
                      border: Border(
                        bottom: BorderSide(
                          color: Theme.of(context).dividerColor,
                        ),
                      ),
                    ),
                    child: Row(
                      children: [
                        if (![0, 1, 13, 14].contains(_index))
                          IconButton(
                            tooltip: 'العودة',
                            onPressed: () => _goTo(_tab == 2 ? 13 : 14),
                            icon: const Icon(Icons.chevron_right),
                          ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: FutureBuilder<Map<String, Object?>>(
                            future: DatabaseService.instance.getSettings(),
                            builder: (context, snap) => Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${snap.data?['school_name'] ?? 'جدولي'}',
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Color(0xFF768390),
                                  ),
                                ),
                                Text(
                                  _index == 0
                                      ? 'جدولي'
                                      : _destinations[_index].label,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        IconButton(
                          tooltip: 'كل الشاشات',
                          onPressed: _more,
                          icon: const Icon(Icons.apps_rounded),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: wide
                        ? Row(
                            children: [
                              SizedBox(
                                width: 236,
                                child: ListView(
                                  padding: const EdgeInsets.all(10),
                                  children: [
                                    for (
                                      var i = 0;
                                      i < _destinations.length;
                                      i++
                                    )
                                      Padding(
                                        padding: const EdgeInsets.only(
                                          bottom: 4,
                                        ),
                                        child: ListTile(
                                          selected: i == _index,
                                          selectedTileColor: Theme.of(context)
                                              .colorScheme
                                              .primaryContainer,
                                          leading: Icon(_destinations[i].icon),
                                          title: Text(_destinations[i].label),
                                          onTap: () => _goTo(i),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              const VerticalDivider(width: 1),
                              Expanded(child: content),
                            ],
                          )
                        : ScreenEntrance(page: _index, child: content),
                  ),
                ],
              ),
            ),
            bottomNavigationBar: wide
                ? null
                : SafeArea(
                    top: false,
                    child: Container(
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        border: Border(
                          top: BorderSide(color: Color(0xFFE6EBEE)),
                        ),
                      ),
                      padding: const EdgeInsets.all(8),
                      child: Row(
                        children: [
                          for (var i = 0; i < 4; i++)
                            Expanded(
                              child: Semantics(
                                selected: _tab == i,
                                child: InkWell(
                                  key: ValueKey('main-tab-$i'),
                                  onTap: () => _goTo([0, 1, 13, 14][i]),
                                  borderRadius: BorderRadius.circular(15),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 8,
                                    ),
                                    decoration: BoxDecoration(
                                      color: _tab == i
                                          ? Theme.of(context)
                                                .colorScheme
                                                .primary
                                                .withValues(alpha: .09)
                                          : Colors.transparent,
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(
                                          [
                                            Icons.home_outlined,
                                            Icons.calendar_month_outlined,
                                            Icons.school_outlined,
                                            Icons.grid_view_outlined,
                                          ][i],
                                          size: 19,
                                          color: _tab == i
                                              ? Theme.of(context)
                                                    .colorScheme
                                                    .primary
                                              : const Color(0xFF768390),
                                        ),
                                        const SizedBox(height: 5),
                                        Text(
                                          [
                                            'الرئيسية',
                                            'الجدول',
                                            'المدرسة',
                                            'المزيد',
                                          ][i],
                                          style: const TextStyle(fontSize: 10),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
          );
        },
      ),
    ),
  );
}
