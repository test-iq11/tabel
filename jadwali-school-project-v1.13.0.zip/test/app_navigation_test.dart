import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iraqi_school_timetable/app/app.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';

class _TestPaths extends PathProviderPlatform {
  _TestPaths(this.directory);
  final String directory;
  @override
  Future<String> getApplicationSupportPath() async => directory;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory directory;
  late PathProviderPlatform previousPaths;
  setUpAll(() async {
    directory = await Directory.systemTemp.createTemp('jadwali-ui-');
    previousPaths = PathProviderPlatform.instance;
    PathProviderPlatform.instance = _TestPaths(directory.path);
    SharedPreferences.setMockInitialValues({});
    final input = jsonDecode(
      File('test/fixtures/backup_school_181.json').readAsStringSync(),
    ) as Map;
    List<Map<String, Object?>> rows(String key) => (input[key] as List)
        .map((r) => Map<String, Object?>.from(r as Map))
        .toList();
    final storage = DatabaseService.instance;
    final db = await storage.database;
    await db.transaction((txn) async {
      await txn.delete('time_slots');
      for (final slot in rows('slots')) {
        await txn.insert('time_slots', slot);
      }
      final known = (await txn.query('subjects')).map((s) => s['id']).toSet();
      for (final req in rows('requirements')) {
        if (known.add(req['subject_id']))
          await txn.insert('subjects', {
            'id': req['subject_id'],
            'name': 'مادة ${req['subject_id']}',
          });
      }
      for (final section in rows('sections')) {
        await txn.insert('sections', {
          'id': section['id'],
          'grade_id': section['grade_id'],
          'name': section['section_name'],
          'max_daily_lessons': 6,
        });
      }
      for (final t in rows('teachers')) {
        await txn.insert('teachers', t);
      }
      for (final q in rows('qualifications')) {
        await txn.insert('teacher_subjects', q);
      }
      for (final q in rows('teacherSubjectGrades')) {
        await txn.insert('teacher_subject_grades', q);
      }
      for (final r in rows('requirements')) {
        await txn.insert('section_subject_requirements', {
          for (final k in [
            'section_id',
            'subject_id',
            'weekly_lessons',
            'max_daily_lessons',
            'allow_same_day',
          ])
            k: r[k],
        });
      }
    });
    await storage.saveAsNewVersion(
      yearId: (await storage.activeYearId())!,
      name: 'الجدول النشط',
      entries: rows('initialPlacements'),
      requireComplete: true,
    );
  });
  tearDownAll(() async {
    await DatabaseService.instance.close();
    PathProviderPlatform.instance = previousPaths;
    await directory.delete(recursive: true);
  });
  Future<void> settle(WidgetTester tester) async {
    // Text fields may keep scheduling cursor frames; wait on data readiness,
    // not the absence of every animation in the application.
    for (var i = 0; i < 80; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)),
      );
      await tester.pump(const Duration(milliseconds: 100));
      if (i >= 4 &&
          find
              .byWidgetPredicate(
                (w) => w is CircularProgressIndicator && w.value == null,
              )
              .evaluate()
              .isEmpty)
        break;
    }
    expect(
      find.byWidgetPredicate(
        (w) => w is CircularProgressIndicator && w.value == null,
      ),
      findsNothing,
    );
  }

  for (final size in [
    const Size(390, 844),
    const Size(320, 740),
    const Size(1280, 900),
  ]) {
    testWidgets(
      'all thirteen real screens open at $size and Excel import is absent',
      (tester) async {
        tester.view.physicalSize = size;
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        final font = FontLoader('JadwaliUI')
          ..addFont(rootBundle.load('assets/fonts/UI-Regular.ttf'));
        await font.load();
        final latin = FontLoader('JadwaliLatin')
          ..addFont(rootBundle.load('assets/fonts/UI-Latin.ttf'));
        await latin.load();
        final icons = FontLoader('MaterialIcons')
          ..addFont(rootBundle.load('fonts/MaterialIcons-Regular.otf'));
        await icons.load();
        final capture = GlobalKey();
        await tester.pumpWidget(
          RepaintBoundary(key: capture, child: const TimetableApp()),
        );
        Future<void> screenshot(String name) async {
          final directory = Platform.environment['JADWALI_SCREENSHOTS'] == null
              ? null
              : '${Platform.environment['JADWALI_SCREENSHOTS']}/${size.width.toInt()}';
          if (directory == null) return;
          await tester.pump();
          final boundary =
              capture.currentContext!.findRenderObject()!
                  as RenderRepaintBoundary;
          final image = (await tester.runAsync(
            () => boundary.toImage(pixelRatio: 1),
          ))!;
          final bytes = await tester.runAsync(
            () => image.toByteData(format: ui.ImageByteFormat.png),
          );
          await tester.runAsync(() async {
            await Directory(directory).create(recursive: true);
            await File('$directory/$name.png')
                .writeAsBytes(bytes!.buffer.asUint8List());
          });
          image.dispose();
        }

        await settle(tester);
        expect(tester.takeException(), isNull, reason: 'dashboard');
        await screenshot('00-home');
        if (size.width < 700) {
          await tester.tap(find.byKey(const ValueKey('main-tab-2')));
          await settle(tester);
          expect(find.text('تفاصيل صغيرة، مدرسة منظمة'), findsOneWidget);
          expect(tester.takeException(), isNull);
          await screenshot('00-school');
          await tester.tap(find.byKey(const ValueKey('main-tab-3')));
          await settle(tester);
          expect(find.text('كل أدوات المدرسة'), findsOneWidget);
          expect(tester.takeException(), isNull);
          await screenshot('00-more');
        }

        var screenIndex = 0;
        for (final label in [
          'الجدول',
          'المعلمون',
          'الحصص المطلوبة',
          'المواد والقيود',
          'إتاحة المعلمين',
          'التعارضات',
          'التوزيع والحلول',
          'الغياب والبدلاء',
          'النسخ والاعتماد',
          'التقارير',
          'النسخ الاحتياطية',
          'إعدادات المدرسة',
        ]) {
          // ignore: avoid_print
          print('Opening $label');
          await tester.tap(find.byTooltip('كل الشاشات'));
          await settle(tester);
          final item = find.descendant(
            of: find.byType(DraggableScrollableSheet),
            matching: find.widgetWithText(ListTile, label),
          );
          final scrollable = find
              .descendant(
                of: find.byType(DraggableScrollableSheet),
                matching: find.byType(Scrollable),
              )
              .first;
          await tester.scrollUntilVisible(item, 250, scrollable: scrollable);
          await Scrollable.ensureVisible(tester.element(item), alignment: .5);
          await settle(tester);
          await tester.tap(item);
          await settle(tester);
          expect(tester.takeException(), isNull, reason: label);
          expect(
            find.textContaining('تعذر تحميل'),
            findsNothing,
            reason: label,
          );
          expect(find.textContaining('استيراد Excel'), findsNothing);
          await screenshot('${++screenIndex}');
          if (label == 'التقارير') {
            expect(find.text('معاينة وطباعة'), findsNothing);
            await tester.tap(find.text('التالي: المحتوى والورق'));
            await settle(tester);
            final next = find.text('معاينة التقرير');
            await tester.scrollUntilVisible(
              next,
              180,
              scrollable: find
                  .descendant(
                    of: find.byType(ListView).last,
                    matching: find.byType(Scrollable),
                  )
                  .first,
            );
            await Scrollable.ensureVisible(tester.element(next));
            await tester.tap(next);
            await settle(tester);
            expect(find.text('معاينة وطباعة'), findsOneWidget);
            expect(tester.takeException(), isNull);
            await screenshot('reports-preview');
          }
        }
      },
    );
  }
}
