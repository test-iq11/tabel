import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:iraqi_school_timetable/features/setup/grade_daily_lessons_page.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  // Sqflite FFI, directory creation, and real file I/O must not be awaited
  // directly inside testWidgets' fake-async zone: that can hang until the
  // ten-minute test timeout even when the app itself has no issue.
  late Directory folder;
  late DatabaseService db;
  late List<Map<String, Object?>> grades;
  setUpAll(() async {
    sqfliteFfiInit();
    folder = await Directory.systemTemp.createTemp('jadwali-grade-card-');
    db = DatabaseService.withStorage(
      factory: databaseFactoryFfi,
      directory: folder.path,
    );
    grades = await db.gradesDetailed();
  });
  tearDownAll(() async {
    await db.close();
    await folder.delete(recursive: true);
  });

  testWidgets('tapping a grade card opens an editable limit and persists it',
      (tester) async {
    final firstId = grades.first['id'] as int;
    var changes = 0;
    await tester.pumpWidget(MaterialApp(home: Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(body: GradeDailyLessonsPage(
        database: db,
        onChanged: () => changes++,
        onSchoolTimes: () {},
      )),
    )));
    final card = find.byKey(ValueKey('tap-grade-daily-$firstId'));
    for (var i = 0; i < 40 && card.evaluate().isEmpty; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)));
      await tester.pump(const Duration(milliseconds: 100));
    }
    expect(card, findsOneWidget);
    await tester.tap(card);
    await tester.pumpAndSettle();
    expect(find.text('حصص ${grades.first['name']}'), findsOneWidget);
    await tester.tap(find.byTooltip('تقليل حصة'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('حفظ'));
    for (var i = 0; i < 40 && changes == 0; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)));
      await tester.pump(const Duration(milliseconds: 100));
    }
    expect(changes, 1);
    // FFI reads must run in real async time, not the widget test fake clock.
    final persisted = (await tester.runAsync(() => db.gradesDetailed()))!;
    expect(persisted.first['max_daily_lessons'], 5);
  });
}
