import 'package:flutter/material.dart';

import '../../core/interface_settings.dart';
import '../../core/jadwali_visuals.dart';
import 'design_studio.dart';

class AppSettingsPage extends StatelessWidget {
  const AppSettingsPage({super.key, required this.onHelp});
  final VoidCallback onHelp;

  Widget _panel(BuildContext context, {required String title,
    required String subtitle, required List<Widget> children}) {
    final c = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: JadwaliVisuals.panel(context),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text(subtitle, style: TextStyle(fontSize: 12, color: c.onSurfaceVariant)),
        const SizedBox(height: 16),
        ...children,
      ]),
    );
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: InterfaceSettings.instance,
    builder: (context, _) {
      final ui = InterfaceSettings.instance;
      final c = Theme.of(context).colorScheme;
      return ListView(padding: const EdgeInsets.fromLTRB(18, 23, 18, 30), children: [
        Text('تخصيص كامل', style: TextStyle(fontWeight: FontWeight.w800,
          color: c.primary, fontSize: 11)),
        const Text('اجعل جدولي على ذوقك',
          style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
        const SizedBox(height: 3),
        Text('الألوان، المسافات، الخط، الحركات والوضع الليلي؛ مع حفظ اختياراتك تلقائيًا.',
          style: TextStyle(fontSize: 12, color: c.onSurfaceVariant)),
        const SizedBox(height: 13),
        Wrap(spacing: 8, runSpacing: 8, children: [
          OutlinedButton.icon(
            key: const ValueKey('settings-reset-preview'),
            onPressed: () {
              ui.applyPalette('indigo');
              ui.dark = false;
              ui.compact = false;
              ui.fontScale = 1.0;
              ui.design = ui.design.change('density', 100.0).change('motion', true);
              ui.save();
            },
            icon: const Icon(Icons.restart_alt_outlined, size: 18),
            label: const Text('الإعدادات الافتراضية'),
          ),
          TextButton.icon(
            onPressed: () => showDialog<void>(
              context: context,
              builder: (ctx) => AlertDialog(
                icon: const Icon(Icons.auto_awesome_outlined, size: 33),
                title: const Text('انتقال ناعم'),
                content: const Text('هذه معاينة للحركات المستخدمة في فتح نوافذ التطبيق.'),
                actions: [TextButton(onPressed: () => Navigator.pop(ctx),
                  child: const Text('إغلاق'))],
              ),
            ),
            icon: const Icon(Icons.play_circle_outline, size: 18),
            label: const Text('جرب حركة المعاينة'),
          ),
        ]),
        const SizedBox(height: 20),
        LayoutBuilder(builder: (context, bounds) {
          final sections = <Widget>[
            _panel(context, title: 'لوحات الألوان',
              subtitle: 'خمسة ألوان مستوحاة من نموذج HTML؛ ألوان المواد والتقارير تبقى مستقلة.',
              children: [
                const JadwaliPaletteSelector(),
                const SizedBox(height: 10),
                Text('اللون المختار: ${JadwaliVisuals.palettes[ui.palette]?.$1 ?? 'نيلي'}',
                  style: TextStyle(color: c.onSurfaceVariant, fontSize: 11)),
              ]),
            _panel(context, title: 'المظهر والإضاءة',
              subtitle: 'وضع ليلي ناعم وواجهة واضحة عند القراءة.',
              children: [
                SwitchListTile.adaptive(
                  key: const ValueKey('settings-dark'),
                  secondary: const Icon(Icons.dark_mode_outlined),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('الوضع الليلي'),
                  subtitle: const Text('يستمر بعد إغلاق التطبيق'),
                  value: ui.dark,
                  onChanged: (v) { ui.dark = v; ui.save(); },
                ),
                const Divider(),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  secondary: const Icon(Icons.motion_photos_off_outlined),
                  title: const Text('حركات الانتقال والبطاقات'),
                  subtitle: const Text('حركات قصيرة ويمكن إيقافها لتقليل التشتيت'),
                  value: ui.design.motion,
                  onChanged: ui.setMotion,
                ),
              ]),
            _panel(context, title: 'الخط والمسافات',
              subtitle: 'تحكم بالحجم وكثافة البطاقات على الهاتف أو الكمبيوتر.',
              children: [
                Text('حجم الخط · ${(ui.fontScale * 100).round()}٪',
                  style: Theme.of(context).textTheme.titleMedium),
                const Text('يضاف إلى حجم الخط المحدد في جهازك.'),
                Slider(key: const ValueKey('settings-font-slider'),
                  value: ui.fontScale, min: .85, max: 1.3, divisions: 9,
                  label: '${(ui.fontScale * 100).round()}٪',
                  onChanged: (v) { ui.fontScale = v; ui.save(); }),
                const Text('معاينة: حصص مدرستي واضحة ومنظمة'),
                Align(alignment: AlignmentDirectional.centerEnd,
                  child: TextButton(onPressed: () { ui.fontScale = 1; ui.save(); },
                    child: const Text('الحجم الافتراضي'))),
                const Divider(),
                const SizedBox(height: 8),
                const Text('كثافة بطاقات الجدول', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                SegmentedButton<bool>(
                  key: const ValueKey('settings-density'),
                  segments: const [
                    ButtonSegment(value: false, label: Text('مريح'), icon: Icon(Icons.view_agenda_outlined)),
                    ButtonSegment(value: true, label: Text('مدمج'), icon: Icon(Icons.view_compact_outlined)),
                  ],
                  selected: {ui.compact},
                  onSelectionChanged: (selection) {
                    ui.compact = selection.first;
                    ui.design = ui.design.change('density', ui.compact ? 88.0 : 100.0);
                    ui.save();
                  },
                ),
              ]),
            _panel(context, title: 'أدوات التخصيص المتقدمة',
              subtitle: 'خيارات التصميم السابقة باقية وتعمل مع الخيارات الحديثة.',
              children: [
                ListTile(
                  key: const ValueKey('open-design-settings'),
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.palette_outlined),
                  title: const Text('استوديو المظهر'),
                  subtitle: const Text('الزخارف، التدرجات، واستيراد تصميمك'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => showDesignStudio(context),
                ),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  secondary: const Icon(Icons.desktop_windows_outlined),
                  title: const Text('القائمة الجانبية على الكمبيوتر'),
                  value: ui.desktopRail,
                  onChanged: (v) { ui.desktopRail = v; ui.save(); },
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.dashboard_customize_outlined),
                  title: const Text('تخصيص الرئيسية'),
                  subtitle: const Text('اختيار أربع بطاقات وترتيبها'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => customizeHome(context),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.help_outline),
                  title: const Text('دليل الاستخدام'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: onHelp,
                ),
              ]),
          ];
          if (bounds.maxWidth < 760) return Column(children: [
            for (final section in sections) ...[
              section, const SizedBox(height: 15),
            ],
          ]);
          return Wrap(spacing: 16, runSpacing: 16, children: [
            for (final section in sections)
              SizedBox(width: (bounds.maxWidth - 16) / 2, child: section),
          ]);
        }),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(
          color: c.primary.withValues(alpha: .05),
          borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            Icon(Icons.info_outline, size: 20, color: c.primary),
            const SizedBox(width: 9),
            Expanded(child: Text('التصميم 1.28.0 · التغييرات تخص المظهر فقط ولا تعدّل بيانات المدرسة أو قيود الحصص.',
              style: TextStyle(fontSize: 11, color: c.onSurfaceVariant))),
          ])),
      ]);
    },
  );
}
