import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import '../core/interface_settings.dart';
import '../features/setup/readiness_card.dart';
import '../features/settings/app_settings_page.dart';
import '../features/settings/design_studio.dart';

import '../core/theme.dart';
import '../core/design_widgets.dart';
import '../core/editor_navigation_guard.dart';
import '../features/conflicts/conflicts_page.dart';
import '../services/conflict_detection_service.dart';
import '../features/dashboard/dashboard_page.dart';
import '../features/smart/smart_workspace_page.dart';
import '../features/smart/smart_access_dialog.dart';
import '../features/data_management/data_management_page.dart';
import '../features/data_management/availability_page.dart';
import '../features/timetable/timetable_page.dart';
import '../features/timetable/teacher_absence_page.dart';
import '../features/reports/reports_page.dart';
import '../features/tools/tools_page.dart';

class TimetableApp extends StatefulWidget {
  const TimetableApp({super.key});
  @override
  State<TimetableApp> createState() => _TimetableAppState();
}

class _TimetableAppState extends State<TimetableApp> {
  @override
  void initState() {
    super.initState();
    InterfaceSettings.instance.load();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: InterfaceSettings.instance,
    builder: (context, _) => MaterialApp(
      title: 'الجدول المدرسي',
      debugShowCheckedModeBanner: false,
      themeAnimationDuration: const Duration(milliseconds: 260),
      themeAnimationCurve: Curves.easeOutCubic,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: buildAppTheme(
        dark: InterfaceSettings.instance.dark,
        design: InterfaceSettings.instance.design,
      ),
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(
          disableAnimations:
              MediaQuery.disableAnimationsOf(context) ||
              !InterfaceSettings.instance.design.motion,
          textScaler: TextScaler.linear(
            MediaQuery.textScalerOf(context).scale(1) *
                InterfaceSettings.instance.fontScale,
          ),
        ),
        child: child!,
      ),
      home: AppShell(),
    ),
  );
}

class AppShell extends StatefulWidget {
  const AppShell({
    this.style = 'calm',
    this.textScale = 1,
    this.onAppearance,
    super.key,
  });
  final String style;
  final double textScale;
  final void Function(String, double)? onAppearance;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0, _focusToken = 0;
  final _editorGuard = EditorNavigationGuard();
  final _visited = <int>{0};
  final _epochs = List.filled(17, 0);
  Map<String, int?>? _focusTarget;
  String? _smartRequest;
  static const _destinations = <({String label, IconData icon})>[
    (label: 'الرئيسية', icon: Icons.dashboard_outlined),
    (label: 'الجدول', icon: Icons.calendar_month_outlined),
    (label: 'المعلمون', icon: Icons.people_outline),
    (label: 'الحصص المطلوبة', icon: Icons.fact_check_outlined),
    (label: 'المواد والقيود', icon: Icons.menu_book_outlined),
    (label: 'إتاحة المعلمين', icon: Icons.event_available_outlined),
    (label: 'التعارضات', icon: Icons.rule_outlined),
    (label: 'التوزيع والحلول', icon: Icons.auto_awesome_outlined),
    (label: 'الغياب والبدلاء', icon: Icons.person_off_outlined),
    (label: 'النسخ والاعتماد', icon: Icons.history_outlined),
    (label: 'التقارير', icon: Icons.print_outlined),
    (label: 'النسخ الاحتياطية', icon: Icons.backup_outlined),
    (label: 'إعدادات المدرسة', icon: Icons.settings_outlined),
    (label: 'إعداد الجدول', icon: Icons.school_outlined),
    (label: 'المزيد', icon: Icons.grid_view_outlined),
    (label: 'إعدادات التطبيق', icon: Icons.tune_outlined),
    (label: 'مختبر ماذا لو؟', icon: Icons.auto_awesome_outlined),
  ];
  Future<void> _goTo(int index, {String? request}) async {
    if (index == _index || index == 9) return;
    InterfaceSettings.instance.stopReading();
    if (_index == 3 &&
        !await (_editorGuard.beforeLeave?.call() ?? Future.value(true)))
      return;
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    setState(() {
      if (index == 16) _smartRequest = request;
      _epochs[index]++;
      _visited.add(index);
      _index = index;
    });
  }

  void _refreshApp() => setState(() {
    for (var i = 0; i < _epochs.length; i++) {
      if (i != _index) _epochs[i]++;
    }
  });
  void _openIssue(ConflictIssue issue) {
    _focusTarget = {
      'sectionId': issue.sectionId,
      'dayId': issue.dayId,
      'slotId': issue.slotId,
      'subjectId': issue.subjectId,
      'token': ++_focusToken,
    };
    _goTo(1);
  }

  void _openTable({int? sectionId, int? teacherId}) {
    _focusTarget = {
      'sectionId': sectionId,
      'teacherId': teacherId,
      'token': ++_focusToken,
    };
    _goTo(1);
  }

  Widget _page(int index) {
    if (!_visited.contains(index)) return const SizedBox.shrink();
    final key = ValueKey('screen-$index-${_epochs[index]}');
    return switch (index) {
      0 => DashboardPage(
        key: key,
        onNavigate: _goTo,
        onOpenSection: (id) => _openTable(sectionId: id),
        onOpenTeacher: (id) => _openTable(teacherId: id),
      ),
      1 => TimetablePage(
        key: key,
        onChanged: _refreshApp,
        focusTarget: _focusTarget,
      ),
      2 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.teachers,
        onOpenTeacher: (id) => _openTable(teacherId: id),
      ),
      3 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.requirements,
        navigationGuard: _editorGuard,
      ),
      4 => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.subjects,
        onRepair: () => _goTo(7),
      ),
      5 => AvailabilityPage(
        key: key,
        onChanged: _refreshApp,
        onEditTeachers: () => _goTo(2),
      ),
      6 => ConflictsPage(key: key, onNavigateToIssue: _openIssue),
      7 => TimetablePage(key: key, onChanged: _refreshApp, searchPage: true),
      8 => TeacherAbsencePage(key: key, onChanged: _refreshApp),
      10 => ReportsPage(key: key, onChanged: _refreshApp),
      11 => ToolsPage(
        key: key,
        onChanged: _refreshApp,
        section: ToolsSection.backups,
      ),
      13 => _hub(true),
      14 => _hub(false),
      15 => AppSettingsPage(key: key, onHelp: _help),
      16 => SmartWorkspacePage(
        key: key,
        request: _smartRequest,
        onNavigate: _goTo,
      ),
      _ => DataManagementPage(
        key: key,
        onChanged: _refreshApp,
        area: DataArea.settings,
      ),
    };
  }

  void _help() {
    final text = switch (_index) {
      15 => 'ابدأ من إعداد الجدول: أدخل الصفوف والأوقات والمعلمين والمواد، ثم حدد حصص كل صف وإتاحة المعلمين. افتح التوزيع لمراجعة الشروط والبحث عن حل. في الجدول اضغط الحصة لعرض تفاصيلها أو اضغط مطولاً لقفلها. التوزيع والتقارير في إعداد الجدول، والنسخ الاحتياطية في المزيد. تكرار المادة يفضّل حصة مبكرة وأخرى في السادسة أو السابعة المتاحة، دون فرض ذلك على الحل.',
      1 => 'اختر الصف واليوم من الشريط الثابت. اضغط الحصة لعرض أدواتها، واضغط مطولاً لقفلها أو فك قفلها. النقل من مقبض السحب. القفل يحمي حصة محددة؛ منع الفترة يخص المادة في كل الصفوف.',
      3 => 'اختر الصف وعدّل الأعداد. يظهر شريط الحفظ والتراجع عند أول تعديل. لن تفقد المسودة عند محاولة المغادرة دون حفظ.',
      4 => 'حدد الفترات الممنوعة على بطاقة المادة. يبقى موضع الصفحة ثابتاً بعد الحفظ. اضغط تعديل المادة لبقية التفاصيل.',
      0 => 'اسم المدرسة في بطاقتها الرئيسية. خصّص أربع بطاقات من زر تخصيص الرئيسية. يمكنك تغيير اسم المدرسة من إعدادات المدرسة.',
      _ => 'إعداد الجدول يجمع بيانات المدرسة والإتاحة والتوزيع والتقارير. في المزيد تجد التعارضات والغياب والنسخ الاحتياطية والإعدادات.',
    };
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      constraints: BoxConstraints(
        maxHeight: MediaQuery.sizeOf(context).height * .85,
      ),
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'دليل الاستخدام',
                  style: Theme.of(ctx).textTheme.titleLarge,
                ),
                const SizedBox(height: 14),
                Text(text),
                const SizedBox(height: 18),
                FilledButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                    _goTo(
                      _index == 15
                          ? 13
                          : _index == 0
                          ? 12
                          : _index == 4
                          ? 4
                          : _index == 3
                          ? 3
                          : 1,
                    );
                  },
                  child: Text(
                    _index == 15
                        ? 'فتح إعداد الجدول'
                        : _index == 0
                        ? 'فتح إعدادات المدرسة'
                        : 'الذهاب إلى الإجراء',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _hub(bool school) {
    final descriptions = <int, String>{
      0: 'ملخص المدرسة والوصول السريع',
      1: 'حصص الصفوف والمعلمين',
      13: 'جميع البيانات اللازمة لملء الجدول',
      15: 'المظهر، حجم الخط والمساعدة والإصدار',
      16: 'جرّب تغيير الشروط على نسخة من بياناتك',
      2: 'النصاب، الاختصاص والإتاحة',
      3: 'أعداد المواد لكل صف',
      4: 'شروط المواد والفترات',
      12: 'الصفوف وأوقات الدوام',
      7: 'مراجعة ثم بحث ثم نتيجة',
      6: 'مراجعة الشروط الحالية',
      8: 'تنظيم حصص المعلم الغائب',
      10: 'معاينة وطباعة وتصدير',
      9: 'الأرشيف ومقارنة الجداول',
      11: 'حفظ البيانات واستعادتها',
      5: 'أوقات التدريس المتاحة',
    };
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(
          school ? 'بيانات إعداد الجدول' : 'كل أدوات المدرسة',
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 6),
        Text(
          school
              ? 'بيانات المدرسة والإتاحة والتوزيع والتقارير، من البداية حتى طباعة جدولك.'
              : 'جميع الأقسام والأدوات في مكان واحد.',
          style: const TextStyle(color: designMuted, fontSize: 12),
        ),
        const SizedBox(height: 22),
        if (!school)
          Padding(
            padding: const EdgeInsets.only(bottom: 18),
            child: OutlinedButton.icon(
              onPressed: () => showSmartAccess(
                context,
                onNavigate: _goTo,
                onTeacher: (id) => _openTable(teacherId: id),
                onSection: (id) => _openTable(sectionId: id),
              ),
              icon: const Icon(Icons.search),
              label: const Text('الوصول الذكي'),
            ),
          ),
        if (!school)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: ActionTile(
              key: const ValueKey('more-design-studio'),
              title: 'استوديو المظهر',
              subtitle: 'بطاقتك وألوانك وخيارات التصميم',
              icon: Icons.tune,
              onTap: () => showDesignStudio(context),
            ),
          ),
        if (school)
          ReadinessCard(
            key: ValueKey('readiness-${_epochs[13]}'),
            onNavigate: _goTo,
          ),
        for (final group
            in (school
                ? [
                    ('بيانات المدرسة', [12, 2, 4, 3, 5]),
                    ('التوزيع والتقارير', [7, 10]),
                  ]
                : [
                    ('التنقل الرئيسي', [0, 1]),
                    ('التفضيلات والمساعدة', [15]),
                    ('أدوات الجدول', [16, 6, 8]),
                    ('حفظ البيانات', [11]),
                  ])) ...[
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(
              group.$1,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
            ),
          ),
          ActionGrid(
            children: [
              for (var n = 0; n < group.$2.length; n++)
                ActionTile(
                  key: ValueKey('more-destination-${group.$2[n]}'),
                  title: _destinations[group.$2[n]].label,
                  subtitle: descriptions[group.$2[n]]!,
                  icon: _destinations[group.$2[n]].icon,
                  tone: n % 4,
                  onTap: () => _goTo(group.$2[n]),
                ),
            ],
          ),
        ],
        const SizedBox(height: 18),
        if (school)
          Padding(
            padding: const EdgeInsets.only(bottom: 18),
            child: FilledButton.icon(
              onPressed: () => _goTo(7),
              icon: const Icon(Icons.auto_awesome_outlined),
              label: const Text('مراجعة البيانات وبدء التوزيع'),
            ),
          ),
        if (school)
          const Text(
            'التكرار في اليوم: يفضّل حصة ضمن الثلاث الأولى وأخرى في السادسة أو السابعة المتاحة، مع المرونة عند الحاجة.',
            style: TextStyle(color: designMuted, fontSize: 12),
          ),
      ],
    );
  }

  int get _tab => _index == 0
      ? 0
      : _index == 1
      ? 1
      : [2, 3, 4, 5, 7, 10, 12, 13].contains(_index)
      ? 2
      : 3;
  /// Current screens and callbacks stay intact. Only the HTML-inspired shell changes.
  static const _desktopLinks = <int>[0, 1, 6, 2, 10, 15];
  static const _mobileLinks = <int>[0, 1, 13, 14, 6];
  int get _activeBottom => _index == 6 ? 4 : _tab;

  Widget _sideLink(int index, bool compact) {
    final c = Theme.of(context).colorScheme;
    final active = index == _index ||
        (index == 13 && _tab == 2 && ![2, 10].contains(_index)) ||
        (index == 14 && _tab == 3 && _index != 6 && _index != 15);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 10),
      child: Material(color: Colors.transparent,
        child: InkWell(
          key: ValueKey('rail-destination-$index'),
          borderRadius: BorderRadius.circular(13),
          onTap: () => _goTo(index),
          child: AnimatedContainer(
            duration: InterfaceSettings.instance.design.motion
                ? const Duration(milliseconds: 190) : Duration.zero,
            padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 14, vertical: 12),
            decoration: BoxDecoration(
              color: active ? c.primary.withValues(alpha: .10) : Colors.transparent,
              borderRadius: BorderRadius.circular(13),
            ),
            child: Row(mainAxisAlignment: compact ? MainAxisAlignment.center : MainAxisAlignment.start, children: [
              Icon(_destinations[index].icon, size: 21,
                color: active ? c.primary : c.onSurfaceVariant),
              if (!compact) ...[
                const SizedBox(width: 13),
                Expanded(child: Text(_destinations[index].label, maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: active ? c.primary : c.onSurfaceVariant,
                    fontWeight: active ? FontWeight.w800 : FontWeight.w600, fontSize: 12))),
              ],
            ]),
          ),
        ),
      ),
    );
  }

  Widget _sideRail() {
    final ui = InterfaceSettings.instance;
    final collapsed = ui.collapsed;
    final c = Theme.of(context).colorScheme;
    return AnimatedContainer(
      duration: ui.design.motion ? const Duration(milliseconds: 220) : Duration.zero,
      width: collapsed ? 82 : 264,
      decoration: BoxDecoration(color: c.surface, border: Border(left: BorderSide(color: c.outlineVariant))),
      child: Column(children: [
        Padding(padding: EdgeInsets.symmetric(horizontal: collapsed ? 10 : 20, vertical: 21),
          child: Row(children: [
            Container(width: 45, height: 45, decoration: BoxDecoration(
              gradient: LinearGradient(colors: [c.primary, ui.design.b]),
              borderRadius: BorderRadius.circular(15),
              boxShadow: [BoxShadow(color: c.primary.withValues(alpha: .23), blurRadius: 15, offset: const Offset(0, 7))]),
              child: const Icon(Icons.calendar_month_rounded, color: Colors.white)),
            if (!collapsed) ...[
              const SizedBox(width: 11),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('جدولي', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: c.onSurface)),
                Text('نظام الجداول المدرسية الذكي', maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 9, color: c.onSurfaceVariant)),
              ])),
            ],
          ])),
        Expanded(child: ListView(children: [
          if (!collapsed) Padding(padding: const EdgeInsets.fromLTRB(22, 10, 22, 12),
            child: Text('مساحة العمل', style: TextStyle(fontSize: 11, color: c.onSurfaceVariant))),
          for (final i in _desktopLinks) _sideLink(i, collapsed),
          Divider(height: 25, indent: 18, endIndent: 18, color: c.outlineVariant),
          if (!collapsed) Padding(padding: const EdgeInsets.fromLTRB(22, 0, 22, 10),
            child: Text('إدارة المدرسة', style: TextStyle(fontSize: 11, color: c.onSurfaceVariant))),
          _sideLink(13, collapsed),
          _sideLink(14, collapsed),
          if (!collapsed) Padding(padding: const EdgeInsets.all(14),
            child: Container(padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(color: c.primary.withValues(alpha: .07), borderRadius: BorderRadius.circular(16)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.auto_awesome, color: c.primary, size: 22),
                const SizedBox(height: 10),
                Text('إصلاح ذكي', style: TextStyle(color: c.onSurface, fontWeight: FontWeight.w800)),
                const SizedBox(height: 5),
                Text('قارن الحلول قبل اعتماد التغييرات.',
                  style: TextStyle(fontSize: 11, color: c.onSurfaceVariant)),
                TextButton(onPressed: () => _goTo(6), child: const Text('افتح الإصلاح')),
              ]))),
        ])),
        IconButton(tooltip: collapsed ? 'توسيع القائمة' : 'طي القائمة',
          icon: Icon(collapsed ? Icons.keyboard_double_arrow_left : Icons.keyboard_double_arrow_right),
          onPressed: () { ui.collapsed = !ui.collapsed; ui.save(); }),
        const SizedBox(height: 8),
      ]),
    );
  }

  Future<void> _showAllScreens() async {
    final theme = Theme.of(context);
    await showModalBottomSheet<void>(
      context: context, isScrollControlled: true,
      builder: (sheet) => SafeArea(child: FractionallySizedBox(heightFactor: .85,
        child: Column(children: [
          Padding(padding: const EdgeInsets.all(18), child: Text('جميع أقسام جدولي', style: theme.textTheme.titleLarge)),
          Expanded(child: ListView(children: [
            for (final i in [0, 1, 6, 2, 3, 4, 5, 7, 8, 10, 11, 12, 13, 14, 15, 16])
              ListTile(
                leading: Icon(_destinations[i].icon),
                title: Text(_destinations[i].label),
                selected: i == _index,
                trailing: const Icon(Icons.chevron_left),
                onTap: () { Navigator.pop(sheet); _goTo(i); },
              ),
          ])),
        ]))),
    );
  }

  Widget _topBar(bool wide) {
    final ui = InterfaceSettings.instance;
    final c = Theme.of(context).colorScheme;
    return Container(
      height: 72,
      padding: EdgeInsets.symmetric(horizontal: wide ? 25 : 12),
      decoration: BoxDecoration(color: c.surface, border: Border(bottom: BorderSide(color: c.outlineVariant))),
      child: Row(children: [
        if (!wide) IconButton(key: const ValueKey('modern-all-screens'),
          tooltip: 'قائمة الأقسام', icon: const Icon(Icons.menu_rounded), onPressed: _showAllScreens),
        if (_index != 0 && ![1, 13, 14, 6].contains(_index))
          IconButton(tooltip: 'رجوع', icon: const Icon(Icons.chevron_right),
            onPressed: () => _goTo(_tab == 2 ? 13 : 14)),
        Flexible(child: Text(_index == 0 ? 'مساحة العمل / الرئيسية' : _destinations[_index].label,
          maxLines: 1, overflow: TextOverflow.ellipsis,
          style: TextStyle(fontSize: wide ? 14 : 12, fontWeight: FontWeight.w800, color: c.onSurface))),
        const Spacer(),
        if (wide) ...[
          OutlinedButton.icon(onPressed: () => _goTo(10),
            icon: const Icon(Icons.description_outlined, size: 16), label: const Text('التقارير')),
          const SizedBox(width: 9),
          OutlinedButton.icon(onPressed: () => showSmartAccess(context,
            onNavigate: _goTo, onTeacher: (id) => _openTable(teacherId: id),
            onSection: (id) => _openTable(sectionId: id)),
            icon: const Icon(Icons.search, size: 18), label: const Text('بحث ذكي')),
          const SizedBox(width: 9),
        ],
        IconButton(tooltip: 'البحث', icon: const Icon(Icons.search),
          onPressed: () => showSmartAccess(context,
            onNavigate: _goTo, onTeacher: (id) => _openTable(teacherId: id),
            onSection: (id) => _openTable(sectionId: id))),
        IconButton(tooltip: 'تبديل الوضع الليلي',
          icon: Icon(ui.dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
          onPressed: () { ui.dark = !ui.dark; ui.save(); }),
        IconButton(tooltip: 'تخصيص المظهر', icon: const Icon(Icons.palette_outlined),
          onPressed: () => _goTo(15)),
      ]),
    );
  }

  Widget _bottomBar() {
    final c = Theme.of(context).colorScheme;
    final motion = InterfaceSettings.instance.design.motion;
    return SafeArea(top: false, child: Align(heightFactor: 1,
      child: Container(
        margin: const EdgeInsets.fromLTRB(10, 6, 10, 9),
        constraints: const BoxConstraints(maxWidth: 650),
        decoration: BoxDecoration(color: c.surface, border: Border.all(color: c.outlineVariant),
          borderRadius: BorderRadius.circular(22),
          boxShadow: const [BoxShadow(color: Color(0x13213565), blurRadius: 23, offset: Offset(0, 7))]),
        padding: const EdgeInsets.all(7),
        child: Row(children: [
          for (var tab = 0; tab < _mobileLinks.length; tab++)
            Expanded(child: Semantics(selected: _activeBottom == tab,
              child: InkWell(
                key: ValueKey('main-tab-$tab'),
                borderRadius: BorderRadius.circular(14),
                onTap: () => _goTo(_mobileLinks[tab]),
                child: AnimatedContainer(
                  duration: motion ? const Duration(milliseconds: 200) : Duration.zero,
                  padding: const EdgeInsets.symmetric(vertical: 9),
                  decoration: BoxDecoration(color: _activeBottom == tab
                      ? c.primary.withValues(alpha: .1) : Colors.transparent,
                    borderRadius: BorderRadius.circular(14)),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon([Icons.home_outlined, Icons.calendar_month_outlined,
                      Icons.school_outlined, Icons.grid_view_outlined, Icons.auto_fix_high_outlined][tab],
                      size: 21, color: _activeBottom == tab ? c.primary : c.onSurfaceVariant),
                    const SizedBox(height: 4),
                    Text(['الرئيسية', 'الجدول', 'إعداد الجدول', 'المزيد', 'الإصلاح'][tab],
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 9,
                        fontWeight: _activeBottom == tab ? FontWeight.w800 : FontWeight.w500,
                        color: _activeBottom == tab ? c.primary : c.onSurfaceVariant)),
                  ]),
                ),
              ),
            )),
        ]),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: _index == 0 && !InterfaceSettings.instance.reading,
    onPopInvokedWithResult: (didPop, result) {
      if (InterfaceSettings.instance.reading) {
        InterfaceSettings.instance.stopReading();
        return;
      }
      if (!didPop) _goTo([1, 13, 14].contains(_index) ? 0 : _tab == 2 ? 13 : 14);
    },
    child: Directionality(textDirection: TextDirection.rtl,
      child: LayoutBuilder(builder: (context, constraints) {
        final ui = InterfaceSettings.instance;
        final wide = constraints.maxWidth > 900 && ui.desktopRail && !ui.reading;
        final pages = IndexedStack(
          index: _index,
          children: List.generate(17, (i) => TickerMode(enabled: _index == i, child: _page(i))),
        );
        final main = Column(children: [
          if (!ui.reading) _topBar(wide),
          Expanded(child: ScreenEntrance(page: _index, child: pages)),
        ]);
        return Scaffold(
          body: SafeArea(child: wide
              ? Row(children: [_sideRail(), Expanded(child: main)])
              : main),
          bottomNavigationBar: wide || ui.reading ? null : _bottomBar(),
        );
      }),
    ),
  );
}
