import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iraqi_school_timetable/app/app.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';

class _TestPaths extends PathProviderPlatform {
  _TestPaths(this.directory);
  final String directory;
  @override
  Future<String> getApplicationSupportPath() async => directory;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory directory;
  late PathProviderPlatform previousPaths;
  setUpAll(() async {
    directory = await Directory.systemTemp.createTemp('jadwali-ui-');
    previousPaths = PathProviderPlatform.instance;
    PathProviderPlatform.instance = _TestPaths(directory.path);
    // Preserve legacy four-tab navigation screenshots; modern desktop sidebar
    // has dedicated coverage in modern_ui_128_test.dart.
    SharedPreferences.setMockInitialValues({'ui_desktop_rail': false});
    final input = jsonDecode(
      File('test/fixtures/backup_school_181.json').readAsStringSync(),
    ) as Map;
    List<Map<String, Object?>> rows(String key) => (input[key] as List)
        .map((r) => Map<String, Object?>.from(r as Map))
        .toList();
    final storage = DatabaseService.instance;
    final db = await storage.database;
    await db.transaction((txn) async {
      await txn.delete('time_slots');
      for (final slot in rows('slots')) {
        await txn.insert('time_slots', slot);
      }
      final known = (await txn.query('subjects')).map((s) => s['id']).toSet();
      for (final req in rows('requirements')) {
        if (known.add(req['subject_id']))
          await txn.insert('subjects', {
            'id': req['subject_id'],
            'name': 'مادة ${req['subject_id']}',
          });
      }
      for (final section in rows('sections')) {
        await txn.insert('sections', {
          'id': section['id'],
          'grade_id': section['grade_id'],
          'name': section['section_name'],
          'max_daily_lessons': 6,
        });
      }
      for (final t in rows('teachers')) {
        await txn.insert('teachers', t);
      }
      for (final q in rows('qualifications')) {
        await txn.insert('teacher_subjects', q);
      }
      for (final q in rows('teacherSubjectGrades')) {
        await txn.insert('teacher_subject_grades', q);
      }
      for (final r in rows('requirements')) {
        await txn.insert('section_subject_requirements', {
          for (final k in [
            'section_id',
            'subject_id',
            'weekly_lessons',
            'max_daily_lessons',
            'allow_same_day',
          ])
            k: r[k],
        });
      }
    });
    await storage.saveAsNewVersion(
      yearId: (await storage.activeYearId())!,
      name: 'الجدول النشط',
      entries: rows('initialPlacements'),
      requireComplete: true,
    );
  });
  tearDownAll(() async {
    await DatabaseService.instance.close();
    PathProviderPlatform.instance = previousPaths;
    await directory.delete(recursive: true);
  });
  Future<void> settle(WidgetTester tester) async {
    // Text fields may keep scheduling cursor frames; wait on data readiness,
    // not the absence of every animation in the application.
    for (var i = 0; i < 80; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)),
      );
      await tester.pump(const Duration(milliseconds: 100));
      if (i >= 4 &&
          find
              .byWidgetPredicate(
                (w) => w is CircularProgressIndicator && w.value == null,
              )
              .evaluate()
              .isEmpty)
        break;
    }
    expect(
      find.byWidgetPredicate(
        (w) => w is CircularProgressIndicator && w.value == null,
      ),
      findsNothing,
    );
  }

  for (final size in [
    const Size(390, 844),
    const Size(320, 740),
    const Size(1280, 900),
  ]) {
    testWidgets(
      'all remaining screens open at $size with one More menu, stable restrictions and long-press pins',
      (tester) async {
        tester.view.physicalSize = size;
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        final font = FontLoader('JadwaliStudio')
          ..addFont(rootBundle.load('assets/fonts/UI-Regular.ttf'));
        await font.load();
        final latin = FontLoader('JadwaliLatin')
          ..addFont(rootBundle.load('assets/fonts/UI-Latin.ttf'));
        await latin.load();
        final icons = FontLoader('MaterialIcons')
          ..addFont(rootBundle.load('fonts/MaterialIcons-Regular.otf'));
        await icons.load();
        final capture = GlobalKey();
        await tester.pumpWidget(
          RepaintBoundary(key: capture, child: const TimetableApp()),
        );
        Future<void> screenshot(String name) async {
          final directory = Platform.environment['JADWALI_SCREENSHOTS'] == null
              ? null
              : '${Platform.environment['JADWALI_SCREENSHOTS']}/${size.width.toInt()}';
          if (directory == null) return;
          await tester.pump();
          final boundary =
              capture.currentContext!.findRenderObject()!
                  as RenderRepaintBoundary;
          final image = (await tester.runAsync(
            () => boundary.toImage(pixelRatio: 1),
          ))!;
          final bytes = await tester.runAsync(
            () => image.toByteData(format: ui.ImageByteFormat.png),
          );
          await tester.runAsync(() async {
            await Directory(directory).create(recursive: true);
            await File('$directory/$name.png')
                .writeAsBytes(bytes!.buffer.asUint8List());
          });
          image.dispose();
        }

        await settle(tester);
        expect(tester.takeException(), isNull, reason: 'dashboard');
        expect(find.text('جدولي'), findsNothing);
        expect(find.text('كل أسبوع، بداية مرتّبة.'), findsNothing);
        expect(find.text('أسبوعك في مكان واحد'), findsNothing);
        expect(find.byTooltip('الوضع الداكن'), findsNothing);
        expect(find.byTooltip('دليل الشاشة'), findsNothing);
        await screenshot('00-home');
        await tester.tap(find.byKey(const ValueKey('customize-school-card')));
        await settle(tester);
        expect(
          find.byKey(const ValueKey('design-live-preview')),
          findsOneWidget,
        );
        await screenshot('design-studio-from-home');
        await tester.tap(find.byKey(const ValueKey('close-design-studio')));
        await settle(tester);
        await tester.tap(find.byKey(const ValueKey('main-tab-3')));
        await settle(tester);
        final settingsTile = find.byKey(const ValueKey('more-destination-15'));
        await tester.scrollUntilVisible(
          settingsTile,
          150,
          scrollable: find
              .descendant(
                of: find.byType(ListView).last,
                matching: find.byType(Scrollable),
              )
              .first,
        );
        await Scrollable.ensureVisible(
          tester.element(settingsTile),
          alignment: .2,
        );
        await settle(tester);
        await tester.tap(settingsTile);
        await settle(tester);
        expect(
          find.byKey(const ValueKey('settings-font-slider')),
          findsOneWidget,
        );
        await tester.tap(find.byKey(const ValueKey('settings-dark')));
        await settle(tester);
        await screenshot('settings-dark');
        expect(tester.takeException(), isNull, reason: 'settings dark');
        final slider = tester.widget<Slider>(
          find.byKey(const ValueKey('settings-font-slider')),
        );
        slider.onChanged!(1.3);
        await settle(tester);
        expect(tester.takeException(), isNull, reason: 'settings large font');
        await screenshot('settings-large-font');
        await tester.tap(find.text('الحجم الافتراضي'));
        await settle(tester);
        await tester.tap(find.byKey(const ValueKey('settings-dark')));
        await settle(tester);
        await tester.tap(find.byKey(const ValueKey('main-tab-0')));
        await settle(tester);
        final dashboardScroll = find
            .descendant(
              of: find.byKey(const ValueKey('smart-dashboard-scroll')),
              matching: find.byType(Scrollable),
            )
            .first;
        expect(find.text('ماذا تريد أن تغيّر؟'), findsNothing);
        expect(find.text('انتباهك هنا'), findsNothing);
        expect(find.byKey(const ValueKey('smart-request-input')), findsNothing);
        final labEntry = find.byKey(const ValueKey('smart-lab-entry'));
        await tester.scrollUntilVisible(
          labEntry,
          220,
          scrollable: dashboardScroll,
        );
        await Scrollable.ensureVisible(tester.element(labEntry), alignment: .3);
        await settle(tester);
        await tester.tap(labEntry);
        await settle(tester);
        expect(find.text('جرّب القرار قبل أن يغيّر أسبوعك'), findsOneWidget);
        expect(
          find.byKey(const ValueKey('run-smart-scenario')),
          findsOneWidget,
        );
        await screenshot('smart-workspace');
        await tester.tap(find.byKey(const ValueKey('main-tab-0')));
        await settle(tester);
        final searchButton = find.byKey(const ValueKey('smart-search-entry'));
        final homeScroll = find
            .descendant(
              of: find.byKey(const ValueKey('smart-dashboard-scroll')),
              matching: find.byType(Scrollable),
            )
            .first;
        await tester.scrollUntilVisible(
          searchButton,
          220,
          scrollable: homeScroll,
        );
        await Scrollable.ensureVisible(
          tester.element(searchButton),
          alignment: .3,
        );
        await settle(tester);
        await tester.tap(searchButton);
        await settle(tester);
        await tester.enterText(
          find.byKey(const ValueKey('smart-access-query')),
          'التقارير',
        );
        await settle(tester);
        expect(find.text('معاينة وحفظ وطباعة'), findsOneWidget);
        await screenshot('smart-access');
        await tester.tap(find.text('إغلاق'));
        await settle(tester);
        tester.state<ScrollableState>(homeScroll).position.jumpTo(0);
        await settle(tester);
        final customize = find.text('تخصيص الرئيسية');
        await tester.scrollUntilVisible(
          customize,
          150,
          scrollable: find
              .descendant(
                of: find.byKey(const ValueKey('smart-dashboard-scroll')),
                matching: find.byType(Scrollable),
              )
              .first,
        );
        await Scrollable.ensureVisible(
          tester.element(customize),
          alignment: .35,
        );
        await settle(tester);
        await tester.tap(customize);
        await settle(tester);
        expect(find.text('اختر أربع بطاقات ورتّبها بالسهمين.'), findsOneWidget);
        await tester.tap(find.byTooltip('تأخير البطاقة').first);
        await settle(tester);
        await tester.tap(find.text('حفظ الاختصارات (4/4)'));
        await settle(tester);
        expect(find.text('اختر أربع بطاقات ورتّبها بالسهمين.'), findsNothing);

        if (size.width < 700) {
          await tester.tap(find.byKey(const ValueKey('main-tab-2')));
          await settle(tester);
          expect(find.text('بيانات إعداد الجدول'), findsOneWidget);
          expect(find.byKey(const ValueKey('setup-readiness')), findsOneWidget);
          expect(tester.takeException(), isNull);
          await screenshot('00-school');
          await tester.tap(find.byKey(const ValueKey('main-tab-3')));
          await settle(tester);
          final moreScroll = find
              .descendant(
                of: find.byType(ListView).last,
                matching: find.byType(Scrollable),
              )
              .first;
          tester.state<ScrollableState>(moreScroll).position.jumpTo(0);
          await settle(tester);
          expect(find.text('كل أدوات المدرسة'), findsOneWidget);
          expect(tester.takeException(), isNull);
          await screenshot('00-more');
        }

        var screenIndex = 0;
        for (final label in [
          'الجدول',
          'المعلمون',
          'الحصص المطلوبة',
          'المواد والقيود',
          'إتاحة المعلمين',
          'التعارضات',
          'التوزيع والحلول',
          'الغياب والبدلاء',
          'التقارير',
          'النسخ الاحتياطية',
          'إعدادات المدرسة',
        ]) {
          // ignore: avoid_print
          print('Opening $label');
          expect(find.byTooltip('كل الشاشات'), findsNothing);
          await tester.tap(find.byKey(const ValueKey('main-tab-3')));
          await settle(tester);
          expect(find.text('النسخ والاعتماد'), findsNothing);
          expect(
            find.byKey(const ValueKey('more-destination-13')),
            findsNothing,
          );
          expect(
            find.byKey(const ValueKey('more-destination-7')),
            findsNothing,
          );
          expect(
            find.byKey(const ValueKey('more-destination-10')),
            findsNothing,
          );
          final destination = {
            'الجدول': 1,
            'المعلمون': 2,
            'الحصص المطلوبة': 3,
            'المواد والقيود': 4,
            'إتاحة المعلمين': 5,
            'التعارضات': 6,
            'التوزيع والحلول': 7,
            'الغياب والبدلاء': 8,
            'التقارير': 10,
            'النسخ الاحتياطية': 11,
            'إعدادات المدرسة': 12,
          }[label]!;
          if ([2, 3, 4, 5, 7, 10, 12].contains(destination)) {
            await tester.tap(find.byKey(const ValueKey('main-tab-2')));
            await settle(tester);
          }
          final item = find.byKey(ValueKey('more-destination-$destination'));
          final scrollable = find
              .descendant(
                of: find.byType(ListView).last,
                matching: find.byType(Scrollable),
              )
              .first;
          tester.state<ScrollableState>(scrollable).position.jumpTo(0);
          await settle(tester);
          await tester.scrollUntilVisible(item, 250, scrollable: scrollable);
          await Scrollable.ensureVisible(tester.element(item), alignment: .5);
          await settle(tester);
          await tester.tap(item);
          await settle(tester);
          expect(tester.takeException(), isNull, reason: label);
          expect(
            find.textContaining('تعذر تحميل'),
            findsNothing,
            reason: label,
          );
          expect(find.textContaining('استيراد Excel'), findsNothing);
          await screenshot('${++screenIndex}');
          if (label == 'المواد والقيود') {
            final activeRows = (await tester.runAsync(
              () => DatabaseService.instance.entriesDetailed(),
            ))!;
            final impacted = activeRows.first;
            final impactChip = find.byKey(
              ValueKey(
                'block-${impacted['subject_id']}-${impacted['slot_id']}',
              ),
            );
            final subjectScroll = find
                .descendant(
                  of: find.byKey(const PageStorageKey('subjects-list')),
                  matching: find.byType(Scrollable),
                )
                .first;
            await tester.scrollUntilVisible(
              impactChip,
              250,
              scrollable: subjectScroll,
              maxScrolls: 100,
            );
            await Scrollable.ensureVisible(tester.element(impactChip));
            await settle(tester);
            if (!tester.widget<FilterChip>(impactChip).selected) {
              await tester.tap(impactChip);
              await settle(tester);
              expect(find.textContaining('يتأثر بهذا المنع'), findsOneWidget);
              await screenshot('constraint-impact');
              await tester.tap(find.text('إلغاء'));
              await settle(tester);
              expect(tester.widget<FilterChip>(impactChip).selected, isFalse);
            }
            tester.state<ScrollableState>(subjectScroll).position.jumpTo(0);
            await settle(tester);
            final chips = find.byWidgetPredicate(
              (w) =>
                  w is FilterChip &&
                  w.key is ValueKey<String> &&
                  (w.key as ValueKey<String>).value.startsWith('block-'),
            );
            // Freeze identity before scrolling/rebuilding the list. A positional
            // finder such as chips.last can resolve to a different rendered chip.
            final chipKey = tester.widget<FilterChip>(chips.last).key!;
            final chip = find.byKey(chipKey);
            final scroll = find
                .descendant(
                  of: find.byKey(const PageStorageKey('subjects-list')),
                  matching: find.byType(Scrollable),
                )
                .first;
            await tester.scrollUntilVisible(chip, 300, scrollable: scroll);
            await Scrollable.ensureVisible(tester.element(chip), alignment: .5);
            await settle(tester);
            await tester.pumpAndSettle();
            final position = tester.state<ScrollableState>(scroll).position;
            final before = position.pixels;
            expect(before, greaterThan(0));
            final selected = tester.widget<FilterChip>(chip).selected;
            final key =
                (tester.widget<FilterChip>(chip).key as ValueKey<String>).value
                    .split('-');
            Future<void> toggleAndWait(bool expected) async {
              await tester.tap(chip);
              var saved = false;
              // SQLite runs outside the fake widget clock. Wait for the actual
              // result, including an impact dialog that can arrive after I/O.
              for (var attempt = 0; attempt < 300; attempt++) {
                await tester.runAsync(
                  () => Future<void>.delayed(const Duration(milliseconds: 50)),
                );
                await tester.pump(const Duration(milliseconds: 100));
                final confirm = find.text('حفظ الشرط فقط');
                if (confirm.hitTestable().evaluate().isNotEmpty) {
                  await tester.tap(confirm);
                  await tester.pumpAndSettle();
                }
                final current = tester.widget<FilterChip>(chip);
                if (current.selected == expected &&
                    current.onSelected != null) {
                  saved = true;
                  break;
                }
              }
              expect(
                saved,
                isTrue,
                reason:
                    'Restriction $chipKey did not finish saving to $expected',
              );
              await tester.pumpAndSettle();
            }

            await toggleAndWait(!selected);
            expect(position.pixels, closeTo(before, 1));
            expect(tester.widget<FilterChip>(chip).selected, !selected);
            await tester.runAsync(() async {
              final rows = await DatabaseService.instance.rows(
                'subject_blocked_slots',
              );
              expect(
                rows.any(
                  (r) =>
                      r['subject_id'] == int.parse(key[1]) &&
                      r['slot_id'] == int.parse(key[2]),
                ),
                !selected,
              );
            });
            await toggleAndWait(selected);
            expect(position.pixels, closeTo(before, 1));
            expect(tester.widget<FilterChip>(chip).selected, selected);
            await tester.runAsync(() async {
              final rows = await DatabaseService.instance.rows(
                'subject_blocked_slots',
              );
              expect(
                rows.any(
                  (r) =>
                      r['subject_id'] == int.parse(key[1]) &&
                      r['slot_id'] == int.parse(key[2]),
                ),
                selected,
              );
            });
          }
          if (label == 'الجدول') {
            final sticky = find.byKey(const ValueKey('sticky-table-controls'));
            final beforeTop = tester.getTopLeft(sticky).dy;
            await tester.drag(
              find.byKey(const ValueKey('daily-lessons')),
              const Offset(0, -160),
            );
            await settle(tester);
            expect(tester.getTopLeft(sticky).dy, closeTo(beforeTop, 1));
            final listScroll = find
                .descendant(
                  of: find.byKey(const ValueKey('daily-lessons')),
                  matching: find.byType(Scrollable),
                )
                .first;
            tester.state<ScrollableState>(listScroll).position.jumpTo(0);
            await settle(tester);
            await tester.tap(find.text('عرض مختصر'));
            await settle(tester);
            expect(find.text('عرض مريح'), findsOneWidget);
            await tester.tap(find.text('عرض مريح'));
            await settle(tester);
            await tester.tap(find.text('ملء الشاشة'));
            await settle(tester);
            expect(find.text('إنهاء القراءة'), findsOneWidget);
            await tester.tap(find.text('إنهاء القراءة'));
            await settle(tester);

            final lesson = find
                .byWidgetPredicate(
                  (w) =>
                      w is InkWell &&
                      w.key is ValueKey<String> &&
                      (w.key as ValueKey<String>).value.startsWith('lesson-'),
                )
                .first;
            await tester.tap(
              find
                  .descendant(
                    of: lesson,
                    matching: find.byTooltip('تفاصيل الحصة'),
                  )
                  .first,
            );
            await settle(tester);
            expect(find.text('تفاصيل الحصة'), findsOneWidget);
            expect(find.text('نقل الحصة'), findsOneWidget);
            await screenshot('lesson-details');
            if (size.width <= 1100) {
              Navigator.of(tester.element(find.text('تفاصيل الحصة'))).pop();
              await settle(tester);
            }
            final parts =
                (tester.widget<InkWell>(lesson).key as ValueKey<String>).value
                    .split('-');
            Future<int> readLock() async {
              final entries = await DatabaseService.instance.entriesDetailed();
              return entries.singleWhere(
                    (e) =>
                        e['section_id'] == int.parse(parts[1]) &&
                        e['day_id'] == int.parse(parts[2]) &&
                        e['slot_id'] == int.parse(parts[3]),
                  )['is_locked']
                  as int;
            }

            final before = await tester.runAsync(readLock);
            await tester.longPress(lesson);
            await settle(tester);
            expect(await tester.runAsync(readLock), before == 1 ? 0 : 1);
            await tester.pumpAndSettle();
            await tester.tap(find.text('تراجع'));
            await settle(tester);
            expect(await tester.runAsync(readLock), before);
            await screenshot('undo-pin');
            expect(find.textContaining('تعذر تحديث قفل الحصة'), findsNothing);
            expect(tester.takeException(), isNull);
          }

          if (label == 'التقارير') {
            expect(find.text('معاينة وطباعة'), findsNothing);
            await tester.tap(find.text('التالي: المحتوى والورق'));
            await settle(tester);
            final next = find.text('معاينة التقرير');
            await tester.scrollUntilVisible(
              next,
              180,
              scrollable: find
                  .descendant(
                    of: find.byType(ListView).last,
                    matching: find.byType(Scrollable),
                  )
                  .first,
            );
            await Scrollable.ensureVisible(tester.element(next));
            await tester.tap(next);
            await settle(tester);
            expect(find.text('معاينة وطباعة'), findsOneWidget);
            expect(tester.takeException(), isNull);
            await screenshot('reports-preview');
          }
        }
      },
    );
  }
}
