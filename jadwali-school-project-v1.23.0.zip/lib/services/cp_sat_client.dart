import 'dart:convert';
import 'dart:io';

import 'schedule_improvement_service.dart';

class CpSatCancellation {
  HttpClient? _client;
  bool cancelled = false;
  Process? _process;
  void attachProcess(Process process) {
    _process = process;
    if (cancelled) process.kill();
  }

  void detachProcess(Process process) {
    if (identical(_process, process)) _process = null;
  }

  void cancel() {
    cancelled = true;
    _client?.close(force: true);
    _process?.kill();
  }
}

/// Optional real OR-Tools CP-SAT engine running on the school's own computer.
/// No request is sent unless the user explicitly presses the CP-SAT button.
/// It is NOT a local Android native solver; the offline Dart engine remains.
class CpSatClient {
  const CpSatClient();

  Future<Map<String, Object?>> solve({
    required Uri endpoint,
    required String token,
    required Map<String, Object?> input,
    CpSatCancellation? cancellation,
    Duration timeout = const Duration(seconds: 65),
  }) async {
    if (endpoint.scheme != 'http' && endpoint.scheme != 'https') {
      throw const FormatException(
        'يجب استخدام عنوان HTTP أو HTTPS لمحرك المدرسة.',
      );
    }
    if (endpoint.host.isEmpty || token.trim().length < 16) {
      throw const FormatException(
        'أدخل رابط المحرك ورمز وصول مكوناً من 16 حرفاً على الأقل.',
      );
    }
    final uri = endpoint.replace(path: '/solve', query: null, fragment: null);
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    cancellation?._client = client;
    try {
      if (cancellation?.cancelled == true)
        throw StateError('أُلغي الاتصال بالمحرك.');
      final request = await client
          .postUrl(uri)
          .timeout(const Duration(seconds: 12));
      request.headers.set(
        HttpHeaders.contentTypeHeader,
        'application/json; charset=utf-8',
      );
      request.headers.set(HttpHeaders.authorizationHeader, 'Bearer $token');
      request.headers.set(HttpHeaders.cacheControlHeader, 'no-store');
      request.add(
        utf8.encode(
          jsonEncode({
            'input': input,
            'timeLimitSeconds': (timeout.inSeconds - 10).clamp(1, 180),
          }),
        ),
      );
      final response = await request.close().timeout(timeout);
      final body = await utf8.decoder.bind(response).join().timeout(timeout);
      if (response.statusCode == 503) {
        throw StateError(
          'المحرك غير جاهز أو مشغول ببحث آخر؛ تحقق من تشغيله وأعد المحاولة بعد قليل.',
        );
      }
      if (response.statusCode != 200) {
        throw StateError(
          'رفض المحرك الطلب (${response.statusCode}). تحقق من الرمز وتشغيل الخادم.',
        );
      }
      return decodeResult(body, input);
    } finally {
      cancellation?._client = null;
      client.close(force: true);
    }
  }

  /// Independently validate native and remote results before review or saving.
  static Map<String, Object?> decodeResult(
    String body,
    Map<String, Object?> input,
  ) {
    final value = jsonDecode(body);
    if (value is! Map) throw const FormatException('استجابة CP-SAT غير صحيحة.');
    final result = Map<String, Object?>.from(value);
    final status = '${result['status'] ?? ''}';
    if (status != 'OPTIMAL' && status != 'FEASIBLE') {
      return <String, Object?>{
        'status': status,
        'message': '${result['message'] ?? 'لم يتم التوصل إلى حل.'}',
        'complete': false,
        'diagnostics': result['diagnostics'] ?? <Object?>[],
        'diagnosticScope': result['diagnosticScope'],
      };
    }
    final rows =
        (result['placements'] as List?)
            ?.map((e) => Map<String, Object?>.from(e as Map))
            .toList() ??
        [];
    // The phone independently validates EVERY hard rule and locked cell.
    if (!ScheduleImprovementService.valid(input, rows)) {
      throw StateError(
        'رفض التطبيق نتيجة CP-SAT لأنها تخالف أحد القيود المحلية. لم يُحفظ أي تعديل.',
      );
    }
    return <String, Object?>{
      'status': status,
      'complete': true,
      'profile': result['profile'] ?? input['profile'] ?? 'minimal_changes',
      'label': 'CP-SAT الرياضي (OR-Tools)',
      'placements': rows,
      'unscheduled': <String>[],
      'dailySpreadIssues': <String>[],
      'requestedCount': rows.length,
      'exploredNodes': result['exploredBranches'] ?? 0,
      'searchLimitReached': result['qualityOptimal'] != true,
      'qualityOptimal': result['qualityOptimal'] == true,
      'engineQuality': result['quality'],
      'engineInitialQuality': result['initialQuality'],
      'engineSeconds': result['wallTime'],
      'engineVersion': result['engineVersion'],
    };
  }
}
