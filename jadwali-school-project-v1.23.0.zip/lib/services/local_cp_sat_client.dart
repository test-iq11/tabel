import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;

import 'cp_sat_client.dart';

/// Starts a bundled, single-request engine. No server, port, or credentials.
class LocalCpSatClient {
  const LocalCpSatClient({this.executable, this.arguments = const []});
  final String? executable;
  final List<String> arguments;

  Future<Map<String, Object?>> solve({
    required Map<String, Object?> input,
    CpSatCancellation? cancellation,
    Duration timeout = const Duration(seconds: 70),
  }) async {
    if (cancellation?.cancelled == true) throw StateError('أُلغي البحث.');
    final path =
        executable ??
        p.join(
          p.dirname(Platform.resolvedExecutable),
          'engine',
          'jadwali_engine.exe',
        );
    if (!await File(path).exists()) {
      throw StateError(
        'ملفات المحرك المرفق غير موجودة. فك حزمة Windows كاملة مع مجلد engine.',
      );
    }
    final process = await Process.start(
      path,
      arguments,
      workingDirectory: p.dirname(path),
    );
    cancellation?.attachProcess(process);
    final output = utf8.decoder.bind(process.stdout).join();
    final errors = process.stderr.drain<void>();
    try {
      return await (() async {
        process.stdin.add(
          utf8.encode(
            jsonEncode({
              'input': input,
              'timeLimitSeconds': (timeout.inSeconds - 10).clamp(1, 180),
            }),
          ),
        );
        await process.stdin.close();
        final code = await process.exitCode;
        final body = await output;
        await errors;
        if (cancellation?.cancelled == true) throw StateError('أُلغي البحث.');
        if (code != 0)
          throw StateError(
            'تعذر تشغيل المحرك المحلي (رمز $code). أعد استخراج الحزمة كاملة.',
          );
        return CpSatClient.decodeResult(body, input);
      })().timeout(timeout);
    } finally {
      process.kill();
      await process.exitCode;
      await output;
      await errors;
      cancellation?.detachProcess(process);
    }
  }
}
