import 'dart:async';
import 'dart:io';

import 'cp_sat_dialog.dart';

import 'package:flutter/material.dart';

import '../../services/schedule_search_controller.dart';
import '../../services/on_device_deep_search.dart';

Future<List<Map<String, Object?>>?> showScheduleSearchDialog(
  BuildContext context, {
  required Map<String, Object?> input,
  required List<String> profiles,
}) => showDialog<List<Map<String, Object?>>>(
  context: context,
  barrierDismissible: false,
  builder: (_) => _ScheduleSearchDialog(input: input, profiles: profiles),
);

class _ScheduleSearchDialog extends StatefulWidget {
  const _ScheduleSearchDialog({required this.input, required this.profiles});
  final Map<String, Object?> input;
  final List<String> profiles;
  @override
  State<_ScheduleSearchDialog> createState() => _ScheduleSearchDialogState();
}

class _ScheduleSearchDialogState extends State<_ScheduleSearchDialog> {
  final _controller = ScheduleSearchController();
  StreamSubscription<Map<String, Object?>>? _subscription;
  Timer? _timer;
  List<Map<String, Object?>> _results = [];
  Map<String, Object?> _progress = {};
  Map<String, Object?>? _cpResult;

  List<Map<String, Object?>> _withCp(List<Map<String, Object?>> rows) => [
    if (_cpResult != null) _cpResult!,
    ...rows,
  ];
  String? _error;
  String _profileLabel = 'البحث عن توزيع';
  bool _running = true;
  bool _stoppedByUser = false;
  bool _closing = false;
  int _seconds = 30;
  bool _deepWorking = false;
  int _deepStep = 0;
  String _deepStatus = '';

  @override
  void initState() {
    super.initState();
    final configured = widget.input['timeLimitMs'];
    if (configured is num && configured > 0)
      _seconds = (configured / 1000).ceil();
    _subscription = _controller.events.listen((event) {
      if (!mounted || _closing) return;
      setState(() {
        if (event['type'] == 'progress' || event['type'] == 'starting')
          _progress = event;
        if (event['type'] == 'solution')
          _results = _withCp(_controller.bestSolutions);
        if (event['type'] == 'profile')
          _profileLabel = '${event['label'] ?? 'البحث عن توزيع'}';
      });
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _running) setState(() {});
    });
    unawaited(
      _run(
        _controller.start({
          ...widget.input,
          'timeLimitMs': widget.input['timeLimitMs'] ?? _seconds * 1000,
        }, profiles: widget.profiles),
      ),
    );
  }

  Future<void> _run(Future<List<Map<String, Object?>>> attempt) async {
    setState(() {
      _running = true;
      _error = null;
    });
    try {
      final results = await attempt;
      if (!mounted || _closing) return;
      setState(() {
        _results = _withCp(results);
        _running = false;
      });
      // Keep incomplete results open, so the operator can run the deep
      // on-device rescue or review the best local board.
      // Nothing is committed before the normal review screen is shown.
    } catch (error) {
      if (!mounted || _closing) return;
      setState(() {
        _running = false;
        _error = 'تعذر إكمال البحث: $error';
      });
    }
  }

  /// All deep searches run in the existing background Dart isolate. This is an
  /// offline constraint-search mode, NOT Google's native OR-Tools CP-SAT.
  /// Each round starts from the best saved solution, even if interrupted.
  Future<void> _runDeepOnPhone() async {
    if (_deepWorking || _closing) return;
    _stoppedByUser = false;
    setState(() {
      _deepWorking = true;
      _deepStep = 0;
      _deepStatus = 'تهيئة البحث العميق على هذا الجهاز';
      _error = null;
    });
    try {
      // Stop and preserve any useful partial result from the fast search.
      if (_controller.isRunning) await _stop();
      _stoppedByUser = false;
      for (final stage in OnDeviceDeepSearch.stages) {
        if (_stoppedByUser || _closing || !mounted) break;
        final best = OnDeviceDeepSearch.best(_controller.bestSolutions);
        if (best != null && best['complete'] == true) break;
        setState(() {
          _deepStep = stage.number;
          _deepStatus = '${stage.label} — حتى ${stage.seconds} ثانية';
          _profileLabel = 'التوزيع العميق دون إنترنت: ${stage.label}';
        });
        await _run(
          _controller.continueSearch(
            nodeLimit: stage.nodes,
            timeLimit: Duration(seconds: stage.seconds),
          ),
        );
      }
      if (!_closing && mounted && !_stoppedByUser) {
        final best = OnDeviceDeepSearch.best(_controller.bestSolutions);
        setState(() {
          _deepStatus = best?['complete'] == true
              ? 'تم العثور على جدول كامل. راجع النتيجة قبل الحفظ.'
              : 'انتهت المحاولات المحدودة؛ لم تثبت استحالة التوزيع.';
        });
      }
    } catch (error) {
      if (mounted && !_closing) {
        setState(() => _error = 'تعذر إكمال البحث المحلي: $error');
      }
    } finally {
      if (mounted && !_closing) setState(() => _deepWorking = false);
    }
  }

  Future<void> _runCpSat() async {
    if (_running || _deepWorking || _closing) return;
    final result = await showCpSatDialog(context, input: widget.input);
    if (!mounted || _closing || result == null) return;
    setState(() {
      _cpResult = result;
      _results = _withCp(_controller.bestSolutions);
      _profileLabel = 'اكتمل البحث الرياضي؛ النتيجة جاهزة للمراجعة';
      _error = null;
    });
  }

  Future<void> _stop() async {
    _stoppedByUser = true;
    final results = await _controller.stop();
    if (!mounted || _closing) return;
    setState(() {
      _results = _withCp(results);
      _running = false;
    });
  }

  void _continue() {
    _stoppedByUser = false;
    unawaited(
      _run(_controller.continueSearch(timeLimit: Duration(seconds: _seconds))),
    );
  }

  Future<void> _cancel() async {
    if (_closing) return;
    _closing = true;
    await _controller.dispose();
    if (mounted) Navigator.of(context).pop();
  }

  int get _bestCount {
    var count = _number(_progress['bestCount']);
    for (final result in _results) {
      final rows = result['placements'];
      if (rows is List && rows.length > count) count = rows.length;
    }
    return count;
  }

  @override
  Widget build(BuildContext context) {
    final requested = _number(_progress['requestedCount']);
    final elapsed = _controller.elapsedMilliseconds ~/ 1000;
    final durationValues = <int>{30, 60, 180, _seconds}.toList()..sort();
    return AlertDialog(
      title: Text(_running ? 'توزيع الحصص جارٍ' : 'احتُفظ بأفضل نتيجة'),
      content: SizedBox(
        width: 520,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(_profileLabel),
              if (_results.any((r) => r['complete'] == true))
                const Text(
                  'وجدنا جدولاً كاملاً صالحاً. يجري الآن تحسين الجودة؛ يمكنك مراجعته في أي وقت.',
                ),
              const SizedBox(height: 14),
              LinearProgressIndicator(
                value: requested > 0
                    ? (_bestCount / requested).clamp(0.0, 1.0)
                    : null,
              ),
              const SizedBox(height: 10),
              Text('الموزع: $_bestCount من $requested حصة'),
              Text(
                'الوقت: ${elapsed ~/ 60}:${(elapsed % 60).toString().padLeft(2, '0')}',
              ),
              const SizedBox(height: 12),
              if (_running)
                const Text(
                  'يمكنك إيقاف البحث والاحتفاظ بأفضل توزيع منشور للمراجعة.',
                ),
              if (!_running && _stoppedByUser)
                const Text(
                  'تستطيع مراجعة النتيجة أو بدء محاولة أوسع انطلاقاً منها. تُفحص القيود قبل الحفظ.',
                ),
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'التوزيع العميق على هذا الجهاز',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'يعمل بالكامل دون إنترنت. يجرب ثلاث مراحل '
                        'بحث متزايدة، ويستخدم أفضل جدول جزئي كنقطة بداية '
                        'مع الاحتفاظ بالقيود والحصص المثبتة.',
                      ),
                      const SizedBox(height: 6),
                      if (!Platform.isWindows)
                        const Text(
                          'هذا البحث المحلي ليس مكتبة Google OR-Tools CP-SAT '
                          'الأصلية؛ دمج CP-SAT على Android ما زال يتطلب بناءً '
                          'واختباراً أصليين.',
                          style: TextStyle(fontSize: 12),
                        ),
                      if (_deepStatus.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text(_deepStatus),
                        if (_deepWorking) Text('المرحلة $_deepStep من 3'),
                      ],
                      const SizedBox(height: 8),
                      FilledButton.icon(
                        onPressed: _deepWorking ? null : _runDeepOnPhone,
                        icon: const Icon(Icons.offline_bolt_outlined),
                        label: Text(
                          _deepWorking
                              ? 'البحث العميق قيد التشغيل...'
                              : 'ابدأ البحث العميق على هذا الجهاز',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (!_running && !_deepWorking) ...[
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  key: const ValueKey('open-cp-sat'),
                  onPressed: _runCpSat,
                  icon: const Icon(Icons.hub_outlined),
                  label: Text(
                    Platform.isWindows
                        ? 'OR-Tools المدمج — دون إنترنت'
                        : 'OR-Tools على كمبيوتر المدرسة',
                  ),
                ),
              ],
              if (_error != null)
                Text(
                  _error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
              if (!_running && !_deepWorking) ...[
                const SizedBox(height: 12),
                DropdownButtonFormField<int>(
                  initialValue: _seconds,
                  decoration: const InputDecoration(
                    labelText: 'مدة المحاولة التالية لكل حل',
                  ),
                  items: durationValues
                      .map(
                        (seconds) => DropdownMenuItem(
                          value: seconds,
                          child: Text(
                            seconds < 60
                                ? '$seconds ثانية'
                                : '${seconds ~/ 60} دقيقة',
                          ),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setState(() => _seconds = value);
                  },
                ),
              ],
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: _cancel, child: const Text('إلغاء')),
        if (_running &&
            !_deepWorking &&
            _results.any((r) => r['complete'] == true))
          FilledButton(
            onPressed: () async {
              await _stop();
              if (!mounted || _closing) return;
              _closing = true;
              Navigator.of(context).pop(_results);
            },
            child: const Text('مراجعة الحل الكامل الآن'),
          ),
        if (_running)
          OutlinedButton.icon(
            onPressed: _stop,
            icon: const Icon(Icons.stop),
            label: const Text('إيقاف والاحتفاظ بالأفضل'),
          ),
        if (!_running && !_deepWorking) ...[
          OutlinedButton.icon(
            onPressed: _continue,
            icon: const Icon(Icons.play_arrow),
            label: const Text('متابعة ببحث أوسع'),
          ),
          FilledButton(
            onPressed: _results.isEmpty
                ? null
                : () {
                    _closing = true;
                    Navigator.of(context).pop(_results);
                  },
            child: const Text('مراجعة أفضل نتيجة'),
          ),
        ],
      ],
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    unawaited(_subscription?.cancel() ?? Future<void>.value());
    unawaited(_controller.dispose());
    super.dispose();
  }
}

int _number(Object? value) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? 0;
