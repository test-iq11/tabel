import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;
import 'package:iraqi_school_timetable/services/local_cp_sat_client.dart';
import 'package:iraqi_school_timetable/services/cp_sat_client.dart';

void main() {
  final dart = p.normalize(
    p.join(
      p.dirname(Platform.resolvedExecutable),
      '..',
      '..',
      '..',
      'dart-sdk',
      'bin',
      Platform.isWindows ? 'dart.exe' : 'dart',
    ),
  );
  LocalCpSatClient client([String? mode]) => LocalCpSatClient(
    executable: dart,
    arguments: [
      File('test/fixtures/fake_desktop_engine.dart').absolute.path,
      if (mode != null) mode,
    ],
  );
  test('local process exchanges JSON without address or token', () async {
    expect(File(dart).existsSync(), isTrue);
    final result = await client().solve(input: {});
    expect(result['status'], 'UNKNOWN');
    expect(result['complete'], isFalse);
  });
  test(
    'local feasible result cannot bypass independent full schedule validation',
    () async {
      final input = Map<String, Object?>.from(
        jsonDecode(
          File('test/fixtures/backup_school_181.json').readAsStringSync(),
        ) as Map,
      );
      await expectLater(
        client('invalid').solve(input: input),
        throwsStateError,
      );
    },
  );
  test(
    'missing bundle explains that engine directory must be extracted',
    () async {
      await expectLater(
        const LocalCpSatClient(executable: 'missing-engine-file.exe')
            .solve(input: {}),
        throwsStateError,
      );
    },
  );
  test('cancelled request never starts a process', () async {
    final cancel = CpSatCancellation()..cancel();
    await expectLater(
      client().solve(input: {}, cancellation: cancel),
      throwsStateError,
    );
  });
  test('cancellation terminates a running child', () async {
    final cancel = CpSatCancellation();
    final result = client('wait').solve(input: {}, cancellation: cancel);
    final check = expectLater(result, throwsStateError);
    await Future<void>.delayed(const Duration(milliseconds: 500));
    cancel.cancel();
    await check.timeout(const Duration(seconds: 5));
  });
  test('timeout terminates a stalled child', () async {
    await expectLater(
      client('wait').solve(input: {}, timeout: const Duration(seconds: 1)),
      throwsA(isA<Exception>()),
    );
  });
}
