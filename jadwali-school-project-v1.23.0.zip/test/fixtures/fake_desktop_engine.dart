import 'dart:convert';
import 'dart:io';

Future<void> main(List<String> args) async {
  final request = jsonDecode(await utf8.decoder.bind(stdin).join()) as Map;
  if (request['input'] is! Map) exit(2);
  if (args.contains('wait'))
    await Future<void>.delayed(const Duration(seconds: 30));
  if (args.contains('invalid')) {
    stdout.write('{"status":"FEASIBLE","placements":[]}');
  } else {
    stdout.write('{"status":"UNKNOWN","message":"bounded search finished"}');
  }
}
