import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/features/timetable/cp_sat_dialog.dart';

void main() {
  testWidgets('bundled Windows mode needs no endpoint or secret', (
    tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(home: CpSatDialog(input: {}, useLocalEngine: true)),
    );
    expect(find.byKey(const ValueKey('cp-endpoint')), findsNothing);
    expect(find.byKey(const ValueKey('cp-token')), findsNothing);
    expect(find.byKey(const ValueKey('cp-run')), findsOneWidget);
    expect(find.textContaining('المحرك مرفق بالتطبيق'), findsOneWidget);
  });
  for (final width in [320.0, 1280.0]) {
    testWidgets(
      'OR-Tools form is usable at width $width without sending on open',
      (tester) async {
        tester.view.physicalSize = Size(width, 800);
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        await tester.pumpWidget(
          MaterialApp(
            home: Builder(
              builder: (context) => Scaffold(
                body: TextButton(
                  onPressed: () => showDialog<void>(
                    context: context,
                    builder: (_) =>
                        const CpSatDialog(input: {}, useLocalEngine: false),
                  ),
                  child: const Text('open'),
                ),
              ),
            ),
          ),
        );
        await tester.tap(find.text('open'));
        await tester.pumpAndSettle();
        expect(find.byKey(const ValueKey('cp-endpoint')), findsOneWidget);
        expect(find.byType(LinearProgressIndicator), findsNothing);
        await tester.tap(find.byKey(const ValueKey('cp-run')));
        await tester.pumpAndSettle();
        expect(find.textContaining('تعذر إكمال الطلب'), findsOneWidget);
        expect(tester.takeException(), isNull);
        await tester.tap(find.text('إغلاق'));
        await tester.pumpAndSettle();
        expect(find.byType(CpSatDialog), findsNothing);
      },
    );
  }
}
