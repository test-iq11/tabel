"""Exercise the actual frozen binary without Python in its environment."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
exe = Path(sys.argv[1]).resolve()
source = json.loads((root / 'test/fixtures/backup_school_181.json').read_text(encoding='utf-8'))
env = dict(os.environ)
for key in ('PYTHONHOME', 'PYTHONPATH', 'VIRTUAL_ENV'):
    env.pop(key, None)
if os.name == 'nt':
    env['PATH'] = str(Path(env['SystemRoot']) / 'System32')
cases = []
for name, blocks in [('bundled 181 cold', []), ('bundled 181 first and second blocked', [1, 2])]:
    data = copy.deepcopy(source)
    data['initialPlacements'] = []
    data['subjectBlockedSlots'] = [dict(subject_id=2, slot_id=s) for s in blocks]
    completed = subprocess.run([str(exe)], input=json.dumps({'input': data, 'timeLimitSeconds': 30}).encode(),
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=50, env=env,
                               cwd=exe.parent, check=True)
    result = json.loads(completed.stdout)
    assert result['status'] in ('OPTIMAL', 'FEASIBLE'), result.get('status')
    assert len(result['placements']) == 181
    cases.append(dict(name=name, input=data, result=result))
    print(name, result['status'], len(result['placements']), flush=True)
# The existing Flutter regression test independently validates these exact results.
fixture = root / 'test/fixtures/cp_sat_regression.json'
previous = json.loads(fixture.read_text(encoding='utf-8'))
previous = [case for case in previous if not case['name'].startswith('bundled ')]
destination = Path(sys.argv[2]) if len(sys.argv) > 2 else fixture
destination.write_text(json.dumps(previous + cases), encoding='utf-8')
