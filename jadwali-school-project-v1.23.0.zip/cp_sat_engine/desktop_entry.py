"""Single local request over stdin/stdout; no network listener or installation."""
import json
import sys
from cp_sat_engine.solver import solve


def main():
    try:
        raw = sys.stdin.buffer.read(2_000_001)
        if len(raw) > 2_000_000:
            raise ValueError('Request too large')
        request = json.loads(raw)
        if not isinstance(request, dict) or not isinstance(request.get('input'), dict):
            raise ValueError('Invalid input')
        result = solve(request['input'], request.get('timeLimitSeconds', 60))
        sys.stdout.buffer.write(json.dumps(result, ensure_ascii=False).encode('utf-8'))
        sys.stdout.buffer.flush()
        return 0
    except Exception:
        sys.stderr.write('Local OR-Tools request failed.\n')
        return 1


if __name__ == '__main__':
    sys.exit(main())
