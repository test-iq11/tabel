import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

/// يصدّر شبكة الجدول الأسبوعي لجميع الشعب إلى PDF أفقي قابل للطباعة.
class PdfReportService {
  Future<pw.Font> _arabicFont() async {
    try {
      final data = await rootBundle.load('assets/fonts/Arabic-Regular.ttf');
      return pw.Font.ttf(data);
    } catch (_) {
      const candidates = [
        '/system/fonts/NotoNaskhArabic-Regular.ttf',
        '/system/fonts/NotoNaskhArabicUI-Regular.ttf',
        '/system/fonts/NotoSansArabic-Regular.ttf',
      ];
      for (final path in candidates) {
        final file = File(path);
        if (await file.exists()) {
          final bytes = await file.readAsBytes();
          return pw.Font.ttf(ByteData.sublistView(bytes));
        }
      }
      throw StateError('لم يتم العثور على خط عربي يدعم PDF. أضف خطاً عربياً مرخصاً باسم assets/fonts/Arabic-Regular.ttf ثم أعد بناء التطبيق.');
    }
  }

  Future<Uint8List> buildTimetablePdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<Map<String, Object?>> entries,
    List<Map<String, Object?>> sections = const [],
    List<Map<String, Object?>> days = const [],
    List<Map<String, Object?>> slots = const [],
    PdfPageFormat? pageFormat,
    String title = 'الجدول الأسبوعي الشامل لجميع الصفوف والشعب',
  }) async {
    final font = await _arabicFont();
    final pdf = pw.Document();
    final format = pageFormat ?? PdfPageFormat.a3.landscape;

    final orderedDays = days.where((d) => _int(d['is_active'], fallback: 1) == 1).toList()
      ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));
    final orderedSlots = slots.where((s) => s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1).toList()
      ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));

    final orderedEntries = [...entries]..sort((a, b) {
      final section = '${a['grade_name'] ?? ''} ${a['section_name'] ?? ''}'.compareTo('${b['grade_name'] ?? ''} ${b['section_name'] ?? ''}');
      if (section != 0) return section;
      final day = _int(a['day_position']).compareTo(_int(b['day_position']));
      if (day != 0) return day;
      return _int(a['slot_position']).compareTo(_int(b['slot_position']));
    });

    final reportSections = <Map<String, Object?>>[];
    if (sections.isNotEmpty) {
      reportSections.addAll(sections);
    } else {
      final seen = <int>{};
      for (final entry in orderedEntries) {
        final id = _int(entry['section_id']);
        if (seen.add(id)) {
          reportSections.add({
            'id': id,
            'grade_name': entry['grade_name'] ?? '',
            'section_name': entry['section_name'] ?? 'الشعبة $id',
          });
        }
      }
    }
    // يحافظ على ترتيب الصفوف القادم من قاعدة البيانات (المرحلة ثم الصف ثم الشعبة).

    final entryByCell = <String, Map<String, Object?>>{};
    for (final entry in orderedEntries) {
      entryByCell['${_int(entry['section_id'])}:${_int(entry['day_id'])}:${_int(entry['slot_id'])}'] = entry;
    }

    pw.Widget cell(String text, {bool header = false, bool filled = false, bool period = false}) {
      final PdfColor background = header
          ? const PdfColor.fromInt(0xFF183B66)
          : filled
              ? const PdfColor.fromInt(0xFFE7F1FC)
              : period
                  ? const PdfColor.fromInt(0xFFF0F3F7)
                  : const PdfColor.fromInt(0xFFFAFBFD);
      final PdfColor foreground = header ? PdfColors.white : const PdfColor.fromInt(0xFF23354B);
      return pw.Container(
        alignment: pw.Alignment.center,
        padding: const pw.EdgeInsets.symmetric(horizontal: 3, vertical: 4),
        decoration: pw.BoxDecoration(color: background),
        child: pw.Directionality(
          textDirection: pw.TextDirection.rtl,
          child: pw.Text(
            text,
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(
              font: font,
              fontSize: header ? 8 : 7,
              color: foreground,
              fontWeight: header || period ? pw.FontWeight.bold : pw.FontWeight.normal,
            ),
          ),
        ),
      );
    }

    final children = <pw.Widget>[];
    if (reportSections.isEmpty) {
      children.add(pw.Padding(
        padding: const pw.EdgeInsets.all(18),
        child: pw.Directionality(textDirection: pw.TextDirection.rtl, child: pw.Text('لا توجد شعب أو جداول للطباعة. أضف الصفوف والشعب ثم أنشئ الجدول الأسبوعي.')),
      ));
    } else if (orderedDays.isEmpty || orderedSlots.isEmpty) {
      children.add(pw.Padding(
        padding: const pw.EdgeInsets.all(18),
        child: pw.Directionality(textDirection: pw.TextDirection.rtl, child: pw.Text('لا توجد أيام دوام أو حصص متاحة للطباعة. راجع إعدادات أيام المدرسة وأوقات الحصص.')),
      ));
    } else {
      for (final section in reportSections) {
        final sectionId = _int(section['id']);
        final label = '${section['grade_name'] ?? ''} - ${section['section_name'] ?? 'الشعبة $sectionId'}'.replaceAll(RegExp(r'^\s*-\s*'), '').trim();
        final widths = <int, pw.TableColumnWidth>{
          0: const pw.FlexColumnWidth(1.25),
          for (var i = 1; i <= orderedDays.length; i++) i: const pw.FlexColumnWidth(1.0),
        };
        final tableRows = <pw.TableRow>[
          pw.TableRow(children: [
            cell('الفترة / الوقت', header: true),
            ...orderedDays.map((day) => cell('${day['name'] ?? ''}', header: true)),
          ]),
          ...orderedSlots.map((slot) => pw.TableRow(children: [
            cell('${slot['name'] ?? ''}\n${slot['start_time'] ?? ''} - ${slot['end_time'] ?? ''}', period: true),
            ...orderedDays.map((day) {
              final entry = entryByCell['$sectionId:${_int(day['id'])}:${_int(slot['id'])}'];
              if (entry == null) return cell('—');
              final subject = entry['subject_name']?.toString() ?? 'مادة';
              final teacher = entry['teacher_name']?.toString().trim();
              final text = teacher == null || teacher.isEmpty ? '$subject\nغير مسند' : '$subject\n$teacher';
              return cell(text, filled: true);
            }),
          ])),
        ];
        children.add(pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            pw.Container(
              padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 5),
              decoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFFDCE9F8)),
              child: pw.Directionality(
                textDirection: pw.TextDirection.rtl,
                child: pw.Text(label, style: pw.TextStyle(font: font, fontSize: 10, fontWeight: pw.FontWeight.bold, color: const PdfColor.fromInt(0xFF183B66))),
              ),
            ),
            pw.Table(
              columnWidths: widths,
              border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.45),
              defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
              children: tableRows,
            ),
            pw.SizedBox(height: 9),
          ],
        ));
      }
    }

    final theme = pw.ThemeData.withFont(base: font, bold: font);
    pdf.addPage(pw.MultiPage(
      pageFormat: format,
      maxPages: 500,
      theme: theme,
      margin: const pw.EdgeInsets.all(18),
      header: (context) => pw.Directionality(textDirection: pw.TextDirection.rtl, child: pw.Column(children: [
        pw.Text(schoolName, style: pw.TextStyle(font: font, fontSize: 15, fontWeight: pw.FontWeight.bold, color: const PdfColor.fromInt(0xFF183B66))),
        pw.SizedBox(height: 3),
        pw.Text(title, style: pw.TextStyle(font: font, fontSize: 11, fontWeight: pw.FontWeight.bold)),
        pw.Text('العام الدراسي: $academicYear  |  النسخة: $versionName  |  الحالة: $status  |  اتجاه الصفحة: أفقي', style: pw.TextStyle(font: font, fontSize: 8)),
        pw.Divider(),
      ])),
      footer: (context) => pw.Align(
        alignment: pw.Alignment.centerLeft,
        child: pw.Text(
          'تاريخ التقرير: ${DateTime.now().toIso8601String().split('T').first}  •  صفحة ${context.pageNumber} من ${context.pagesCount}',
          style: pw.TextStyle(font: font, fontSize: 7),
        ),
      ),
      build: (context) => children,
    ));
    return pdf.save();
  }

  Future<String?> savePdf(Uint8List bytes, {String fileName = 'الجدول-المدرسي.pdf'}) async {
    return FilePicker.platform.saveFile(
      dialogTitle: 'حفظ تقرير PDF',
      fileName: fileName,
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      bytes: bytes,
    );
  }

  Future<void> preview(Uint8List bytes) async {
    await Printing.layoutPdf(onLayout: (_) async => bytes);
  }

  int _int(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
