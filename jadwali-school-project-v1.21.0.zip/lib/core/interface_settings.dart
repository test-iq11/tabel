import 'dart:convert';

import 'package:flutter/material.dart';

import 'design_style.dart';

import 'package:shared_preferences/shared_preferences.dart';

class InterfaceSettings extends ChangeNotifier {
  static final instance = InterfaceSettings();
  bool dark = false, compact = false, collapsed = false, reading = false;
  Map<String, int> softPriorities = {'spacing': 2, 'gaps': 2, 'balance': 2};
  DesignStyle design = const DesignStyle();
  bool desktopRail = false;
  Future<void> _pendingSave = Future.value();
  double fontScale = 1.0;
  List<int> shortcuts = [7, 10, 3, 6];
  static const allowed = [7, 10, 3, 6, 2, 4, 8, 11];
  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    for (final key in softPriorities.keys.toList()) {
      softPriorities[key] = (p.getInt('priority_$key') ?? 2).clamp(1, 3);
    }
    try {
      final value = jsonDecode(p.getString('ui_design_v2') ?? '{}');
      design = value is Map ? DesignStyle.fromMap(value) : const DesignStyle();
    } catch (_) {
      design = const DesignStyle();
    }
    desktopRail = p.getBool('ui_desktop_rail') ?? false;
    final storedScale = p.getDouble('ui_font_scale') ?? 1.0;
    fontScale = storedScale.isFinite ? storedScale.clamp(.85, 1.3) : 1.0;
    dark = p.getBool('ui_dark') ?? false;
    compact = p.getBool('ui_compact') ?? false;
    collapsed = p.getBool('ui_collapsed') ?? false;
    final saved = (p.getStringList('ui_shortcuts') ?? [])
        .map(int.tryParse)
        .whereType<int>()
        .toList();
    if (saved.length == 4 &&
        saved.toSet().length == 4 &&
        saved.every(allowed.contains))
      shortcuts = saved;
    notifyListeners();
  }

  Future<void> save() {
    notifyListeners();
    // Snapshot and serialize writes: rapid slider changes cannot restore an older value.
    final values = <String, Object>{
      'ui_design_v2': jsonEncode(design.toMap()),
      'ui_desktop_rail': desktopRail,
      'ui_font_scale': fontScale,
      'ui_dark': dark,
      'ui_compact': compact,
      'ui_collapsed': collapsed,
      'ui_shortcuts': shortcuts.map((i) => '$i').toList(),
      for (final e in softPriorities.entries) 'priority_${e.key}': e.value,
    };
    return _pendingSave = _pendingSave.catchError((Object _) {}).then((
      _,
    ) async {
      final p = await SharedPreferences.getInstance();
      for (final e in values.entries) {
        switch (e.value) {
          case bool v:
            await p.setBool(e.key, v);
          case double v:
            await p.setDouble(e.key, v);
          case int v:
            await p.setInt(e.key, v);
          case String v:
            await p.setString(e.key, v);
          case List<String> v:
            await p.setStringList(e.key, v);
        }
      }
    });
  }

  void toggleReading() {
    reading = !reading;
    notifyListeners();
  }

  void stopReading() {
    if (reading) {
      reading = false;
      notifyListeners();
    }
  }
}

const shortcutInfo = <int, (String, String, IconData, int)>{
  7: ('توزيع جديد', 'راجع الشروط وابدأ البحث', Icons.auto_awesome_outlined, 0),
  10: ('تقارير المدرسة', 'معاينة، حفظ وطباعة', Icons.description_outlined, 1),
  3: ('الحصص المطلوبة', 'اضبط حصص كل صف', Icons.menu_book_outlined, 2),
  6: ('فحص التعارضات', 'راجع أثر الشروط', Icons.check_outlined, 3),
  2: ('المعلمون', 'النصاب والاختصاص', Icons.people_outline, 0),
  4: ('المواد والقيود', 'شروط واضحة لكل مادة', Icons.settings_outlined, 1),
  8: ('الغياب والبدلاء', 'راجع الحصص المتأثرة', Icons.person_off_outlined, 2),
  11: ('النسخ الاحتياطية', 'حفظ واستعادة البيانات', Icons.backup_outlined, 3),
};
Future<void> customizeHome(BuildContext context) async {
  final settings = InterfaceSettings.instance;
  final draft = [...settings.shortcuts];
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (sheet) => StatefulBuilder(
      builder: (ctx, update) => SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(ctx).height * .8,
          child: Column(
            children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'تخصيص الرئيسية',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    const Text('اختر أربع بطاقات ورتّبها بالسهمين.'),
                    for (var n = 0; n < draft.length; n++)
                      ListTile(
                        title: Text(shortcutInfo[draft[n]]!.$1),
                        leading: Text('${n + 1}'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              tooltip: 'تقديم البطاقة',
                              onPressed: n == 0
                                  ? null
                                  : () => update(() {
                                      final v = draft[n];
                                      draft[n] = draft[n - 1];
                                      draft[n - 1] = v;
                                    }),
                              icon: const Icon(Icons.arrow_upward),
                            ),
                            IconButton(
                              tooltip: 'تأخير البطاقة',
                              onPressed: n == draft.length - 1
                                  ? null
                                  : () => update(() {
                                      final v = draft[n];
                                      draft[n] = draft[n + 1];
                                      draft[n + 1] = v;
                                    }),
                              icon: const Icon(Icons.arrow_downward),
                            ),
                          ],
                        ),
                      ),
                    const Divider(),
                    for (final item in shortcutInfo.entries)
                      CheckboxListTile(
                        title: Text(item.value.$1),
                        value: draft.contains(item.key),
                        onChanged: (v) => update(() {
                          if (v == true) {
                            if (draft.length < 4) draft.add(item.key);
                          } else {
                            draft.remove(item.key);
                          }
                        }),
                      ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: FilledButton(
                  onPressed: draft.length != 4
                      ? null
                      : () {
                          settings.shortcuts = [...draft];
                          settings.save();
                          Navigator.pop(sheet);
                        },
                  child: Text('حفظ الاختصارات (${draft.length}/4)'),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
