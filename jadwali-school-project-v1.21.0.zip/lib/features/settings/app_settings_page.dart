import 'package:flutter/material.dart';

import '../../core/interface_settings.dart';
import 'design_studio.dart';

class AppSettingsPage extends StatelessWidget {
  const AppSettingsPage({super.key, required this.onHelp});
  final VoidCallback onHelp;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: InterfaceSettings.instance,
    builder: (context, _) {
      final ui = InterfaceSettings.instance;
      return ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  key: const ValueKey('settings-dark'),
                  secondary: const Icon(Icons.dark_mode_outlined),
                  title: const Text('الوضع الليلي'),
                  subtitle: const Text('ألوان هادئة للاستخدام مساءً'),
                  value: ui.dark,
                  onChanged: (value) {
                    ui.dark = value;
                    ui.save();
                  },
                ),
                const Divider(height: 1),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'حجم الخط · ${(ui.fontScale * 100).round()}٪',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const Text('يضاف إلى حجم الخط المحدد في جهازك.'),
                      Slider(
                        key: const ValueKey('settings-font-slider'),
                        value: ui.fontScale,
                        min: .85,
                        max: 1.3,
                        divisions: 9,
                        label: '${(ui.fontScale * 100).round()}٪',
                        onChanged: (value) {
                          ui.fontScale = value;
                          ui.save();
                        },
                      ),
                      const Text('معاينة: حصص مدرستي واضحة ومنظمة'),
                      Align(
                        alignment: AlignmentDirectional.centerEnd,
                        child: TextButton(
                          onPressed: () {
                            ui.fontScale = 1;
                            ui.save();
                          },
                          child: const Text('الحجم الافتراضي'),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(
              children: [
                ListTile(
                  key: const ValueKey('open-design-settings'),
                  leading: const Icon(Icons.palette_outlined),
                  title: const Text('استوديو المظهر'),
                  subtitle: const Text(
                    'الألوان والبطاقة والزخارف واستيراد تصميمك',
                  ),
                  onTap: () => showDesignStudio(context),
                ),
                SwitchListTile(
                  title: const Text('تنقل جانبي على الكمبيوتر'),
                  value: ui.desktopRail,
                  onChanged: (v) {
                    ui.desktopRail = v;
                    ui.save();
                  },
                ),
                SwitchListTile(
                  title: const Text('عرض الجدول المختصر'),
                  subtitle: const Text('بطاقات حصص أقل ارتفاعاً'),
                  value: ui.compact,
                  onChanged: (value) {
                    ui.compact = value;
                    ui.save();
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.dashboard_customize_outlined),
                  title: const Text('تخصيص الرئيسية'),
                  subtitle: const Text('اختر البطاقات الأربع ورتّبها'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => customizeHome(context),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.help_outline),
                  title: const Text('دليل الاستخدام'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: onHelp,
                ),
                const ListTile(
                  leading: Icon(Icons.info_outline),
                  title: Text('إصدار التطبيق'),
                  subtitle: Text('1.21.0 (58)'),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Text(
                    'تُحفظ تفضيلات العرض على هذا الجهاز، ولا تغيّر بيانات المدرسة أو قيود توزيع الحصص.',
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    },
  );
}
