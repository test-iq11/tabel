import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iraqi_school_timetable/core/interface_settings.dart';
import 'package:iraqi_school_timetable/core/theme.dart';
import 'package:iraqi_school_timetable/features/settings/design_studio.dart';

void main() {
  for (final width in [320.0, 390.0, 1280.0]) {
    testWidgets(
      'live studio, color picker, dark mode and persistence at $width',
      (tester) async {
        SharedPreferences.setMockInitialValues({});
        final settings = InterfaceSettings.instance;
        await tester.runAsync(() => settings.load());
        tester.view.physicalSize = Size(width, 844);
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        await (FontLoader(
          'JadwaliStudio',
        )..addFont(rootBundle.load('assets/fonts/UI-Regular.ttf'))).load();
        await (FontLoader(
          'MaterialIcons',
        )..addFont(rootBundle.load('fonts/MaterialIcons-Regular.otf'))).load();
        await (FontLoader(
          'JadwaliLatin',
        )..addFont(rootBundle.load('assets/fonts/UI-Latin.ttf'))).load();
        final boundary = GlobalKey();
        await tester.pumpWidget(
          RepaintBoundary(
            key: boundary,
            child: ListenableBuilder(
              listenable: settings,
              builder: (context, _) => MaterialApp(
                debugShowCheckedModeBanner: false,
                theme: buildAppTheme(
                  design: settings.design,
                  dark: settings.dark,
                ),
                builder: (context, child) => Directionality(
                  textDirection: TextDirection.rtl,
                  child: MediaQuery(
                    data: MediaQuery.of(context).copyWith(
                      textScaler: TextScaler.linear(settings.fontScale),
                    ),
                    child: child!,
                  ),
                ),
                home: Builder(
                  builder: (context) => Scaffold(
                    body: TextButton(
                      onPressed: () =>
                          showDesignStudio(context, schoolName: 'مدرسة الأفق'),
                      child: const Text('open'),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
        await tester.tap(find.text('open'));
        await tester.pumpAndSettle();
        final scroll = find
            .descendant(
              of: find.byKey(const ValueKey('design-studio-scroll')),
              matching: find.byType(Scrollable),
            )
            .first;
        Future<void> reveal(Finder f) async {
          await tester.scrollUntilVisible(f, 160, scrollable: scroll);
          await Scrollable.ensureVisible(tester.element(f), alignment: .4);
          await tester.pumpAndSettle();
        }

        await reveal(find.byKey(const ValueKey('design-preset-3')));
        await tester.tap(find.byKey(const ValueKey('design-preset-3')));
        await tester.pumpAndSettle();
        expect(settings.design.a.toARGB32(), 0xff713e47);
        await reveal(find.byKey(const ValueKey('design-color-a')));
        await tester.tap(find.byKey(const ValueKey('design-color-a')));
        await tester.pumpAndSettle();
        await tester.enterText(
          find.byKey(const ValueKey('design-color-hex')),
          '#29547a',
        );
        await tester.pumpAndSettle();
        await tester.tap(find.byKey(const ValueKey('design-color-apply')));
        await tester.pumpAndSettle();
        expect(settings.design.a.toARGB32(), 0xff29547a);
        await reveal(find.byKey(const ValueKey('design-radius')));
        final position = tester.state<ScrollableState>(scroll).position.pixels;
        tester
            .widget<Slider>(find.byKey(const ValueKey('design-radius')))
            .onChanged!(16);
        await tester.pumpAndSettle();
        expect(
          tester.state<ScrollableState>(scroll).position.pixels,
          closeTo(position, 1),
        );
        expect(settings.design.radius, 16);
        await reveal(find.byKey(const ValueKey('design-pattern-dots')));
        await tester.tap(find.byKey(const ValueKey('design-pattern-dots')));
        await tester.pumpAndSettle();
        await reveal(find.byKey(const ValueKey('design-dark')));
        await tester.tap(find.byKey(const ValueKey('design-dark')));
        await tester.pumpAndSettle();
        expect(settings.dark, true);
        tester
            .widget<Slider>(find.byKey(const ValueKey('design-font')))
            .onChanged!(1.3);
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
        if (Platform.environment['JADWALI_SCREENSHOTS'] != null) {
          final dir = Directory(
            '${Platform.environment['JADWALI_SCREENSHOTS']}/${width.toInt()}',
          );
          dir.createSync(recursive: true);
          final image = (await tester.runAsync(
            () =>
                (boundary.currentContext!.findRenderObject()
                        as RenderRepaintBoundary)
                    .toImage(),
          ))!;
          final data = await tester.runAsync(
            () => image.toByteData(format: ui.ImageByteFormat.png),
          );
          File('${dir.path}/design-studio.png')
              .writeAsBytesSync(data!.buffer.asUint8List());
          image.dispose();
        }
        await tester.tap(find.byKey(const ValueKey('close-design-studio')));
        await tester.pumpAndSettle();
        await tester.runAsync(() => settings.save());
        await tester.runAsync(() => settings.load());
        expect(settings.design.a.toARGB32(), 0xff29547a);
        expect(settings.design.pattern, 'dots');
      },
    );
  }
}
