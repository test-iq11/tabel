import 'package:flutter/material.dart';

ThemeData buildAppTheme({String style = 'calm'}) {
  final navy = style == 'blue'
      ? const Color(0xFF183B66)
      : style == 'paper'
      ? const Color(0xFF4B4A3C)
      : const Color(0xFF24594F);
  final blue = style == 'blue'
      ? const Color(0xFF2878C8)
      : style == 'paper'
      ? const Color(0xFF807650)
      : const Color(0xFF358374);
  const green = Color(0xFF16845B);
  final scheme =
      ColorScheme.fromSeed(
        seedColor: blue,
        brightness: Brightness.light,
      ).copyWith(
        primary: navy,
        secondary: blue,
        tertiary: green,
        surface: Colors.white,
      );
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'JadwaliArabic',
    colorScheme: scheme,
    scaffoldBackgroundColor: style == 'paper'
        ? const Color(0xFFF7F5EE)
        : const Color(0xFFF4F7F6),
    appBarTheme: AppBarTheme(
      backgroundColor: Color(0xFFF4F7FB),
      foregroundColor: navy,
      iconTheme: IconThemeData(color: blue),
      actionsIconTheme: IconThemeData(color: blue),
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
      titleTextStyle: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w800,
        color: navy,
      ),
    ),
    iconTheme: IconThemeData(color: blue),
    listTileTheme: ListTileThemeData(
      iconColor: blue,
      contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 3),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(14)),
      ),
    ),
    dividerTheme: const DividerThemeData(
      color: Color(0xFFE7EDF5),
      thickness: 1,
      space: 1,
    ),
    cardTheme: CardThemeData(
      color: Colors.white,
      elevation: 0,
      shadowColor: const Color(0x140D2340),
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(color: Color(0xFFE2E9E6)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(13),
        borderSide: const BorderSide(color: Color(0xFFDCE4EE)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(13),
        borderSide: const BorderSide(color: Color(0xFFDCE4EE)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(13),
        borderSide: BorderSide(color: blue, width: 1.7),
      ),
      prefixIconColor: blue,
      suffixIconColor: const Color(0xFF71839A),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: navy,
        foregroundColor: Colors.white,
        minimumSize: const Size(44, 46),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: navy,
        minimumSize: const Size(44, 44),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: const Color(0xFFEAF1F8),
      labelStyle: const TextStyle(fontWeight: FontWeight.w600),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white,
      surfaceTintColor: Colors.transparent,
      indicatorColor: const Color(0xFFDCEBFA),
      indicatorShape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      iconTheme: WidgetStateProperty.resolveWith<IconThemeData?>(
        (states) => IconThemeData(
          color: states.contains(WidgetState.selected)
              ? navy
              : const Color(0xFF71839A),
          size: 23,
        ),
      ),
      labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>(
        (states) => TextStyle(
          fontSize: 11,
          fontWeight: states.contains(WidgetState.selected)
              ? FontWeight.w800
              : FontWeight.w500,
          color: states.contains(WidgetState.selected)
              ? navy
              : const Color(0xFF71839A),
        ),
      ),
    ),
    textTheme: TextTheme(
      headlineSmall: TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.w800,
        color: navy,
      ),
      titleLarge: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w800,
        color: navy,
      ),
      titleMedium: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: navy,
      ),
      bodyMedium: TextStyle(fontSize: 14, height: 1.45),
    ),
  );
}
