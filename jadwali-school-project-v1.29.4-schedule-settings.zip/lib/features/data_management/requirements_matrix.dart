import 'package:flutter/material.dart';

import '../../core/preview_widgets.dart';
import '../../core/editor_navigation_guard.dart';
import '../../core/ui_helpers.dart';
import '../../data/database_service.dart';

/// Edits counts only; existing per-subject daily rules remain untouched.
class RequirementsMatrix extends StatefulWidget {
  const RequirementsMatrix({
    required this.sections,
    required this.subjects,
    required this.requirements,
    required this.onChanged,
    required this.onRules,
    this.navigationGuard,
    super.key,
  });
  final List<Map<String, Object?>> sections, subjects, requirements;
  final VoidCallback onChanged;
  final EditorNavigationGuard? navigationGuard;
  final Future<void> Function(
    Map<String, Object?>,
    Map<String, Object?>,
    Map<String, Object?>?,
  )
  onRules;
  @override
  State<RequirementsMatrix> createState() => _RequirementsMatrixState();
}

class _RequirementsMatrixState extends State<RequirementsMatrix> {
  final _controllers = <String, TextEditingController>{};
  final _dirty = <String>{};
  bool _saving = false;
  int? _selectedSection;
  @override
  void initState() {
    super.initState();
    widget.navigationGuard?.beforeLeave = _beforeLeave;
  }

  Future<bool> _beforeLeave() async {
    if (_saving) return false;
    if (_dirty.isEmpty) return true;
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('تعديلات غير محفوظة'),
        content: Text('هل تريد حفظ أعداد الحصص قبل الانتقال؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, 'cancel'),
            child: Text('البقاء'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, 'discard'),
            child: Text('تجاهل التعديلات'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, 'save'),
            child: Text('حفظ والانتقال'),
          ),
        ],
      ),
    );
    if (result == 'discard') return true;
    if (result == 'save') return _save();
    return false;
  }

  String _key(Object? section, Object? subject) => '$section:$subject';
  Map<String, Object?>? _existing(Object? section, Object? subject) {
    for (final r in widget.requirements) {
      if (r['section_id'] == section && r['subject_id'] == subject) return r;
    }
    return null;
  }

  String _normalize(String text) => text.split('').map((c) {
    final n = '٠١٢٣٤٥٦٧٨٩'.indexOf(c);
    final f = '۰۱۲۳۴۵۶۷۸۹'.indexOf(c);
    return n >= 0
        ? '$n'
        : f >= 0
        ? '$f'
        : c;
  }).join();
  TextEditingController _controller(
    Map<String, Object?> section,
    Map<String, Object?> subject,
  ) => _controllers.putIfAbsent(
    _key(section['id'], subject['id']),
    () => TextEditingController(
      text:
          '${_existing(section['id'], subject['id'])?['weekly_lessons'] ?? 0}',
    ),
  );
  @override
  void didUpdateWidget(covariant RequirementsMatrix oldWidget) {
    super.didUpdateWidget(oldWidget);
    for (final section in widget.sections) {
      for (final subject in widget.subjects) {
        final key = _key(section['id'], subject['id']);
        if (!_dirty.contains(key))
          _controller(section, subject).text =
              '${_existing(section['id'], subject['id'])?['weekly_lessons'] ?? 0}';
      }
    }
  }

  @override
  void dispose() {
    if (widget.navigationGuard?.beforeLeave == _beforeLeave)
      widget.navigationGuard?.beforeLeave = null;
    for (final c in _controllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  int _count(Map<String, Object?> s, Map<String, Object?> m) =>
      int.tryParse(_normalize(_controller(s, m).text)) ?? 0;
  Future<bool> _save({bool refresh = true}) async {
    if (_saving) return false;
    final changes = <(int, int, int)>[];
    for (final key in _dirty) {
      final n = int.tryParse(_normalize(_controllers[key]!.text));
      if (n == null || n < 0 || n > 60) {
        showMessage(
          context,
          'أدخل عدداً بين 0 و60 في كل خلية معدّلة.',
          error: true,
        );
        return false;
      }
      final parts = key.split(':').map(int.parse).toList();
      changes.add((parts[0], parts[1], n));
    }
    if (changes.isEmpty) return true;
    setState(() => _saving = true);
    try {
      final db = await DatabaseService.instance.database;
      await db.transaction((txn) async {
        for (final change in changes) {
          final old = await txn.query(
            'section_subject_requirements',
            where: 'section_id=? AND subject_id=?',
            whereArgs: [change.$1, change.$2],
          );
          if (old.isEmpty) {
            if (change.$3 > 0)
              await txn.insert('section_subject_requirements', {
                'section_id': change.$1,
                'subject_id': change.$2,
                'weekly_lessons': change.$3,
                'max_daily_lessons': 2,
                'allow_same_day': 1,
              });
          } else {
            await txn.update(
              'section_subject_requirements',
              {'weekly_lessons': change.$3},
              where: 'section_id=? AND subject_id=?',
              whereArgs: [change.$1, change.$2],
            );
          }
        }
      });
      if (!mounted) return true;
      setState(() => _dirty.clear());
      if (refresh) widget.onChanged();
      showMessage(context, 'تم حفظ متطلبات الصفوف.');
      return true;
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر حفظ المتطلبات: $e', error: true);
      return false;
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _copy() async {
    if (widget.sections.length < 2) return;
    var from = widget.sections.first['id'], to = widget.sections.last['id'];
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, update) => AlertDialog(
          title: Text('نسخ أعداد حصص صف'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (final source in [true, false])
                DropdownButtonFormField<Object>(
                  initialValue: source ? from : to,
                  decoration: InputDecoration(
                    labelText: source ? 'من الصف' : 'إلى الصف',
                  ),
                  items: [
                    for (final s in widget.sections)
                      DropdownMenuItem(
                        value: s['id']!,
                        child: Text(
                          '${displayGradeName(s['grade_name'])} / ${s['section_name']}',
                        ),
                      ),
                  ],
                  onChanged: (v) => update(() {
                    if (source) {
                      from = v;
                    } else {
                      to = v;
                    }
                  }),
                ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text('إلغاء'),
            ),
            FilledButton(
              onPressed: from == to ? null : () => Navigator.pop(context, true),
              child: Text('نسخ إلى المسودة'),
            ),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    setState(() {
      for (final m in widget.subjects) {
        final a = widget.sections.firstWhere((s) => s['id'] == from),
            b = widget.sections.firstWhere((s) => s['id'] == to);
        _controller(b, m).text = _controller(a, m).text;
        _dirty.add(_key(to, m['id']));
      }
    });
  }

  Future<void> _openRules(
    Map<String, Object?> s,
    Map<String, Object?> m,
  ) async {
    if (!await _save(refresh: false) || !mounted) return;
    final rows = await DatabaseService.instance.requirementsDetailed();
    Map<String, Object?>? existing;
    for (final r in rows) {
      if (r['section_id'] == s['id'] && r['subject_id'] == m['id'])
        existing = r;
    }
    if (mounted) await widget.onRules(s, m, existing);
  }

  Widget _mobile() {
    if (widget.sections.isEmpty)
      return Center(child: Text('أضف صفاً من إعداد الجدول > الصفوف والشعب أولاً.'));
    final s = widget.sections.firstWhere(
      (s) => s['id'] == _selectedSection,
      orElse: () => widget.sections.first,
    );
    void adjust(Map<String, Object?> m, int amount) {
      setState(() {
        _controller(s, m).text = '${(_count(s, m) + amount).clamp(0, 999)}';
        _dirty.add(_key(s['id'], m['id']));
      });
    }

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              pageHeading(
                'الحصص المطلوبة',
                'اختر الصف ثم اضبط عدد حصص كل مادة.',
              ),
              DropdownButtonFormField<int>(
                initialValue: s['id'] as int,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'الصف / الشعبة'),
                items: [
                  for (final row in widget.sections)
                    DropdownMenuItem(
                      value: row['id'] as int,
                      child: Text(
                        '${displayGradeName(row['grade_name'])} · ${row['section_name']}',
                      ),
                    ),
                ],
                onChanged: _saving
                    ? null
                    : (v) => setState(() => _selectedSection = v),
              ),
              SizedBox(height: 12),
              Text(
                'إجمالي الصف: ${widget.subjects.fold<int>(0, (n, m) => n + _count(s, m))} حصة',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              Text(
                _dirty.isEmpty ? 'الأعداد المحفوظة' : 'تعديلات غير محفوظة',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  fontSize: 11,
                ),
              ),
              SizedBox(height: 12),
              for (final m in widget.subjects)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            '${m['name']}',
                            style: TextStyle(fontWeight: FontWeight.w700),
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              IconButton(
                                tooltip: 'تقليل الحصص',
                                onPressed: _saving ? null : () => adjust(m, -1),
                                icon: const Icon(Icons.remove),
                              ),
                              SizedBox(
                                width: 58,
                                child: TextField(
                                  key: ValueKey(
                                    'requirement-${s['id']}-${m['id']}',
                                  ),
                                  enabled: !_saving,
                                  controller: _controller(s, m),
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  onChanged: (_) => setState(
                                    () => _dirty.add(_key(s['id'], m['id'])),
                                  ),
                                ),
                              ),
                              IconButton(
                                tooltip: 'زيادة الحصص',
                                onPressed: _saving ? null : () => adjust(m, 1),
                                icon: const Icon(Icons.add),
                              ),
                              const Spacer(),
                              Flexible(
                                child: TextButton(
                                  onPressed: _saving
                                      ? null
                                      : () => _openRules(s, m),
                                  child: Text(
                                    'قواعد المادة',
                                    style: TextStyle(fontSize: 10),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              TextButton(
                onPressed: _saving ? null : _copy,
                child: Text('نسخ إعدادات صف'),
              ),
            ],
          ),
        ),
        if (_dirty.isNotEmpty)
          Container(
            key: const ValueKey('requirements-savebar'),
            padding: const EdgeInsets.all(12),
            color: Theme.of(context).colorScheme.surface,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('تعديلات غير محفوظة', style: TextStyle(fontSize: 11)),
                Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: _saving
                            ? null
                            : () {
                                setState(() {
                                  for (final s in widget.sections) {
                                    for (final m in widget.subjects) {
                                      _controller(s, m).text =
                                          '${_existing(s['id'], m['id'])?['weekly_lessons'] ?? 0}';
                                    }
                                  }
                                  _dirty.clear();
                                });
                              },
                        child: Text('تراجع'),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: FilledButton(
                        onPressed: _saving ? null : _save,
                        child: Text(_saving ? 'جارٍ الحفظ…' : 'حفظ المتطلبات'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) => MediaQuery.sizeOf(context).width < 700
      ? _mobile()
      : ListView(
          padding: const EdgeInsets.all(16),
          children: [
            pageHeading(
              'الحصص المطلوبة',
              'المواد والصفوف في شبكة واحدة. الأرقام العربية والإنجليزية مدعومة.',
            ),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: const Icon(Icons.check, size: 16),
                label: Text(_saving ? 'جارٍ الحفظ…' : 'حفظ المتطلبات'),
              ),
            ),
            SizedBox(height: 20),
            PreviewPanel(
              title: 'متطلبات الصفوف',
              subtitle: _dirty.isEmpty
                  ? 'الأعداد المحفوظة'
                  : 'تعديلات غير محفوظة',
              trailing: TextButton(
                onPressed: _saving ? null : _copy,
                child: Text('نسخ إعدادات صف', style: TextStyle(fontSize: 11)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                      horizontalMargin: 12,
                      columnSpacing: 20,
                      dataRowMinHeight: 88,
                      dataRowMaxHeight: 88,
                      headingRowColor: const WidgetStatePropertyAll(
                        Color(0xFFF8FAFB),
                      ),
                      columns: [
                        const DataColumn(label: Text('المادة')),
                        for (final s in widget.sections)
                          DataColumn(
                            label: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(displayGradeName(s['grade_name'])),
                                Text(
                                  'الشعبة ${s['section_name']}',
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceVariant,
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                      rows: [
                        for (final m in widget.subjects)
                          DataRow(
                            cells: [
                              DataCell(
                                Text(
                                  '${m['name']}',
                                  style: TextStyle(fontSize: 12),
                                ),
                              ),
                              for (final s in widget.sections)
                                DataCell(
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SizedBox(
                                        width: 64,
                                        height: 38,
                                        child: TextField(
                                          key: ValueKey(
                                            'requirement-${s['id']}-${m['id']}',
                                          ),
                                          enabled: !_saving,
                                          controller: _controller(s, m),
                                          keyboardType: TextInputType.number,
                                          textAlign: TextAlign.center,
                                          style: TextStyle(fontSize: 12),
                                          decoration: const InputDecoration(
                                            contentPadding:
                                                EdgeInsets.symmetric(
                                                  horizontal: 4,
                                                  vertical: 4,
                                                ),
                                          ),
                                          onChanged: (_) => setState(
                                            () => _dirty.add(
                                              _key(s['id'], m['id']),
                                            ),
                                          ),
                                        ),
                                      ),
                                      TextButton(
                                        style: TextButton.styleFrom(
                                          minimumSize: const Size(64, 32),
                                          padding: EdgeInsets.zero,
                                        ),
                                        onPressed: _saving
                                            ? null
                                            : () async {
                                                if (!await _save(
                                                      refresh: false,
                                                    ) ||
                                                    !mounted)
                                                  return;
                                                final rows =
                                                    await DatabaseService
                                                        .instance
                                                        .requirementsDetailed();
                                                Map<String, Object?>? existing;
                                                for (final r in rows) {
                                                  if (r['section_id'] ==
                                                          s['id'] &&
                                                      r['subject_id'] ==
                                                          m['id'])
                                                    existing = r;
                                                }
                                                if (mounted)
                                                  await widget.onRules(
                                                    s,
                                                    m,
                                                    existing,
                                                  );
                                              },
                                        child: Text(
                                          'قواعد المادة',
                                          style: TextStyle(fontSize: 10),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                        DataRow(
                          cells: [
                            const DataCell(Text('إجمالي الصف')),
                            for (final s in widget.sections)
                              DataCell(
                                Text(
                                  '${widget.subjects.fold<int>(0, (sum, m) => sum + _count(s, m))}',
                                ),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      'المجموع: ${widget.sections.fold<int>(0, (sum, s) => sum + widget.subjects.fold<int>(0, (n, m) => n + _count(s, m)))} حصة',
                      style: TextStyle(
                        fontSize: 12,
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
}
