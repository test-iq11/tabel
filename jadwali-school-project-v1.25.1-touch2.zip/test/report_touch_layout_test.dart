import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/features/reports/reports_page.dart';
import 'package:iraqi_school_timetable/services/reference_timetable_layout.dart';

import 'fixtures/original_report_preview.dart';

void main() {
  testWidgets(
    'interactive report preserves every unselected pixel and cell size',
    (tester) async {
      tester.view.physicalSize = const Size(1100, 1000);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await (FontLoader(
        'Report',
      )..addFont(rootBundle.load('assets/fonts/UI-Regular.ttf'))).load();
      final layout = ReferenceTimetableLayout(
        templateColumns: false,
        sections: [
          {
            'id': 1,
            'grade_name': 'السادس',
            'section_name': 'أ',
            'max_daily_lessons': 6,
          },
        ],
        days: [
          for (var d = 1; d <= 2; d++)
            {
              'id': d,
              'name': d == 1 ? 'الأحد' : 'الاثنين',
              'position': d,
              'is_active': 1,
            },
        ],
        slots: [
          for (var p = 1; p <= 7; p++)
            {
              'id': p,
              'name': '$p',
              'position': p,
              'kind': 'lesson',
              'is_available': 1,
            },
        ],
        entries: [
          {
            'id': 1,
            'section_id': 1,
            'day_id': 1,
            'slot_id': 1,
            'subject_name': 'العربية',
            'teacher_name': 'نور',
          },
          {
            'id': 2,
            'section_id': 1,
            'day_id': 1,
            'slot_id': 7,
            'subject_name': 'العلوم',
            'teacher_name': 'علي',
          },
        ],
      );
      final boundary = GlobalKey();
      Future<Uint8List> capture(Widget child) async {
        await tester.pumpWidget(
          MaterialApp(
            theme: ThemeData(fontFamily: 'Report'),
            home: Directionality(
              textDirection: TextDirection.rtl,
              child: Scaffold(
                body: RepaintBoundary(key: boundary, child: child),
              ),
            ),
          ),
        );
        await tester.pumpAndSettle();
        return (await tester.runAsync(() async {
          final img =
              await (boundary.currentContext!.findRenderObject()
                      as RenderRepaintBoundary)
                  .toImage();
          final bytes = (await img.toByteData(
            format: ui.ImageByteFormat.rawRgba,
          ))!.buffer.asUint8List();
          img.dispose();
          return bytes;
        }))!;
      }

      final original = await capture(
        OriginalReferenceTimetablePreview(
          layout: layout,
          school: 'مدرسة',
          number: '1',
          date: '',
          manager: '',
        ),
      );
      Map<String, Object?>? tapped;
      final interactive = await capture(
        ReferenceTimetablePreview(
          layout: layout,
          school: 'مدرسة',
          number: '1',
          date: '',
          manager: '',
          onLessonTap: (e) => tapped = e,
        ),
      );
      expect(interactive, orderedEquals(original));
      final first = find.byKey(const ValueKey('report-lesson-1-1-1'));
      expect(tester.getSize(first), const Size(152, 36));
      await tester.tap(first);
      await tester.pump();
      expect(tapped?['id'], 1);
      final seventh = find.byKey(const ValueKey('report-lesson-1-1-7'));
      await tester.tap(seventh);
      expect(tapped?['id'], 2);
      expect(tester.takeException(), isNull);
    },
  );
}
