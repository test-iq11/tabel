import 'conflict_detection_service.dart';

/// A swap exchanges the complete lesson payload; cell IDs and pins stay put.
class LessonSwapService {
  const LessonSwapService();
  static const payload = ['subject_id', 'teacher_id', 'room_id'];
  static const identity = [
    'id',
    'version_id',
    'section_id',
    'day_id',
    'slot_id',
    ...payload,
    'is_locked',
  ];

  List<Map<String, Object?>> proposed(
    List<Map<String, Object?>> board,
    Map<String, Object?> first,
    Map<String, Object?> second,
  ) => [
    for (final row in board)
      if (row['id'] == first['id'])
        {...row, for (final key in payload) key: second[key]}
      else if (row['id'] == second['id'])
        {...row, for (final key in payload) key: first[key]}
      else
        row,
  ];

  List<ConflictIssue> scan(
    Map<String, Object?> data,
    List<Map<String, Object?>> entries,
  ) {
    List<Map<String, Object?>> rows(String key) =>
        (data[key] as List? ?? const []).cast<Map<String, Object?>>();
    Object name(String table, Object? id) =>
        rows(table).where((r) => r['id'] == id).firstOrNull?['name'] ??
        id ??
        '';
    return const ConflictDetectionService().scan(
      entries: [
        for (final row in entries)
          {
            for (final e in row.entries)
              if (!e.key.endsWith('_name')) e.key: e.value,
            'teacher_name': name('teachers', row['teacher_id']),
            'subject_name': name('subjects', row['subject_id']),
            'day_name': name('days', row['day_id']),
            'slot_name': name('slots', row['slot_id']),
          },
      ],
      sections: rows('sections'),
      requirements: rows('requirements'),
      teachers: rows('teachers'),
      qualifications: rows('qualifications'),
      teacherGrades: rows('teacherGrades'),
      teacherSubjectGrades: rows('teacherSubjectGrades'),
      days: rows('days'),
      slots: rows('slots'),
      subjectBlockedSlots: rows('subjectBlockedSlots'),
      teacherAvailability: rows('availability'),
    );
  }

  static String issueKey(ConflictIssue i) =>
      '${i.type}:${i.message}:${i.sectionId}:${i.teacherId}:${i.subjectId}:${i.dayId}:${i.slotId}';

  String? validate(
    Map<String, Object?> data,
    Map<String, Object?> first,
    Map<String, Object?> second,
  ) {
    if (first['id'] == second['id']) return 'اختر حصتين مختلفتين.';
    if (first['subject_id'] == second['subject_id']) {
      return 'اختر مادة مختلفة؛ لا يمكن تبديل المادة مع نفسها حتى في يوم آخر.';
    }
    if (first['version_id'] != second['version_id'])
      return 'تغيرت النسخة النشطة؛ حدّث الجدول.';
    if (first['section_id'] != second['section_id']) {
      return 'اختر الحصة الثانية من الصف والشعبة نفسيهما حتى يبقى نصاب المواد محفوظاً.';
    }
    if (first['is_locked'] == 1 || second['is_locked'] == 1) {
      return 'إحدى الحصتين مقفلة. اضغط عليها مطولاً لفتح القفل أولاً.';
    }
    final board = (data['entries'] as List).cast<Map<String, Object?>>();
    final baseline = <String, int>{};
    for (final issue in scan(data, board)) {
      final k = issueKey(issue);
      baseline[k] = (baseline[k] ?? 0) + 1;
    }
    final issues = scan(data, proposed(board, first, second));
    for (final issue in issues) {
      // Repeat timing is a preference, not a reason to reject a manual swap.
      if (issue.type == 'تكرار توقيت المادة في أيام متتالية') continue;
      final k = issueKey(issue);
      if ((baseline[k] ?? 0) == 0) return issue.message;
      baseline[k] = baseline[k]! - 1;
    }
    return null;
  }
}
