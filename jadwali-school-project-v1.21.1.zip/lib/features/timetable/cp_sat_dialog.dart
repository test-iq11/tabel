import 'package:flutter/material.dart';

import '../../services/cp_sat_client.dart';

Future<Map<String, Object?>?> showCpSatDialog(
  BuildContext context, {
  required Map<String, Object?> input,
}) => showDialog<Map<String, Object?>>(
  context: context,
  barrierDismissible: false,
  builder: (_) => CpSatDialog(input: input),
);

/// Uses the same review/atomic-save path as the offline search. No DB writes.
class CpSatDialog extends StatefulWidget {
  const CpSatDialog({super.key, required this.input});
  final Map<String, Object?> input;
  @override
  State<CpSatDialog> createState() => _CpSatDialogState();
}

class _CpSatDialogState extends State<CpSatDialog> {
  final _endpoint = TextEditingController();
  final _token = TextEditingController();
  final _cancel = CpSatCancellation();
  String _profile = 'minimal_changes';
  int _seconds = 60;
  bool _busy = false;
  String? _error;
  Map<String, Object?>? _result;

  Future<void> _solve() async {
    setState(() {
      _busy = true;
      _error = null;
      _result = null;
    });
    try {
      final result = await const CpSatClient().solve(
        endpoint: Uri.parse(_endpoint.text.trim()),
        token: _token.text.trim(),
        input: {...widget.input, 'profile': _profile},
        timeout: Duration(seconds: _seconds + 10),
        cancellation: _cancel,
      );
      if (mounted) setState(() => _result = result);
    } catch (error) {
      if (mounted) setState(() => _error = 'تعذر إكمال الطلب: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final complete = _result?['complete'] == true;
    final quality = _result?['engineQuality'];
    return AlertDialog(
      title: const Text('محرك OR-Tools الرياضي'),
      content: SizedBox(
        width: 520,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'شغّل محرك المدرسة على الكمبيوتر، ثم أدخل عنوانه ورمز الوصول. عند التشغيل تُرسل بيانات التوزيع إلى هذا العنوان. البحث يشمل الأسبوع كله ويحافظ على الأقفال. لا يُحفظ الجدول قبل مراجعته.',
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _endpoint,
                enabled: !_busy,
                key: const ValueKey('cp-endpoint'),
                textDirection: TextDirection.ltr,
                keyboardType: TextInputType.url,
                decoration: const InputDecoration(
                  labelText: 'عنوان كمبيوتر المدرسة',
                  hintText: 'http://192.168.1.10:8765',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _token,
                enabled: !_busy,
                key: const ValueKey('cp-token'),
                obscureText: true,
                enableSuggestions: false,
                autocorrect: false,
                decoration: const InputDecoration(
                  labelText: 'رمز الوصول (16 حرفاً على الأقل)',
                ),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: _profile,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'أولوية التحسين بعد اكتمال الجدول',
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'minimal_changes',
                    child: Text('أقل تغييرات'),
                  ),
                  DropdownMenuItem(
                    value: 'teacher_gaps',
                    child: Text('تقليل فراغات المعلمين'),
                  ),
                  DropdownMenuItem(
                    value: 'balanced_subjects',
                    child: Text('توازن المواد وفصل التكرار'),
                  ),
                ],
                onChanged: _busy ? null : (v) => setState(() => _profile = v!),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                initialValue: _seconds,
                decoration: const InputDecoration(
                  labelText: 'الوقت المتاح للبحث والتحسين',
                ),
                items: [30, 60, 180]
                    .map(
                      (s) =>
                          DropdownMenuItem(value: s, child: Text('$s ثانية')),
                    )
                    .toList(),
                onChanged: _busy ? null : (v) => setState(() => _seconds = v!),
              ),
              if (_busy) ...[
                const SizedBox(height: 14),
                const LinearProgressIndicator(),
                const Text(
                  'البحث عن جدول كامل ثم تحسينه… إغلاق النافذة يوقف انتظار الهاتف؛ قد يكمل الكمبيوتر محاولته حتى المهلة.',
                ),
              ],
              if (_error != null)
                Text(
                  _error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
              if (_result != null) ...[
                const SizedBox(height: 14),
                Text(
                  complete
                      ? 'جدول كامل اجتاز فحص القيود داخل التطبيق.'
                      : '${_result!['message']}',
                ),
                if (complete)
                  Text(
                    _result!['qualityOptimal'] == true
                        ? 'ثبتت أفضلية النتيجة وفق معيار التحسين المختار.'
                        : 'هذه أفضل نتيجة وجدها المحرك ضمن المهلة؛ لم تثبت مثالية الجودة.',
                  ),
                if (quality is Map)
                  Text(
                    'فراغات المعلمين: ${quality['teacherGaps']} • حصص بقيت في مكانها: ${quality['retainedLessons']}',
                  ),
                for (final item in (_result!['diagnostics'] as List? ?? []))
                  if (item is Map)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text('• ${item['message']}'),
                    ),
              ],
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            _cancel.cancel();
            Navigator.of(context).pop();
          },
          child: const Text('إغلاق'),
        ),
        if (!complete)
          FilledButton(
            onPressed: _busy ? null : _solve,
            key: const ValueKey('cp-run'),
            child: const Text('تشغيل OR-Tools'),
          ),
        if (complete)
          FilledButton(
            onPressed: () => Navigator.of(context).pop(_result),
            child: const Text('إرسال الحل للمراجعة'),
          ),
      ],
    );
  }

  @override
  void dispose() {
    _cancel.cancel();
    _endpoint.dispose();
    _token.dispose();
    super.dispose();
  }
}
