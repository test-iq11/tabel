import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Values shared with jadwali-design-studio.html. Export/import is compatible.
@immutable
class DesignStyle {
  const DesignStyle({
    this.accent = const Color(0xff24776d),
    this.a = const Color(0xff174d48),
    this.b = const Color(0xff459480),
    this.background = const Color(0xfff4f6f2),
    this.angle = 125,
    this.radius = 30,
    this.round = 23,
    this.shadow = 12,
    this.pattern = 'rings',
    this.texture = 10,
    this.mode = 'gradient',
    this.density = 100,
    this.motion = true,
    this.safe = true,
    this.focus = false,
  });
  final Color accent, a, b, background;
  final double angle, radius, round, shadow, texture, density;
  final String pattern, mode;
  final bool motion, safe, focus;
  static String hex(Color c) =>
      '#${(c.toARGB32() & 0xffffff).toRadixString(16).padLeft(6, '0')}';
  static Color? parseColor(Object? value) =>
      value is String && RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(value)
      ? Color(0xff000000 | int.parse(value.substring(1), radix: 16))
      : null;
  Map<String, Object> toMap() => {
    'accent': hex(accent),
    'a': hex(a),
    'b': hex(b),
    'background': hex(background),
    'angle': angle,
    'radius': radius,
    'round': round,
    'shadow': shadow,
    'pattern': pattern,
    'texture': texture,
    'mode': mode,
    'density': density,
    'motion': motion,
    'safe': safe,
    'focus': focus,
  };
  factory DesignStyle.fromMap(Map data) {
    double number(String key, double fallback, double min, double max) {
      final n = double.tryParse('${data[key]}');
      return n != null && n.isFinite ? n.clamp(min, max) : fallback;
    }

    bool flag(String k, bool fallback) =>
        data[k] is bool ? data[k] as bool : fallback;
    return DesignStyle(
      accent: parseColor(data['accent']) ?? const Color(0xff24776d),
      a: parseColor(data['a']) ?? const Color(0xff174d48),
      b: parseColor(data['b']) ?? const Color(0xff459480),
      background: parseColor(data['background']) ?? const Color(0xfff4f6f2),
      angle: number('angle', 125, 0, 360),
      radius: number('radius', 30, 0, 48),
      round: number('round', 23, 8, 32),
      shadow: number('shadow', 12, 0, 30),
      texture: number('texture', 10, 0, 30),
      density: number('density', 100, 85, 115),
      pattern: ['rings', 'dots', 'lines', 'none'].contains(data['pattern'])
          ? data['pattern']
          : 'rings',
      mode: data['mode'] == 'solid' ? 'solid' : 'gradient',
      motion: flag('motion', true),
      safe: flag('safe', true),
      focus: flag('focus', false),
    );
  }
  DesignStyle change(String key, Object value) =>
      DesignStyle.fromMap({...toMap(), key: value});
  static Color mix(Color a, Color b, double amount) =>
      Color.lerp(a, b, amount)!;
  static double contrast(Color a, Color b) {
    final x = a.computeLuminance(), y = b.computeLuminance();
    return (math.max(x, y) + .05) / (math.min(x, y) + .05);
  }

  static Color foreground(Color a, [Color? b]) {
    b ??= a;
    const dark = Color(0xff142d2a);
    return math.min(contrast(Colors.white, a), contrast(Colors.white, b)) >=
            math.min(contrast(dark, a), contrast(dark, b))
        ? Colors.white
        : dark;
  }

  (Color, Color, Color, bool) get heroColors {
    var first = a, last = mode == 'solid' ? a : b;
    final text = foreground(first, last);
    var correction = 0.0;
    if (safe) {
      while (math.min(contrast(text, first), contrast(text, last)) < 4.6 &&
          correction < .8) {
        correction += .05;
        final target = text == Colors.white ? Colors.black : Colors.white;
        first = mix(a, target, correction);
        last = mix(mode == 'solid' ? a : b, target, correction);
      }
    }
    return (first, last, text, correction > 0);
  }

  Color primary(bool dark) => dark ? mix(accent, Colors.white, .4) : accent;
  Color soft(bool dark) => mix(
    accent,
    dark ? const Color(0xff20283c) : Colors.white,
    dark ? .72 : .9,
  );
  LinearGradient get heroGradient {
    final radians = angle * math.pi / 180, c = heroColors;
    final end = Alignment(math.sin(radians), -math.cos(radians));
    return LinearGradient(
      begin: Alignment(-end.x, -end.y),
      end: end,
      colors: [c.$1, c.$2],
    );
  }

  static const presets = [
    ('حديقة', '#24776d', '#174d48', '#459480', '#f4f6f2'),
    ('لافندر', '#7962b7', '#403365', '#967dc4', '#f6f4fa'),
    ('محيط', '#326d9b', '#1b385a', '#4288a5', '#f2f6fa'),
    ('غروب', '#a66046', '#713e47', '#c68b57', '#faf5f0'),
    ('وردي', '#a4597c', '#642e51', '#b77d99', '#faf3f6'),
    ('رمل', '#897047', '#514a37', '#b39d76', '#f8f6f0'),
    ('ليلي', '#5c6e9b', '#1b263c', '#4c5976', '#f3f5f9'),
    ('نعناع', '#397965', '#2e6555', '#95b9a0', '#f3f8f3'),
  ];
  DesignStyle preset(int index) {
    final p = presets[index];
    return DesignStyle.fromMap({
      ...toMap(),
      'accent': p.$2,
      'a': p.$3,
      'b': p.$4,
      'background': p.$5,
    });
  }
}
