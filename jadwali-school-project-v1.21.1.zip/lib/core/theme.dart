import 'package:flutter/material.dart';

import 'design_style.dart';

ThemeData buildAppTheme({
  String style = 'calm',
  bool dark = false,
  DesignStyle design = const DesignStyle(),
}) {
  final primary = design.primary(dark), soft = design.soft(dark);
  final surface = dark ? const Color(0xff20283c) : Colors.white;
  final background = dark ? const Color(0xff121c23) : design.background;
  final ink = dark ? const Color(0xffeef0fa) : const Color(0xff25324a);
  final muted = dark ? const Color(0xffaab5cd) : const Color(0xff758096);
  final line = dark ? const Color(0xff333d55) : const Color(0xffe8ebf3);
  final scheme =
      ColorScheme.fromSeed(
        seedColor: primary,
        brightness: dark ? Brightness.dark : Brightness.light,
      ).copyWith(
        primary: primary,
        onPrimary: DesignStyle.foreground(primary),
        primaryContainer: soft,
        onPrimaryContainer: primary,
        secondary: primary,
        surface: surface,
        surfaceContainer: surface,
        surfaceContainerLow: surface,
        surfaceContainerHigh: surface,
        surfaceContainerHighest: soft,
        onSurface: ink,
        onSurfaceVariant: muted,
        outlineVariant: line,
      );
  final border = OutlineInputBorder(
    borderRadius: BorderRadius.circular(12),
    borderSide: BorderSide(color: line),
  );
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'JadwaliStudio',
    fontFamilyFallback: const ['JadwaliLatin'],
    colorScheme: scheme,
    scaffoldBackgroundColor: background,
    dialogTheme: DialogThemeData(
      backgroundColor: surface,
      surfaceTintColor: Colors.transparent,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: background,
      foregroundColor: ink,
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
    ),
    iconTheme: IconThemeData(color: primary),
    listTileTheme: ListTileThemeData(
      iconColor: primary,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 3),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    dividerTheme: DividerThemeData(color: line, thickness: 1, space: 1),
    cardTheme: CardThemeData(
      color: surface,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(design.round),
        side: BorderSide(color: line),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surface,
      border: border,
      enabledBorder: border,
      focusedBorder: border.copyWith(
        borderSide: BorderSide(color: primary, width: 1.7),
      ),
      prefixIconColor: primary,
      suffixIconColor: muted,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: primary,
        foregroundColor: scheme.onPrimary,
        minimumSize: const Size(44, 46),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: primary,
        minimumSize: const Size(44, 44),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: surface,
      selectedColor: soft,
      secondarySelectedColor: soft,
      labelStyle: TextStyle(
        fontFamily: 'JadwaliStudio',
        fontFamilyFallback: const ['JadwaliLatin'],
        color: ink,
      ),
      secondaryLabelStyle: TextStyle(color: primary),
      side: BorderSide(color: line),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(99)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: surface,
      surfaceTintColor: Colors.transparent,
      indicatorColor: soft,
    ),
    bottomSheetTheme: BottomSheetThemeData(backgroundColor: surface),
    textTheme: TextTheme(
      headlineSmall: TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.w700,
        color: ink,
      ),
      titleLarge: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: ink,
      ),
      titleMedium: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: ink,
      ),
      bodyLarge: TextStyle(fontSize: 15, height: 1.7, color: ink),
      bodyMedium: TextStyle(fontSize: 13, height: 1.7, color: ink),
      bodySmall: TextStyle(fontSize: 11, height: 1.7, color: muted),
    ),
  );
}
