import 'package:flutter/material.dart';

import 'interface_settings.dart';

class SmartPanel extends StatelessWidget {
  const SmartPanel({super.key, required this.child, this.tint = false});
  final Widget child;
  final bool tint;
  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: EdgeInsets.all(
        22 * InterfaceSettings.instance.design.density / 100,
      ),
      decoration: BoxDecoration(
        color: colors.surface,
        gradient: tint
            ? LinearGradient(
                colors: [
                  colors.surface,
                  InterfaceSettings.instance.design.soft(
                    Theme.of(context).brightness == Brightness.dark,
                  ),
                ],
              )
            : null,
        border: Border.all(color: colors.outlineVariant.withValues(alpha: .45)),
        borderRadius: BorderRadius.circular(
          InterfaceSettings.instance.design.round,
        ),
      ),
      child: Material(type: MaterialType.transparency, child: child),
    );
  }
}

class SmartBadge extends StatelessWidget {
  const SmartBadge(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.primary.withValues(alpha: .08),
      borderRadius: BorderRadius.circular(9),
    ),
    child: Text(
      text,
      style: TextStyle(
        color: Theme.of(context).colorScheme.primary,
        fontSize: 11,
      ),
    ),
  );
}

class SmartHeading extends StatelessWidget {
  const SmartHeading(this.text, {super.key, this.action});
  final String text;
  final Widget? action;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 26, bottom: 14),
    child: Row(
      children: [
        Expanded(
          child: Text(
            text,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          ),
        ),
        ?action,
      ],
    ),
  );
}
