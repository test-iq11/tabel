import 'package:flutter/material.dart';

import 'interface_settings.dart';

const designInk = Color(0xFF28314F);
const designMuted = Color(0xFF6F758B);
const designAccent = Color(0xFF24776D);
const designTones = [
  (Color(0xFFEDE7FB), Color(0xFF6952A2)),
  (Color(0xFFE2F1EC), Color(0xFF367C6B)),
  (Color(0xFFF9EADE), Color(0xFF9B633D)),
  (Color(0xFFE5EEF9), Color(0xFF4D709B)),
];

class ActionTile extends StatefulWidget {
  const ActionTile({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
    this.tone = 0,
    super.key,
  });
  final String title, subtitle;
  final IconData icon;
  final VoidCallback onTap;
  final int tone;
  @override
  State<ActionTile> createState() => _ActionTileState();
}

class _ActionTileState extends State<ActionTile> {
  bool pressed = false;
  @override
  Widget build(BuildContext context) {
    final colors = widget.tone == 0
        ? (
            InterfaceSettings.instance.design.soft(
              Theme.of(context).brightness == Brightness.dark,
            ),
            Theme.of(context).colorScheme.primary,
          )
        : Theme.of(context).brightness == Brightness.dark
        ? const [
            (Color(0xFF39304F), Color(0xFFE1D2FF)),
            (Color(0xFF24443F), Color(0xFFB4E8D6)),
            (Color(0xFF4B3931), Color(0xFFF5CFAE)),
            (Color(0xFF2B3C58), Color(0xFFC1DAFA)),
          ][widget.tone % 4]
        : designTones[widget.tone % designTones.length];
    return AnimatedScale(
      scale: pressed ? .97 : 1,
      duration: MediaQuery.disableAnimationsOf(context)
          ? Duration.zero
          : const Duration(milliseconds: 150),
      child: Material(
        color: colors.$1,
        borderRadius: BorderRadius.circular(
          InterfaceSettings.instance.design.round,
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(
            InterfaceSettings.instance.design.round,
          ),
          onTap: widget.onTap,
          onHighlightChanged: (v) => setState(() => pressed = v),
          child: Padding(
            padding: EdgeInsets.all(
              16 * InterfaceSettings.instance.design.density / 100,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(9),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(
                          alpha: Theme.of(context).brightness == Brightness.dark
                              ? .08
                              : .65,
                        ),
                        borderRadius: BorderRadius.circular(13),
                      ),
                      child: Icon(widget.icon, color: colors.$2, size: 23),
                    ),
                    const Spacer(),
                    Icon(Icons.north_west, color: colors.$2, size: 18),
                  ],
                ),
                const SizedBox(height: 14),
                Text(
                  widget.title,
                  style: TextStyle(
                    color: colors.$2,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  widget.subtitle,
                  style: TextStyle(color: colors.$2, fontSize: 11, height: 1.8),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ActionGrid extends StatelessWidget {
  const ActionGrid({required this.children, super.key});
  final List<Widget> children;
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, c) {
      final columns = c.maxWidth > 850
          ? (children.length == 3 ? 3 : 4)
          : c.maxWidth < 300 || MediaQuery.textScalerOf(context).scale(1) > 1.2
          ? 1
          : 2;
      return Wrap(
        spacing: 12,
        runSpacing: 12,
        children: [
          for (final child in children)
            SizedBox(
              width:
                  children.length == 3 && columns == 2 && child == children.last
                  ? c.maxWidth
                  : (c.maxWidth - 12 * (columns - 1)) / columns,
              child: child,
            ),
        ],
      );
    },
  );
}

class ScreenEntrance extends StatefulWidget {
  const ScreenEntrance({required this.child, required this.page, super.key});
  final Widget child;
  final int page;
  @override
  State<ScreenEntrance> createState() => _ScreenEntranceState();
}

class _ScreenEntranceState extends State<ScreenEntrance>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 320),
    value: 1,
  );
  @override
  void didUpdateWidget(covariant ScreenEntrance oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.page != widget.page) {
      if (MediaQuery.disableAnimationsOf(context)) {
        _controller.value = 1;
      } else {
        _controller.forward(from: 0);
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _controller,
    child: widget.child,
    builder: (_, child) {
      final value = Curves.easeOutCubic.transform(_controller.value);
      return Opacity(
        opacity: value,
        child: Transform.translate(
          offset: Offset(0, 12 * (1 - value)),
          child: child,
        ),
      );
    },
  );
}
