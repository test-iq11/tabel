import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'design_style.dart';

class SchoolHero extends StatelessWidget {
  const SchoolHero({
    super.key,
    required this.design,
    required this.name,
    this.count = 0,
    this.requested = 0,
    this.sections = 0,
    this.days = 0,
    this.teachers = 0,
    this.preview = false,
    this.onCustomize,
    this.onTimetable,
    this.onScenario,
  });
  final DesignStyle design;
  final String name;
  final int count, requested, sections, days, teachers;
  final bool preview;
  final VoidCallback? onCustomize, onTimetable, onScenario;
  @override
  Widget build(BuildContext context) {
    final ink = design.heroColors.$3;
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(design.radius),
        boxShadow: [
          BoxShadow(
            color: const Color(0xff14322d)
                .withValues(alpha: preview ? .08 : design.shadow / 100),
            blurRadius: preview ? 12 : 38,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(design.radius),
        child: DecoratedBox(
          decoration: BoxDecoration(gradient: design.heroGradient),
          child: CustomPaint(
            painter: _HeroPattern(design),
            child: Material(
              type: MaterialType.transparency,
              child: DefaultTextStyle(
                style: TextStyle(
                  fontFamily: 'JadwaliStudio',
                  fontFamilyFallback: const ['JadwaliLatin'],
                  color: ink,
                  fontSize: 13,
                  height: 1.7,
                ),
                child: Padding(
                  padding: EdgeInsets.all(
                    preview
                        ? 18
                        : (MediaQuery.sizeOf(context).width < 700 ? 24 : 32) *
                              design.density /
                              100,
                  ),
                  child: preview
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'معاينة البطاقة',
                              style: TextStyle(
                                fontSize: 10,
                                color: ink.withValues(alpha: .8),
                              ),
                            ),
                            Text(
                              name.isEmpty ? 'المدرسة' : name,
                              style: const TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.w700,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const Text(
                              'ألوانك وتفاصيلك، كما تختارها',
                              style: TextStyle(fontSize: 10),
                            ),
                          ],
                        )
                      : LayoutBuilder(
                          builder: (context, c) {
                            final narrow =
                                c.maxWidth < 620 ||
                                MediaQuery.textScalerOf(context).scale(1) >
                                    1.25;
                            final title = Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 11,
                                        vertical: 6,
                                      ),
                                      decoration: BoxDecoration(
                                        color: ink.withValues(alpha: .08),
                                        borderRadius: BorderRadius.circular(99),
                                      ),
                                      child: Text(
                                        'أسبوع دراسي · $days أيام',
                                        style: const TextStyle(fontSize: 10),
                                      ),
                                    ),
                                    if (onCustomize != null)
                                      OutlinedButton.icon(
                                        key: const ValueKey(
                                          'customize-school-card',
                                        ),
                                        onPressed: onCustomize,
                                        style: OutlinedButton.styleFrom(
                                          foregroundColor: ink,
                                          side: BorderSide(
                                            color: ink.withValues(alpha: .25),
                                          ),
                                          minimumSize: const Size(44, 36),
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 12,
                                          ),
                                          shape: const StadiumBorder(),
                                        ),
                                        icon: const Icon(Icons.tune, size: 16),
                                        label: const Text(
                                          'صمّم بطاقتك',
                                          style: TextStyle(fontSize: 10),
                                        ),
                                      ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  name.isEmpty ? 'المدرسة' : name,
                                  style: TextStyle(
                                    fontSize: narrow ? 31 : 40,
                                    fontWeight: FontWeight.w700,
                                    height: 1.5,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  'جدولك واضح. وأدواتك أقرب إليك.',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: ink.withValues(alpha: .85),
                                  ),
                                ),
                                const SizedBox(height: 20),
                                Wrap(
                                  spacing: 10,
                                  runSpacing: 8,
                                  children: [
                                    FilledButton.icon(
                                      onPressed: onTimetable,
                                      style: FilledButton.styleFrom(
                                        backgroundColor: Colors.white
                                            .withValues(alpha: .94),
                                        foregroundColor: const Color(
                                          0xff203a35,
                                        ),
                                      ),
                                      icon: const Icon(
                                        Icons.calendar_month_outlined,
                                        size: 18,
                                      ),
                                      label: const Text(
                                        'استعرض الجدول',
                                        style: TextStyle(fontSize: 11),
                                      ),
                                    ),
                                    OutlinedButton.icon(
                                      onPressed: onScenario,
                                      style: OutlinedButton.styleFrom(
                                        foregroundColor: ink,
                                        side: BorderSide(
                                          color: ink.withValues(alpha: .2),
                                        ),
                                        backgroundColor: ink.withValues(
                                          alpha: .07,
                                        ),
                                      ),
                                      icon: const Icon(
                                        Icons.auto_awesome_outlined,
                                        size: 18,
                                      ),
                                      label: const Text(
                                        'جرّب تغييراً',
                                        style: TextStyle(fontSize: 11),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            );
                            final stats = Container(
                              padding: const EdgeInsets.all(18),
                              decoration: BoxDecoration(
                                color: ink.withValues(alpha: .07),
                                border: Border.all(
                                  color: ink.withValues(alpha: .18),
                                ),
                                borderRadius: BorderRadius.circular(22),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    'حصص الأسبوع',
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: ink.withValues(alpha: .8),
                                    ),
                                  ),
                                  Text(
                                    '$count حصة',
                                    style: const TextStyle(
                                      fontSize: 29,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  Text(
                                    'من $requested مطلوبة',
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: ink.withValues(alpha: .8),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(9),
                                    child: LinearProgressIndicator(
                                      value: requested > 0
                                          ? (count / requested).clamp(0, 1)
                                          : 0,
                                      minHeight: 5,
                                      color: ink.withValues(alpha: .7),
                                      backgroundColor: ink.withValues(
                                        alpha: .15,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Wrap(
                                    spacing: 12,
                                    runSpacing: 4,
                                    children: [
                                      Text(
                                        '$sections صفوف',
                                        style: const TextStyle(fontSize: 10),
                                      ),
                                      Text(
                                        '$days أيام',
                                        style: const TextStyle(fontSize: 10),
                                      ),
                                      Text(
                                        '$teachers معلماً',
                                        style: const TextStyle(fontSize: 10),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                            return narrow
                                ? Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.stretch,
                                    children: [
                                      title,
                                      const SizedBox(height: 22),
                                      stats,
                                    ],
                                  )
                                : Row(
                                    children: [
                                      Expanded(child: title),
                                      const SizedBox(width: 25),
                                      SizedBox(width: 230, child: stats),
                                    ],
                                  );
                          },
                        ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _HeroPattern extends CustomPainter {
  const _HeroPattern(this.design);
  final DesignStyle design;
  @override
  void paint(Canvas canvas, Size size) {
    if (design.pattern == 'none' || design.texture == 0) return;
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    final p = Paint()
      ..color = design.heroColors.$3.withValues(alpha: design.texture / 100)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    switch (design.pattern) {
      case 'rings':
        final center = const Offset(180, 70);
        for (final r in [250.0, 315.0, 380.0]) {
          canvas.drawCircle(center, r, p);
        }
      case 'dots':
        p.style = PaintingStyle.fill;
        for (var x = 10.0; x < size.width; x += 20) {
          for (var y = 10.0; y < size.height; y += 20) {
            canvas.drawCircle(Offset(x, y), 1, p);
          }
        }
      case 'lines':
        final extent = math.max(size.width, size.height);
        for (var x = -extent; x < size.width + extent; x += 36) {
          canvas.drawLine(
            Offset(x, 0),
            Offset(x + size.height, size.height),
            p,
          );
        }
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(_HeroPattern old) => old.design != design;
}
