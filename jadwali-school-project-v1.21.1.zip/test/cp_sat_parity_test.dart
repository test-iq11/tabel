import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';

void main() {
  final cases = jsonDecode(
    File('test/fixtures/cp_sat_regression.json').readAsStringSync(),
  ) as List;
  for (final value in cases) {
    final item = Map<String, Object?>.from(value as Map);
    test(
      'independent phone validator accepts actual OR-Tools: ${item['name']}',
      () {
        final input = Map<String, Object?>.from(item['input'] as Map);
        final result = Map<String, Object?>.from(item['result'] as Map);
        final rows = (result['placements'] as List)
            .map((r) => Map<String, Object?>.from(r as Map))
            .toList();
        expect(rows, hasLength(181));
        expect(ScheduleImprovementService.valid(input, rows), isTrue);
        expect(
          result['objective'] as num,
          lessThanOrEqualTo(result['initialObjective'] as num),
        );
        final seventh = rows.where((r) => r['slot_id'] == 7).toList();
        expect(seventh, hasLength(1));
        expect(seventh.single['section_id'], 11);
        expect(seventh.single['day_id'], 1);
      },
    );
  }
}
