"""Generate actual OR-Tools outputs for independent validation by Flutter.
Run from project root: python -m ci.cp_sat_regression
"""
import copy
import json
from pathlib import Path
from cp_sat_engine.solver import solve


def main():
    root = Path(__file__).resolve().parents[1]
    source = json.loads((root/'test/fixtures/backup_school_181.json').read_text())
    cases = []
    for name, blocks, profile, seed, pinned in [
        ('181 baseline', [], 'minimal_changes', True, False),
        ('181 from scratch', [], 'minimal_changes', False, False),
        ('181 first blocked', [1], 'minimal_changes', True, False),
        ('181 second blocked', [2], 'minimal_changes', True, False),
        ('181 first and second blocked', [1,2], 'minimal_changes', False, False),
        ('181 locks and restriction', [1,2], 'minimal_changes', True, True),
        ('181 teacher gaps', [], 'teacher_gaps', True, False),
        ('181 balanced and spaced', [], 'balanced_subjects', True, False),
    ]:
        data=copy.deepcopy(source)
        data['profile']=profile
        data['subjectBlockedSlots']=[dict(subject_id=2,slot_id=s) for s in blocks]
        if pinned:
            data['lockedPlacements']=[r for r in source['initialPlacements']
                                     if r['subject_id']!=2][:3]
        if not seed:data['initialPlacements']=[]
        result=solve(data,15)
        if result['status'] not in ('OPTIMAL','FEASIBLE'):
            raise AssertionError(f'{name}: {result}')
        cases.append(dict(name=name,input=data,result=result))
        print(name, result['status'], len(result['placements']), round(result['wallTime'],2), flush=True)
    path=root/'test/fixtures/cp_sat_regression.json'
    path.write_text(json.dumps(cases,ensure_ascii=False,separators=(',',':')))


if __name__=='__main__':main()
