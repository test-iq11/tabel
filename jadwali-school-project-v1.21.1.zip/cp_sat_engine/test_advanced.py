"""Real CP-SAT regressions, including cross-day repair and soft preferences."""
import copy
import json
import unittest
from pathlib import Path
from .solver import solve
from . import test_solver


class AdvancedTests(unittest.TestCase):
    def setUp(self):
        fixture = test_solver.CpSatTests(); fixture.setUp()
        self.data = copy.deepcopy(fixture.small)

    def solved(self, data=None, seconds=3):
        result = solve(data or self.data, seconds)
        self.assertIn(result['status'], ('OPTIMAL', 'FEASIBLE'), result)
        rows = result['placements']
        self.assertEqual(len(rows), sum(r['weekly_lessons'] for r in (data or self.data)['requirements']))
        self.assertEqual(len({(r['section_id'], r['day_id'], r['slot_id']) for r in rows}), len(rows))
        self.assertEqual(len({(r['teacher_id'], r['day_id'], r['slot_id']) for r in rows}), len(rows))
        self.assertLessEqual(result['objective'], result['initialObjective'])
        return result

    def test_repairs_another_day_not_only_problem_day(self):
        self.data['slots'] = self.data['slots'][:1]
        self.data['requirements'][0]['weekly_lessons'] = 1
        self.data['requirements'].append(dict(self.data['requirements'][0], subject_id=2))
        self.data['teachers'].append(dict(self.data['teachers'][0], id=2))
        self.data['qualifications'].append({'teacher_id': 2, 'subject_id': 2})
        self.data['initialPlacements'] = [
            dict(section_id=1, subject_id=1, teacher_id=1, day_id=1, slot_id=1),
            dict(section_id=1, subject_id=2, teacher_id=2, day_id=2, slot_id=1)]
        self.data['teacherAvailability'] = [dict(teacher_id=1, day_id=1, slot_id=1, is_available=0)]
        rows = self.solved()['placements']
        self.assertEqual({(r['subject_id'], r['day_id']) for r in rows}, {(1, 2), (2, 1)})

    def test_spacing_preference_and_flexible_fallback(self):
        self.data['days'] = self.data['days'][:1]
        self.data['slots'] = [dict(id=i, position=i-1, kind='lesson') for i in range(1,7)]
        self.data['requirements'][0].update(allow_same_day=1, max_daily_lessons=2)
        self.data['profile'] = 'balanced_subjects'
        result = self.solved()
        periods = sorted(r['slot_id'] for r in result['placements'])
        self.assertLessEqual(periods[0], 3); self.assertEqual(periods[1], 6)
        self.assertEqual(result['quality']['repeatSpacingPenalty'], 0)
        self.data['subjectBlockedSlots'] = [dict(subject_id=1,slot_id=i) for i in (1,2,3)]
        result = self.solved()
        self.assertTrue(all(r['slot_id'] >= 4 for r in result['placements']))

    def test_minimal_changes_is_strictly_primary(self):
        self.data['initialPlacements'] = [
            dict(section_id=1,subject_id=1,teacher_id=1,day_id=1,slot_id=2),
            dict(section_id=1,subject_id=1,teacher_id=1,day_id=2,slot_id=2)]
        result = self.solved()
        self.assertEqual(result['quality']['retainedLessons'], 2)
        self.assertTrue(result['qualityOptimal'])

    def test_shared_teacher_weekly_bottleneck_explained(self):
        self.data['teachers'][0]['weekly_load'] = 1
        result = solve(self.data,3)
        self.assertEqual(result['status'],'INFEASIBLE')
        self.assertIn('teacher_week',{r['code'] for r in result['diagnostics']})
        self.assertEqual(result['diagnosticScope'],'sufficient_not_minimal')

    def test_conflicting_locks_are_explained_not_removed(self):
        self.data['requirements'][0].update(allow_same_day=1,max_daily_lessons=2)
        self.data['lockedPlacements'] = [dict(section_id=1,subject_id=1,teacher_id=1,day_id=1,slot_id=i) for i in (1,2)]
        result = solve(self.data,3)
        self.assertEqual(result['status'],'INFEASIBLE')
        self.assertIn('lock',{r['code'] for r in result['diagnostics']})

    def test_break_interrupts_consecutive_limit(self):
        self.data['days'] = self.data['days'][:1]
        self.data['slots'][1]['position'] = 2
        self.data['requirements'][0].update(allow_same_day=1,max_daily_lessons=2)
        self.solved()

    def test_missing_teacher_limits_are_not_invented(self):
        self.data['teachers'] = [{'id':1}]
        self.solved()

    def test_changed_teacher_pool_and_nonsequential_identifiers(self):
        self.data['teachers'].append(dict(self.data['teachers'][0],id=777))
        self.data['qualifications'].append(dict(teacher_id=777,subject_id=1))
        self.solved()
        self.data['teachers'] = self.data['teachers'][1:]
        result = self.solved()
        self.assertTrue(all(r['teacher_id']==777 for r in result['placements']))

    def test_negative_zero_duplicate_and_bad_demands(self):
        for n in (-1, 1.5, 'oops'):
            data=copy.deepcopy(self.data);data['requirements'][0]['weekly_lessons']=n
            self.assertEqual(solve(data,1)['status'],'INVALID_INPUT')
        self.data['requirements'].append(dict(self.data['requirements'][0],weekly_lessons=0))
        self.assertEqual(solve(self.data,1)['status'],'INVALID_INPUT')

    def test_duplicate_ids_and_overlapping_times(self):
        data=copy.deepcopy(self.data);data['teachers'].append(data['teachers'][0])
        self.assertEqual(solve(data,1)['status'],'INVALID_INPUT')
        for row in self.data['slots']:row.update(start_time='08:00',end_time='08:45')
        self.assertEqual(solve(self.data,1)['status'],'INVALID_INPUT')

    def test_tied_positions_use_start_time_not_id(self):
        self.data['slots'] = [dict(id=99,position=5,kind='lesson',start_time='08:00',end_time='08:40'),
                              dict(id=1,position=5,kind='lesson',start_time='09:00',end_time='09:40')]
        self.solved()

    def test_no_seed_and_first_two_periods_blocked_on_real_school(self):
        data=json.loads((Path(__file__).resolve().parents[1]/'test/fixtures/backup_school_181.json').read_text())
        data['initialPlacements']=[]
        data['subjectBlockedSlots']=[dict(subject_id=2,slot_id=i) for i in (1,2)]
        result=self.solved(data,15)
        self.assertEqual(len(result['placements']),181)
        self.assertFalse(any(r['subject_id']==2 and r['slot_id'] in (1,2) for r in result['placements']))
        self.assertEqual(sum(r['slot_id']==7 for r in result['placements']),1)


if __name__=='__main__': unittest.main()
