import http.client
import json
import threading
import unittest
from http.server import ThreadingHTTPServer
from unittest.mock import patch
from . import server


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.token=patch.object(server,'TOKEN','1234567890abcdef'); self.token.start()
        self.http=ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
        self.thread=threading.Thread(target=self.http.serve_forever,daemon=True); self.thread.start()

    def tearDown(self):
        self.http.shutdown();self.http.server_close();self.thread.join();self.token.stop()

    def request(self,body,token='1234567890abcdef',length=None):
        connection=http.client.HTTPConnection('127.0.0.1',self.http.server_port,timeout=5)
        headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'}
        if length is not None:headers['Content-Length']=length
        connection.request('POST','/solve',body,headers)
        response=connection.getresponse(); result=json.loads(response.read());connection.close()
        return response.status,result

    def test_authentication_required(self):
        self.assertEqual(self.request('{}',token='wrong')[0],401)

    def test_malformed_length_is_handled(self):
        self.assertEqual(self.request('{}',length='oops')[0],400)

    def test_invalid_body_releases_search_slot(self):
        self.assertEqual(self.request('not json')[0],400)
        with patch.object(server,'solve',return_value={'status':'UNKNOWN'}) as solve:
            code,result=self.request('{"input":{}}')
            self.assertEqual(code,200);self.assertEqual(result['status'],'UNKNOWN');solve.assert_called_once()

    def test_busy_engine_does_not_start_second_job(self):
        server.SEARCH_SLOT.acquire()
        try:
            with patch.object(server,'solve') as solve:
                code,result=self.request('{"input":{}}')
                self.assertEqual(code,503);self.assertEqual(result['status'],'busy');solve.assert_not_called()
        finally:server.SEARCH_SLOT.release()

    def test_failure_releases_search_slot(self):
        with patch.object(server,'solve',side_effect=RuntimeError('private data')):
            code,result=self.request('{"input":{}}')
            self.assertEqual(code,500);self.assertNotIn('private data',json.dumps(result))
        self.assertTrue(server.SEARCH_SLOT.acquire(False));server.SEARCH_SLOT.release()
