"""Soft objectives only. No preference may remove a feasible timetable."""
from collections import defaultdict


def placement_key(row):
    return tuple(int(row.get(k) or 0) for k in
                 ('section_id', 'subject_id', 'teacher_id', 'day_id', 'slot_id'))


def pair_penalty(a, b):
    # Prefer first occurrence in periods 1–3, second in 6–7, but stay flexible.
    return (3 if a >= 3 else 0) + (4 if b < 5 else 0) + max(0, 3 - (b - a))


def build_objective(model, payload, variables, days, slots):
    teacher_cells, group_cells, section_days = defaultdict(list), defaultdict(list), defaultdict(list)
    for (sec, sub, teacher, day, slot), var in variables.items():
        teacher_cells[teacher, day, slot].append(var)
        group_cells[sec, sub, day, slot].append(var)
        section_days[sec, day].append(var)
    components = defaultdict(list)
    bounds = defaultdict(int)

    def term(component, expression, maximum):
        components[component].append(expression)
        bounds[component] += maximum

    def occupied(values):
        if not values:
            return model.new_constant(0)
        value = model.new_bool_var('occupied')
        model.add(value == sum(values))
        return value

    def both(a, b):
        value = model.new_bool_var('both')
        model.add(value <= a)
        model.add(value <= b)
        model.add(value >= a + b - 1)
        return value

    tids = [int(t['id']) for t in payload['teachers']]
    dids = [int(d['id']) for d in days]
    sids = [int(s['id']) for s in slots]
    for tid in tids:
        for did in dids:
            cells = [occupied(teacher_cells[tid, did, sid]) for sid in sids]
            for i in range(1, len(cells) - 1):
                before = model.new_bool_var('before')
                after = model.new_bool_var('after')
                model.add_max_equality(before, cells[:i])
                model.add_max_equality(after, cells[i + 1:])
                gap = model.new_bool_var('gap')
                model.add(gap <= before)
                model.add(gap <= after)
                model.add(gap + cells[i] <= 1)
                model.add(gap >= before + after - cells[i] - 1)
                term('gaps', gap, 1)
    groups = {(k[0], k[1]) for k in variables}
    for sec, sub in sorted(groups):
        previous = None
        for did in dids:
            cells = [occupied(group_cells[sec, sub, did, sid]) for sid in sids]
            for a in range(len(cells)):
                for b in range(a + 1, len(cells)):
                    penalty = pair_penalty(a, b)
                    if penalty:
                        term('spacing', both(cells[a], cells[b]) * penalty, penalty)
            if previous is not None:
                for a, b in zip(previous, cells):
                    term('balance', both(a, b), 1)
            previous = cells
    for sec in payload['sections']:
        counts = []
        for did in dids:
            count = model.new_int_var(0, len(slots), 'daily_count')
            model.add(count == sum(section_days[int(sec['id']), did]))
            counts.append(count)
        high = model.new_int_var(0, len(slots), 'high')
        low = model.new_int_var(0, len(slots), 'low')
        model.add_max_equality(high, counts)
        model.add_min_equality(low, counts)
        term('balance', high - low, len(slots))
    old = {placement_key(r) for r in payload.get('initialPlacements', []) if r.get('room_id') is None}
    retained = sum(var for key, var in variables.items() if key in old)
    # Fixed constant makes nonnegative even with a partial/obsolete old timetable.
    term('changes', len(old) - retained, len(old))
    weights = payload.get('softPriorities', {})
    if not isinstance(weights, dict):
        weights = {}
    from .solver import as_int
    weights = {k: min(3, max(1, as_int(weights.get(k), 2))) for k in ('gaps', 'balance', 'spacing')}
    expressions = {k: sum(components[k]) * weights.get(k, 1)
                   for k in ('changes', 'gaps', 'balance', 'spacing')}
    bounds = {k: bounds[k] * weights.get(k, 1) for k in expressions}
    profile = payload.get('profile', 'minimal_changes')
    if profile not in ('minimal_changes', 'teacher_gaps', 'balanced_subjects'):
        profile = 'minimal_changes'
    primary = {'minimal_changes': ['changes'], 'teacher_gaps': ['gaps'],
               'balanced_subjects': ['balance', 'spacing']}[profile]
    secondary = [k for k in expressions if k not in primary]
    # Actual calculated bounds, not a magic coefficient: lower priorities can
    # never outweigh one unit of the selected primary criterion.
    objective = sum(expressions[k] for k in primary) * (1 + sum(bounds[k] for k in secondary))
    objective += sum(expressions[k] for k in secondary)
    return objective, profile


def quality_metrics(payload, selected, days, slots):
    rank = {int(s['id']): i for i, s in enumerate(slots)}
    teacher_days, groups, section_days = defaultdict(set), defaultdict(set), defaultdict(int)
    for sec, sub, teacher, day, slot in selected:
        teacher_days[teacher, day].add(rank[slot])
        groups[sec, sub, day].add(rank[slot])
        section_days[sec, day] += 1
    gaps = sum(max(v) - min(v) + 1 - len(v) for v in teacher_days.values() if v)
    spacing = sum(pair_penalty(a, b) for values in groups.values()
                  for a in values for b in values if a < b)
    balance = 0
    dids = [int(d['id']) for d in days]
    for sec, sub in {(k[0], k[1]) for k in groups}:
        for a, b in zip(dids, dids[1:]):
            balance += len(groups[sec, sub, a] & groups[sec, sub, b])
    for sec in payload['sections']:
        counts = [section_days[int(sec['id']), day] for day in dids]
        balance += max(counts) - min(counts)
    old = {placement_key(r) for r in payload.get('initialPlacements', []) if r.get('room_id') is None}
    return {'teacherGaps': gaps, 'repeatSpacingPenalty': spacing,
            'balancePenalty': balance, 'retainedLessons': len(old & set(selected)),
            'changedOrRemovedLessons': len(old - set(selected))}
