"""Genuine Google OR-Tools CP-SAT engine for Jadwali.

Does not import teacher names in logs. Accepts the exact JSON input sent to the
Flutter ScheduleSearchController, never changes the database, and returns
candidate placements for independent validation on the phone.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any
import os
import re
import time

ENGINE_VERSION = "1.20.0"


def as_int(v: Any, fallback: int = 0) -> int:
    try:
        return int(v)
    except (ValueError, TypeError):
        return fallback


def ordered(rows, active=False):
    result = [row for row in rows if not active or as_int(row.get('is_active'), 1) == 1]
    return sorted(result, key=lambda r: (as_int(r.get('position')), str(r.get('start_time', '')), as_int(r.get('id'))))


def grade_allowed(tid, sid, grade, qualified, legacy, modern, modern_teachers):
    if (tid, sid) not in qualified or grade <= 0:
        return False
    grades = modern.get((tid, sid))
    if grades:
        return 0 in grades or grade in grades
    if tid in modern_teachers:
        return False
    if tid in legacy:
        return grade in legacy[tid]
    return not modern


def normalize(value):
    text = re.sub(r'[\u064B-\u065F\u0670\u0640]', '', str(value or '').strip().lower())
    return re.sub('[أإآٱ]', 'ا', text).replace('ى', 'ي')


def sunday(day):
    name = normalize(day.get('name'))
    return (name == 'الاحد' or name.startswith('الاحد ') or name == 'sunday') if name else (
        as_int(day.get('position'), -1) == 0 or as_int(day.get('id'), -1) == 1)


def sixth(section):
    name = normalize(section.get('grade_name') or section.get('grade'))
    return ('سادس' in name or name in ('6', '٦', 'sixth', 'grade 6', 'grade6', 'sixth grade')
            or 'الصف 6' in name or 'الصف ٦' in name
            or (not name and as_int(section.get('grade_position'), -1) == 5))


def invalid_input(payload):
    """Reject corrupt demand/IDs before constructing a model, never coerce away demand."""
    if not isinstance(payload, dict):
        return 'بيانات المدرسة يجب أن تكون كائناً.'
    for field in ('sections', 'teachers', 'days', 'slots', 'requirements', 'qualifications',
                  'teacherGrades', 'teacherSubjectGrades', 'subjectBlockedSlots',
                  'teacherAvailability', 'availability', 'initialPlacements', 'lockedPlacements'):
        rows = payload.get(field, [])
        if not isinstance(rows, list) or any(not isinstance(r, dict) for r in rows):
            return 'قائمة بيانات غير صالحة: ' + field
        if field in ('sections', 'teachers', 'days', 'slots'):
            ids = [as_int(r.get('id')) for r in rows]
            if any(i <= 0 for i in ids) or len(ids) != len(set(ids)):
                return 'أرقام مكررة أو غير صالحة: ' + field
    keys = set()
    for r in payload.get('requirements', []):
        key = as_int(r.get('section_id')), as_int(r.get('subject_id'))
        n = r.get('weekly_lessons')
        if key in keys or min(key) <= 0 or not re.fullmatch(r'\d+', str(n)):
            return 'متطلب مكرر أو عدد حصص غير صالح.'
        keys.add(key)
    # Match the independent phone validator, including breaks/inactive slots.
    def minutes(v):
        try:
            h, m = map(int, str(v).split(':'))
            return h * 60 + m if 0 <= h <= 23 and 0 <= m <= 59 else None
        except (ValueError, TypeError):
            return None
    intervals = []
    for row in payload.get('slots', []):
        start, end = minutes(row.get('start_time')), minutes(row.get('end_time'))
        if start is not None and end is not None and end > start:
            if any(start < b and a < end for a, b in intervals):
                return 'أوقات الفترات متداخلة؛ صحح وقت البداية والنهاية.'
            intervals.append((start, end))
    return None


def solve(payload: dict, timeout_seconds: int = 45) -> dict:
    # Imported on demand, so the server emits a descriptive health error if
    # OR-Tools was not installed instead of silently mimicking CP-SAT.
    from ortools.sat.python import cp_model

    started = time.monotonic()
    deadline = started + max(1, min(as_int(timeout_seconds, 45), 180))
    error = invalid_input(payload)
    if error:
        return {'status': 'INVALID_INPUT', 'message': error, 'placements': []}
    sections = {as_int(x['id']): x for x in payload.get('sections', [])}
    teachers = {as_int(x['id']): x for x in payload.get('teachers', [])}
    requirements = [r for r in payload.get('requirements', []) if as_int(r.get('weekly_lessons')) > 0]
    days = ordered(payload.get('days', []), True)
    slots = ordered([s for s in payload.get('slots', []) if s.get('kind') == 'lesson' and as_int(s.get('is_available'), 1) == 1])
    qualified = {(as_int(r.get('teacher_id')), as_int(r.get('subject_id'))) for r in payload.get('qualifications', [])}
    legacy = defaultdict(set)
    modern = defaultdict(set)
    for r in payload.get('teacherGrades', []):
        legacy[as_int(r.get('teacher_id'))].add(as_int(r.get('grade_id')))
    for r in payload.get('teacherSubjectGrades', []):
        modern[as_int(r.get('teacher_id')), as_int(r.get('subject_id'))].add(as_int(r.get('grade_id')))
    modern_teachers = {t for t, _ in modern}
    blocks = {(as_int(r.get('subject_id')), as_int(r.get('slot_id'))) for r in payload.get('subjectBlockedSlots', [])}
    unavailable = {(as_int(r.get('teacher_id')), as_int(r.get('day_id')), as_int(r.get('slot_id')))
                   for r in payload.get('teacherAvailability', payload.get('availability', []))
                   if as_int(r.get('is_available'), 1) == 0}
    required_by_section = defaultdict(int)
    for r in requirements:
        required_by_section[as_int(r.get('section_id'))] += as_int(r.get('weekly_lessons'))
    by_key = defaultdict(list)
    for r in requirements:
        by_key[(as_int(r.get('section_id')), as_int(r.get('subject_id')))].append(r)
    if any(len(v) != 1 for v in by_key.values()):
        return {'status': 'INVALID_INPUT', 'message': 'يوجد متطلب مكرر للمادة والشعبة.'}
    if not days or not slots or not sections:
        return {'status': 'INVALID_INPUT', 'message': 'أيام أو فترات أو شعب المدرسة غير مكتملة.'}
    # Seven-period exception matches the Flutter policy: sixth grade, Sunday,
    # full six daily periods and >6*activeDays weekly demand.
    section_limit = {}
    seventh = {}
    for sec_id, sec in sections.items():
        configured = as_int(sec.get('max_daily_lessons'), 6)
        normal = min(configured if configured > 0 else len(slots), len(slots), 6)
        section_limit[sec_id] = normal
        seventh[sec_id] = (sixth(sec) and normal >= 6 and len(slots) >= 7
                           and any(sunday(d) for d in days)
                           and required_by_section[sec_id] > len(days) * 6)

    model = cp_model.CpModel()
    diagnostics = {}

    def guarded(constraint, code, message, **ids):
        literal = model.new_bool_var('rule_' + str(len(diagnostics)))
        constraint.only_enforce_if(literal)
        model.add_assumption(literal)
        diagnostics[literal.index] = {'code': code, 'message': message, **ids}


    choices = defaultdict(list)
    by_section_cell = defaultdict(list)
    by_teacher_cell = defaultdict(list)
    by_teacher_day = defaultdict(list)
    by_teacher_week = defaultdict(list)
    by_section_day = defaultdict(list)
    by_group_day = defaultdict(list)
    by_group_day_early = defaultdict(list)
    by_group_day_late = defaultdict(list)
    hint_keys = {(as_int(r.get('section_id')), as_int(r.get('subject_id')),
                  as_int(r.get('teacher_id')), as_int(r.get('day_id')), as_int(r.get('slot_id')))
                 for r in payload.get('initialPlacements', [])}
    fixed_keys = {(as_int(r.get('section_id')), as_int(r.get('subject_id')),
                   as_int(r.get('teacher_id')), as_int(r.get('day_id')), as_int(r.get('slot_id')))
                  for r in payload.get('lockedPlacements', [])}
    # Avoid weakening room locks: the application currently generates no rooms.
    if any(r.get('room_id') is not None for r in payload.get('lockedPlacements', [])):
        return {'status': 'UNSUPPORTED', 'message': 'محرك CP-SAT لا يدعم تثبيت القاعات حتى الآن؛ استخدم البحث المحلي.'}
    if len(fixed_keys) != len(payload.get('lockedPlacements', [])):
        return {'status': 'INVALID_INPUT', 'message': 'هناك حصص مثبتة مكررة.'}
    var_by_key = {}
    for (sec_id, sub_id), group in by_key.items():
        req = group[0]
        sec = sections.get(sec_id)
        if sec is None:
            return {'status': 'INVALID_INPUT', 'message': 'المتطلبات تشير إلى شعبة غير موجودة.'}
        eligible = [tid for tid in teachers if grade_allowed(tid, sub_id, as_int(sec.get('grade_id')),
                     qualified, legacy, modern, modern_teachers)]
        if not eligible:
            return {'status': 'INFEASIBLE', 'message': f'المتطلب {sec_id}/{sub_id}: لا يوجد معلم مؤهل.'}
        for tid in eligible:
            for day in days:
                did = as_int(day['id'])
                for rank, slot in enumerate(slots):
                    sid = as_int(slot['id'])
                    if rank >= section_limit[sec_id]:
                        if not (rank == 6 and seventh[sec_id] and sunday(day)):
                            continue
                    if ((sub_id, sid) in blocks or (tid, did, sid) in unavailable):
                        continue
                    key = (sec_id, sub_id, tid, did, sid)
                    v = model.new_bool_var('x_' + '_'.join(map(str, key)))
                    var_by_key[key] = v
                    choices[sec_id, sub_id].append(v)
                    by_section_cell[sec_id, did, sid].append(v)
                    by_teacher_cell[tid, did, sid].append(v)
                    by_teacher_day[tid, did].append(v)
                    by_teacher_week[tid].append(v)
                    by_section_day[sec_id, did].append(v)
                    by_group_day[sec_id, sub_id, did].append(v)
                    if rank < 5:
                        by_group_day_early[sec_id, sub_id, did].append(v)
                    elif rank in (5, 6):
                        by_group_day_late[sec_id, sub_id, did].append(v)
                    if key in hint_keys:
                        model.add_hint(v, 1)
        if len({(k[3], k[4]) for k in var_by_key if k[:2] == (sec_id, sub_id)}) < as_int(req['weekly_lessons']):
            return {'status': 'INFEASIBLE', 'message': f'المادة {sub_id} للشعبة {sec_id}: الخانات المتاحة أقل من المطلوب.'}
        guarded(model.add(sum(choices[sec_id, sub_id]) == as_int(req['weekly_lessons'])),
                'demand', f'متطلب الشعبة {sec_id} والمادة {sub_id}: {req["weekly_lessons"]} حصة ضمن الإتاحة الحالية.',
                sectionId=sec_id, subjectId=sub_id)
        for day in days:
            did = as_int(day['id'])
            values = by_group_day[sec_id, sub_id, did]
            weekly = as_int(req['weekly_lessons'])
            allow_same = as_int(req.get('allow_same_day')) == 1
            max_daily = as_int(req.get('max_daily_lessons'), 2)
            # Necessary repeat only with sixth (or permitted seventh) and an
            # early slot. Replicate the effective restriction from Flutter.
            has_early = any((sub_id, as_int(s['id'])) not in blocks and rank < min(5, section_limit[sec_id])
                            for rank, s in enumerate(slots))
            has_late = any((sub_id, as_int(s['id'])) not in blocks and
                           (rank == 5 and section_limit[sec_id] >= 6 or
                            rank == 6 and seventh[sec_id] and sunday(day))
                           for rank, s in enumerate(slots))
            repeat = (weekly > len(days) and not allow_same and section_limit[sec_id] >= 6
                      and has_early and has_late)
            model.add(sum(values) <= (max(1, max_daily) if allow_same else (2 if repeat else 1)))
            if weekly >= 5:
                model.add(sum(values) >= 1)
            if repeat:
                early = by_group_day_early[sec_id, sub_id, did]
                late = by_group_day_late[sec_id, sub_id, did]
                model.add(sum(early) <= 1)
                model.add(sum(late) <= 1)
                # Having a second lesson requires one early and one late.
                # Early+late cannot exceed 2; max 1 for each is sufficient.
    for values in by_section_cell.values():
        model.add(sum(values) <= 1)
    for values in by_teacher_cell.values():
        model.add(sum(values) <= 1)
    for (sec_id, did), values in by_section_day.items():
        day = next(x for x in days if as_int(x['id']) == did)
        model.add(sum(values) <= (7 if seventh[sec_id] and sunday(day) else section_limit[sec_id]))
    for tid, teacher in teachers.items():
        weekly_max = as_int(teacher.get('weekly_load'))
        if weekly_max > 0:
            guarded(model.add(sum(by_teacher_week[tid]) <= weekly_max), 'teacher_week',
                    f'نصاب المعلم {tid} الأسبوعي لا يتجاوز {weekly_max}.', teacherId=tid)
        max_daily = as_int(teacher.get('max_daily_lessons'))
        for day in days:
            did = as_int(day['id'])
            if max_daily > 0:
                guarded(model.add(sum(by_teacher_day[tid, did]) <= max_daily), 'teacher_day',
                        f'المعلم {tid}: الحد اليومي {max_daily} في اليوم {did}.', teacherId=tid, dayId=did)
            run = as_int(teacher.get('max_consecutive_lessons'))
            if run > 0 and run < len(slots):
                for first in range(0, len(slots) - run):
                    window = slots[first:first + run + 1]
                    if any(as_int(b.get('position')) != as_int(a.get('position')) + 1
                           for a, b in zip(window, window[1:])):
                        continue  # A break/position gap interrupts consecutive lessons.
                    seq = [v for rank in range(first, first + run + 1)
                           for v in by_teacher_cell[tid, did, as_int(slots[rank]['id'])]]
                    if seq:
                        guarded(model.add(sum(seq) <= run), 'teacher_run',
                                f'المعلم {tid}: حد التتابع {run} في اليوم {did}.', teacherId=tid, dayId=did)
    missing_locks = fixed_keys - set(var_by_key)
    if missing_locks:
        return {'status': 'INFEASIBLE', 'message': 'إحدى الحصص المثبتة لم تعد متاحة أو لم يعد معلمها مؤهلاً.'}
    for key in fixed_keys:
        guarded(model.add(var_by_key[key] == 1), 'lock',
                f'حصة مقفلة للشعبة {key[0]} في اليوم {key[3]} والفترة {key[4]}.',
                sectionId=key[0], subjectId=key[1], teacherId=key[2], dayId=key[3], slotId=key[4])
    # First find a feasible complete week. Soft wishes never exclude a valid week.
    from .quality import build_objective, quality_metrics
    objective, profile = build_objective(model, payload, var_by_key, days, slots)
    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = min(8, max(1, os.cpu_count() or 1))
    solver.parameters.random_seed = 2026
    solver.parameters.max_time_in_seconds = max(.01, (deadline - time.monotonic()) * .7)
    solver.parameters.stop_after_first_solution = True
    status = solver.solve(model)
    stages = [{'stage': 'feasibility', 'status': solver.status_name(status), 'seconds': solver.wall_time}]
    if status == cp_model.UNKNOWN and time.monotonic() < deadline:
        solver.parameters.max_time_in_seconds = max(.01, deadline - time.monotonic())
        solver.parameters.random_seed = 2027
        status = solver.solve(model)
        stages.append({'stage': 'retry', 'status': solver.status_name(status), 'seconds': solver.wall_time})
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        core = []
        if status == cp_model.INFEASIBLE:
            core = [diagnostics[i] for i in solver.sufficient_assumptions_for_infeasibility() if i in diagnostics]
        return {'status': solver.status_name(status), 'placements': [],
                'engineVersion': ENGINE_VERSION, 'stages': stages,
                'diagnostics': core,
                'diagnosticScope': 'sufficient_not_minimal' if core else 'model',
                'requestedCount': sum(as_int(r['weekly_lessons']) for r in requirements),
                'message': ('ثبت تعارض القيود الحالية. القيود المذكورة تشكل مجموعة كافية للتعارض ضمن بقية قواعد المدرسة، وليست بالضرورة أصغر مجموعة.'
                            if status == cp_model.INFEASIBLE else
                            'انتهت المهلة دون حل كامل؛ لم تثبت الاستحالة.')}
    # Retain the complete incumbent even if quality optimization times out.
    selected = [key for key, var in var_by_key.items() if solver.value(var)]
    initial_score = int(solver.value(objective))
    initial_metrics = quality_metrics(payload, selected, days, slots)
    branches = solver.num_branches
    best_score = initial_score
    quality_optimal = False
    bound = None
    if time.monotonic() < deadline:
        model.clear_hints()
        for var in var_by_key.values():
            model.add_hint(var, solver.value(var))
        model.add(objective <= initial_score)
        model.minimize(objective)
        solver.parameters.stop_after_first_solution = False
        solver.parameters.max_time_in_seconds = max(.01, deadline - time.monotonic())
        improved = solver.solve(model)
        branches += solver.num_branches
        stages.append({'stage': 'quality', 'status': solver.status_name(improved), 'seconds': solver.wall_time})
        if improved in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            selected = [key for key, var in var_by_key.items() if solver.value(var)]
            best_score = int(solver.objective_value)
            bound = solver.best_objective_bound
            quality_optimal = improved == cp_model.OPTIMAL
    placements = [{'section_id': k[0], 'subject_id': k[1], 'teacher_id': k[2],
                   'day_id': k[3], 'slot_id': k[4], 'room_id': None} for k in sorted(selected)]
    return {'status': 'OPTIMAL' if quality_optimal else 'FEASIBLE', 'placements': placements,
            'requestedCount': sum(as_int(r['weekly_lessons']) for r in requirements),
            'exploredBranches': branches, 'wallTime': time.monotonic() - started,
            'engineVersion': ENGINE_VERSION, 'profile': profile, 'stages': stages,
            'qualityOptimal': quality_optimal, 'objective': best_score,
            'initialObjective': initial_score, 'bestObjectiveBound': bound,
            'initialQuality': initial_metrics,
            'quality': quality_metrics(payload, selected, days, slots)}
