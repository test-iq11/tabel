import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/ui_helpers.dart';
import '../../data/database_service.dart';

import '../../services/auto_scheduler_service.dart';
import '../../services/conflict_detection_service.dart';
import '../../services/preflight_inspection_service.dart';
import '../../services/teacher_assignment_policy.dart';


List<Map<String, Object?>> _schedulerMapList(Object? value) =>
    (value as List).map((row) => Map<String, Object?>.from(row as Map)).toList();

/// ينفّذ محرك الجدولة في isolate منفصل حتى لا تتجمّد الواجهة أثناء البحث.
Map<String, Object?> _generateScheduleInBackground(Map<String, Object?> input) {
  final result = const AutoSchedulerService(nodeLimit: 180000).generate(
    sections: _schedulerMapList(input['sections']),
    requirements: _schedulerMapList(input['requirements']),
    teachers: _schedulerMapList(input['teachers']),
    qualifications: _schedulerMapList(input['qualifications']),
    teacherGrades: _schedulerMapList(input['teacherGrades']),
    teacherSubjectGrades: _schedulerMapList(input['teacherSubjectGrades']),
    subjectBlockedSlots: _schedulerMapList(input['subjectBlockedSlots']),
    days: _schedulerMapList(input['days']),
    slots: _schedulerMapList(input['slots']),
    teacherAvailability: _schedulerMapList(input['availability']),
  );
  return <String, Object?>{
    'placements': result.placements,
    'unscheduled': result.unscheduled,
    'requestedCount': result.requestedCount,
    'exploredNodes': result.exploredNodes,
    'searchLimitReached': result.searchLimitReached,
  };
}

int _asInt(Object? value, {int fallback = 0}) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse('$value') ?? fallback;
}

class TimetablePage extends StatefulWidget {
  const TimetablePage({required this.onChanged, this.focusTarget, super.key});
  final VoidCallback onChanged;
  final Map<String, int?>? focusTarget;
  @override
  State<TimetablePage> createState() => _TimetablePageState();
}

class _TimetablePageState extends State<TimetablePage> {
  Future<Map<String, Object?>>? _future;
  int? _sectionFilter;
  int? _dayFilter;
  int? _teacherFilter;
  String _viewMode = 'section';
  bool _isGenerating = false;
  int? _highlightSectionId;
  int? _highlightDayId;
  int? _highlightSlotId;
  int? _lastFocusToken;

  @override
  void initState() { super.initState(); _applyFocusTarget(widget.focusTarget); _reload(); }

  @override
  void didUpdateWidget(covariant TimetablePage oldWidget) {
    super.didUpdateWidget(oldWidget);
    final token = widget.focusTarget?['token'];
    if (token != null && token != _lastFocusToken) {
      _applyFocusTarget(widget.focusTarget);
    }
  }

  void _applyFocusTarget(Map<String, int?>? target) {
    if (target == null) return;
    _lastFocusToken = target['token'];
    _highlightSectionId = target['sectionId'];
    _highlightDayId = target['dayId'];
    _highlightSlotId = target['slotId'];
    if (_highlightSectionId != null) _sectionFilter = _highlightSectionId;
    if (_highlightDayId != null) _dayFilter = _highlightDayId;
  }
  void _reload() => _future = _loadData();

  Future<Map<String, Object?>> _loadData() async {
    final db = DatabaseService.instance;
    final yearId = await db.activeYearId();
    final versionId = await db.activeVersionId(yearId);
    return {
      'year': await db.activeYear() ?? <String, Object?>{},
      'versionId': versionId,
      'version': versionId == null ? <String, Object?>{} : (await db.rows('timetable_versions')).firstWhere((v) => v['id'] == versionId, orElse: () => <String, Object?>{}),
      'sections': await db.sectionsDetailed(),
      'subjects': await db.rows('subjects', orderBy: 'name'),
      'teachers': await db.rows('teachers', orderBy: 'name'),
      'qualifications': await db.rows('teacher_subjects'),
      'teacherGrades': await db.rows('teacher_grades'),
      'teacherSubjectGrades': await db.rows('teacher_subject_grades'),
      'subjectBlockedSlots': await db.rows('subject_blocked_slots'),
      'days': await db.rows('school_days', orderBy: 'position'),
      'slots': await db.rows('time_slots', orderBy: 'position'),
      'entries': await db.entriesDetailed(versionId: versionId),
      'requirements': await db.requirementsDetailed(),
      'availability': await db.rows('teacher_availability'),
      'yearId': yearId,
    };
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('محرر الجدول الأسبوعي'), actions: [
      IconButton(tooltip: 'فحص ما قبل التوزيع', onPressed: _isGenerating ? null : _runPreflightOnly, icon: const Icon(Icons.fact_check_outlined)),
      IconButton(tooltip: 'تحديث', onPressed: () => setState(_reload), icon: const Icon(Icons.refresh)),
      IconButton(tooltip: 'الجدولة التلقائية', onPressed: _isGenerating ? null : _generateAutomatically, icon: _isGenerating ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome)),
    ]),
    body: FutureBuilder<Map<String, Object?>>(future: _future, builder: (context, snapshot) {
      if (snapshot.hasError) return emptyState(icon: Icons.error_outline, title: 'تعذر تحميل الجدول', message: '${snapshot.error}');
      if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
      if (!snapshot.hasData) return emptyState(icon: Icons.info_outline, title: 'لا توجد بيانات', message: 'لم تُرجع قاعدة البيانات بيانات للجدول. حدّث الصفحة وحاول مرة أخرى.');
      final data = snapshot.data!;
      final sections = (data['sections'] as List).cast<Map<String, Object?>>();
      final subjects = (data['subjects'] as List).cast<Map<String, Object?>>();
      final teachers = (data['teachers'] as List).cast<Map<String, Object?>>();
      final qualifications = (data['qualifications'] as List).cast<Map<String, Object?>>();
      final teacherGrades = (data['teacherGrades'] as List).cast<Map<String, Object?>>();
      final teacherSubjectGrades = (data['teacherSubjectGrades'] as List).cast<Map<String, Object?>>();
      final days = (data['days'] as List).cast<Map<String, Object?>>().where((d) => d['is_active'] == 1).toList();
      final slots = (data['slots'] as List).cast<Map<String, Object?>>();
      final entries = (data['entries'] as List).cast<Map<String, Object?>>();
      final requirements = (data['requirements'] as List).cast<Map<String, Object?>>();
      final allSections = sections;
      final visibleSections = _sectionFilter == null ? allSections : allSections.where((s) => s['id'] == _sectionFilter).toList();
      final visibleDays = _dayFilter == null ? days : days.where((d) => d['id'] == _dayFilter).toList();
      final effectiveTeacherId = teachers.any((t) => t['id'] == _teacherFilter)
          ? _teacherFilter
          : (teachers.isEmpty ? null : _asInt(teachers.first['id']));
      final selectedTeacher = teachers.where((t) => _asInt(t['id']) == effectiveTeacherId).isEmpty
          ? null
          : teachers.firstWhere((t) => _asInt(t['id']) == effectiveTeacherId);
      final version = (data['version'] as Map).cast<String, Object?>();
      final year = (data['year'] as Map).cast<String, Object?>();

      return Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 10), child: Column(children: [
          Row(children: [
            Expanded(child: DropdownButtonFormField<String>(
              key: const ValueKey('timetable-view-mode'),
              initialValue: _viewMode,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'طريقة عرض الجدول', prefixIcon: Icon(Icons.view_week_outlined, color: Color(0xFF7C5CDB))),
              items: const [
                DropdownMenuItem(value: 'section', child: Text('جدول الصف / الشعبة')),
                DropdownMenuItem(value: 'teacher', child: Text('جدول المعلم')),
              ],
              onChanged: (value) => setState(() {
                _viewMode = value ?? 'section';
                if (_viewMode == 'teacher') _dayFilter = null;
              }),
            )),
            if (_viewMode == 'teacher') ...[
              const SizedBox(width: 8),
              Expanded(child: DropdownButtonFormField<int>(
                key: ValueKey('teacher-filter-$effectiveTeacherId'),
                initialValue: effectiveTeacherId,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'اختر المعلم', prefixIcon: Icon(Icons.person_pin_circle_outlined, color: Color(0xFF16845B))),
                items: teachers.map((t) => DropdownMenuItem<int>(
                  value: _asInt(t['id']),
                  child: Text('${t['name']}', overflow: TextOverflow.ellipsis),
                )).toList(),
                onChanged: (value) => setState(() => _teacherFilter = value),
              )),
            ],
          ]),
          if (_viewMode == 'section') ...[
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: DropdownButtonFormField<int?>(
                initialValue: _sectionFilter, isExpanded: true,
                decoration: const InputDecoration(labelText: 'عرض الشعبة', prefixIcon: Icon(Icons.groups_outlined, color: Color(0xFF2878C8))),
                items: [const DropdownMenuItem<int?>(value: null, child: Text('جميع الشعب')),
                  ...sections.map((s) => DropdownMenuItem<int?>(value: s['id'] as int, child: Text('${displayGradeName(s['grade_name'])} - ${s['section_name']}', overflow: TextOverflow.ellipsis)))],
                onChanged: (value) async {
                  setState(() => _sectionFilter = value);
                  final prefs = await SharedPreferences.getInstance();
                  if (value == null) { await prefs.remove('last_timetable_section_filter'); } else { await prefs.setInt('last_timetable_section_filter', value); }
                },
              )),
              const SizedBox(width: 8),
              Expanded(child: DropdownButtonFormField<int?>(
                initialValue: _dayFilter, isExpanded: true,
                decoration: const InputDecoration(labelText: 'اليوم', prefixIcon: Icon(Icons.today_outlined, color: Color(0xFFB87419))),
                items: [const DropdownMenuItem<int?>(value: null, child: Text('كل الأيام')),
                  ...days.map((d) => DropdownMenuItem<int?>(value: d['id'] as int, child: Text('${d['name']}')))],
                onChanged: (value) => setState(() => _dayFilter = value),
              )),
            ]),
          ] else
            const Padding(padding: EdgeInsets.only(top: 7), child: Align(alignment: Alignment.centerRight, child: Text('يظهر هنا أسبوع المعلم كاملاً، مع جميع أيام الدوام المفعّلة حتى لو لم تكن لديه حصص في بعضها.', style: TextStyle(fontSize: 11, color: Color(0xFF526274))))),
          const SizedBox(height: 8),
          Card(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9), child: Row(children: [
            const Icon(Icons.history_toggle_off, color: Color(0xFF2878C8)), const SizedBox(width: 9),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${year['name'] ?? 'عام غير محدد'} • ${version['name'] ?? 'لا توجد نسخة'}', style: const TextStyle(fontWeight: FontWeight.w800)), Text('الحالة: ${version['status'] ?? 'مسودة'} • ${entries.length} حصة محفوظة', style: const TextStyle(color: Colors.black54, fontSize: 12))])),
            IconButton(tooltip: 'إنشاء جدول تلقائي', onPressed: _isGenerating ? null : _generateAutomatically, icon: _isGenerating ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome, color: Color(0xFF2878C8))),
          ]))),
        ])),
        if (_isGenerating) const Padding(
          padding: EdgeInsets.fromLTRB(16, 0, 16, 10),
          child: Card(child: Padding(padding: EdgeInsets.all(12), child: Row(children: [
            SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)),
            SizedBox(width: 10), Expanded(child: Text('يجري توزيع حصص جميع الشعب على المعلمين مع مراعاة الاختصاص والصفوف والفترات الممنوعة والنصاب. قد يستغرق ذلك بعض الوقت.')),
          ]))),
        ),
        Expanded(child: sections.isEmpty ? emptyState(icon: Icons.groups_outlined, title: 'لا توجد شعب', message: 'أضف الصفوف والشعب من تبويب إدارة البيانات أولاً.')
          : subjects.isEmpty || teachers.isEmpty ? emptyState(icon: Icons.info_outline, title: 'أكمل بيانات المدرسة', message: 'أضف مادة ومعلماً واحداً على الأقل، ثم حدّد المواد المؤهلة للمعلمين من إدارة البيانات.')
          : slots.where((s) => s['kind'] == 'lesson').isEmpty || days.isEmpty ? emptyState(icon: Icons.access_time, title: 'لا توجد أوقات متاحة', message: 'فعّل أيام الدوام وأضف فترات من نوع حصة دراسية في إعدادات المدرسة.')
          : _viewMode == 'teacher'
              ? (selectedTeacher == null
                  ? emptyState(icon: Icons.person_search_outlined, title: 'لا يوجد معلم محدد', message: 'أضف معلماً أولاً ثم اختره لعرض جدوله الأسبوعي.')
                  : ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 20), children: [
                      _buildTeacherTable(teacher: selectedTeacher, days: days, slots: slots, entries: entries, subjects: subjects),
                    ]))
              : visibleSections.isEmpty ? emptyState(icon: Icons.search_off, title: 'لا توجد نتائج', message: 'غيّر تصفية الشعبة لعرض الجدول.')
              : ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 20), children: [
                  if (requirements.isEmpty) Container(padding: const EdgeInsets.all(12), margin: const EdgeInsets.only(bottom: 12), decoration: BoxDecoration(color: const Color(0xFFFFF3D8), borderRadius: BorderRadius.circular(14)), child: const Text('لم تُسجّل الحصص الأسبوعية المطلوبة بعد؛ يمكنك إدخال حصص يدوياً، لكن الجدولة التلقائية تحتاج متطلبات المواد لكل شعبة.', style: TextStyle(color: Color(0xFF865300)))),
                  ...visibleSections.map((section) => Padding(padding: const EdgeInsets.only(bottom: 14), child: _buildSectionTable(
                    section: section, days: visibleDays, slots: slots, entries: entries, requirements: requirements,
                    subjects: subjects, teachers: teachers, qualifications: qualifications,
                    teacherGrades: teacherGrades, teacherSubjectGrades: teacherSubjectGrades,
                    allSlots: slots, allDays: days,
                  ))),
                ])),
      ]);
    }),
  );

  Color _subjectColor(Map<String, Object?>? entry, List<Map<String, Object?>> subjects) {
    final subjectId = entry == null ? null : _asInt(entry['subject_id']);
    const palette = <Color>[
      Color(0xFF2878C8), Color(0xFF16845B), Color(0xFF8A63C7),
      Color(0xFFE09B32), Color(0xFF168A9B), Color(0xFFD65B70),
      Color(0xFF5D7C2F), Color(0xFFB45F06), Color(0xFF4C64A8),
    ];
    final index = subjects.indexWhere((subject) => _asInt(subject['id']) == subjectId);
    if (index < 0) return palette[0];
    final raw = subjects[index]['color'];
    final storedColor = raw is int ? raw : (raw is num ? raw.toInt() : int.tryParse('$raw') ?? 0);
    // The seed database gave every subject the same blue. Use a readable palette
    // for those legacy defaults, but respect custom colors saved by the user.
    if (storedColor > 0 && storedColor != 0xFF2196F3) return Color(storedColor);
    return palette[index % palette.length];
  }

  Widget _buildTeacherTable({
    required Map<String, Object?> teacher,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> subjects,
  }) {
    final teacherId = _asInt(teacher['id']);
    final teacherEntries = entries.where((e) => _asInt(e['teacher_id'], fallback: -1) == teacherId).toList();
    final lessonCount = teacherEntries.length;
    final taughtDays = teacherEntries.map((e) => _asInt(e['day_id'])).toSet().length;
    final weeklyLoad = _asInt(teacher['weekly_load']);
    return Card(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 13, 14, 10),
          child: Row(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: const LinearGradient(colors: [Color(0xFF16845B), Color(0xFF168A9B)]),
              ),
              child: const Icon(Icons.co_present_rounded, color: Colors.white, size: 25),
            ),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${teacher['name']}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Color(0xFF183B66))),
              Text('الجدول الأسبوعي الكامل • ${days.length} أيام في الأسبوع', style: const TextStyle(fontSize: 12, color: Color(0xFF63748A))),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text('$lessonCount حصة', style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF16845B))),
              Text(weeklyLoad > 0 ? 'من أصل $weeklyLoad' : 'النصاب غير محدد', style: const TextStyle(fontSize: 10, color: Color(0xFF63748A))),
            ]),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
          child: Wrap(spacing: 7, runSpacing: 6, children: [
            _TeacherStatChip(icon: Icons.event_available_rounded, label: 'أيام التدريس $taughtDays/${days.length}', color: const Color(0xFF2878C8)),
            _TeacherStatChip(icon: Icons.check_circle_outline_rounded, label: 'الخانات الفارغة ظاهرة', color: const Color(0xFF8A63C7)),
          ]),
        ),
        const Divider(height: 1),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            horizontalMargin: 8,
            columnSpacing: 8,
            dataRowMinHeight: 64,
            dataRowMaxHeight: 76,
            columns: [
              const DataColumn(label: SizedBox(width: 100, child: Text('الحصة / الوقت'))),
              ...days.map((day) => DataColumn(label: SizedBox(width: 130, child: Center(child: Text(
                _asInt(day['is_active'], fallback: 1) == 1 ? '${day['name']}' : '${day['name']}\n(معطل)',
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.w900, color: _asInt(day['is_active'], fallback: 1) == 1 ? const Color(0xFF183B66) : const Color(0xFF9AA8B8)),
              )))),
            ],
            rows: slots.map((slot) {
              final isLesson = slot['kind'] == 'lesson' && _asInt(slot['is_available'], fallback: 1) == 1;
              return DataRow(cells: [
                DataCell(SizedBox(width: 100, child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${slot['name']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                  Text('${slot['start_time'] ?? ''}–${slot['end_time'] ?? ''}', style: const TextStyle(fontSize: 10, color: Color(0xFF63748A))),
                  if (!isLesson) Text(_periodLabel('${slot['kind']}'), style: const TextStyle(fontSize: 10, color: Color(0xFFB45F06))),
                ]))),
                ...days.map((day) {
                  final matching = teacherEntries.where((entry) =>
                    _asInt(entry['day_id']) == _asInt(day['id']) &&
                    _asInt(entry['slot_id']) == _asInt(slot['id'])).toList();
                  final first = matching.isEmpty ? null : matching.first;
                  final subjectColor = _subjectColor(first, subjects);
                  final bg = !isLesson
                      ? const Color(0xFFF0F2F4)
                      : first == null ? const Color(0xFFFAFBFD) : subjectColor.withOpacity(.12);
                  return DataCell(SizedBox(width: 130, child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color: bg,
                      borderRadius: BorderRadius.circular(9),
                      border: Border.all(color: matching.length > 1 ? const Color(0xFFD64545) : subjectColor.withOpacity(first == null ? .12 : .42)),
                    ),
                    child: matching.isNotEmpty
                        ? Column(mainAxisAlignment: MainAxisAlignment.center, children: matching.map((entry) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 2),
                            child: Row(children: [
                              Container(width: 3, height: 30, decoration: BoxDecoration(color: _subjectColor(entry, subjects), borderRadius: BorderRadius.circular(4))),
                              const SizedBox(width: 5),
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                                Text('${entry['subject_name'] ?? 'مادة غير معروفة'}', maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: _subjectColor(entry, subjects))),
                                Text('${entry['grade_name'] ?? ''} - ${entry['section_name'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 9, color: Color(0xFF526274))),
                              ])),
                            ]),
                          )).toList())
                        : Center(child: Icon(isLesson ? Icons.remove_rounded : Icons.block_outlined, size: 16, color: isLesson ? const Color(0xFFD2DAE5) : const Color(0xFFADB7C4))),
                  )));
                }),
              ]);
            }).toList(),
          ),
        ),
        Padding(padding: const EdgeInsets.fromLTRB(14, 0, 14, 12), child: Row(children: [
          const Icon(Icons.info_outline_rounded, size: 15, color: Color(0xFF63748A)),
          const SizedBox(width: 6),
          Expanded(child: Text('الخانات الفارغة لا تعني وجود تعارض؛ إنها أوقات لا يدرّس فيها ${teacher['name']}. تظهر أيام الأسبوع كاملة، وتُوسم الأيام المعطّلة بوضوح.', style: const TextStyle(fontSize: 11, color: Color(0xFF63748A)))),
        ])),
      ]),
    );
  }

  Widget _buildSectionTable({
    required Map<String, Object?> section,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> requirements,
    required List<Map<String, Object?>> subjects,
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> qualifications,
    required List<Map<String, Object?>> teacherGrades,
    required List<Map<String, Object?>> teacherSubjectGrades,
    required List<Map<String, Object?>> allSlots,
    required List<Map<String, Object?>> allDays,
  }) {
    final sectionId = section['id'] as int;
    final sectionEntries = entries.where((e) => e['section_id'] == sectionId).toList();
    final activeSlots = slots;
    return Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.fromLTRB(14, 12, 14, 4), child: Row(children: [
        Container(width: 4, height: 34, decoration: BoxDecoration(color: const Color(0xFF2878C8), borderRadius: BorderRadius.circular(4))),
        const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${displayGradeName(section['grade_name'])} - ${section['section_name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)), Text('${sectionEntries.length} حصة موزعة', style: const TextStyle(color: Colors.black54, fontSize: 12))])),
        IconButton(tooltip: 'إضافة حصة للشعبة', onPressed: days.isEmpty || activeSlots.where((s) => s['kind'] == 'lesson').isEmpty ? null : () => _chooseCell(section, days, activeSlots, sectionEntries, entries, requirements, subjects, teachers, qualifications, teacherGrades, teacherSubjectGrades, allSlots, allDays), icon: const Icon(Icons.add_circle_outline, color: Color(0xFF2878C8))),
      ])),
      const Divider(height: 1),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          horizontalMargin: 8, columnSpacing: 8, dataRowMinHeight: 58, dataRowMaxHeight: 74,
          columns: [const DataColumn(label: SizedBox(width: 100, child: Text('الفترة / الوقت'))), ...days.map((d) => DataColumn(label: SizedBox(width: 128, child: Text('${d['name']}', textAlign: TextAlign.center))))],
          rows: activeSlots.map((slot) {
            final isLesson = slot['kind'] == 'lesson' && slot['is_available'] == 1;
            return DataRow(cells: [
              DataCell(SizedBox(width: 100, child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${slot['name']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                Text('${slot['start_time']}–${slot['end_time']}', style: const TextStyle(fontSize: 10, color: Colors.black54)),
                if (!isLesson) Text(_periodLabel('${slot['kind']}'), style: const TextStyle(fontSize: 10, color: Colors.deepOrange)),
              ]))),
              ...days.map((day) {
                final matches = sectionEntries.where((e) => e['day_id'] == day['id'] && e['slot_id'] == slot['id']).toList();
                final entry = matches.isEmpty ? null : matches.first;
                final filled = entry != null;
                return DataCell(SizedBox(width: 128, child: DragTarget<Map<String, Object?>>(
                  onWillAcceptWithDetails: (details) => isLesson &&
                      details.data['section_id'] == sectionId &&
                      !(details.data['day_id'] == day['id'] && details.data['slot_id'] == slot['id']) &&
                      !sectionEntries.any((saved) => saved['day_id'] == day['id'] && saved['slot_id'] == slot['id']),
                  onAcceptWithDetails: (details) => _moveEntryToCell(
                    source: details.data, section: section, day: day, slot: slot,
                    allDays: allDays, allSlots: allSlots,
                  ),
                  builder: (context, candidates, rejected) {
                    final targetHover = candidates.isNotEmpty;
                    final isFocusedCell = _highlightSectionId == sectionId &&
                      _highlightDayId == day['id'] && _highlightSlotId == slot['id'];
                    final lessonColor = _subjectColor(entry, subjects);
                    final cellColor = targetHover ? const Color(0xFFD6F5E5) :
                      isFocusedCell ? const Color(0xFFFFE7A3) :
                      !isLesson ? const Color(0xFFF0F2F4) : filled ? lessonColor.withOpacity(.12) : const Color(0xFFFAFBFD);
                    final cellContent = Material(
                      color: cellColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: BorderSide(color: isFocusedCell ? const Color(0xFFB77900) : filled ? lessonColor.withOpacity(.38) : Colors.transparent, width: isFocusedCell ? 2.5 : 1),
                      ),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(10),
                        onTap: () {
                          if (!isLesson) { showMessage(context, 'هذه الفترة ليست متاحة للتدريس.'); return; }
                          _editCell(section, day, slot, entry, allSlots, entries, requirements, subjects, teachers, qualifications, teacherGrades, teacherSubjectGrades, allDays);
                        },
                        child: Padding(padding: const EdgeInsets.all(7), child: filled ? Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Text('${entry['subject_name'] ?? 'مادة'}', textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: isFocusedCell ? const Color(0xFF7A4A00) : lessonColor)),
                          const SizedBox(height: 3), Text('${entry['teacher_name'] ?? 'غير مسند'}', textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: Colors.black54)),
                          const SizedBox(height: 2), const Icon(Icons.drag_indicator, size: 13, color: Color(0xFF8CA3BA)),
                        ]) : Center(child: Icon(isLesson ? Icons.add : Icons.block, size: 16, color: isLesson ? const Color(0xFF9CB5CE) : Colors.black26))),
                      ),
                    );
                    final dragEntry = entry;
                    if (isLesson && dragEntry != null) {
                      return LongPressDraggable<Map<String, Object?>>(
                        data: Map<String, Object?>.from(dragEntry),
                        feedback: _dragFeedback(dragEntry),
                        childWhenDragging: Opacity(opacity: .25, child: cellContent),
                        child: cellContent,
                      );
                    }
                    return cellContent;
                  },
                )));
              }),
            ]);
          }).toList(),
        ),
      ),
      Padding(padding: const EdgeInsets.fromLTRB(12, 0, 12, 10), child: Row(children: [
        const Icon(Icons.touch_app_outlined, size: 15, color: Colors.black45), const SizedBox(width: 5),
        const Expanded(child: Text('اضغط الخلية لإضافة أو تعديل الحصة، واضغط مطولاً ثم اسحب الدرس إلى خلية فارغة لنقله مع فحص التعارضات.', style: TextStyle(fontSize: 11, color: Colors.black54))),
        TextButton(onPressed: () async { if (await confirmAction(context, 'تفريغ جدول الشعبة', 'سيتم حذف جميع حصص هذه الشعبة من نسخة العمل النشطة. هل تريد المتابعة؟')) { final db = await DatabaseService.instance.database; final yearId = await DatabaseService.instance.activeYearId(); final versionId = yearId == null ? null : await DatabaseService.instance.ensureEditableActiveVersion(yearId); if (versionId != null) { await db.delete('timetable_entries', where: 'version_id=? AND section_id=?', whereArgs: [versionId, sectionId]); await db.update('timetable_versions', {'status': 'قيد التعديل', 'updated_at': DateTime.now().toIso8601String()}, where: 'id=?', whereArgs: [versionId]); setState(_reload); widget.onChanged(); } } }, child: const Text('تفريغ الشعبة')),
      ])),
    ]));
  }

  Widget _dragFeedback(Map<String, Object?> entry) => Material(
    color: Colors.transparent,
    child: Opacity(
      opacity: .9,
      child: SizedBox(
        width: 128,
        height: 58,
        child: Card(
          color: const Color(0xFF183B66),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(6),
              child: Text(
                '${entry['subject_name']}\n${entry['teacher_name'] ?? 'غير مسند'}',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
      ),
    ),
  );

  String _periodLabel(String kind) => switch (kind) { 'break' => 'استراحة', 'activity' => 'نشاط', _ => 'غير متاحة' };

  Future<void> _chooseCell(
    Map<String, Object?> section, List<Map<String, Object?>> days, List<Map<String, Object?>> slots,
    List<Map<String, Object?>> sectionEntries, List<Map<String, Object?>> allEntries, List<Map<String, Object?>> requirements,
    List<Map<String, Object?>> subjects, List<Map<String, Object?>> teachers,
    List<Map<String, Object?>> qualifications,
    List<Map<String, Object?>> teacherGrades,
    List<Map<String, Object?>> teacherSubjectGrades,
    List<Map<String, Object?>> allSlots, List<Map<String, Object?>> allDays,
  ) async {
    final choices = <Map<String, Object?>>[];
    for (final day in days) {
      for (final slot in slots.where((s) => s['kind'] == 'lesson' && s['is_available'] == 1)) {
        if (!sectionEntries.any((e) => e['day_id'] == day['id'] && e['slot_id'] == slot['id'])) choices.add({'day': day, 'slot': slot});
      }
    }
    if (choices.isEmpty) { showMessage(context, 'لا توجد خلايا فارغة في جدول هذه الشعبة.'); return; }
    final selected = await showDialog<Map<String, Object?>>(context: context, builder: (ctx) => SimpleDialog(title: const Text('اختر خلية لإضافة حصة'), children: choices.take(80).map((c) => SimpleDialogOption(onPressed: () => Navigator.pop(ctx, c), child: Text('${(c['day'] as Map)['name']} • ${(c['slot'] as Map)['name']} (${(c['slot'] as Map)['start_time']})'))).toList()));
    if (selected != null) await _editCell(section, selected['day'] as Map<String, Object?>, selected['slot'] as Map<String, Object?>, null, allSlots, allEntries, requirements, subjects, teachers, qualifications, teacherGrades, teacherSubjectGrades, allDays);
  }

  Future<void> _editCell(
    Map<String, Object?> section, Map<String, Object?> day, Map<String, Object?> slot,
    Map<String, Object?>? entry, List<Map<String, Object?>> slots, List<Map<String, Object?>> allEntries,
    List<Map<String, Object?>> allRequirements, List<Map<String, Object?>> allSubjects,
    List<Map<String, Object?>> allTeachers, List<Map<String, Object?>> qualifications,
    List<Map<String, Object?>> teacherGrades,
    List<Map<String, Object?>> teacherSubjectGrades,
    List<Map<String, Object?>> allDays,
  ) async {
    final sectionId = section['id'] as int;
    final orderedLessonSlots = slots
        .where((s) => s['kind'] == 'lesson' && _asInt(s['is_available'], fallback: 1) == 1)
        .toList()
      ..sort((a, b) => _asInt(a['position']).compareTo(_asInt(b['position'])));
    final periodRank = orderedLessonSlots.indexWhere((s) => s['id'] == slot['id']);
    if (entry == null && periodRank >= 6) {
      final activeDayCount = allDays.where((d) => _asInt(d['is_active'], fallback: 1) == 1).length;
      final weeklyRequired = allRequirements
          .where((r) => r['section_id'] == sectionId)
          .fold<int>(0, (sum, r) => sum + _asInt(r['weekly_lessons']));
      final sixPeriodCapacity = activeDayCount * 6;
      final configuredLimit = _asInt(section['max_daily_lessons'], fallback: 6);
      if (periodRank > 6 || activeDayCount == 0 || configuredLimit < 7 || weeklyRequired <= sixPeriodCapacity) {
        showMessage(context,
          'مُنعت إضافة الحصة السابعة. لا تُستخدم إلا عند الضرورة، عندما تتجاوز متطلبات الشعبة $sixPeriodCapacity حصة أسبوعياً ويكون الحد اليومي مضبوطاً على 7.',
          error: true,
        );
        return;
      }
    }
    final sectionRequirements = allRequirements.where((r) => r['section_id'] == sectionId).toList();
    final subjectIds = sectionRequirements.map((r) => r['subject_id']).toSet();
    final availableSubjects = subjectIds.isEmpty ? allSubjects : allSubjects.where((s) => subjectIds.contains(s['id'])).toList();
    if (availableSubjects.isEmpty) { showMessage(context, 'أضف مادة أولاً.'); return; }
    int? selectedSubject = entry?['subject_id'] as int? ?? availableSubjects.first['id'] as int;
    int? selectedTeacher = entry?['teacher_id'] as int?;
    final assignmentPolicy = TeacherAssignmentPolicy(
      qualifications: qualifications,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
    );
    final sectionGradeId = _asInt(section['grade_id']);
    final result = await showDialog<Map<String, Object?>>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, update) {
      final qualifiedIds = qualifications.where((q) => q['subject_id'] == selectedSubject).map((q) => q['teacher_id']).toSet();
      final teacherOptions = allTeachers.where((t) =>
        qualifiedIds.contains(t['id']) && selectedSubject != null &&
        assignmentPolicy.isGradeAllowed(_asInt(t['id']), selectedSubject!, sectionGradeId)
      ).toList();
      final selectedTeacherAvailable = selectedTeacher == null || teacherOptions.any((t) => t['id'] == selectedTeacher);
      return AlertDialog(
        title: Text(entry == null ? 'إضافة حصة' : 'تعديل الحصة'),
        content: SizedBox(width: 400, child: Column(mainAxisSize: MainAxisSize.min, children: [
          Align(alignment: Alignment.centerRight, child: Text('${displayGradeName(section['grade_name'])} - ${section['section_name']}\n${day['name']} • ${slot['name']} (${slot['start_time']}–${slot['end_time']})', style: const TextStyle(color: Colors.black54))),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            initialValue: selectedSubject, isExpanded: true,
            decoration: const InputDecoration(labelText: 'المادة', prefixIcon: Icon(Icons.menu_book_rounded, color: Color(0xFF8A63C7))),
            items: availableSubjects.map((subject) {
              final subjectColor = _subjectColor(subject, allSubjects);
              return DropdownMenuItem<int>(value: subject['id'] as int, child: Row(children: [
                Container(width: 9, height: 28, decoration: BoxDecoration(color: subjectColor, borderRadius: BorderRadius.circular(5))),
                const SizedBox(width: 9), Expanded(child: Text('${subject['name']}', overflow: TextOverflow.ellipsis)),
              ]));
            }).toList(),
            onChanged: (v) => update(() { selectedSubject = v; selectedTeacher = null; }),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<int?>(
            key: ValueKey(selectedSubject), initialValue: selectedTeacherAvailable ? selectedTeacher : null, isExpanded: true,
            decoration: const InputDecoration(labelText: 'المعلم المسموح للمادة والصف', prefixIcon: Icon(Icons.person_pin_circle_outlined, color: Color(0xFF16845B))),
            items: [
              const DropdownMenuItem<int?>(value: null, child: Row(children: [Icon(Icons.person_off_outlined, color: Color(0xFFB87419), size: 19), SizedBox(width: 8), Text('غير مسند حالياً')])),
              ...teacherOptions.map((t) => DropdownMenuItem<int?>(value: t['id'] as int, child: Row(children: [const Icon(Icons.person_outline_rounded, color: Color(0xFF16845B), size: 19), const SizedBox(width: 8), Expanded(child: Text('${t['name']}', overflow: TextOverflow.ellipsis))]))),
            ],
            onChanged: (v) => update(() => selectedTeacher = v),
          ),
          if (teacherOptions.isEmpty) Padding(padding: const EdgeInsets.only(top: 9), child: Text(
            qualifiedIds.isEmpty
              ? 'لا يوجد معلم مؤهل لهذه المادة. يمكن إبقاء الحصة دون معلم، لكن لا يجوز إسنادها إلى معلم غير مؤهل.'
              : 'لا يوجد معلم مسموح له بهذه المادة في الصف المحدد. راجع «البيانات > المعلمون» لتصحيح صفوف المادة؛ لن يُسمح بحفظ إسناد مخالف.',
            style: const TextStyle(color: Colors.deepOrange, fontSize: 12),
          )),
        ])),
        actions: [
          if (entry != null) TextButton(onPressed: () => Navigator.pop(ctx, {'delete': true}), child: const Text('حذف الحصة', style: TextStyle(color: Colors.red))),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, {'subject_id': selectedSubject, 'teacher_id': selectedTeacher}), child: const Text('حفظ')),
        ],
      );
    }));
    if (result == null) return;
    if (result['delete'] == true) {
      if (!await confirmAction(context, 'حذف الحصة', 'هل تريد حذف الحصة المحددة؟')) return;
      try {
        final db = await DatabaseService.instance.database;
        final yearId = await DatabaseService.instance.activeYearId();
        final versionId = yearId == null ? null : await DatabaseService.instance.ensureEditableActiveVersion(yearId);
        if (versionId == null) throw StateError('لا توجد نسخة نشطة قابلة للتعديل.');
        final cloned = await db.query('timetable_entries', where: 'version_id=? AND section_id=? AND day_id=? AND slot_id=?', whereArgs: [versionId, sectionId, day['id'], slot['id']], limit: 1);
        if (cloned.isEmpty) throw StateError('لم يتم العثور على الحصة في نسخة العمل.');
        await db.delete('timetable_entries', where: 'id=?', whereArgs: [cloned.first['id']]);
        await db.update('timetable_versions', {'status': 'قيد التعديل', 'updated_at': DateTime.now().toIso8601String()}, where: 'id=?', whereArgs: [versionId]);
        if (mounted) { showMessage(context, 'تم حذف الحصة.'); setState(_reload); widget.onChanged(); }
      } catch (e) { if (mounted) showMessage(context, 'تعذر حذف الحصة: $e', error: true); }
      return;
    }
    final newEntry = <String, Object?>{
      'id': entry?['id'] ?? -1,
      'section_id': sectionId, 'subject_id': result['subject_id'], 'teacher_id': result['teacher_id'],
      'room_id': entry?['room_id'], 'day_id': day['id'], 'slot_id': slot['id'],
      'version_id': entry?['version_id'] ?? (await DatabaseService.instance.activeVersionId(await DatabaseService.instance.activeYearId())),
      'subject_name': availableSubjects.firstWhere((s) => s['id'] == result['subject_id'])['name'],
      'section_name': section['section_name'], 'grade_id': section['grade_id'], 'grade_name': section['grade_name'],
      'teacher_name': result['teacher_id'] == null ? null : allTeachers.firstWhere((t) => t['id'] == result['teacher_id'])['name'],
    };
    if (newEntry['version_id'] == null) { showMessage(context, 'لا يوجد عام دراسي نشط.', error: true); return; }
    final entriesForScan = allEntries.where((e) => e['id'] != entry?['id']).toList()..add(newEntry);
    final slotsForScan = slots;
    final issues = const ConflictDetectionService().scan(
      entries: entriesForScan, requirements: allRequirements, sections: await DatabaseService.instance.sectionsDetailed(), slots: slotsForScan,
      teachers: allTeachers, qualifications: qualifications, days: allDays,
      teacherGrades: await DatabaseService.instance.rows('teacher_grades'),
      teacherSubjectGrades: await DatabaseService.instance.rows('teacher_subject_grades'),
      subjectBlockedSlots: await DatabaseService.instance.rows('subject_blocked_slots'),
      teacherAvailability: await DatabaseService.instance.rows('teacher_availability'),
      enforceQualifications: true,
    );
    final blockers = issues.where((i) =>
      i.severity == 'خطأ مانع' &&
      i.dayId == day['id'] &&
      i.slotId == slot['id'] &&
      // عالج فقط التعارضات المرتبطة بهذه الشعبة أو بهذا المعلم. لا تمنع الحفظ
      // بسبب مخالفة غير مرتبطة في شعبة أخرى تستخدم الفترة نفسها.
      (i.sectionId == sectionId ||
       (result['teacher_id'] != null && i.teacherId == result['teacher_id']))
    ).toList();
    if (blockers.isNotEmpty) {
      if (mounted) await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('لا يمكن حفظ الحصة بسبب تعارض'),
        content: SizedBox(width: 420, child: Column(mainAxisSize: MainAxisSize.min, children: blockers.map((i) => ListTile(leading: const Icon(Icons.error_outline, color: Colors.red), title: Text(i.type), subtitle: Text(i.message))).toList())),
        actions: [FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('رجوع للتعديل'))],
      ));
      return;
    }
    try {
      final yearId = await DatabaseService.instance.activeYearId();
      if (yearId == null) throw StateError('لا يوجد عام دراسي نشط.');
      final writableVersionId = await DatabaseService.instance.ensureEditableActiveVersion(yearId);
      if (writableVersionId == null) throw StateError('لا توجد نسخة نشطة قابلة للتعديل.');
      int? targetEntryId;
      if (entry != null) {
        final db = await DatabaseService.instance.database;
        final cloned = await db.query('timetable_entries', where: 'version_id=? AND section_id=? AND day_id=? AND slot_id=?', whereArgs: [writableVersionId, sectionId, day['id'], slot['id']], limit: 1);
        if (cloned.isNotEmpty) targetEntryId = cloned.first['id'] as int;
      }
      final values = Map<String, Object?>.from(newEntry)
        ..['version_id'] = writableVersionId
        ..remove('id')..remove('subject_name')..remove('section_name')..remove('teacher_name');
      await DatabaseService.instance.saveEntry(values, entryId: targetEntryId);
      if (mounted) {
        showMessage(context, result['teacher_id'] == null ? 'حُفظت الحصة دون معلم؛ راجع التحذيرات قبل الاعتماد.' : 'تم حفظ الحصة دون تعارضات مانعة.');
        setState(_reload); widget.onChanged();
      }
    } catch (e) { if (mounted) showMessage(context, 'تعذر حفظ الحصة. قد تكون الخلية مشغولة: $e', error: true); }
  }

  PreflightResult _inspectBeforeScheduling(Map<String, Object?> data) {
    final result = const PreflightInspectionService().inspect(
      sections: (data['sections'] as List).cast<Map<String, Object?>>(),
      requirements: (data['requirements'] as List).cast<Map<String, Object?>>(),
      teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
      subjects: (data['subjects'] as List).cast<Map<String, Object?>>(),
      qualifications: (data['qualifications'] as List).cast<Map<String, Object?>>(),
      teacherGrades: (data['teacherGrades'] as List).cast<Map<String, Object?>>(),
      teacherSubjectGrades: (data['teacherSubjectGrades'] as List).cast<Map<String, Object?>>(),
      days: (data['days'] as List).cast<Map<String, Object?>>(),
      slots: (data['slots'] as List).cast<Map<String, Object?>>(),
      currentEntries: (data['entries'] as List).cast<Map<String, Object?>>(),
      availability: (data['availability'] as List).cast<Map<String, Object?>>(),
      subjectBlockedSlots: (data['subjectBlockedSlots'] as List).cast<Map<String, Object?>>(),
    );
    if (data['yearId'] != null) return result;
    return PreflightResult([
      ...result.findings,
      const PreflightFinding(
        code: 'no_active_year',
        title: 'لا يوجد عام دراسي نشط',
        message: 'لم يتم تحديد عام دراسي نشط لحفظ النسخة الناتجة.',
        recommendation: 'اختر عاماً دراسياً نشطاً من إعدادات المدرسة.',
        blocking: true,
        category: 'الإعدادات',
      ),
    ]);
  }

  Future<bool> _showPreflight(PreflightResult result, {required bool allowContinue}) async {
    if (!mounted) return false;
    final decision = await showDialog<bool>(
      context: context,
      barrierDismissible: !result.findings.any((f) => f.blocking),
      builder: (ctx) => AlertDialog(
        title: const Row(children: [Icon(Icons.fact_check_outlined, color: Color(0xFF2878C8)), SizedBox(width: 8), Expanded(child: Text('الفحص الذكي قبل التوزيع'))]),
        content: SizedBox(
          width: 560,
          child: SingleChildScrollView(child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(spacing: 8, runSpacing: 6, children: [
                Chip(avatar: const Icon(Icons.error_outline, size: 17, color: Colors.red), label: Text('موانع: ${result.blockers}')),
                Chip(avatar: const Icon(Icons.info_outline, size: 17, color: Colors.deepOrange), label: Text('ملاحظات: ${result.warnings}')),
              ]),
              const SizedBox(height: 8),
              Text(result.canStart
                  ? 'انتهى الفحص الأولي. ستُعرض نتيجة التوزيع وحصصه المتبقية قبل أي حفظ.'
                  : 'لا يمكن بدء التوزيع لأن هناك متطلبات أساسية مفقودة. أصلح الموانع أولاً.'),
              if (result.findings.isEmpty) const Padding(padding: EdgeInsets.only(top: 12), child: ListTile(leading: Icon(Icons.check_circle, color: Colors.green), title: Text('لم تُكتشف مشكلات في الإعدادات الأساسية.'), contentPadding: EdgeInsets.zero)),
              ...result.findings.take(18).map((f) => Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: f.blocking ? const Color(0xFFFFECEC) : const Color(0xFFFFF7E8),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: f.blocking ? const Color(0xFFE4A0A0) : const Color(0xFFE8D09B)),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Icon(f.blocking ? Icons.error_outline : Icons.warning_amber_outlined, size: 18, color: f.blocking ? Colors.red : Colors.deepOrange),
                      const SizedBox(width: 6), Expanded(child: Text(f.title, style: const TextStyle(fontWeight: FontWeight.w800))),
                    ]),
                    const SizedBox(height: 4), Text(f.message, style: const TextStyle(fontSize: 12)),
                    const SizedBox(height: 4), Text('الإجراء المقترح: ${f.recommendation}', style: const TextStyle(fontSize: 12, color: Color(0xFF526274))),
                  ]),
                ),
              )),
              if (result.findings.length > 18) Padding(padding: const EdgeInsets.only(top: 8), child: Text('وتوجد ${result.findings.length - 18} ملاحظات إضافية.', style: const TextStyle(color: Colors.black54))),
            ],
          )),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إغلاق')),
          if (allowContinue && result.canStart)
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('متابعة إلى التوزيع')),
        ],
      ),
    );
    return decision == true && result.canStart;
  }

  Future<void> _runPreflightOnly() async {
    try {
      final data = await _loadData();
      final result = _inspectBeforeScheduling(data);
      await _showPreflight(result, allowContinue: false);
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر إكمال الفحص المسبق: $e', error: true);
    }
  }

  Future<Map<String, Object?>?> _chooseSafeMoveAlternative({
    required Map<String, Object?> sourceEntry,
    required Map<String, Object?> section,
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> requirements,
    required List<Map<String, Object?>> teachers,
    required List<Map<String, Object?>> qualifications,
    required List<Map<String, Object?>> teacherGrades,
    required List<Map<String, Object?>> teacherSubjectGrades,
    required List<Map<String, Object?>> subjectBlockedSlots,
    required List<Map<String, Object?>> availability,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
    required List<dynamic> blockers,
  }) async {
    final sectionId = _asInt(section['id']);
    final entryId = _asInt(sourceEntry['id']);
    final teacherId = sourceEntry['teacher_id'] == null ? null : _asInt(sourceEntry['teacher_id']);
    final sectionEntries = entries.where((e) => _asInt(e['section_id']) == sectionId).toList();
    final otherEntries = entries.where((e) => _asInt(e['id']) != entryId).toList();
    final requirementsForSection = requirements.where((r) => _asInt(r['section_id']) == sectionId).toList();
    final weeklyDemand = requirementsForSection.fold<int>(0, (sum, row) => sum + _asInt(row['weekly_lessons']));
    final activeDays = days.where((d) => _asInt(d['is_active'], fallback: 1) == 1).toList();
    final lessonSlots = slots.where((slot) => slot['kind'] == 'lesson' && _asInt(slot['is_available'], fallback: 1) == 1).toList()
      ..sort((a, b) => _asInt(a['position']).compareTo(_asInt(b['position'])));
    final configuredDailyLimit = _asInt(section['max_daily_lessons'], fallback: 6);
    final seventhAllowed = activeDays.isNotEmpty && configuredDailyLimit >= 7 && weeklyDemand > activeDays.length * 6;
    final rankBySlot = <int, int>{for (var i = 0; i < lessonSlots.length; i++) _asInt(lessonSlots[i]['id']): i};
    final blocked = <String>{for (final row in subjectBlockedSlots) '${_asInt(row['subject_id'])}:${_asInt(row['slot_id'])}'};
    final alternatives = <Map<String, Object?>>[];
    const hardIssues = <String>{
      'تعارض المعلم', 'تعارض الشعبة', 'تعارض القاعة', 'تأهيل المعلم',
      'الصف غير مسموح للمعلم', 'تعذر تحديد صف الشعبة', 'فترة غير متاحة',
      'المعلم غير متاح في الفترة', 'المادة في فترة ممنوعة', 'يوم غير مفعل', 'يوم غير معروف', 'فترة غير معروفة', 'متطلبات مكررة', 'عدد حصص مطلوب غير صالح',
    };
    const softRuleTypes = <String>{'تكرار المادة يومياً', 'تجاوز الحد اليومي', 'حصص متتالية زائدة'};
    final scanner = const ConflictDetectionService();
    final baselineIssues = scanner.scan(
      entries: entries, requirements: requirements, sections: [section], slots: slots, teachers: teachers,
      qualifications: qualifications, days: days, teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades, subjectBlockedSlots: subjectBlockedSlots,
      teacherAvailability: availability,
    );
    bool existedBefore(ConflictIssue issue) => baselineIssues.any((before) =>
      before.type == issue.type && before.message == issue.message &&
      before.sectionId == issue.sectionId && before.teacherId == issue.teacherId &&
      before.subjectId == issue.subjectId && before.dayId == issue.dayId);

    for (final day in activeDays) {
      for (final slot in lessonSlots) {
        final dayId = _asInt(day['id']);
        final slotId = _asInt(slot['id']);
        if (dayId == _asInt(sourceEntry['day_id']) && slotId == _asInt(sourceEntry['slot_id'])) continue;
        if (sectionEntries.any((e) => _asInt(e['day_id']) == dayId && _asInt(e['slot_id']) == slotId && _asInt(e['id']) != entryId)) continue;
        final rank = rankBySlot[slotId] ?? 0;
        if (rank > 5 && !(rank == 6 && seventhAllowed)) continue;
        if (rank > 6) continue;
        if (teacherId != null && availability.any((row) =>
          _asInt(row['teacher_id']) == teacherId && _asInt(row['day_id']) == dayId &&
          _asInt(row['slot_id']) == slotId && _asInt(row['is_available'], fallback: 1) == 0)) continue;
        if (blocked.contains('${_asInt(sourceEntry['subject_id'])}:$slotId')) continue;

        final candidate = Map<String, Object?>.from(sourceEntry)
          ..['day_id'] = dayId
          ..['slot_id'] = slotId;
        final prospective = [...otherEntries, candidate];
        final issues = scanner.scan(
          entries: prospective,
          requirements: requirements,
          sections: [section],
          slots: slots,
          teachers: teachers,
          qualifications: qualifications,
          days: days,
          teacherGrades: teacherGrades,
          teacherSubjectGrades: teacherSubjectGrades,
          subjectBlockedSlots: subjectBlockedSlots,
          teacherAvailability: availability,
        );
        final hasBlockingIssue = issues.any((issue) =>
          issue.dayId == dayId &&
          (issue.sectionId == sectionId || (teacherId != null && issue.teacherId == teacherId)) &&
          ((issue.severity == 'خطأ مانع' && hardIssues.contains(issue.type) && issue.slotId == slotId) ||
           (softRuleTypes.contains(issue.type) && !existedBefore(issue))));
        if (!hasBlockingIssue) {
          alternatives.add({'day': day, 'slot': slot, 'day_id': dayId, 'slot_id': slotId});
        }
      }
    }

    if (!mounted) return null;
    final chosen = await showDialog<Map<String, Object?>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تعذر نقل الحصة إلى هذه الخلية'),
        content: SizedBox(
          width: 460,
          child: SingleChildScrollView(child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('أسباب رفض النقل:', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              ...blockers.take(4).map((issue) => Padding(
                padding: const EdgeInsets.only(bottom: 7),
                child: Text('• ${issue.type}: ${issue.message}', style: const TextStyle(fontSize: 12)),
              )),
              const Divider(),
              Text(alternatives.isEmpty
                ? 'لم أعثر على خلية بديلة آمنة للحصة. راجع صلاحية المعلم والفترات المتاحة ثم أعد المحاولة.'
                : 'هذه خلايا بديلة اجتازت فحص التعارضات. اختر واحدة لنقل الحصة إليها:',
                style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              ...alternatives.take(12).map((alternative) {
                final d = alternative['day'] as Map<String, Object?>;
                final sl = alternative['slot'] as Map<String, Object?>;
                return ListTile(
                  dense: true,
                  leading: const Icon(Icons.check_circle_outline, color: Colors.green),
                  title: Text('${d['name']} — ${sl['name']}'),
                  subtitle: Text('${sl['start_time'] ?? ''}–${sl['end_time'] ?? ''}'),
                  onTap: () => Navigator.pop(ctx, alternative),
                );
              }),
            ],
          )),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء'))],
      ),
    );
    return chosen;
  }

  Future<void> _moveEntryToCell({
    required Map<String, Object?> source,
    required Map<String, Object?> section,
    required Map<String, Object?> day,
    required Map<String, Object?> slot,
    required List<Map<String, Object?>> allDays,
    required List<Map<String, Object?>> allSlots,
  }) async {
    final sectionId = _asInt(section['id']);
    final sourceDayId = _asInt(source['day_id']);
    final sourceSlotId = _asInt(source['slot_id']);
    final targetDayId = _asInt(day['id']);
    final targetSlotId = _asInt(slot['id']);
    if (sourceDayId == targetDayId && sourceSlotId == targetSlotId) return;
    try {
      final data = await _loadData();
      final entries = (data['entries'] as List).cast<Map<String, Object?>>();
      final sourceMatches = entries.where((e) => _asInt(e['section_id']) == sectionId &&
          _asInt(e['day_id']) == sourceDayId && _asInt(e['slot_id']) == sourceSlotId).toList();
      if (sourceMatches.isEmpty) throw StateError('لم تعد الحصة المصدر موجودة في النسخة الحالية. حدّث الجدول وحاول مجدداً.');
      final sourceEntry = sourceMatches.first;
      final targetSlotMatches = allSlots.where((s) => _asInt(s['id']) == targetSlotId).toList();
      final targetSlot = targetSlotMatches.isEmpty ? null : targetSlotMatches.first;
      if (targetSlot == null || targetSlot['kind'] != 'lesson' || _asInt(targetSlot['is_available'], fallback: 1) == 0) {
        throw StateError('الفترة المستهدفة ليست فترة تدريس متاحة.');
      }
      final occupied = entries.any((e) => _asInt(e['section_id']) == sectionId &&
          _asInt(e['day_id']) == targetDayId && _asInt(e['slot_id']) == targetSlotId);
      if (occupied) throw StateError('الخلية المستهدفة مشغولة. انقل الحصة إلى خلية فارغة أولاً؛ لا يتم استبدال الحصص تلقائياً.');
      final candidate = Map<String, Object?>.from(sourceEntry)
        ..['day_id'] = targetDayId
        ..['slot_id'] = targetSlotId;
      final prospective = entries.where((e) => _asInt(e['id']) != _asInt(sourceEntry['id'])).toList()..add(candidate);
      final requirementsForScan = (data['requirements'] as List).cast<Map<String, Object?>>();
      final teachersForScan = (data['teachers'] as List).cast<Map<String, Object?>>();
      final qualificationsForScan = (data['qualifications'] as List).cast<Map<String, Object?>>();
      final teacherGradesForScan = (data['teacherGrades'] as List).cast<Map<String, Object?>>();
      final teacherSubjectGradesForScan = (data['teacherSubjectGrades'] as List).cast<Map<String, Object?>>();
      final blockedSlotsForScan = (data['subjectBlockedSlots'] as List).cast<Map<String, Object?>>();
      final scanner = const ConflictDetectionService();
      final scanIssues = scanner.scan(
        entries: prospective, requirements: requirementsForScan, sections: (data['sections'] as List).cast<Map<String, Object?>>(), slots: allSlots,
        teachers: teachersForScan, qualifications: qualificationsForScan, days: allDays,
        teacherGrades: teacherGradesForScan, teacherSubjectGrades: teacherSubjectGradesForScan,
        subjectBlockedSlots: blockedSlotsForScan,
        teacherAvailability: (data['availability'] as List).cast<Map<String, Object?>>(),
      );
      final baselineIssues = scanner.scan(
        entries: entries, requirements: requirementsForScan, sections: (data['sections'] as List).cast<Map<String, Object?>>(), slots: allSlots,
        teachers: teachersForScan, qualifications: qualificationsForScan, days: allDays,
        teacherGrades: teacherGradesForScan, teacherSubjectGrades: teacherSubjectGradesForScan,
        subjectBlockedSlots: blockedSlotsForScan,
        teacherAvailability: (data['availability'] as List).cast<Map<String, Object?>>(),
      );
      final teacherId = sourceEntry['teacher_id'] == null ? null : _asInt(sourceEntry['teacher_id']);
      const hardIssueTypes = {
        'تعارض المعلم', 'تعارض الشعبة', 'تعارض القاعة', 'تأهيل المعلم',
        'الصف غير مسموح للمعلم', 'تعذر تحديد صف الشعبة', 'فترة غير متاحة',
        'المعلم غير متاح في الفترة', 'المادة في فترة ممنوعة', 'يوم غير مفعل', 'يوم غير معروف', 'فترة غير معروفة', 'متطلبات مكررة', 'عدد حصص مطلوب غير صالح',
      };
      const softRuleTypes = {'تكرار المادة يومياً', 'تجاوز الحد اليومي', 'حصص متتالية زائدة'};
      bool relatedOnTargetDay(ConflictIssue issue) => issue.dayId == targetDayId &&
        (issue.sectionId == sectionId || (teacherId != null && issue.teacherId == teacherId));
      bool existedBefore(ConflictIssue issue) => baselineIssues.any((before) =>
        before.type == issue.type && before.message == issue.message &&
        before.sectionId == issue.sectionId && before.teacherId == issue.teacherId &&
        before.subjectId == issue.subjectId && before.dayId == issue.dayId);
      final blockers = scanIssues.where((issue) => relatedOnTargetDay(issue) && (
        (issue.severity == 'خطأ مانع' && issue.slotId == targetSlotId && hardIssueTypes.contains(issue.type)) ||
        (softRuleTypes.contains(issue.type) && !existedBefore(issue))
      )).toList();
      if (blockers.isNotEmpty) {
        final alternative = await _chooseSafeMoveAlternative(
          sourceEntry: sourceEntry,
          section: section,
          entries: entries,
          requirements: (data['requirements'] as List).cast<Map<String, Object?>>(),
          teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
          qualifications: (data['qualifications'] as List).cast<Map<String, Object?>>(),
          teacherGrades: (data['teacherGrades'] as List).cast<Map<String, Object?>>(),
          teacherSubjectGrades: (data['teacherSubjectGrades'] as List).cast<Map<String, Object?>>(),
          subjectBlockedSlots: (data['subjectBlockedSlots'] as List).cast<Map<String, Object?>>(),
          availability: (data['availability'] as List).cast<Map<String, Object?>>(),
          days: allDays,
          slots: allSlots,
          blockers: blockers,
        );
        if (alternative == null || !mounted) return;
        await _moveEntryToCell(
          source: sourceEntry,
          section: section,
          day: alternative['day'] as Map<String, Object?>,
          slot: alternative['slot'] as Map<String, Object?>,
          allDays: allDays,
          allSlots: allSlots,
        );
        return;
      }
      final yearId = data['yearId'] as int?;
      if (yearId == null) throw StateError('لا يوجد عام دراسي نشط.');
      final versionId = await DatabaseService.instance.ensureEditableActiveVersion(yearId);
      if (versionId == null) throw StateError('لا توجد نسخة عمل قابلة للتعديل.');
      final db = await DatabaseService.instance.database;
      final actual = await db.query('timetable_entries', where: 'version_id=? AND section_id=? AND day_id=? AND slot_id=?',
          whereArgs: [versionId, sectionId, sourceDayId, sourceSlotId], limit: 1);
      if (actual.isEmpty) throw StateError('تعذر العثور على الحصة في نسخة العمل بعد التحقق. لم يُنفّذ النقل.');
      await DatabaseService.instance.saveEntry({'day_id': targetDayId, 'slot_id': targetSlotId, 'version_id': versionId}, entryId: _asInt(actual.first['id']));
      if (mounted) {
        showMessage(context, 'نُقلت الحصة إلى ${day['name']}، ${slot['name']} بعد فحص التعارضات.');
        setState(_reload);
        widget.onChanged();
      }
    } catch (e) {
      if (mounted) showMessage(context, 'لم يتم نقل الحصة: $e', error: true);
    }
  }

  Future<void> _generateAutomatically() async {
    if (_isGenerating) return;
    setState(() => _isGenerating = true);
    try {
      final data = await _loadData();
      final preflight = _inspectBeforeScheduling(data);
      final continueAfterPreflight = await _showPreflight(preflight, allowContinue: true);
      if (!continueAfterPreflight) return;
      final yearId = data['yearId'] as int?;
      if (yearId == null) throw StateError('أنشئ عاماً دراسياً نشطاً أولاً.');
      // الجدولة التلقائية تخص المدرسة كلها دائماً، ولا تتأثر بمرشح العرض الذي قد يعرض شعبة واحدة.
      final allSections = (data['sections'] as List).cast<Map<String, Object?>>();
      final allRequirements = (data['requirements'] as List).cast<Map<String, Object?>>();
      if (allSections.isEmpty || allRequirements.isEmpty) throw StateError('أضف الشعب وحدد الحصص الأسبوعية المطلوبة لكل مادة قبل بدء الجدولة.');
      final generated = await compute(_generateScheduleInBackground, <String, Object?>{
        'sections': allSections,
        'requirements': allRequirements,
        'teachers': (data['teachers'] as List).cast<Map<String, Object?>>(),
        'qualifications': (data['qualifications'] as List).cast<Map<String, Object?>>(),
        'teacherGrades': (data['teacherGrades'] as List).cast<Map<String, Object?>>(),
        'teacherSubjectGrades': (data['teacherSubjectGrades'] as List).cast<Map<String, Object?>>(),
        'subjectBlockedSlots': (data['subjectBlockedSlots'] as List).cast<Map<String, Object?>>(),
        'days': (data['days'] as List).cast<Map<String, Object?>>(),
        'slots': (data['slots'] as List).cast<Map<String, Object?>>(),
        'availability': (data['availability'] as List).cast<Map<String, Object?>>(),
      });
      final result = SchedulerResult(
        placements: _schedulerMapList(generated['placements']),
        unscheduled: (generated['unscheduled'] as List).cast<String>(),
        requestedCount: generated['requestedCount'] as int,
        exploredNodes: generated['exploredNodes'] as int,
        searchLimitReached: generated['searchLimitReached'] as bool,
      );
      // لا نثق بنتيجة محرك التوزيع وحدها: نفحص كل الحصص المراد حفظها
      // بمحرك التعارضات نفسه قبل عرض خيار الحفظ، ونمنع حفظ أي إسناد مخالف.
      final generatedIssues = const ConflictDetectionService().scan(
        entries: result.placements,
        requirements: allRequirements,
        sections: allSections,
        slots: (data['slots'] as List).cast<Map<String, Object?>>(),
        teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
        qualifications: (data['qualifications'] as List).cast<Map<String, Object?>>(),
        days: (data['days'] as List).cast<Map<String, Object?>>(),
        teacherGrades: (data['teacherGrades'] as List).cast<Map<String, Object?>>(),
        teacherSubjectGrades: (data['teacherSubjectGrades'] as List).cast<Map<String, Object?>>(),
        subjectBlockedSlots: (data['subjectBlockedSlots'] as List).cast<Map<String, Object?>>(),
        teacherAvailability: (data['availability'] as List).cast<Map<String, Object?>>(),
        enforceQualifications: true,
      );
      // لا تستخدم قائمة جزئية لأن أنواعاً جديدة من الأخطاء المانعة قد تُضاف
      // لاحقاً إلى الفاحص. يجب ألا تمر أي نتيجة موسومة «خطأ مانع» إلى النسخة
      // المحفوظة، بما في ذلك تداخل أوقات الفترات أو تجاوز سياسة الحصة السابعة.
      final assignmentBlockers = generatedIssues
          .where((issue) => issue.severity == 'خطأ مانع')
          .toList();
      if (assignmentBlockers.isNotEmpty) {
        final details = assignmentBlockers.take(8).map((issue) => '• ${issue.type}: ${issue.message}').join('\n');
        throw StateError('أوقف الحفظ لأن الفحص النهائي اكتشف تعارضات في التوزيع الآلي:\n$details');
      }
      if (!mounted) return;
      final fairnessNotes = generatedIssues
          .where((issue) => issue.type == 'تكرار توقيت المادة في أيام متتالية')
          .toList();
      final approve = await showDialog<bool>(context: context, barrierDismissible: false, builder: (ctx) => AlertDialog(
        title: Text(result.complete ? 'نتيجة الجدولة مكتملة' : 'نتيجة جزئية — تحتاج مراجعة'),
        content: SizedBox(width: 460, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: _ResultMetric(label: 'المطلوب', value: '${result.requestedCount}')), Expanded(child: _ResultMetric(label: 'الموزع', value: '${result.placements.length}')), Expanded(child: _ResultMetric(label: 'المتبقي', value: '${result.requestedCount - result.placements.length}'))]),
          const SizedBox(height: 10), Text('عُقد البحث المفحوصة: ${result.exploredNodes}${result.searchLimitReached ? ' (وصل البحث إلى الحد المحدد)' : ''}'),
          if (fairnessNotes.isNotEmpty) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: const Color(0xFFFFF4DF), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE9C16A))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [const Icon(Icons.balance_rounded, color: Color(0xFF9A6500), size: 18), const SizedBox(width: 6), Expanded(child: Text('ملاحظات عدالة التوزيع: ${fairnessNotes.length}', style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF805400))))]),
                const SizedBox(height: 4),
                const Text('هذه ليست تعارضات مانعة؛ تعني أن المادة ظهرت في الفترة نفسها بيومين متتاليين. حاول المحرك تقليلها، لكن قد تبقى عندما تمنع القيود الأخرى البدائل.', style: TextStyle(fontSize: 11, color: Color(0xFF805400))),
                ...fairnessNotes.take(4).map((issue) => Padding(padding: const EdgeInsets.only(top: 4), child: Text('• ${issue.message}', style: const TextStyle(fontSize: 11, color: Color(0xFF805400))))),
                if (fairnessNotes.length > 4) Text('... و${fairnessNotes.length - 4} ملاحظات أخرى', style: const TextStyle(fontSize: 11, color: Color(0xFF805400))),
              ]),
            ),
          ],
          const SizedBox(height: 10), Text('يُسند التطبيق المعلمين تلقائياً وفق الاختصاصات والصفوف والنصاب والإتاحة. ويقارن محرك التوزيع حلولاً متعددة ضمن حد البحث لتحسين عدالة توزيع المواد والفترات، مع أولوية مطلقة للقيود المانعة. الجدولة تشمل جميع شعب المدرسة ولا تتأثر بمرشح العرض.'),
          const SizedBox(height: 8), Text(result.complete ? 'تم إسناد جميع الحصص إلى معلمين مؤهلين دون تعارضات مبدئية. يمكنك حفظ الجدول الكامل كنسخة جديدة.' : 'لم يكتمل الجدول. راجع الأسباب أدناه؛ قد يكون مجموع حصص الشعبة أكبر من عدد الفترات المتاحة، أو لم يُسجّل معلم ضمن اختصاص المادة، أو توجد قيود نصاب/إتاحة. لن تتغير النسخة الحالية إلا إذا اخترت صراحة حفظ التوزيع المتاح كمسودة.'),
          if (result.unscheduled.isNotEmpty) ...[
            const SizedBox(height: 12), const Text('الحصص غير الموزعة والأسباب', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.deepOrange)),
            ...result.unscheduled.take(12).map((reason) => Padding(padding: const EdgeInsets.only(top: 6), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.warning_amber, size: 18, color: Colors.deepOrange), const SizedBox(width: 6), Expanded(child: Text(reason, style: const TextStyle(fontSize: 12)))]))),
            if (result.unscheduled.length > 12) Text('... و${result.unscheduled.length - 12} حالات أخرى'),
          ],
        ]))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إغلاق دون حفظ')),
          if (result.complete)
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ الجدول الكامل'))
          else if (result.placements.isNotEmpty)
            FilledButton.tonal(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ المتاح كمسودة ناقصة')),
        ],
      ));
      if (approve == true) {
        final activeYear = (data['year'] as Map)['name']?.toString() ?? 'العام';
        final isComplete = result.complete;
        final newId = await DatabaseService.instance.saveAsNewVersion(
          yearId: yearId,
          name: '${isComplete ? 'الجدول الأسبوعي التلقائي' : 'توزيع جزئي غير مكتمل'} ${DateTime.now().toString().substring(0, 16)}',
          entries: result.placements,
          notes: isComplete
              ? 'جدول كامل لجميع الشعب مولد آلياً للعام $activeYear؛ عقد البحث ${result.exploredNodes}.'
              : 'توزيع آلي جزئي للعام $activeYear: وُزعت ${result.placements.length} من ${result.requestedCount} حصة. يجب مراجعة الحصص المتبقية قبل الاعتماد.',
        );
        if (mounted) showMessage(context, isComplete
            ? 'تم حفظ الجدول الكامل في النسخة رقم $newId، مع الاحتفاظ بالنسخة السابقة.'
            : 'تم حفظ التوزيع الجزئي في النسخة رقم $newId كمسودة غير مكتملة. راجع فحص التعارضات وأكمل الحصص المتبقية.',
          error: !isComplete);
        setState(_reload); widget.onChanged();
      }
    } catch (e) {
      if (mounted) showMessage(context, '$e', error: true);
    } finally {
      if (mounted) setState(() => _isGenerating = false);
    }
  }
}

class _TeacherStatChip extends StatelessWidget {
  const _TeacherStatChip({required this.icon, required this.label, required this.color});
  final IconData icon;
  final String label;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
    decoration: BoxDecoration(color: color.withOpacity(.10), borderRadius: BorderRadius.circular(11), border: Border.all(color: color.withOpacity(.22))),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 15, color: color), const SizedBox(width: 5),
      Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: color)),
    ]),
  );
}

class _ResultMetric extends StatelessWidget {
  const _ResultMetric({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Column(children: [Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Color(0xFF183B66))), Text(label, style: const TextStyle(color: Colors.black54, fontSize: 12))]);
}
