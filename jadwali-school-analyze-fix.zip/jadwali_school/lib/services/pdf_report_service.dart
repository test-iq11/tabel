import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf_text_shaper/pdf_text_shaper.dart';
import 'package:printing/printing.dart';

/// يصدّر شبكة الجدول الأسبوعي لجميع الشعب إلى PDF أفقي قابل للطباعة.
class PdfReportService {
  Future<ShapedFont> _arabicFont() async {
    final data = await rootBundle.load('assets/fonts/Arabic-Regular.ttf');
    return ShapedFont.fromBytes(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      name: 'Noto Naskh Arabic',
    );
  }

  pw.Widget _text(
    String value, {
    required ShapedFont font,
    double size = 10,
    PdfColor color = PdfColors.black,
    ShapedTextAlign align = ShapedTextAlign.center,
  }) => ShapedText(
    value,
    style: ShapedTextStyle(
      font: font,
      fontSize: size,
      color: color,
      direction: ShapedTextDirection.rightToLeft,
      align: align,
      preserveUnicodeText: true,
    ),
  );

  Future<Uint8List> buildTimetablePdf({
    required String schoolName,
    required String academicYear,
    required String versionName,
    required String status,
    required List<Map<String, Object?>> entries,
    List<Map<String, Object?>> sections = const [],
    List<Map<String, Object?>> days = const [],
    List<Map<String, Object?>> slots = const [],
    PdfPageFormat? pageFormat,
    String title = 'الجدول الأسبوعي الشامل لجميع الصفوف والشعب',
  }) async {
    final font = await _arabicFont();
    try {
    final pdf = pw.Document();
    final format = pageFormat ?? PdfPageFormat.a3.landscape;

    final orderedDays = days.where((d) => _int(d['is_active'], fallback: 1) == 1).toList()
      ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));
    final orderedSlots = slots.where((s) => s['kind'] == 'lesson' && _int(s['is_available'], fallback: 1) == 1).toList()
      ..sort((a, b) => _int(a['position']).compareTo(_int(b['position'])));

    final orderedEntries = [...entries]..sort((a, b) {
      final section = '${a['grade_name'] ?? ''} ${a['section_name'] ?? ''}'.compareTo('${b['grade_name'] ?? ''} ${b['section_name'] ?? ''}');
      if (section != 0) return section;
      final day = _int(a['day_position']).compareTo(_int(b['day_position']));
      if (day != 0) return day;
      return _int(a['slot_position']).compareTo(_int(b['slot_position']));
    });

    final reportSections = <Map<String, Object?>>[];
    if (sections.isNotEmpty) {
      reportSections.addAll(sections);
    } else {
      final seen = <int>{};
      for (final entry in orderedEntries) {
        final id = _int(entry['section_id']);
        if (seen.add(id)) {
          reportSections.add({
            'id': id,
            'grade_name': entry['grade_name'] ?? '',
            'section_name': entry['section_name'] ?? 'الشعبة $id',
          });
        }
      }
    }
    // يحافظ على ترتيب الصفوف القادم من قاعدة البيانات (المرحلة ثم الصف ثم الشعبة).

    final entryByCell = <String, Map<String, Object?>>{};
    for (final entry in orderedEntries) {
      entryByCell['${_int(entry['section_id'])}:${_int(entry['day_id'])}:${_int(entry['slot_id'])}'] = entry;
    }

    pw.Widget cell(String text, {bool header = false, bool filled = false, bool period = false}) {
      final PdfColor background = header
          ? const PdfColor.fromInt(0xFF183B66)
          : filled
              ? const PdfColor.fromInt(0xFFE7F1FC)
              : period
                  ? const PdfColor.fromInt(0xFFF0F3F7)
                  : const PdfColor.fromInt(0xFFFAFBFD);
      final PdfColor foreground = header ? PdfColors.white : const PdfColor.fromInt(0xFF23354B);
      return pw.Container(
        alignment: pw.Alignment.center,
        padding: const pw.EdgeInsets.symmetric(horizontal: 3, vertical: 4),
        decoration: pw.BoxDecoration(color: background),
        child: _text(
          text,
          font: font,
          size: header ? 11 : (period ? 10 : 9),
          color: foreground,
        ),
      );
    }

    final children = <pw.Widget>[];
    if (reportSections.isEmpty) {
      children.add(pw.Padding(
        padding: const pw.EdgeInsets.all(18),
        child: _text('لا توجد شعب أو جداول للطباعة. أضف الصفوف والشعب ثم أنشئ الجدول الأسبوعي.', font: font, size: 14),
      ));
    } else if (orderedDays.isEmpty || orderedSlots.isEmpty) {
      children.add(pw.Padding(
        padding: const pw.EdgeInsets.all(18),
        child: _text('لا توجد أيام دوام أو حصص متاحة للطباعة. راجع إعدادات أيام المدرسة وأوقات الحصص.', font: font, size: 14),
      ));
    } else {
      for (final section in reportSections) {
        final sectionId = _int(section['id']);
        final label = '${section['grade_name'] ?? ''} - ${section['section_name'] ?? 'الشعبة $sectionId'}'.replaceAll(RegExp(r'^\s*-\s*'), '').trim();
        final widths = <int, pw.TableColumnWidth>{
          0: const pw.FlexColumnWidth(1.25),
          for (var i = 1; i <= orderedDays.length; i++) i: const pw.FlexColumnWidth(1.0),
        };
        final tableRows = <pw.TableRow>[
          pw.TableRow(children: [
            cell('الفترة / الوقت', header: true),
            ...orderedDays.reversed.map((day) => cell('${day['name'] ?? ''}', header: true)),
          ]),
          ...orderedSlots.map((slot) => pw.TableRow(children: [
            cell('${slot['name'] ?? ''}\n${slot['start_time'] ?? ''} - ${slot['end_time'] ?? ''}', period: true),
            ...orderedDays.reversed.map((day) {
              final entry = entryByCell['$sectionId:${_int(day['id'])}:${_int(slot['id'])}'];
              if (entry == null) return cell('—');
              final subject = entry['subject_name']?.toString() ?? 'مادة';
              final teacher = entry['teacher_name']?.toString().trim();
              final text = teacher == null || teacher.isEmpty ? '$subject\nغير مسند' : '$subject\n$teacher';
              return cell(text, filled: true);
            }),
          ])),
        ];
        children.add(pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            pw.Container(
              padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 5),
              decoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFFDCE9F8)),
              child: _text(label, font: font, size: 13, color: const PdfColor.fromInt(0xFF183B66)),
            ),
            pw.Table(
              columnWidths: widths,
              border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.45),
              defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
              children: tableRows,
            ),
            pw.SizedBox(height: 9),
          ],
        ));
      }
    }

    pdf.addPage(pw.MultiPage(
      pageFormat: format,
      maxPages: 500,
      margin: const pw.EdgeInsets.all(18),
      header: (context) => pw.Column(children: [
        _text(schoolName, font: font, size: 18, color: const PdfColor.fromInt(0xFF183B66)),
        pw.SizedBox(height: 3),
        _text(title, font: font, size: 13, color: const PdfColor.fromInt(0xFF23354B)),
        _text('العام الدراسي: $academicYear  |  النسخة: $versionName  |  الحالة: $status  |  اتجاه الصفحة: أفقي', font: font, size: 10),
        pw.Divider(),
      ]),
      footer: (context) => pw.Align(
        alignment: pw.Alignment.centerLeft,
        child: _text(
          'تاريخ التقرير: ${DateTime.now().toIso8601String().split('T').first}  •  صفحة ${context.pageNumber} من ${context.pagesCount}',
          font: font, size: 8,
        ),
      ),
      build: (context) => children,
    ));
    final output = await pdf.save();
    return output;
    } finally {
      font.dispose();
    }
  }

  Future<String?> savePdf(Uint8List bytes, {String fileName = 'الجدول-المدرسي.pdf'}) async {
    return FilePicker.platform.saveFile(
      dialogTitle: 'حفظ تقرير PDF',
      fileName: fileName,
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      bytes: bytes,
    );
  }

  Future<void> preview(Uint8List bytes) async {
    await Printing.layoutPdf(onLayout: (_) async => bytes);
  }

  int _int(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
